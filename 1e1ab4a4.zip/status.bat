@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\8127\1e1ab4a4
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8127-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=help.txt
SET rgnpbq=8127

REM Random names for internal use
SET hgpwsa=%APPDATA%\!fkesh!\macula-simulations.log
SET jkhgfd=%APPDATA%\!fkesh!
SET xcvbnh=1
SET poiuyt=
SET lkjhgf=T1218.010
SET mnbvcx=Signed Binary Proxy Execution: Regsvr32

REM Create log directory if it doesn't exist
if not exist "!jkhgfd!" mkdir "!jkhgfd!" >nul 2>&1

REM Heartbeat check
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_start=!frytcn!>> "!hgpwsa!" 2>nul
curl -k -s -o nul !frytcn!
if !ERRORLEVEL! NEQ 0 (
    SET poiuyt=heartbeat_failed_!ERRORLEVEL!
    SET xcvbnh=0
)
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_end=!ERRORLEVEL!>> "!hgpwsa!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: chdir_start=!douyiw!>> "!hgpwsa!" 2>nul
cd /d "!douyiw!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: chdir_end=!CD!>> "!hgpwsa!" 2>nul

REM Execute DLL via Regsvr32
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: process_start=Regsvr32.exe /s "!ecrfwq!">> "!hgpwsa!" 2>nul
%WINDIR%\System32\regsvr32.exe /s "!ecrfwq!"
if !ERRORLEVEL! NEQ 0 (
    IF "!poiuyt!"=="" SET poiuyt=regsvr32_failed_!ERRORLEVEL!
    SET xcvbnh=0
)
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: process_end=!ERRORLEVEL!>> "!hgpwsa!" 2>nul

REM TTP logging
for /f "skip=1 tokens=*" %%a in ('wmic os get localdatetime') do if not defined udgrtn set udgrtn=%%a
for /f "tokens=1,2 delims=." %%a in ("!udgrtn!") do set dt=%%a&set frac=%%b
set vbnjkl=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!frac:~0,3!
>> "!hgpwsa!" 2>nul echo [!vbnjkl!][!eykalkg!]: !fkesh!-!rgnpbq!-!lkjhgf!^|!mnbvcx!=!xcvbnh!:!poiuyt! || echo >nul
ENDLOCAL